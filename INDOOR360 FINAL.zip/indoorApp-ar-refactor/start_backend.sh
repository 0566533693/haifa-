#!/bin/bash
# Indoor360 Backend Startup Script
# This script activates the Python 3.12 virtual environment and starts the FastAPI backend

# Activate the virtual environment from home directory
source ~/indoor360_venv/bin/activate

# Navigate to backend directory
cd "$(dirname "$0")/backend"

# Set PYTHONPATH to include the backend directory
export PYTHONPATH=$(pwd)

# Start the uvicorn server
echo "Starting Indoor360 Backend on http://0.0.0.0:8000"
echo "API Documentation: http://localhost:8000/docs"
echo ""

python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
