import UIKit
import MapKit

// MARK: - Overlay carrying the path and style (fixed screen-point dots)
final class RouteDotsOverlay: NSObject, MKOverlay {
    let coords: [CLLocationCoordinate2D]
    let dotRadius: CGFloat        // in screen points
    let spacing: CGFloat          // center-to-center spacing in points
    let color: UIColor

    private let _bounding: MKMapRect
    var coordinate: CLLocationCoordinate2D { coords.first ?? kCLLocationCoordinate2DInvalid }
    var boundingMapRect: MKMapRect { _bounding }

    init(coords: [CLLocationCoordinate2D], dotRadius: CGFloat = 4, spacing: CGFloat = 12, color: UIColor = .systemBlue) {
        self.coords = coords
        self.dotRadius = dotRadius
        self.spacing = spacing
        self.color = color

        // Conservative bounding rect: include all vertices
        var rect = MKMapRect.null
        for c in coords {
            let p = MKMapPoint(c)
            let r = MKMapRect(x: p.x, y: p.y, width: 0.1, height: 0.1)
            rect = rect.isNull ? r : rect.union(r)
        }
        self._bounding = rect
        super.init()
    }
}

// MARK: - Renderer that draws dots in view space (constant on-screen size)
final class RouteDotsRenderer: MKOverlayRenderer {
    private var dots: RouteDotsOverlay { overlay as! RouteDotsOverlay }

    override func draw(_ mapRect: MKMapRect, zoomScale: MKZoomScale, in ctx: CGContext) {
        let coords = dots.coords
        guard coords.count >= 2 else { return }

        ctx.saveGState()
        defer { ctx.restoreGState() }
        ctx.setFillColor(dots.color.cgColor)

        // Project to screen points
        let pts: [CGPoint] = coords.map { point(for: MKMapPoint($0)) }

        let spacing = max(1, dots.spacing)
        let r = max(0.5, dots.dotRadius)

        // Always draw a dot at the start (like Apple Maps)
        if let first = pts.first {
            ctx.fillEllipse(in: CGRect(x: first.x - r, y: first.y - r, width: 2*r, height: 2*r))
        }

        // Accumulate distance along the whole path, place a dot every spacing pts
        var carried: CGFloat = 0  // distance since last dot
        for i in 0..<(pts.count - 1) {
            var a = pts[i]
            let b = pts[i+1]
            var segLen = hypot(b.x - a.x, b.y - a.y)
            if segLen == 0 { continue }

            // Unit direction from a -> b
            let ux = (b.x - a.x) / segLen
            let uy = (b.y - a.y) / segLen

            // Place as many dots as fit on this segment, honoring carry from previous segments
            while carried + segLen >= spacing {
                let need = spacing - carried
                // Advance from 'a' by need
                let cx = a.x + ux * need
                let cy = a.y + uy * need
                ctx.fillEllipse(in: CGRect(x: cx - r, y: cy - r, width: 2*r, height: 2*r))

                // Update segment cursor and bookkeeping
                a = CGPoint(x: cx, y: cy)
                segLen -= need
                carried = 0
            }

            // Whatever distance left on this segment contributes to the next dot
            carried += segLen
        }
    }
}
