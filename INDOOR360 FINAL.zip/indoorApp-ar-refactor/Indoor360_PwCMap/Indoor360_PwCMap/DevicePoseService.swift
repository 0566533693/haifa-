import Foundation
import CoreMotion

enum NavMode: String {
    case ar
    case map2d
}

/// Publishes device pitch and a nav mode with hysteresis so it won’t flap.
final class DevicePoseService: ObservableObject {
    @Published private(set) var pitchDeg: Double = 0        // -90 (flat, face up) ... +90 (flat, face down)
    @Published private(set) var navMode: NavMode = .map2d    // default to map2d

    private let motion = CMMotionManager()
    private let queue  = OperationQueue()
    private var current: NavMode = .map2d

    // Hysteresis thresholds (tune as needed):
    // - Switch to AR if pitch <= -55° (phone upright-ish).
    // - Switch to 2D if pitch >= -35° (phone flattening).
    // This 20° gap prevents oscillation.
    private let toAR_ThresholdDeg: Double  = -55
    private let to2D_ThresholdDeg: Double = -35

    func start() {
        guard motion.isDeviceMotionAvailable else { return }
        motion.deviceMotionUpdateInterval = 1.0 / 30.0 // 30 Hz, light
        motion.startDeviceMotionUpdates(using: .xArbitraryCorrectedZVertical, to: queue) { [weak self] dm, _ in
            guard let self = self, let dm = dm else { return }
            // Pitch: rotation around device’s x-axis. Using z-vertical gives a stable gravity ref.
            // Convert to degrees and clamp to [-90, +90] range for intuition.
            let pitch = dm.attitude.pitch * 180.0 / .pi
            let clamped = max(-90.0, min(90.0, pitch))

            DispatchQueue.main.async {
                self.pitchDeg = clamped
                self.updateModeIfNeeded(pitchDeg: clamped)
            }
        }
    }

    func stop() {
        motion.stopDeviceMotionUpdates()
    }

    private func updateModeIfNeeded(pitchDeg: Double) {
        switch current {
        case .map2d:
            if pitchDeg <= toAR_ThresholdDeg {
                current = .ar
                navMode = .ar
                print("[DevicePose] mode -> AR (pitch=\(Int(pitchDeg))°)")
            }
        case .ar:
            if pitchDeg >= to2D_ThresholdDeg {
                current = .map2d
                navMode = .map2d
                print("[DevicePose] mode -> Map2D (pitch=\(Int(pitchDeg))°)")
            }
        }
    }
}
