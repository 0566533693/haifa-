import Foundation
import ARKit

struct ARDisplacementSample {
    let east: Double   // meters (+east)
    let north: Double  // meters (+north)
    let timestamp: TimeInterval
}

final class ARPrecisionService: NSObject, ObservableObject, ARSessionDelegate {
    @Published private(set) var sample: ARDisplacementSample?

    private let session = ARSession()
    private var originTransform: simd_float4x4?
    private var emaEast: Double = 0
    private var emaNorth: Double = 0
    private var hasEMA = false
    private let alpha = 0.25     // smoothing

    private(set) var isRunning = false

    func start() {
        guard ARWorldTrackingConfiguration.isSupported else {
            print("[ARPrecision] ARWorldTracking not supported"); return
        }
        let cfg = ARWorldTrackingConfiguration()
        cfg.worldAlignment = .gravityAndHeading
        cfg.environmentTexturing = .none

        session.delegate = self
        session.run(cfg, options: [.resetTracking, .removeExistingAnchors])
        originTransform = nil
        isRunning = true
        print("[ARPrecision] start")
    }

    func stop() {
        session.pause()
        isRunning = false
        sample = nil
        originTransform = nil
        hasEMA = false
        print("[ARPrecision] stop")
    }

    func reset() {
        originTransform = nil
        hasEMA = false
        sample = nil
        print("[ARPrecision] reset")
    }

    // MARK: ARSessionDelegate

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        // Build origin on first good frame
        if originTransform == nil {
            originTransform = frame.camera.transform
            return
        }
        guard let origin = originTransform else { return }

        // Delta transform in world (gravity+heading aligned)
        let current = frame.camera.transform
        let delta = simd_mul(simd_inverse(origin), current)

        // World space axes: x→east, z→south (so -z = north) with gravity+heading alignment.
        let dx = Double(delta.columns.3.x)          // meters east
        let dz = Double(delta.columns.3.z)          // meters south
        let east = dx
        let north = -dz

        // Smooth & publish, ~15 Hz throttle
        let now = CACurrentMediaTime()
        let (se, sn) = smooth(east: east, north: north)
        self.sample = ARDisplacementSample(east: se, north: sn, timestamp: now)
    }

    private func smooth(east: Double, north: Double) -> (Double, Double) {
        if !hasEMA { emaEast = east; emaNorth = north; hasEMA = true }
        else {
            emaEast = emaEast + alpha * (east - emaEast)
            emaNorth = emaNorth + alpha * (north - emaNorth)
        }
        return (emaEast, emaNorth)
    }

    func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        print("[ARPrecision] tracking = \(camera.trackingState)")
    }
}
