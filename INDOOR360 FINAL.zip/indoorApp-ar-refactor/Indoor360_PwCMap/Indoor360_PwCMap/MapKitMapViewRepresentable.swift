import SwiftUI
import MapKit

struct MapKitMapViewRepresentable: UIViewRepresentable {
    var units: [IMDFUnit]
    var openings: [IMDFOpening]
    var fixtures: [IMDFFixture]
    var route: [IMDFPoint]
    var selectedStartId: String?
    var selectedEndId:   String?
    var preserveCameraOnTap: Bool
    var fitOnFirstLoad: Bool
    var showsUserLocation: Bool
    var trackUser: Bool = false   // keep default for older callers
    var onTapUnit: (IMDFUnit, IMDFPoint) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView(frame: .zero)
        map.delegate = context.coordinator
        map.pointOfInterestFilter = .excludingAll
        map.isRotateEnabled = true
        map.isPitchEnabled = false
        map.showsCompass = false

        // User location
        map.showsUserLocation = showsUserLocation
        map.userTrackingMode = trackUser ? .followWithHeading : .none

        // Allow very close zoom (prevents Apple Maps default from limiting you)
        map.setCameraZoomRange(
            MKMapView.CameraZoomRange(
                minCenterCoordinateDistance: 2,        // ~super close
                maxCenterCoordinateDistance: 50_000
            ),
            animated: false
        )

        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        map.addGestureRecognizer(tap)
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        // Keep user location / tracking in sync
        map.showsUserLocation = showsUserLocation
        let desired: MKUserTrackingMode = trackUser ? .followWithHeading : .none
        if map.userTrackingMode != desired {
            map.setUserTrackingMode(desired, animated: true)
        }

        // Update overlays first so we have geometry to fit to
        context.coordinator.updateOverlays(
            on: map,
            units: units,
            openings: openings,
            fixtures: fixtures,
            route: route,
            selectedStartId: selectedStartId,
            selectedEndId: selectedEndId
        )

        // Fit exactly once, after overlays exist and units are non-empty
        if fitOnFirstLoad && !context.coordinator.didFitOnce && !units.isEmpty {
            // Do this after the runloop turn so renderers are ready
            DispatchQueue.main.async {
                if context.coordinator.fitToUnits(map, units: units) {
                    context.coordinator.didFitOnce = true
                }
            }
        }
    }

    final class Coordinator: NSObject, MKMapViewDelegate {
        var parent: MapKitMapViewRepresentable
        var unitOverlayMap: [MKPolygon: IMDFUnit] = [:]
        var fixturePolys: [MKPolygon] = []
        var openingLines: [MKPolyline] = []
        var didFitOnce = false

        init(_ parent: MapKitMapViewRepresentable) { self.parent = parent }

        // Returns true if it actually fit to a non-empty rect
        func fitToUnits(_ map: MKMapView, units: [IMDFUnit]) -> Bool {
            var rect: MKMapRect = .null
            for u in units {
                for poly in u.polygons {
                    let mk = mkPolygon(from: poly)
                    rect = rect.isNull ? mk.boundingMapRect : rect.union(mk.boundingMapRect)
                }
            }
            guard !rect.isNull else { return false }
            map.setVisibleMapRect(
                rect,
                edgePadding: UIEdgeInsets(top: 60, left: 20, bottom: 120, right: 20),
                animated: false
            )
            return true
        }

        func updateOverlays(
            on map: MKMapView,
            units: [IMDFUnit],
            openings: [IMDFOpening],
            fixtures: [IMDFFixture],
            route: [IMDFPoint],
            selectedStartId: String?,
            selectedEndId: String?
        ) {
            // Clear everything we own and re-add (simple + robust)
            map.removeOverlays(map.overlays)
            unitOverlayMap.removeAll()
            fixturePolys.removeAll()
            openingLines.removeAll()

            // Units
            for u in units {
                for poly in u.polygons {
                    let mk = mkPolygon(from: poly)
                    unitOverlayMap[mk] = u
                    map.addOverlay(mk)
                }
            }

            // Fixtures
            for f in fixtures {
                for poly in f.polygons {
                    let mk = mkPolygon(from: poly)
                    fixturePolys.append(mk)
                    map.addOverlay(mk)
                }
            }

            // Openings
            for o in openings {
                if let lines = o.lines {
                    for line in lines where line.count >= 2 {
                        let coords = line.map { CLLocationCoordinate2D(latitude: $0.y, longitude: $0.x) }
                        let pl = MKPolyline(coordinates: coords, count: coords.count)
                        openingLines.append(pl)
                        map.addOverlay(pl)
                    }
                }
            }

            // Route (Apple-style dots, fixed on-screen size)
            if route.count >= 2 {
                let coords = route.map { CLLocationCoordinate2D(latitude: $0.y, longitude: $0.x) }
                let dots = RouteDotsOverlay(coords: coords, dotRadius: 2.5, spacing: 10, color: .systemBlue)
                map.addOverlay(dots)
            }

            // Selected unit coloring
            self._selectedStartId = selectedStartId
            self._selectedEndId   = selectedEndId
        }

        // MARK: Tap handling

        @objc func handleTap(_ g: UITapGestureRecognizer) {
            guard let map = g.view as? MKMapView else { return }
            let pt = g.location(in: map)
            let coord = map.convert(pt, toCoordinateFrom: map)
            let tapPoint = IMDFPoint(x: coord.longitude, y: coord.latitude)

            // Hit test polygons
            for (poly, unit) in unitOverlayMap {
                if let renderer = map.renderer(for: poly) as? MKPolygonRenderer {
                    let p = renderer.point(for: MKMapPoint(coord))
                    if renderer.path.contains(p) {
                        parent.onTapUnit(unit, tapPoint)
                        return
                    }
                }
            }
        }

        // MARK: Renderers

        private var _selectedStartId: String?
        private var _selectedEndId:   String?

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if overlay is RouteDotsOverlay {
                return RouteDotsRenderer(overlay: overlay)
            }

            if let poly = overlay as? MKPolygon {
                if let unit = unitOverlayMap[poly] {
                    let r = MKPolygonRenderer(polygon: poly)
                    let id = unit.id
                    if id == _selectedStartId {
                        r.fillColor = UIColor.systemGreen.withAlphaComponent(0.35)
                    } else if id == _selectedEndId {
                        r.fillColor = UIColor.systemRed.withAlphaComponent(0.35)
                    } else {
                        r.fillColor = UIColor.systemGray5.withAlphaComponent(1.0)
                    }
                    r.strokeColor = UIColor.systemGray3
                    r.lineWidth = 1.0
                    return r
                } else if fixturePolys.contains(poly) {
                    let r = MKPolygonRenderer(polygon: poly)
                    r.fillColor = UIColor.systemPurple.withAlphaComponent(0.18)
                    r.strokeColor = UIColor.systemPurple.withAlphaComponent(0.5)
                    r.lineWidth = 1.0
                    return r
                }
            }

            if let line = overlay as? MKPolyline, openingLines.contains(line) {
                let r = MKPolylineRenderer(polyline: line)
                r.strokeColor = UIColor.systemTeal
                r.lineWidth = 2.0
                r.lineCap = .round
                return r
            }

            return MKOverlayRenderer(overlay: overlay)
        }

        // MARK: Helpers

        private func mkPolygon(from p: IMDFPolygon) -> MKPolygon {
            func coords(_ pts: [IMDFPoint]) -> [CLLocationCoordinate2D] {
                pts.map { CLLocationCoordinate2D(latitude: $0.y, longitude: $0.x) }
            }
            let outer = coords(p.outer)
            let interiorPolys = p.holes.map { MKPolygon(coordinates: coords($0), count: $0.count) }
            return MKPolygon(coordinates: outer, count: outer.count, interiorPolygons: interiorPolys)
        }
    }
}
