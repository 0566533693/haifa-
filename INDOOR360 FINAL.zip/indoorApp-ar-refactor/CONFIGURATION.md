# Indoor360 Configuration Guide

This document explains how to configure and run both the **Backend** (Python/FastAPI) and **iOS App** (Swift/SwiftUI) projects.

---

## 📁 Project Structure

```
indoorApp/
├── backend/                    # Python FastAPI backend
│   ├── app/
│   │   └── config.py          # ⭐ Central backend configuration
│   └── ...
├── Indoor360/
│   └── Indoor360-FrontEnd/
│       └── Indoor360-FrontEnd/
│           └── Utilities/
│               └── Network/
│                   └── AppConfig.swift  # ⭐ Central iOS configuration
└── start_backend.sh           # Backend startup script
```

---

## 🗄️ Database Configuration (Backend)

All database settings are centralized in **one file**:

**File:** `backend/app/config.py`

### Option 1: Edit the default value directly

```python
DATABASE_URL: str = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:root@127.0.0.1:5432/INDOOR"  # ← Change this
)
```

**Format:** `postgresql://USERNAME:PASSWORD@HOST:PORT/DATABASE_NAME`

### Option 2: Use environment variable (recommended for production)

Create a `.env` file in the `backend/` folder:

```bash
# backend/.env
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/INDOOR
JWT_SECRET_KEY=your-super-secret-key-min-32-chars
```

Or export it in your terminal:

```bash
export DATABASE_URL="postgresql://postgres:root@127.0.0.1:5432/INDOOR"
```

---

## 🌐 API Base URL Configuration (iOS App)

All API endpoint URLs are centralized in **one file**:

**File:** `Indoor360/Indoor360-FrontEnd/Indoor360-FrontEnd/Utilities/Network/AppConfig.swift`

### Automatic Detection (Current Setup)

The app automatically uses:
- **Simulator:** `http://localhost:8000`
- **Physical Device:** `http://192.168.1.180:8000` (update this IP)

### To Change the Physical Device IP

Edit the `#else` section in `AppConfig.swift`:

```swift
#else
// Physical device needs the Mac's LAN IP
static let baseURL: URL = {
    let s = "http://YOUR_MAC_IP:8000"  // ← Change this
    guard let url = URL(string: s) else {
        preconditionFailure("Invalid AppConfig.baseURL: \(s)")
    }
    return url
}()
#endif
```

### Finding Your Mac's IP Address

Run this command in Terminal:

```bash
ipconfig getifaddr en0
```

---

## 🚀 Running the Backend

### Prerequisites

1. Python 3.12+ with virtual environment
2. PostgreSQL database running
3. Required Python packages installed

### Start the Backend

```bash
# From the project root
./start_backend.sh
```

Or manually:

```bash
# Activate virtual environment
source ~/indoor360_venv/bin/activate

# Navigate to backend
cd backend

# Set PYTHONPATH
export PYTHONPATH=$(pwd)

# Start server
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Verify Backend is Running

- **API:** http://localhost:8000
- **API Docs:** http://localhost:8000/docs

---

## 📱 Running the iOS App

### Prerequisites

1. Xcode 15+ installed
2. iOS Simulator or physical device
3. Backend server running

### Open in Xcode

```bash
open Indoor360/Indoor360-FrontEnd/Indoor360-FrontEnd.xcodeproj
```

### Run the App

1. Select your target device (Simulator or Physical)
2. Press `Cmd + R` or click the Play button
3. The app will connect to the backend using the configured base URL

---

## ⚙️ Quick Reference

| Setting | File | Variable |
|---------|------|----------|
| Database URL | `backend/app/config.py` | `DATABASE_URL` |
| JWT Secret | `backend/app/config.py` | `JWT_SECRET_KEY` |
| API Base URL | `AppConfig.swift` | `baseURL` |
| CORS Origins | `backend/app/config.py` | `CORS_ALLOW_ORIGINS` |

---

## 🔧 Troubleshooting

### iOS App can't connect to backend

1. **Simulator:** Make sure backend is running on `localhost:8000`
2. **Physical Device:**
   - Ensure Mac and iPhone are on the same WiFi network
   - Update the IP in `AppConfig.swift` to your Mac's current LAN IP
   - Check that port 8000 is not blocked by firewall

### Database connection failed

1. Verify PostgreSQL is running:
   ```bash
   pg_isready -h localhost -p 5432
   ```
2. Check credentials in `backend/app/config.py`
3. Ensure the database `INDOOR` exists

### Backend won't start

1. Activate the virtual environment:
   ```bash
   source ~/indoor360_venv/bin/activate
   ```
2. Install dependencies:
   ```bash
   pip install -r backend/requirements.txt
   ```
