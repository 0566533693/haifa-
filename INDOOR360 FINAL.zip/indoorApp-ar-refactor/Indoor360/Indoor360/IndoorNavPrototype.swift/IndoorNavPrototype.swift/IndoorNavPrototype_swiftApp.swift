//
//  IndoorNavPrototype_swiftApp.swift
//  IndoorNavPrototype.swift
//
//  Created by Shahad  on 19/08/2025.
//

import SwiftUI

@main
struct IndoorNavPrototype_swiftApp: App {
    var body: some Scene {
        WindowGroup {
            IndoorNavigationPrototype()
        }
    }
}
