//
//  IndoorNavigationPrototypeViewController.swift
//  IndoorNavPrototype.swift
//
//  Created by Shahad  on 19/08/2025.
//

import UIKit
import MapKit

class IndoorNavigationPrototypeViewController: UIViewController {
    private var mapView: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        // Setup map view
        mapView = MKMapView(frame: view.bounds)
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(mapView)
        
        // Optionally add a label for testing
        let label = UILabel()
        label.text = "Indoor Navigation Screen"
        label.textAlignment = .center
        label.textColor = .white
        label.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)

        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            label.heightAnchor.constraint(equalToConstant: 40),
            label.widthAnchor.constraint(equalToConstant: 250)
        ])
    }
}
