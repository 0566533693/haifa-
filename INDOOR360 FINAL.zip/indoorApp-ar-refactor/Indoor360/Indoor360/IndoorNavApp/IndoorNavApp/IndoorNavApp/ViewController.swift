//
//  ViewController.swift
//  IndoorNavApp
//
//  Created by Shahad  on 25/08/2025.
//

import UIKit
import MapKit
import CoreLocation

// MARK: - IMDF domain models

struct IMDFLevel {
    let id: String
    let ordinal: Int
    let name: String
}

struct IMDFUnit {
    let id: String
    let levelId: String
    let category: String
    let polygon: MKPolygon
}

struct IMDFOpening {
    let id: String
    let levelId: String
    let polyline: MKPolyline
    let repCoordinate: CLLocationCoordinate2D
}

struct IMDFRelationship {
    let id: String
    let category: String
    let direction: String
    let originId: String
    let originType: String
    let intermediaryOpeningIds: [String]
    let destinationId: String
    let destinationType: String
}

// MARK: - IMDF store

final class IMDFStore {
    var levelsById = [String: IMDFLevel]()
    var unitsById = [String: IMDFUnit]()
    var unitsByLevel = [String: [IMDFUnit]]()
    var openingsById = [String: IMDFOpening]()
    var relationships = [IMDFRelationship]()
}

// MARK: - IMDF loader

final class IMDFLoader {
    static func load(fromIMDFFolder folderName: String = "IMDF") throws -> IMDFStore {
        guard let baseURL = Bundle.main.resourceURL?.appendingPathComponent(folderName) else {
            throw NSError(domain: "IMDF", code: 1, userInfo: [NSLocalizedDescriptionKey: "IMDF folder not found in bundle. Add it as a Folder Reference named '\(folderName)'"])
        }
        let store = IMDFStore()
        try decodeLevels(into: store, url: baseURL.appendingPathComponent("level.geojson"))
        try decodeUnits(into: store, url: baseURL.appendingPathComponent("unit.geojson"))
        try decodeOpenings(into: store, url: baseURL.appendingPathComponent("opening.geojson"))
        try decodeRelationships(into: store, url: baseURL.appendingPathComponent("relationship.geojson"))
        return store
    }

    private static func readRoot(_ url: URL) throws -> [String: Any] {
        let data = try Data(contentsOf: url)
        let obj = try JSONSerialization.jsonObject(with: data, options: [])
        guard let dict = obj as? [String: Any] else { throw NSError(domain: "IMDF", code: 2, userInfo: [NSLocalizedDescriptionKey: "Invalid GeoJSON"]) }
        return dict
    }

    private static func decodeLevels(into store: IMDFStore, url: URL) throws {
        let root = try readRoot(url)
        guard let feats = root["features"] as? [[String: Any]] else { return }
        for f in feats {
            guard let id = f["id"] as? String,
                  let props = f["properties"] as? [String: Any] else { continue }
            let ordinal = (props["ordinal"] as? Int) ?? 0
            let nameDict = (props["name"] as? [String: Any]) ?? [:]
            let name = (nameDict["en"] as? String) ?? "Level \(ordinal)"
            store.levelsById[id] = IMDFLevel(id: id, ordinal: ordinal, name: name)
        }
    }

    private static func decodeUnits(into store: IMDFStore, url: URL) throws {
        let data = try Data(contentsOf: url)
        let root = try readRoot(url)
        let featuresRaw = (root["features"] as? [[String: Any]]) ?? []
        let features = try MKGeoJSONDecoder().decode(data).compactMap { $0 as? MKGeoJSONFeature }
        for (idx, feature) in features.enumerated() {
            guard let props = featuresRaw[idx]["properties"] as? [String: Any],
                  let id = featuresRaw[idx]["id"] as? String else { continue }
            let levelId = props["level_id"] as? String ?? ""
            let category = props["category"] as? String ?? "room"
            guard let polygon = feature.geometry.compactMap({ $0 as? MKPolygon }).first else { continue }
            let unit = IMDFUnit(id: id, levelId: levelId, category: category, polygon: polygon)
            store.unitsById[id] = unit
            store.unitsByLevel[levelId, default: []].append(unit)
        }
    }

    private static func decodeOpenings(into store: IMDFStore, url: URL) throws {
        let data = try Data(contentsOf: url)
        let root = try readRoot(url)
        let featuresRaw = (root["features"] as? [[String: Any]]) ?? []
        let features = try MKGeoJSONDecoder().decode(data).compactMap { $0 as? MKGeoJSONFeature }
        for (idx, feature) in features.enumerated() {
            guard let props = featuresRaw[idx]["properties"] as? [String: Any],
                  let id = featuresRaw[idx]["id"] as? String else { continue }
            let levelId = props["level_id"] as? String ?? ""
            guard let polyline = feature.geometry.compactMap({ $0 as? MKPolyline }).first else { continue }
            let rep = polylineMidpoint(polyline)
            let o = IMDFOpening(id: id, levelId: levelId, polyline: polyline, repCoordinate: rep)
            store.openingsById[id] = o
        }
    }

    private static func decodeRelationships(into store: IMDFStore, url: URL) throws {
        let root = try readRoot(url)
        guard let feats = root["features"] as? [[String: Any]] else { return }
        for f in feats {
            let id = (f["id"] as? String) ?? UUID().uuidString
            let p = (f["properties"] as? [String: Any]) ?? [:]
            let cat = (p["category"] as? String) ?? ""
            let dir = (p["direction"] as? String) ?? "undirected"

            func parseEndpoint(_ obj: Any?) -> (id: String, type: String)? {
                guard let d = obj as? [String: Any],
                      let fid = d["id"] as? String,
                      let ftype = d["feature_type"] as? String else { return nil }
                return (fid, ftype)
            }
            let origin = parseEndpoint(p["origin"])
            let dest = parseEndpoint(p["destination"])
            var interOpenings: [String] = []
            if let arr = p["intermediary"] as? [[String: Any]] {
                interOpenings = arr.compactMap { ($0["id"] as? String) }
            }
            guard let o = origin, let d = dest else { continue }
            let rel = IMDFRelationship(id: id, category: cat, direction: dir,
                                       originId: o.id, originType: o.type,
                                       intermediaryOpeningIds: interOpenings,
                                       destinationId: d.id, destinationType: d.type)
            if rel.category == "traversal" {
                store.relationships.append(rel)
            }
        }
    }
}

// MARK: - Geometry helpers

private func polylineMidpoint(_ line: MKPolyline) -> CLLocationCoordinate2D {
    let count = line.pointCount
    guard count > 1 else { return line.coordinate }
    let pts = Array(UnsafeBufferPointer(start: line.points(), count: count))
    let first = pts.first!
    let last = pts.last!
    let mid = MKMapPoint(x: (first.x + last.x) / 2.0, y: (first.y + last.y) / 2.0)
    return mid.coordinate
}

private func polygonCentroid(_ polygon: MKPolygon) -> CLLocationCoordinate2D {
    let n = polygon.pointCount
    guard n > 0 else { return polygon.coordinate }
    let pts = Array(UnsafeBufferPointer(start: polygon.points(), count: n))
    let sx = pts.reduce(0.0) { $0 + $1.x }
    let sy = pts.reduce(0.0) { $0 + $1.y }
    let c = MKMapPoint(x: sx / Double(n), y: sy / Double(n))
    return c.coordinate
}

private func meters(_ a: CLLocationCoordinate2D, _ b: CLLocationCoordinate2D) -> Double {
    let mapPointA = MKMapPoint(a)
    let mapPointB = MKMapPoint(b)
    return mapPointA.distance(to: mapPointB)
}

// MARK: - Routing graph (A*)

struct Node {
    let id: String
    let coord: CLLocationCoordinate2D
}

struct Edge {
    let a: String
    let b: String
    let cost: Double
}

final class Graph {
    var nodes = [String: Node]()
    var adj = [String: [Edge]]()

    func ensureNode(id: String, coord: CLLocationCoordinate2D) {
        if nodes[id] == nil {
            nodes[id] = Node(id: id, coord: coord)
        }
    }

    func addUndirected(_ a: String, _ b: String, cost: Double) {
        let e1 = Edge(a: a, b: b, cost: cost)
        let e2 = Edge(a: b, b: a, cost: cost)
        adj[a, default: []].append(e1)
        adj[b, default: []].append(e2)
    }
}

final class Router {
    static func aStar(from start: String, to goal: String, graph: Graph) -> [String] {
        struct QItem: Comparable {
            let f: Double
            let id: String
            static func < (l: QItem, r: QItem) -> Bool { l.f < r.f }
        }
        guard graph.nodes[start] != nil, graph.nodes[goal] != nil else { return [] }

        var open = [QItem]()
        func push(_ item: QItem) {
            open.append(item)
            open.sort()
        }
        func pop() -> QItem { open.removeFirst() }

        var cameFrom = [String: String]()
        var gScore = [String: Double]()
        var fScore = [String: Double]()
        for n in graph.nodes.keys { gScore[n] = .infinity; fScore[n] = .infinity }
        gScore[start] = 0
        fScore[start] = heuristic(start, goal, graph)
        push(QItem(f: fScore[start]!, id: start))

        var inOpen = Set([start])

        while !open.isEmpty {
            let current = pop()
            inOpen.remove(current.id)

            if current.id == goal {
                var path = [goal]
                var c = goal
                while let prev = cameFrom[c] {
                    path.append(prev)
                    c = prev
                }
                return path.reversed()
            }

            for e in graph.adj[current.id] ?? [] {
                let tentative = (gScore[current.id] ?? .infinity) + e.cost
                if tentative < (gScore[e.b] ?? .infinity) {
                    cameFrom[e.b] = current.id
                    gScore[e.b] = tentative
                    fScore[e.b] = tentative + heuristic(e.b, goal, graph)
                    if !inOpen.contains(e.b) {
                        push(QItem(f: fScore[e.b] ?? .infinity, id: e.b))
                        inOpen.insert(e.b)
                    }
                }
            }
        }
        return []
    }

    private static func heuristic(_ a: String, _ b: String, _ g: Graph) -> Double {
        guard let ca = g.nodes[a]?.coord, let cb = g.nodes[b]?.coord else { return 0 }
        return meters(ca, cb)
    }
}

// MARK: - Graph builder

final class IMDFGraphBuilder {
    static func buildGraph(store: IMDFStore, onLevelId levelId: String) -> Graph {
        let g = Graph()

        for unit in store.unitsByLevel[levelId] ?? [] {
            let key = "unit:\(unit.id)"
            g.ensureNode(id: key, coord: polygonCentroid(unit.polygon))
        }

        for (_, opening) in store.openingsById where opening.levelId == levelId {
            let key = "opening:\(opening.id)"
            g.ensureNode(id: key, coord: opening.repCoordinate)
        }

        for rel in store.relationships {
            let openings = rel.intermediaryOpeningIds.compactMap { store.openingsById[$0] }.filter { $0.levelId == levelId }
            if openings.isEmpty { continue }

            for op in openings {
                let opKey = "opening:\(op.id)"

                if let originCoord = coordForEndpoint(id: rel.originId, type: rel.originType, store: store) {
                    let oKey = "\(rel.originType):\(rel.originId)"
                    g.ensureNode(id: oKey, coord: originCoord)
                    g.addUndirected(oKey, opKey, cost: meters(originCoord, op.repCoordinate))
                }

                if let destCoord = coordForEndpoint(id: rel.destinationId, type: rel.destinationType, store: store) {
                    let dKey = "\(rel.destinationType):\(rel.destinationId)"
                    g.ensureNode(id: dKey, coord: destCoord)
                    g.addUndirected(opKey, dKey, cost: meters(op.repCoordinate, destCoord))
                }
            }
        }

        return g
    }

    private static func coordForEndpoint(id: String, type: String, store: IMDFStore) -> CLLocationCoordinate2D? {
        switch type {
        case "unit":
            if let u = store.unitsById[id] { return polygonCentroid(u.polygon) }
        case "opening":
            if let o = store.openingsById[id] { return o.repCoordinate }
        default: break
        }
        return nil
    }
}

// MARK: - View Controller

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    let mapView = MKMapView()
    let locationManager = CLLocationManager()

    private var store: IMDFStore?
    private var graph: Graph?
    private var activeLevelId: String = ""
    private var routeOverlay: MKPolyline?

    private var startNodeId: String?
    private var goalNodeId: String?

    let venueCenter = CLLocationCoordinate2D(latitude: 25.2007704, longitude: 55.2746848)

    override func viewDidLoad() {
        super.viewDidLoad()
        print("ViewController loaded") // Debug to confirm viewDidLoad is called

        mapView.frame = view.bounds
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        mapView.delegate = self
        mapView.showsUserLocation = true
        view.addSubview(mapView)

        addGestureRecognizers()

        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()

        do {
            store = try IMDFLoader.load()
            print("IMDF files loaded: \(store?.levelsById.count ?? 0) levels, \(store?.unitsById.count ?? 0) units")
            if let lvl = store?.levelsById.values.sorted(by: { $0.ordinal < $1.ordinal }).first {
                activeLevelId = lvl.id
            } else {
                print("No levels found in IMDF.")
                toast("No levels found in IMDF.")
                return
            }
            graph = IMDFGraphBuilder.buildGraph(store: store!, onLevelId: activeLevelId)
            drawLevel(activeLevelId)
            zoomToVenue()
            print("IMDF loaded successfully for level: \(activeLevelId)")
            toast("Loaded IMDF venue. Long-press to pick START, then long-press again for DEST to route.")
        } catch {
            print("IMDF load error: \(error)")
            toast("IMDF load error: \(error.localizedDescription)")
        }
    }

    private func addGestureRecognizers() {
        let lp = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        lp.minimumPressDuration = 0.4
        mapView.addGestureRecognizer(lp)
    }

    @objc private func handleLongPress(_ g: UILongPressGestureRecognizer) {
        if g.state == .began {
            let pt = g.location(in: mapView)
            let coord = mapView.convert(pt, toCoordinateFrom: mapView)
            if let u = unit(at: coord, levelId: activeLevelId) {
                let nodeId = "unit:\(u.id)"
                dropPin(at: polygonCentroid(u.polygon), title: (startNodeId == nil) ? "Start" : "Dest")
                if startNodeId == nil {
                    startNodeId = nodeId
                    toast("Start set. Long-press destination.")
                } else {
                    goalNodeId = nodeId
                    computeAndDrawRoute()
                    startNodeId = nil
                    goalNodeId = nil
                }
            } else {
                toast("No unit at that location.")
            }
        }
    }

    private func computeAndDrawRoute() {
        guard let s = startNodeId, let t = goalNodeId, let g = graph else { return }
        let path = Router.aStar(from: s, to: t, graph: g)
        guard path.count >= 2 else {
            toast("No path.")
            return
        }

        let coords: [CLLocationCoordinate2D] = path.compactMap { g.nodes[$0]?.coord }
        if let overlay = routeOverlay { mapView.removeOverlay(overlay) }
        let line = MKPolyline(coordinates: coords, count: coords.count)
        routeOverlay = line
        mapView.addOverlay(line)

        mapView.setVisibleMapRect(line.boundingMapRect, edgePadding: UIEdgeInsets(top: 60, left: 30, bottom: 60, right: 30), animated: true)
    }

    private func zoomToVenue() {
        let span = MKCoordinateSpan(latitudeDelta: 0.002, longitudeDelta: 0.002)
        let region = MKCoordinateRegion(center: venueCenter, span: span)
        mapView.setRegion(region, animated: true)
    }

    private func drawLevel(_ levelId: String) {
        mapView.removeOverlays(mapView.overlays)
        let units = store?.unitsByLevel[levelId] ?? []
        mapView.addOverlays(units.map { $0.polygon })
        for opening in store?.openingsById.values.filter({ $0.levelId == levelId }) ?? [] {
            mapView.addOverlay(opening.polyline)
        }
    }

    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polygon = overlay as? MKPolygon {
            let r = MKPolygonRenderer(polygon: polygon)
            r.lineWidth = 0.5
            r.strokeColor = .separator
            if let unit = unit(for: polygon), unit.category.lowercased() == "walkway" {
                r.fillColor = UIColor.systemTeal.withAlphaComponent(0.15)
            } else {
                r.fillColor = UIColor.systemGray.withAlphaComponent(0.12)
            }
            return r
        } else if let polyline = overlay as? MKPolyline {
            if polyline === routeOverlay {
                let r = MKPolylineRenderer(polyline: polyline)
                r.lineWidth = 5
                r.strokeColor = .systemBlue
                r.lineJoin = .round
                r.lineCap = .round
                return r
            } else {
                let r = MKPolylineRenderer(polyline: polyline)
                r.lineWidth = 1
                r.strokeColor = UIColor.systemGray2.withAlphaComponent(0.6)
                return r
            }
        }
        return MKOverlayRenderer(overlay: overlay)
    }

    private func unit(for polygon: MKPolygon) -> IMDFUnit? {
        store?.unitsById.values.first { $0.polygon === polygon }
    }

    private func unit(at coordinate: CLLocationCoordinate2D, levelId: String) -> IMDFUnit? {
        guard let store = store else { return nil }
        for u in store.unitsByLevel[levelId] ?? [] {
            let renderer = MKPolygonRenderer(polygon: u.polygon)
            let mapPoint = MKMapPoint(coordinate)
            let pt = renderer.point(for: mapPoint)
            if renderer.path.contains(pt) {
                return u
            }
        }
        let fallback = (store.unitsByLevel[levelId] ?? [])
            .map { ($0, meters(polygonCentroid($0.polygon), coordinate)) }
            .sorted { $0.1 < $1.1 }
            .first
        if let f = fallback, f.1 < 10 { return f.0 }
        return nil
    }

    private func dropPin(at coord: CLLocationCoordinate2D, title: String) {
        let ann = MKPointAnnotation()
        ann.coordinate = coord
        ann.title = title
        mapView.addAnnotation(ann)
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) { [weak self, weak ann] in
            if let a = ann { self?.mapView.removeAnnotation(a) }
        }
    }

    private func toast(_ text: String) {
        let label = PaddingLabel()
        label.text = text
        label.textColor = .white
        label.numberOfLines = 0
        label.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        label.layer.cornerRadius = 10
        label.clipsToBounds = true
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10)
        ])
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            label.removeFromSuperview()
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
            locationManager.startUpdatingLocation()
        } else {
            print("Location permission denied")
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        print("User location: \(location.coordinate.latitude), \(location.coordinate.longitude)")
    }
}

final class PaddingLabel: UILabel {
    var inset = UIEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: inset))
    }
    override var intrinsicContentSize: CGSize {
        let s = super.intrinsicContentSize
        return CGSize(width: s.width + inset.left + inset.right,
                      height: s.height + inset.top + inset.bottom)
    }
}

extension Array {
    func safeIndex(_ i: Index) -> Element? {
        i < count ? self[i] : nil
    }
}
