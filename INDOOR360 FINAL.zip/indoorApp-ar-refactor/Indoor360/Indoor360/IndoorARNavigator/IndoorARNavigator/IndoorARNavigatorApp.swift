//
//  IndoorARNavigatorApp.swift
//  IndoorARNavigator
//
//  Created by Shahad  on 22/07/2025.
//

import SwiftUI

@main
struct IndoorARNavigatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
