/*import SwiftUI
import ARKit
import RealityKit

// MARK: - AR View Container
struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)

        // AR configuration
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal, .vertical]
        config.environmentTexturing = .automatic

        arView.session.run(config)
        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {}
}

// MARK: - Content View
struct ContentView: View {
    var body: some View {
        ARViewContainer()
            .edgesIgnoringSafeArea(.all)
    }
}

#Preview {
    ContentView()
}

*/



/* Ahmed's code
 
import SwiftUI
import ARKit

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARSCNView {
        let arView = ARSCNView(frame: .zero)
        
        // Configure AR Session
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal, .vertical]  // Detect floors and walls
        config.environmentTexturing = .automatic  // Better lighting
        
        // Enable scene reconstruction if LiDAR available
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            config.sceneReconstruction = .mesh
        }
        
        arView.session.run(config)
        return arView
    }
    
    func updateUIView(_ uiView: ARSCNView, context: Context) {}
}

struct ContentView: View {
    var body: some View {
        ARViewContainer()
            .edgesIgnoringSafeArea(.all)
    }
}
*/


/* chat code
import SwiftUI
import ARKit
import SceneKit

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARSCNView {
        let arView = ARSCNView(frame: .zero)

        // Configure AR Session
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal, .vertical]
        config.environmentTexturing = .automatic

        arView.session.run(config)
        
        // 🔧 Enable debug visuals (yellow grids, feature points, etc.)
        arView.debugOptions = [
            .showFeaturePoints,
            .showWorldOrigin,
            .showDetectedPlanes
        ]

        return arView
    }

    func updateUIView(_ uiView: ARSCNView, context: Context) {}
}

struct ContentView: View {
    var body: some View {
        ARViewContainer()
            .edgesIgnoringSafeArea(.all)
    }
}
*/


import SwiftUI
import ARKit

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARSCNView {
        let arView = ARSCNView(frame: .zero)
        let config = ARWorldTrackingConfiguration()

        // ✅ Essential settings for indoor navigation
        config.planeDetection = [.horizontal, .vertical]
        config.automaticImageScaleEstimationEnabled = true
        config.worldAlignment = .gravityAndHeading
        config.isCollaborationEnabled = false  // Set true for multi-user AR

        // ✅ LiDAR-specific optimizations (optional, for iPad Pro / iPhone Pro)
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.meshWithClassification) {
            config.sceneReconstruction = .meshWithClassification
            config.frameSemantics.insert(.sceneDepth)
        }

        // 🔧 Enable debug visuals
        arView.debugOptions = [
            .showFeaturePoints,
            .showWorldOrigin
        ]

        arView.session.run(config)
        arView.delegate = context.coordinator  // Optional: For handling planes

        return arView
    }

    func updateUIView(_ uiView: ARSCNView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    class Coordinator: NSObject, ARSCNViewDelegate {
        // Optional: Plane visualization or session tracking callbacks
    }
}

struct ContentView: View {
    var body: some View {
        ARViewContainer()
            .edgesIgnoringSafeArea(.all)
    }
}
