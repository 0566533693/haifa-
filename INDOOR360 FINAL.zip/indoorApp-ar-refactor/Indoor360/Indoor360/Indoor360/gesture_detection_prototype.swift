import SwiftUI
import CoreMotion
import AVFoundation

// MARK: - Main App View
struct Indoor360AppView: View {
    @StateObject private var motionManager = MotionManager()
    @State private var isARMode = false
    @State private var transitionProgress: Double = 0.0
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // 2D Map View
                MapView()
                    .opacity(isARMode ? 0 : 1)
                    .scaleEffect(isARMode ? 1.2 : 1.0)
                    .blur(radius: isARMode ? 10 : 0)
                
                // AR Camera View
                ARCameraView()
                    .opacity(isARMode ? 1 : 0)
                    .scaleEffect(isARMode ? 1.0 : 0.8)
                
                // Transition Overlay
                if transitionProgress > 0 {
                    TransitionOverlay(progress: transitionProgress)
                }
                
                // Debug Info
                VStack {
                    Spacer()
                    DebugPanel(
                        pitch: motionManager.pitch,
                        isGestureDetected: motionManager.isPhoneRaised,
                        mode: isARMode ? "AR Mode" : "2D Mode"
                    )
                }
            }
        }
        .onReceive(motionManager.$isPhoneRaised) { phoneRaised in
            handleGestureDetection(phoneRaised)
        }
        .onAppear {
            motionManager.startMonitoring()
        }
        .onDisappear {
            motionManager.stopMonitoring()
        }
    }
    
    private func handleGestureDetection(_ phoneRaised: Bool) {
        if phoneRaised && !isARMode {
            // Transition to AR mode
            withAnimation(.easeInOut(duration: 0.8)) {
                transitionProgress = 1.0
                isARMode = true
            }
            
            // Reset transition progress after animation
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                transitionProgress = 0.0
            }
        } else if !phoneRaised && isARMode {
            // Transition back to 2D mode
            withAnimation(.easeInOut(duration: 0.6)) {
                isARMode = false
                transitionProgress = 0.0
            }
        }
    }
}

// MARK: - Motion Manager
class MotionManager: ObservableObject {
    private let motionManager = CMMotionManager()
    private let queue = OperationQueue()
    
    @Published var pitch: Double = 0.0
    @Published var isPhoneRaised: Bool = false
    
    // Gesture detection parameters
    private let raisedThreshold: Double = 0.5  // Phone tilted up
    private let loweredThreshold: Double = -0.3  // Phone tilted down
    private let stabilityDuration: TimeInterval = 0.3
    
    private var lastGestureTime: Date = Date()
    private var stableRaisedTime: Date?
    
    func startMonitoring() {
        guard motionManager.isDeviceMotionAvailable else {
            print("Device motion not available")
            return
        }
        
        motionManager.deviceMotionUpdateInterval = 0.1
        motionManager.startDeviceMotionUpdates(to: queue) { [weak self] motion, error in
            guard let motion = motion, error == nil else { return }
            
            DispatchQueue.main.async {
                self?.processMotionUpdate(motion)
            }
        }
    }
    
    func stopMonitoring() {
        motionManager.stopDeviceMotionUpdates()
    }
    
    private func processMotionUpdate(_ motion: CMDeviceMotion) {
        // Get pitch (rotation around x-axis)
        let currentPitch = motion.attitude.pitch
        pitch = currentPitch
        
        let now = Date()
        
        // Check if phone is raised
        if currentPitch < raisedThreshold {
            // Phone is tilted up
            if stableRaisedTime == nil {
                stableRaisedTime = now
            } else if now.timeIntervalSince(stableRaisedTime!) > stabilityDuration {
                // Phone has been stable in raised position
                if !isPhoneRaised {
                    isPhoneRaised = true
                    lastGestureTime = now
                }
            }
        } else if currentPitch > loweredThreshold {
            // Phone is tilted down/normal
            stableRaisedTime = nil
            if isPhoneRaised && now.timeIntervalSince(lastGestureTime) > stabilityDuration {
                isPhoneRaised = false
            }
        }
    }
}

// MARK: - 2D Map View
struct MapView: View {
    @State private var userLocation = CGPoint(x: 150, y: 200)
    @State private var destination = CGPoint(x: 300, y: 100)
    
    var body: some View {
        ZStack {
            // Map background
            Rectangle()
                .fill(Color.gray.opacity(0.2))
                .overlay(
                    // Grid pattern
                    Path { path in
                        let spacing: CGFloat = 40
                        for i in 0..<20 {
                            let x = CGFloat(i) * spacing
                            path.move(to: CGPoint(x: x, y: 0))
                            path.addLine(to: CGPoint(x: x, y: 800))
                        }
                        for i in 0..<20 {
                            let y = CGFloat(i) * spacing
                            path.move(to: CGPoint(x: 0, y: y))
                            path.addLine(to: CGPoint(x: 800, y: y))
                        }
                    }
                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                )
            
            // Navigation path
            Path { path in
                path.move(to: userLocation)
                path.addLine(to: destination)
            }
            .stroke(Color.blue, lineWidth: 3)
            .opacity(0.7)
            
            // User location
            Circle()
                .fill(Color.blue)
                .frame(width: 20, height: 20)
                .position(userLocation)
                .overlay(
                    Circle()
                        .stroke(Color.white, lineWidth: 2)
                        .frame(width: 20, height: 20)
                        .position(userLocation)
                )
            
            // Destination
            Circle()
                .fill(Color.red)
                .frame(width: 16, height: 16)
                .position(destination)
            
            // Instructions
            VStack {
                HStack {
                    Text("📍 Office Building - Floor 2")
                        .font(.headline)
                        .foregroundColor(.primary)
                    Spacer()
                }
                .padding()
                Spacer()
            }
        }
        .background(Color.white)
    }
}

// MARK: - AR Camera View
struct ARCameraView: View {
    var body: some View {
        ZStack {
            // Simulated camera feed
            LinearGradient(
                gradient: Gradient(colors: [Color.black.opacity(0.8), Color.gray.opacity(0.4)]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            // AR Navigation Elements
            VStack {
                Spacer()
                
                // Direction arrow
                Image(systemName: "arrow.up")
                    .font(.system(size: 60, weight: .bold))
                    .foregroundColor(.cyan)
                    .shadow(color: .cyan, radius: 10)
                    .scaleEffect(1.2)
                    .animation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true), value: true)
                
                Text("Continue straight 15m")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black.opacity(0.6))
                    .cornerRadius(10)
                
                Spacer()
                
                // Distance indicator
                HStack {
                    Text("🎯 Conference Room B")
                        .foregroundColor(.white)
                        .font(.headline)
                    Spacer()
                    Text("45m")
                        .foregroundColor(.cyan)
                        .font(.title2)
                        .fontWeight(.bold)
                }
                .padding()
                .background(Color.black.opacity(0.6))
                .cornerRadius(10)
                .padding()
            }
        }
    }
}

// MARK: - Transition Overlay
struct TransitionOverlay: View {
    let progress: Double
    
    var body: some View {
        ZStack {
            // Ripple effect
            Circle()
                .stroke(Color.cyan.opacity(0.6), lineWidth: 2)
                .scaleEffect(progress * 3)
                .opacity(1 - progress)
            
            Circle()
                .stroke(Color.cyan.opacity(0.3), lineWidth: 1)
                .scaleEffect(progress * 2)
                .opacity(1 - progress)
            
            // Center pulse
            Circle()
                .fill(Color.cyan.opacity(0.8))
                .frame(width: 20, height: 20)
                .scaleEffect(1 + progress * 0.5)
                .opacity(1 - progress)
        }
        .animation(.easeOut(duration: 0.8), value: progress)
    }
}

// MARK: - Debug Panel
struct DebugPanel: View {
    let pitch: Double
    let isGestureDetected: Bool
    let mode: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Debug Info")
                .font(.caption)
                .fontWeight(.bold)
            Text("Pitch: \(pitch, specifier: "%.2f")")
                .font(.caption)
            Text("Gesture: \(isGestureDetected ? "Detected" : "None")")
                .font(.caption)
                .foregroundColor(isGestureDetected ? .green : .primary)
            Text("Mode: \(mode)")
                .font(.caption)
                .fontWeight(.semibold)
        }
        .padding(8)
        .background(Color.black.opacity(0.7))
        .foregroundColor(.white)
        .cornerRadius(8)
        .padding()
    }
}

// MARK: - App Entry Point
@main
struct Indoor360AppMain: App {
    var body: some Scene {
        WindowGroup {
            Indoor360AppView()
        }
    }
}

