import Foundation
import CoreLocation
import Combine

/// Wraps CLLocationManager with simple quality gating + verbose debug logs.
final class LocationService: NSObject, ObservableObject, CLLocationManagerDelegate {

    enum Mode { case selecting, navigating }

    @Published var authorization: CLAuthorizationStatus = .notDetermined
    @Published var latest: CLLocation?
    @Published var mode: Mode = .selecting {
        didSet { updateDesiredAccuracy() }
    }

    private let manager = CLLocationManager()

    // Tunables
    private let maxAgeSec: TimeInterval = 10
    private let maxHDOP: CLLocationAccuracy = 40 // accept fixes <= 40 m

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.activityType = .otherNavigation
        authorization = manager.authorizationStatus
        print("[LocationService] init; auth=\(authorization.rawValue)")
    }

    /// Call this early (e.g., VenuePickerView.onAppear) to prompt if needed.
    func ensureAuthorization() {
        let status = manager.authorizationStatus
        print("[LocationService] ensureAuthorization: \(status.rawValue)")
        if status == .notDetermined {
            print("[LocationService] requesting WhenInUse…")
            manager.requestWhenInUseAuthorization()
        }
    }

    func requestWhenInUse() {
        print("[LocationService] requestWhenInUse()")
        manager.requestWhenInUseAuthorization()
    }

    func start() {
        updateDesiredAccuracy()
        print("[LocationService] start updates, desiredAccuracy=\(manager.desiredAccuracy)")
        manager.startUpdatingLocation()

        #if targetEnvironment(simulator)
        // Simulator fallback: If no location after 2 seconds, provide Reception Desk coordinates
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            guard let self = self, self.latest == nil else { return }
            print("[LocationService] 🔧 Simulator: No GPS fix, providing fallback location (Reception Desk)")
            let fallbackLocation = CLLocation(
                latitude: 25.200700,
                longitude: 55.274600
            )
            self.latest = fallbackLocation
            print("[LocationService] fix lat=25.200700 lon=55.274600 acc=5m (simulator fallback)")
        }
        #endif
    }

    func stop() {
        print("[LocationService] stop updates")
        manager.stopUpdatingLocation()
    }

    private func updateDesiredAccuracy() {
        switch mode {
        case .selecting:  manager.desiredAccuracy = kCLLocationAccuracyBest
        case .navigating: manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        }
        print("[LocationService] mode=\(mode) -> desiredAccuracy=\(manager.desiredAccuracy)")
    }

    // MARK: - Delegate

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorization = manager.authorizationStatus
        print("[LocationService] auth changed -> \(authorization.rawValue)")
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }

        #if targetEnvironment(simulator)
        // In Simulator, accept all locations (GPX playback may have old timestamps)
        latest = loc
        print(String(format: "[LocationService] fix lat=%.6f lon=%.6f acc=%.0fm (simulator)",
                     loc.coordinate.latitude, loc.coordinate.longitude, loc.horizontalAccuracy))
        return
        #endif

        let age = Date().timeIntervalSince(loc.timestamp)
        guard age <= maxAgeSec else {
            print("[LocationService] drop fix: old (age \(age)s)")
            return
        }
        guard loc.horizontalAccuracy > 0, loc.horizontalAccuracy <= maxHDOP else {
            print("[LocationService] drop fix: accuracy \(loc.horizontalAccuracy)m > \(maxHDOP)m")
            return
        }
        latest = loc
        print(String(format: "[LocationService] fix lat=%.6f lon=%.6f acc=%.0fm",
                     loc.coordinate.latitude, loc.coordinate.longitude, loc.horizontalAccuracy))
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("[LocationService] didFailWithError: \(error)")
    }
}
