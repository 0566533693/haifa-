import SwiftUI
import CoreLocation

private enum RoutePickState { case idle, pickingStart, pickingEnd }
private enum StartMode: String, CaseIterable { case tap = "Tap on map", myLocation = "My Location" }

struct MapRouteView: View {
    let venueId: UUID
    let venueName: String

    // Optional: Pre-set route from NavigationSession (for Map Mode from AR)
    var initialRoute: [IMDFPoint]? = nil
    var initialStartName: String? = nil
    var initialEndName: String? = nil
    var initialDestinationPoint: IMDFPoint? = nil

    // Data
    @State private var units: [IMDFUnit] = []
    @State private var openings: [IMDFOpening] = []
    @State private var fixtures: [IMDFFixture] = []
    @State private var graph: IndoorGraph = IndoorGraph()

    private let store = LocalBundleIMDFStore()
    private let gb    = GraphBuilder()
    private let astar = AStar()

    // Location
    @StateObject private var loc = LocationService()
    @State private var startMode: StartMode = .myLocation
    @State private var guessedLevelId: String?
    @State private var venueBounds: (minX: Double, maxX: Double, minY: Double, maxY: Double)?

    // UI state
    @State private var pickState: RoutePickState = .idle
    @State private var selectedStart: IMDFUnit?
    @State private var selectedEnd:   IMDFUnit?
    @State private var startTapCoord: IMDFPoint?
    @State private var endTapCoord:   IMDFPoint?
    @State private var pathPoints: [IMDFPoint] = []
    @State private var errorText: String?
    @State private var fitOnFirstLoad = true

    // Live navigation
    @State private var snappedStartNodeId: String?
    @State private var liveRoutingEnabled = false
    @State private var isNavigating = false
    @State private var trackUserOnMap = false

    // Arrival detection
    private let arrivalThresholdMeters: Double = 3.0
    @State private var endTargetCoord: IMDFPoint?

    // Level picking dialog (unchanged)
    @State private var showLevelPicker = false
    @State private var levelChoices: [IMDFLevel] = []
    @State private var levelPickerTitle = "Select floor"

    // Reroute debounce
    @State private var lastRerouteTime: TimeInterval = 0
    private let minRerouteInterval: TimeInterval = 0.35

    // Determine if we're in navigation mode (from QR code/AR)
    private var isInNavigationMode: Bool {
        initialRoute != nil || initialDestinationPoint != nil
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            MapKitMapViewRepresentable(
                units: units,
                openings: openings,
                fixtures: fixtures,
                route: pathPoints,
                selectedStartId: selectedStart?.id,
                selectedEndId: selectedEnd?.id,
                preserveCameraOnTap: pickState != .idle,
                fitOnFirstLoad: fitOnFirstLoad,
                showsUserLocation: startMode == .myLocation,
                trackUser: trackUserOnMap,
                userLocation: userCoordinate,
                userHeading: userHeading
            ) { tappedUnit, tapCoord in
                handleMapTap(on: tappedUnit, at: tapCoord)
            }
            .ignoresSafeArea()

            if pickState != .idle {
                VStack(spacing: 8) {
                    Text(pickStateText).font(.headline)
                    if startMode == .myLocation {
                        Text(accuracyText).font(.caption)
                    } else if let s = selectedStart {
                        Text("Start: \(s.name ?? s.id)").font(.subheadline)
                    }
                }
                .padding(.horizontal, 16).padding(.vertical, 12)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(.bottom, isNavigating ? 76 : 104)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }

            // Hide UI controls when in navigation mode (from QR code/AR)
            if !isInNavigationMode {
                VStack(spacing: 10) {
                    Picker("Start", selection: $startMode) {
                        Text(StartMode.tap.rawValue).tag(StartMode.tap)
                        Text(StartMode.myLocation.rawValue).tag(StartMode.myLocation)
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal, 16)

                    // Primary action: Find Route (build a static route only)
                    Button(action: onFindRouteTapped) {
                        Text("Find Route")
                            .font(.title3).bold()
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                    }
                    .background(Color.orange)
                    .foregroundColor(.white)
                    .clipShape(Capsule())
                    .padding(.horizontal, 16)

                    // Secondary action: Start Navigation (appears only when a path exists and not already navigating)
                    if !pathPoints.isEmpty && !isNavigating && startMode == .myLocation {
                        Button {
                            beginNavigation()
                        } label: {
                            Text("Start Navigation")
                                .font(.headline).bold()
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                        }
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                        .padding(.horizontal, 16)
                    }

                    // End/Stop navigation button (optional, only when navigating)
                    if isNavigating {
                        Button(role: .destructive) { endNavigation(userInitiated: true) } label: {
                            Text("Stop Navigation").frame(maxWidth: .infinity).padding(.vertical, 10)
                        }
                        .buttonStyle(.borderedProminent)
                        .padding(.horizontal, 16)
                    }

                    Spacer().frame(height: 16)
                }
                .padding(.bottom, 12)
            }
        }
        .navigationTitle(venueName)
        .navigationBarTitleDisplayMode(.inline)
        .task { await loadVenue() }
        .onReceive(loc.$latest) { _ in handleLocationUpdate() }
        .onChange(of: loc.authorization, initial: false) { oldValue, newValue in
            print("[MapRouteView] auth \(oldValue.rawValue) -> \(newValue.rawValue)")
            if startMode == .myLocation, newValue == .denied {
                errorText = "Location permission denied. Switch to 'Tap on map' or enable in Settings."
            }
        }
        .confirmationDialog(levelPickerTitle, isPresented: $showLevelPicker, titleVisibility: .visible) {
            ForEach(levelChoices, id: \.id) { lvl in
                Button(levelDisplay(lvl)) {
                    guessedLevelId = lvl.id
                    print("[MapRouteView] user-picked floor -> \(lvl.id)")
                    handleLocationUpdate()
                }
            }
            Button("Cancel", role: .cancel) {}
        }
        .alert("Info", isPresented: Binding(get: { errorText != nil }, set: { _ in errorText = nil })) {
            Button("OK", role: .cancel) {}
        } message: { Text(errorText ?? "") }
    }

    // MARK: - Derived UI

    private var pickStateText: String {
        switch pickState {
        case .idle:          return ""
        case .pickingStart:  return startMode == .tap ? "Select start point" : "Determining your location…"
        case .pickingEnd:    return "Select destination"
        }
    }

    private var accuracyText: String {
        if let a = loc.latest?.horizontalAccuracy, a > 0 {
            let m = Int(a.rounded())
            return "accuracy \(m)m"
        }
        return "accuracy n/a"
    }

    private var userCoordinate: CLLocationCoordinate2D? {
        guard isNavigating, let fix = loc.latest else { return nil }
        return fix.coordinate
    }

    private var userHeading: CLLocationDirection? {
        guard isNavigating, let fix = loc.latest else { return nil }
        return fix.course >= 0 ? fix.course : nil
    }

    // MARK: - Buttons

    private func onFindRouteTapped() {
        print("[MapRouteView] Find Route tapped; startMode=\(startMode)")
        // Reset any previous nav session
        endNavigation(userInitiated: false)
        pathPoints.removeAll()
        selectedStart = nil
        selectedEnd   = nil
        startTapCoord = nil
        endTapCoord   = nil
        snappedStartNodeId = nil

        if startMode == .myLocation {
            switch loc.authorization {
            case .authorizedAlways, .authorizedWhenInUse:
                loc.mode = .selecting
                loc.start()
                pickState = .pickingEnd
                print("[MapRouteView] starting location updates (selecting)")
            case .denied, .restricted:
                errorText = "Location permission is denied. You can allow it in Settings, or switch to 'Tap on map'."
                pickState = .idle
            case .notDetermined:
                print("[MapRouteView] requesting authorization from route button…")
                loc.requestWhenInUse()
                pickState = .pickingEnd
            @unknown default:
                pickState = .idle
            }
        } else {
            pickState = .pickingStart
        }
    }

    private func beginNavigation() {
        guard startMode == .myLocation else {
            errorText = "Navigation uses your location. Switch start mode to 'My Location'."
            return
        }
        guard !pathPoints.isEmpty else {
            errorText = "Build a route first."
            return
        }
        isNavigating = true
        liveRoutingEnabled = true
        loc.mode = .navigating
        // Don't track user on map - we want to keep the route view zoomed properly
        // User location/heading are shown via overlays instead
        print("[MapRouteView] Navigation started")
        // Store end target coord for arrival detection
        endTargetCoord = endTapCoord
    }

    private func endNavigation(userInitiated: Bool) {
        if isNavigating {
            print("[MapRouteView] Navigation ended (\(userInitiated ? "user" : "auto"))")
        }
        isNavigating = false
        liveRoutingEnabled = false
        trackUserOnMap = false
        // keep the route on screen until user clears or finds another route
    }

    // MARK: - Tap handling

    private func handleMapTap(on unit: IMDFUnit, at tapCoord: IMDFPoint) {
        print("[MapRouteView] tap unit=\(unit.id) name=\(unit.name ?? "-") at lon=\(tapCoord.x), lat=\(tapCoord.y)")
        switch pickState {
        case .idle:
            break
        case .pickingStart:
            selectedStart = unit
            startTapCoord = tapCoord
            pickState = .pickingEnd
        case .pickingEnd:
            selectedEnd = unit
            endTapCoord = tapCoord
            pickState = .idle
            computeRouteIfReady()
        }
    }

    // MARK: - Routing

    private func computeRouteIfReady() {
        if startMode == .tap {
            guard let sUnit = selectedStart,
                  let eUnit = selectedEnd,
                  let sCoord = startTapCoord,
                  let eCoord = endTapCoord else { return }
            guard let startNodeId = nearestNavNodeId(to: sCoord, preferredLevel: sUnit.levelId),
                  let endNodeId   = nearestNavNodeId(to: eCoord, preferredLevel: eUnit.levelId) else {
                errorText = "Couldn’t find nearby graph nodes for the tapped points."
                return
            }
            print("[MapRouteView] A* (manual) start=\(startNodeId) end=\(endNodeId)")
            runAStar(start: startNodeId, goal: endNodeId)
            return
        }

        // My Location → destination (build a static route first; navigation starts later)
        guard let eUnit = selectedEnd, let eCoord = endTapCoord else { return }
        guard let myFix = loc.latest else { return }
        let myP = IMDFPoint(x: myFix.coordinate.longitude, y: myFix.coordinate.latitude)

        let guess = guessLevelId(at: myP)
        let prefer = guessedLevelId ?? guess.first
        guard let startId = nearestNavNodeId(to: myP, preferredLevel: prefer),
              let endId   = nearestNavNodeId(to: eCoord, preferredLevel: eUnit.levelId) else {
            errorText = "Couldn’t find nearby graph nodes near you or the destination."
            return
        }
        print("[MapRouteView] A* (pre-nav) start=\(startId) end=\(endId)")
        runAStar(start: startId, goal: endId)
        // Don't enable liveRouting yet; we wait for "Start Navigation"
        endTargetCoord = eCoord
    }

    private func runAStar(start: String, goal: String) {
        if let res = astar.findPath(graph: graph, start: start, goal: goal) {
            print(String(format: "[MapRouteView] A* ok, distance=%.1fm, nodes=%d",
                         res.distance, res.path.count))
            pathPoints = res.path.compactMap { graph.nodes[$0]?.position }
        } else {
            print("[MapRouteView] A* failed")
            errorText = "No route found."
            pathPoints.removeAll()
        }
    }

    // MARK: - Location updates, live re-route, arrival

    private func handleLocationUpdate() {
        guard startMode == .myLocation, let fix = loc.latest else { return }
        let p = IMDFPoint(x: fix.coordinate.longitude, y: fix.coordinate.latitude)

        // Venue guard
        if let bbox = venueBounds {
            let outsideMeters = outsideDistanceMeters(point: p, bbox: bbox)
            if outsideMeters > 0 {
                let msg = "You appear to be outside the venue (~\(Int(outsideMeters)) m)."
                print("[MapRouteView] \(msg)")
                errorText = msg
                snappedStartNodeId = nil
                return
            }
        }

        // Floor guess (your existing simple approach)
        let guess = guessLevelId(at: p)
        if guess.isEmpty {
            if guessedLevelId == nil {
                print("[MapRouteView] no floor match at location; you may use picker")
                levelChoices = vLevelsSorted()
                levelPickerTitle = "Which floor are you on?"
                // showLevelPicker = true   // keep manual trigger
            }
        } else if guess.count == 1 {
            guessedLevelId = guess.first!
        }

        let prefer = guessedLevelId ?? guess.first
        guard let startId = nearestNavNodeId(to: p, preferredLevel: prefer) else {
            print("[MapRouteView] no nearby nav node")
            return
        }

        let changed = (startId != snappedStartNodeId)
        snappedStartNodeId = startId
        // print("[MapRouteView] snapped to node \(startId) (changed=\(changed))")

        // Live re-route only when navigating
        if isNavigating, liveRoutingEnabled, changed, let eUnit = selectedEnd, let eCoord = endTapCoord {
            if let endNodeId = nearestNavNodeId(to: eCoord, preferredLevel: eUnit.levelId) {
                let now = CACurrentMediaTime()
                if now - lastRerouteTime >= minRerouteInterval {
                    lastRerouteTime = now
                    print("[MapRouteView] live reroute…")
                    runAStar(start: startId, goal: endNodeId)
                }
            }
        }

        // Arrival detection (while navigating)
        if isNavigating, let target = endTargetCoord {
            let d = geod(p, target)
            if d <= arrivalThresholdMeters {
                errorText = "You’ve arrived."
                endNavigation(userInitiated: false)
            }
        }
    }

    // MARK: - Loading

    private func loadVenue() async {
        do {
            let v = try store.load(id: venueId)
            units    = v.units
            openings = v.openings
            fixtures = v.fixtures
            graph    = gb.buildGraph(venue: v)
            fitOnFirstLoad = true
            venueBounds = computeVenueBounds(units: v.units)
            print("[MapRouteView] venue loaded; units=\(v.units.count)")

            if let precomputedRoute = initialRoute, !precomputedRoute.isEmpty {
                pathPoints = precomputedRoute
            }

            // If we have an initial destination name (from AR Map Mode), auto-find and route to it
            var configuredInitialDestination = false

            if let destName = initialEndName, !destName.isEmpty {
                print("[MapRouteView] Looking for destination: '\(destName)'")

                // Find the destination unit by name (case-insensitive, partial match)
                let searchName = destName.lowercased()
                if let destUnit = units.first(where: {
                    ($0.name?.lowercased().contains(searchName) ?? false) ||
                    ($0.name?.lowercased() == searchName)
                }) {
                    print("[MapRouteView] ✅ Found destination unit: \(destUnit.name ?? destUnit.id)")

                    // Calculate center of the unit as tap coordinate
                    if let firstPoly = destUnit.polygons.first {
                        let center = polygonCenter(firstPoly)
                        print("[MapRouteView] Destination center: \(center)")
                        configureDestination(unit: destUnit, coordinate: center)
                        configuredInitialDestination = true
                    }
                } else {
                    print("[MapRouteView] ⚠️ Could not find unit matching '\(destName)'")
                    // List available unit names for debugging
                    let unitNames = units.compactMap { $0.name }.prefix(10)
                    print("[MapRouteView] Available units: \(unitNames)")
                }
            }

            if !configuredInitialDestination {
                let coordinateHint = initialDestinationPoint ?? initialRoute?.last
                if let hint = coordinateHint {
                    if configureDestinationUsingCoordinate(hint) {
                        configuredInitialDestination = true
                    } else {
                        print("[MapRouteView] ⚠️ Could not map coordinate hint to a unit: \(hint)")
                    }
                }
            }

            if !configuredInitialDestination {
                print("[MapRouteView] No initial destination provided")
            }
        } catch {
            self.errorText = error.localizedDescription
        }
    }

    /// Calculate center point of a polygon
    private func polygonCenter(_ poly: IMDFPolygon) -> IMDFPoint {
        let points = poly.outer
        guard !points.isEmpty else { return IMDFPoint(x: 0, y: 0) }
        let sumX = points.reduce(0.0) { $0 + $1.x }
        let sumY = points.reduce(0.0) { $0 + $1.y }
        return IMDFPoint(x: sumX / Double(points.count), y: sumY / Double(points.count))
    }

    private func configureDestination(unit: IMDFUnit, coordinate: IMDFPoint) {
        selectedEnd = unit
        endTapCoord = coordinate
        endTargetCoord = coordinate
        startMode = .myLocation
        loc.mode = .selecting
        loc.start()
        scheduleAutoRouteComputation()
    }

    private func configureDestinationUsingCoordinate(_ coordinate: IMDFPoint) -> Bool {
        guard let destUnit = unitContaining(point: coordinate) ?? nearestUnit(to: coordinate) else {
            return false
        }
        print("[MapRouteView] ✅ Matched coordinate hint to unit: \(destUnit.name ?? destUnit.id)")
        configureDestination(unit: destUnit, coordinate: coordinate)
        return true
    }

    private func scheduleAutoRouteComputation() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.autoComputeRouteToDestination()
        }
    }

    /// Auto-compute route from current location to pre-selected destination
    private func autoComputeRouteToDestination() {
        guard let eUnit = selectedEnd, let eCoord = endTapCoord else {
            print("[MapRouteView] Cannot auto-route: no destination set")
            return
        }

        guard let myFix = loc.latest else {
            print("[MapRouteView] Cannot auto-route: no location fix yet, will retry...")
            // Retry after location is available
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.autoComputeRouteToDestination()
            }
            return
        }

        let myP = IMDFPoint(x: myFix.coordinate.longitude, y: myFix.coordinate.latitude)
        print("[MapRouteView] Auto-routing from location \(myP) to \(eUnit.name ?? eUnit.id)")

        // Find nearest nav nodes
        guard let startNodeId = nearestNavNodeId(to: myP, preferredLevel: guessedLevelId),
              let endNodeId = nearestNavNodeId(to: eCoord, preferredLevel: eUnit.levelId) else {
            print("[MapRouteView] Cannot find nav nodes for auto-route")
            return
        }

        print("[MapRouteView] A* (auto) start=\(startNodeId) end=\(endNodeId)")
        runAStar(start: startNodeId, goal: endNodeId)

        // Store snapped start for live updates
        snappedStartNodeId = startNodeId

        // Automatically start navigation after route is computed
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if !self.pathPoints.isEmpty {
                print("[MapRouteView] Auto-starting navigation")
                self.beginNavigation()
            }
        }
    }    // MARK: - Helpers

    private func unitContaining(point: IMDFPoint) -> IMDFUnit? {
        for unit in units {
            if let poly = unit.polygons.first, polygonContains(point, poly: poly) {
                return unit
            }
        }
        return nil
    }

    private func nearestUnit(to point: IMDFPoint) -> IMDFUnit? {
        var best: IMDFUnit?
        var bestDistance = Double.infinity
        for unit in units {
            let distance = geod(point, unit.centroid)
            if distance < bestDistance {
                bestDistance = distance
                best = unit
            }
        }
        return best
    }

    private func nearestNavNodeId(to p: IMDFPoint, preferredLevel: String?) -> String? {
        var candidates = graph.nodes.values.filter { $0.id.hasPrefix("N:") }
        if let lvl = preferredLevel {
            let same = candidates.filter { $0.levelId == lvl }
            if !same.isEmpty { candidates = same }
        }
        var bestId: String?
        var bestD = Double.infinity
        for n in candidates {
            let d = geod(p, n.position)
            if d < bestD { bestD = d; bestId = n.id }
        }
        return bestId
    }

    private func geod(_ a: IMDFPoint, _ b: IMDFPoint) -> Double {
        let lat1 = a.y * .pi/180, lat2 = b.y * .pi/180
        let dLat = (b.y - a.y) * .pi/180, dLon = (b.x - a.x) * .pi/180
        let s = sin(dLat/2)*sin(dLat/2) + cos(lat1)*cos(lat2)*sin(dLon/2)*sin(dLon/2)
        let c = 2 * atan2(s.squareRoot(), (1 - s).squareRoot())
        return 6371000.0 * c
    }

    private func computeVenueBounds(units: [IMDFUnit]) -> (Double, Double, Double, Double) {
        var minX = Double.greatestFiniteMagnitude, maxX = -minX
        var minY = Double.greatestFiniteMagnitude, maxY = -minY
        for u in units {
            for poly in u.polygons {
                for p in poly.outer {
                    minX = min(minX, p.x); maxX = max(maxX, p.x)
                    minY = min(minY, p.y); maxY = max(maxY, p.y)
                }
            }
        }
        return (minX, maxX, minY, maxY)
    }

    /// > 0 → meters outside; <= 0 → inside or on edge
    private func outsideDistanceMeters(point p: IMDFPoint, bbox: (Double,Double,Double,Double)) -> Double {
        let (minX, maxX, minY, maxY) = bbox
        let clampX = min(max(p.x, minX), maxX)
        let clampY = min(max(p.y, minY), maxY)
        let nearest = IMDFPoint(x: clampX, y: clampY)
        let d = geod(p, nearest)
        if p.x >= minX && p.x <= maxX && p.y >= minY && p.y <= maxY { return 0 }
        return d
    }

    private func guessLevelId(at p: IMDFPoint) -> [String] {
        var hits = Set<String>()
        for u in units {
            if polygonContains(p, poly: u.polygons.first ?? IMDFPolygon(outer: [], holes: [])) {
                if let id = u.levelId { hits.insert(id) }
            }
        }
        return Array(hits)
    }

    private func polygonContains(_ p: IMDFPoint, poly: IMDFPolygon) -> Bool {
        func ring(_ pts: [IMDFPoint]) -> Bool {
            var inside = false
            var j = pts.count - 1
            for i in 0..<pts.count {
                let xi = pts[i].x, yi = pts[i].y
                let xj = pts[j].x, yj = pts[j].y
                let denom = (yj - yi)
                let xInt = denom != 0 ? (xj - xi) * (p.y - yi) / denom + xi : xi
                let intersect = ((yi > p.y) != (yj > p.y)) && (p.x < xInt)
                if intersect { inside.toggle() }
                j = i
            }
            return inside
        }
        guard !poly.outer.isEmpty else { return false }
        if !ring(poly.outer) { return false }
        for h in poly.holes { if ring(h) { return false } }
        return true
    }

    private func vLevelsSorted() -> [IMDFLevel] {
        var levels: [String: (String?, Int)] = [:]
        for u in units {
            if let lid = u.levelId {
                let old = levels[lid] ?? (nil, 0)
                levels[lid] = (old.0, old.1)
            }
        }
        return levels.keys.map { IMDFLevel(id: $0, name: nil, ordinal: 0) }
    }

    private func levelsByIds(_ ids: [String]) -> [IMDFLevel] {
        let set = Set(ids)
        return vLevelsSorted().filter { set.contains($0.id) }
    }

    private func levelDisplay(_ l: IMDFLevel) -> String {
        l.name ?? "Level \(l.ordinal != 0 ? l.ordinal : 0)"
    }
}
