import Foundation
import CoreMotion

enum NavMode: String {
    case ar
    case map2d
}

/// Publishes device pitch and a nav mode with hysteresis so it won't flap.
final class DevicePoseService: ObservableObject {
    @Published private(set) var pitchDeg: Double = 0        // -90 (flat, face up) ... +90 (flat, face down)
    @Published private(set) var tiltFromFlatDeg: Double = 0 // 0 = flat, 90 = upright

    // Default to map2d, but in Simulator start in Map mode since AR doesn't work
    #if targetEnvironment(simulator)
    @Published private(set) var navMode: NavMode = .map2d
    #else
    @Published private(set) var navMode: NavMode = .map2d
    #endif

    /// Manual override for mode (useful for Simulator or manual control)
    @Published var manualModeOverride: NavMode? = nil

    private let motion = CMMotionManager()
    private let queue  = OperationQueue()

    #if targetEnvironment(simulator)
    private var current: NavMode = .map2d  // Start in map mode for Simulator
    #else
    private var current: NavMode = .map2d
    #endif

    // Hysteresis thresholds (based on tilt from a flat table):
    // - Switch to AR if tilt ≥ 55° (phone close to upright).
    // - Switch back to 2D map if tilt ≤ 35° (phone returning to flat).
    private let toAR_ThresholdDeg: Double  = 55
    private let to2D_ThresholdDeg: Double = 35

    func start() {
        guard motion.isDeviceMotionAvailable else { return }
        motion.deviceMotionUpdateInterval = 1.0 / 30.0 // 30 Hz, light
        motion.startDeviceMotionUpdates(using: .xArbitraryCorrectedZVertical, to: queue) { [weak self] dm, _ in
            guard let self = self, let dm = dm else { return }
            // Pitch: rotation around device’s x-axis. Using z-vertical gives a stable gravity ref.
            // Convert to degrees and clamp to [-90, +90] range for intuition.
            let pitch = dm.attitude.pitch * 180.0 / .pi
            let clampedPitch = max(-90.0, min(90.0, pitch))

            // Use gravity to measure how far we are from lying flat (0°) versus upright (90°).
            let gz = max(-1.0, min(1.0, dm.gravity.z))
            let tilt = acos(abs(gz)) * 180.0 / .pi

            DispatchQueue.main.async {
                self.pitchDeg = clampedPitch
                self.tiltFromFlatDeg = tilt
                self.updateModeIfNeeded(tiltDeg: tilt)
            }
        }
    }

    func stop() {
        motion.stopDeviceMotionUpdates()
    }

    private func updateModeIfNeeded(tiltDeg: Double) {
        // If manual override is set, use it instead of automatic tilt detection
        if let override = manualModeOverride {
            if navMode != override {
                current = override
                navMode = override
                print("[DevicePose] mode -> \(override == .ar ? "AR" : "Map2D") (manual override)")
            }
            return
        }

        // Automatic tilt-based mode switching
        switch current {
        case .map2d:
            if tiltDeg >= toAR_ThresholdDeg {
                current = .ar
                navMode = .ar
                print("[DevicePose] mode -> AR (tilt=\(Int(tiltDeg))°)")
            }
        case .ar:
            if tiltDeg <= to2D_ThresholdDeg {
                current = .map2d
                navMode = .map2d
                print("[DevicePose] mode -> Map2D (tilt=\(Int(tiltDeg))°)")
            }
        }
    }

    /// Toggle between AR and Map modes manually (useful for Simulator)
    func toggleMode() {
        let newMode: NavMode = (navMode == .ar) ? .map2d : .ar
        manualModeOverride = newMode
        current = newMode
        navMode = newMode
        print("[DevicePose] mode toggled -> \(newMode == .ar ? "AR" : "Map2D")")
    }

    /// Clear manual override and return to automatic tilt-based switching
    func clearManualOverride() {
        manualModeOverride = nil
        print("[DevicePose] manual override cleared, returning to automatic mode")
    }
}
