import SwiftUI
import CoreLocation

struct VenuePickerView: View {
    private let store = LocalBundleIMDFStore()
    @State private var venues: [IMDFVenueMeta] = []
    @State private var errorText: String?
    @State private var autoNavigated = false

    // NEW: ask for permission at launch
    @StateObject private var loc = LocationService()

    /// Formats venue name by replacing underscores with spaces
    private func formatVenueName(_ name: String) -> String {
        name.replacingOccurrences(of: "_", with: " ")
    }

    var body: some View {
        NavigationStack {
            Group {
                if venues.count == 1, let singleVenue = venues.first {
                    // Skip venue picker and go directly to map
                    MapRouteView(venueId: singleVenue.id, venueName: formatVenueName(singleVenue.name))
                } else {
                    List(venues, id: \.id) { meta in
                        NavigationLink(formatVenueName(meta.name)) {
                            MapRouteView(venueId: meta.id, venueName: formatVenueName(meta.name))
                        }
                    }
                    .navigationTitle("IMDF Venues")
                }
            }
            .task {
                venues = store.list()
                if venues.isEmpty {
                    errorText = "No venues found. Add a blue folder IMDFVenues with venue subfolders to the app bundle."
                }
                // Prompt once on first launch
                loc.ensureAuthorization()
            }
            .alert("Info",
                   isPresented: Binding(get: { errorText != nil }, set: { _ in errorText = nil })) {
                Button("OK", role: .cancel) { }
            } message: { Text(errorText ?? "") }
        }
    }
}
