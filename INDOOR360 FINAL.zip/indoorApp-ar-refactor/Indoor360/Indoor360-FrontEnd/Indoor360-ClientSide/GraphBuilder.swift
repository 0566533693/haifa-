import Foundation

struct GraphBuilder {

    func buildGraph(venue v: IMDFVenue) -> IndoorGraph {
        var g = IndoorGraph()

        guard let ng = v.navGraph, !ng.nodes.isEmpty else {
            print("GraphBuilder: no navGraph present")
            return g
        }

        // 1) Walkable nav nodes
        let nodes = ng.nodes.filter { $0.walkable ?? true }
        let nodeById = Dictionary(uniqueKeysWithValues: nodes.map { ($0.id, $0) })
        func nk(_ id: String) -> String { "N:\(id)" }

        for n in nodes {
            g.addNode(IndoorGraphNode(id: nk(n.id), levelId: n.levelId, position: n.point))
        }

        // 2) Nav edges
        for e in ng.edges {
            guard let a = nodeById[e.fromId], let b = nodeById[e.toId] else { continue }
            let cost = e.weight ?? geod(a.point, b.point)
            g.addUndirectedEdge(nk(a.id), nk(b.id), cost: cost)
        }

        // 3) Openings lookup
        let openingsByUnit: [String: [IMDFOpening]] = {
            var dict: [String: [IMDFOpening]] = [:]
            for o in v.openings {
                for uid in o.unitIds { dict[uid, default: []].append(o) }
            }
            return dict
        }()

        // Debug counters
        var unitsWithOpenings = 0
        var doorEdgesAdded = 0
        var fallbackEdges = 0

        // 4) Units → add node, connect via doors
        for u in v.units {
            g.addNode(IndoorGraphNode(id: u.id, levelId: u.levelId, position: u.centroid))

            // Candidates: opening line midpoints → opening centroid → unit centroid
            var candidates: [IMDFPoint] = []
            if let list = openingsByUnit[u.id], !list.isEmpty {
                unitsWithOpenings += 1
                for o in list {
                    if let lines = o.lines, !lines.isEmpty {
                        for line in lines {
                            if let mid = polylineMidpoint(line) { candidates.append(mid) }
                        }
                    } else if let c = o.centroid {
                        candidates.append(c)
                    }
                }
            }
            if candidates.isEmpty { candidates.append(u.centroid) }

            // Pool: prefer same level
            let sameLevel = nodes.filter { ($0.levelId ?? u.levelId) == u.levelId }
            let pool = sameLevel.isEmpty ? nodes : sameLevel

            let maxDoorLinkMeters = 3.5
            var connected = 0
            var usedNav = Set<String>()

            for c in candidates {
                guard let best = nearestNavNode(to: c, in: pool) else { continue }
                let d = geod(c, best.point)
                if d <= maxDoorLinkMeters && !usedNav.contains(best.id) {
                    g.addUndirectedEdge(u.id, nk(best.id), cost: geod(u.centroid, best.point))
                    usedNav.insert(best.id)
                    connected += 1
                    doorEdgesAdded += 1
                    if connected >= 2 { break }
                }
            }

            if connected == 0, let nearest = nearestNavNode(to: u.centroid, in: pool) {
                g.addUndirectedEdge(u.id, nk(nearest.id), cost: geod(u.centroid, nearest.point))
                fallbackEdges += 1
            }
        }

        // 5) Cross-level transitions
        for t in v.transitions where t.unitIds.count >= 2 {
            for i in 0..<(t.unitIds.count - 1) {
                let a = t.unitIds[i], b = t.unitIds[i+1]
                if let na = g.nodes[a], let nb = g.nodes[b] {
                    g.addUndirectedEdge(a, b, cost: geod(na.position, nb.position) * 1.2)
                }
            }
        }

        print("GraphBuilder: navNodes=\(nodes.count) openings=\(v.openings.count) unitsWithOpenings=\(unitsWithOpenings) doorEdgesAdded=\(doorEdgesAdded) fallbackEdges=\(fallbackEdges)")
        return g
    }

    // MARK: helpers

    private func geod(_ a: IMDFPoint, _ b: IMDFPoint) -> Double {
        let lat1 = a.y * .pi/180, lat2 = b.y * .pi/180
        let dLat = (b.y - a.y) * .pi/180
        let dLon = (b.x - a.x) * .pi/180
        let s = sin(dLat/2)*sin(dLat/2) + cos(lat1)*cos(lat2)*sin(dLon/2)*sin(dLon/2)
        let c = 2 * atan2(s.squareRoot(), (1 - s).squareRoot())
        return 6371000.0 * c
    }

    private func nearestNavNode(to target: IMDFPoint, in nodes: [IMDFNavNode]) -> IMDFNavNode? {
        guard !nodes.isEmpty else { return nil }
        var best: (IMDFNavNode, Double)? = nil
        for n in nodes {
            let d = geod(n.point, target)
            if best == nil || d < best!.1 { best = (n, d) }
        }
        return best?.0
    }

    private func polylineMidpoint(_ pts: [IMDFPoint]) -> IMDFPoint? {
        guard pts.count >= 2 else { return pts.first }
        var total = 0.0
        var lens: [Double] = []
        for i in 0..<(pts.count - 1) {
            let d = geod(pts[i], pts[i+1]); lens.append(d); total += d
        }
        if total == 0 { return pts.first }
        var acc = 0.0
        let half = total / 2
        for i in 0..<(pts.count - 1) {
            let a = pts[i], b = pts[i+1], d = lens[i]
            if acc + d >= half {
                let t = (half - acc) / d
                return IMDFPoint(x: a.x + (b.x - a.x)*t, y: a.y + (b.y - a.y)*t)
            }
            acc += d
        }
        return pts.last
    }
}
