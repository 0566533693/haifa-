import Foundation
import CoreLocation

/// Utilities to clean up and enrich raw A* paths for rendering and guidance.
enum PathPostProcessor {

    // MARK: Public entry point

    /// Produce a display-ready path and coarse turn hints from raw IMDF points.
    /// - Parameters:
    ///   - raw: Raw path from A* (map order: [start ... end]).
    ///   - maxSegmentMeters: Densify long segments to ≤ this length (meters).
    ///   - smoothingPasses: Chaikin passes (0 = off). 1–2 recommended.
    ///   - simplifyToleranceMeters: Douglas–Peucker tolerance (0 = off).
    static func makeDisplayPath(
        from raw: [IMDFPoint],
        maxSegmentMeters: Double = 2.0,
        smoothingPasses: Int = 1,
        simplifyToleranceMeters: Double = 0.3
    ) -> (points: [IMDFPoint], turns: [TurnHint]) {
        guard raw.count >= 2 else { return (raw, []) }

        // 1) Optional simplify (reduces noise, preserves shape)
        let simplified = (simplifyToleranceMeters > 0)
            ? douglasPeucker(raw, epsilonMeters: simplifyToleranceMeters)
            : raw

        // 2) Densify for consistent sampling (helps smoothing + rendering)
        let dense = densify(simplified, maxSegmentMeters: maxSegmentMeters)

        // 3) Optional smoothing (Chaikin)
        let smooth = (smoothingPasses > 0)
            ? chaikin(dense, passes: smoothingPasses)
            : dense

        // 4) Turn hints on the simplified polyline
        let hints = turnHints(along: simplified)

        return (smooth, hints)
    }

    // MARK: - Turn hints

    struct TurnHint {
        enum Kind { case start, forward, left, right, finish }   // ← renamed from continue
        let index: Int
        let kind: Kind
        let angleDeg: Double?
        let position: IMDFPoint
    }

    private static func turnHints(along pts: [IMDFPoint]) -> [TurnHint] {
        guard pts.count >= 2 else { return [] }
        var out: [TurnHint] = []
        out.append(TurnHint(index: 0, kind: .start, angleDeg: nil, position: pts[0]))

        for i in 1..<(pts.count - 1) {
            let a = pts[i-1], b = pts[i], c = pts[i+1]
            let ang = signedTurnAngleDegrees(a, b, c) // +left, -right
            let absAng = abs(ang)

            if absAng >= 30 {
                out.append(TurnHint(index: i, kind: ang > 0 ? .left : .right, angleDeg: ang, position: b))
            } else if absAng <= 10 {
                if out.last?.kind != .forward {
                    out.append(TurnHint(index: i, kind: .forward, angleDeg: ang, position: b))
                }
            }
        }

        out.append(TurnHint(index: pts.count - 1, kind: .finish, angleDeg: nil, position: pts.last!))
        return out
    }

    private static func signedTurnAngleDegrees(_ a: IMDFPoint, _ b: IMDFPoint, _ c: IMDFPoint) -> Double {
        let v1 = (x: b.x - a.x, y: b.y - a.y)
        let v2 = (x: c.x - b.x, y: c.y - b.y)
        let cross = v1.x * v2.y - v1.y * v2.x
        let dot   = v1.x * v2.x + v1.y * v2.y
        return atan2(cross, dot) * 180.0 / .pi
    }

    // MARK: - Simplify (Douglas–Peucker)

    private static func douglasPeucker(_ pts: [IMDFPoint], epsilonMeters: Double) -> [IMDFPoint] {
        guard pts.count >= 3 else { return pts }

        func perpendicularDistanceMeters(_ p: IMDFPoint, _ a: IMDFPoint, _ b: IMDFPoint) -> Double {
            let ax = a.x, ay = a.y; let bx = b.x, by = b.y
            let px = p.x, py = p.y
            let dx = bx - ax, dy = by - ay
            if dx == 0 && dy == 0 { return geod(p, a) }
            let t = max(0, min(1, ((px - ax)*dx + (py - ay)*dy) / (dx*dx + dy*dy)))
            let proj = IMDFPoint(x: ax + t*dx, y: ay + t*dy)
            return geod(p, proj)
        }

        func recurse(_ arr: [IMDFPoint]) -> [IMDFPoint] {
            if arr.count < 3 { return arr }
            let start = arr.first!, end = arr.last!
            var index = 0
            var dMax: Double = 0
            for i in 1..<(arr.count - 1) {
                let d = perpendicularDistanceMeters(arr[i], start, end)
                if d > dMax { index = i; dMax = d }
            }
            if dMax > epsilonMeters {
                let left  = recurse(Array(arr[0...index]))
                let right = recurse(Array(arr[index...]))
                return left.dropLast() + right
            } else {
                return [start, end]
            }
        }

        return recurse(pts)
    }

    // MARK: - Densify

    private static func densify(_ pts: [IMDFPoint], maxSegmentMeters: Double) -> [IMDFPoint] {
        guard pts.count >= 2 else { return pts }
        var out: [IMDFPoint] = []
        for i in 0..<(pts.count - 1) {
            let a = pts[i], b = pts[i+1]
            out.append(a)
            let d = geod(a, b)
            if d > maxSegmentMeters {
                let steps = Int(ceil(d / maxSegmentMeters))
                for s in 1..<steps {
                    let t = Double(s) / Double(steps)
                    out.append(IMDFPoint(x: a.x + (b.x - a.x) * t,
                                         y: a.y + (b.y - a.y) * t))
                }
            }
        }
        out.append(pts.last!)
        return out
    }

    // MARK: - Chaikin smoothing

    private static func chaikin(_ pts: [IMDFPoint], passes: Int) -> [IMDFPoint] {
        guard pts.count >= 3, passes > 0 else { return pts }
        var current = pts
        for _ in 0..<passes {
            var next: [IMDFPoint] = [current.first!]
            for i in 0..<(current.count - 1) {
                let p0 = current[i], p1 = current[i+1]
                let q = IMDFPoint(x: 0.75*p0.x + 0.25*p1.x, y: 0.75*p0.y + 0.25*p1.y)
                let r = IMDFPoint(x: 0.25*p0.x + 0.75*p1.x, y: 0.25*p0.y + 0.75*p1.y)
                next.append(contentsOf: [q, r])
            }
            next.append(current.last!)
            current = next
        }
        return current
    }

    // MARK: - Geodesic helper

    private static func geod(_ a: IMDFPoint, _ b: IMDFPoint) -> Double {
        let lat1 = a.y * .pi/180, lat2 = b.y * .pi/180
        let dLat = (b.y - a.y) * .pi/180
        let dLon = (b.x - a.x) * .pi/180
        let s = sin(dLat/2)*sin(dLat/2) + cos(lat1)*cos(lat2)*sin(dLon/2)*sin(dLon/2)
        let c = 2 * atan2(s.squareRoot(), (1 - s).squareRoot())
        return 6371000.0 * c
    }
}
