import Foundation

public struct IMDFPoint: Hashable, Codable { public var x: Double; public var y: Double }

public struct IMDFPolygon: Hashable {
    public let outer: [IMDFPoint]
    public let holes: [[IMDFPoint]]
}

public struct IMDFAnchor: Hashable { public let id: String; public let name: String?; public let point: IMDFPoint }
public struct IMDFLevel:  Hashable { public let id: String; public let name: String?; public let ordinal: Int }

public struct IMDFUnit: Hashable {
    public let id: String
    public let name: String?
    public let levelId: String?
    public let centroid: IMDFPoint
    public let polygons: [IMDFPolygon]
}

public struct IMDFOpening: Hashable {
    public let id: String
    public let unitIds: [String]
    public let centroid: IMDFPoint?
    public let lines: [[IMDFPoint]]?   // optional; may be nil
}

public struct IMDFTransition: Hashable {
    public let id: String
    public let unitIds: [String]
    public let centroid: IMDFPoint?
    public let levelIds: [String]
}

// Optional, not required by MapKit view; present to keep parity with some datasets.
public struct IMDFFixture: Hashable {
    public let id: String
    public let kind: String?
    public let polygons: [IMDFPolygon]
    public let levelId: String?
}

// ===== Nav graph for grid routing =====
public struct IMDFNavNode: Hashable {
    public let id: String
    public let levelId: String?
    public let point: IMDFPoint
    public let kind: String?
    public let walkable: Bool?
}
public struct IMDFNavEdge: Hashable {
    public let fromId: String
    public let toId: String
    public let bidir: Bool
    public let weight: Double?
    public let kind: String?
}
public struct IMDFNavGraph: Hashable {
    public let nodes: [IMDFNavNode]
    public let edges: [IMDFNavEdge]
}

public struct IMDFVenue: Hashable {
    public let id: UUID
    public let name: String
    public let levels: [IMDFLevel]
    public let units: [IMDFUnit]
    public let openings: [IMDFOpening]
    public let transitions: [IMDFTransition]
    public let anchors: [IMDFAnchor]
    public let folderURL: URL
    public let navGraph: IMDFNavGraph?
    public let fixtures: [IMDFFixture]   // may be empty
}
