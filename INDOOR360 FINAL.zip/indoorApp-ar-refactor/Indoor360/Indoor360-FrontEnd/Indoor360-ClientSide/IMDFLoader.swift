import Foundation
import UIKit
import CryptoKit

public struct IMDFVenueMeta: Hashable {
    public let id: UUID
    public let name: String
    public let folderURL: URL
}

protocol IMDFStore {
    func list() -> [IMDFVenueMeta]
    func load(id: UUID) throws -> IMDFVenue
}

final class LocalBundleIMDFStore: IMDFStore {
    func list() -> [IMDFVenueMeta] {
        guard let bundleRoot = Bundle.main.resourceURL else { return [] }
        var metas: [IMDFVenueMeta] = []
        let fm = FileManager.default

        func dirIsIMDF(_ dir: URL) -> Bool {
            guard let entries = try? fm.contentsOfDirectory(atPath: dir.path) else { return false }
            let names = Set(entries.map { $0.lowercased() })
            return names.contains("unit.geojson") && names.contains("level.geojson")
        }
        func collect(in dir: URL, depth: Int = 0) {
            guard depth <= 3,
                  let urls = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])
            else { return }
            for u in urls {
                if ((try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false) {
                    if dirIsIMDF(u) {
                        metas.append(IMDFVenueMeta(id: deterministicUUID(from: u.path), name: u.lastPathComponent, folderURL: u))
                    } else {
                        collect(in: u, depth: depth + 1)
                    }
                }
            }
        }
        if let imdfRoot = Bundle.main.url(forResource: "IMDFVenues", withExtension: nil) {
            collect(in: imdfRoot)
        } else {
            collect(in: bundleRoot)
        }
        var seen = Set<String>()
        return metas.filter { seen.insert($0.folderURL.path).inserted }.sorted { $0.name < $1.name }
    }

    func load(id: UUID) throws -> IMDFVenue {
        guard let meta = list().first(where: { $0.id == id }) else {
            throw IMDFLoaderError.parseFailed("Venue meta not found.")
        }
        return try IMDFLoader().importPackage(from: meta.folderURL, forcedName: meta.name, forcedId: meta.id)
    }

    private func deterministicUUID(from s: String) -> UUID {
        let b = Array(SHA256.hash(data: Data(s.utf8)))
        let u = uuid_t(b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7],b[8],b[9],b[10],b[11],b[12],b[13],b[14],b[15])
        return UUID(uuid: u)
    }
}

enum IMDFLoaderError: Error, LocalizedError {
    case notDirectory
    case fileMissing(String)
    case parseFailed(String)
    var errorDescription: String? {
        switch self {
        case .notDirectory: return "Selected IMDF path is not a directory."
        case .fileMissing(let f): return "Missing required IMDF file: \(f)"
        case .parseFailed(let why): return "Failed to parse IMDF: \(why)"
        }
    }
}

final class IMDFLoader {

    /// Exact (case-insensitive) match for a filename anywhere under root.
    private func findExact(_ name: String, under root: URL) -> URL? {
        let want = name.lowercased()
        let e = FileManager.default.enumerator(at: root, includingPropertiesForKeys: nil)
        while let u = e?.nextObject() as? URL {
            if u.lastPathComponent.lowercased() == want { return u }
        }
        return nil
    }

    func importPackage(from folderURL: URL, forcedName: String? = nil, forcedId: UUID? = nil) throws -> IMDFVenue {
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: folderURL.path, isDirectory: &isDir), isDir.boolValue
        else { throw IMDFLoaderError.notDirectory }

        // Required (strict)
        guard let levelURL = findExact("level.geojson", under: folderURL) else {
            throw IMDFLoaderError.fileMissing("level.geojson")
        }
        guard let unitURL = findExact("unit.geojson", under: folderURL) else {
            throw IMDFLoaderError.fileMissing("unit.geojson")
        }

        // Optional (strict singular)
        let openingURL    = findExact("opening.geojson", under: folderURL)
        let transitionURL = findExact("transition.geojson", under: folderURL)
        let anchorURL     = findExact("anchor.geojson", under: folderURL)
        let fixtureURL    = findExact("fixture.geojson", under: folderURL)

        // Optional nav network
        let navNodesURL = findExact("nav_nodes_classified.geojson", under: folderURL)
                       ?? findExact("nav_nodes.geojson", under: folderURL)
        let navEdgesURL = findExact("nav_edges_walkable.geojson", under: folderURL)
                       ?? findExact("nav_edges.geojson", under: folderURL)

        // Parse
        let levels      = try parseLevels(levelURL)
        let units       = try parseUnits(unitURL)
        let openings    = (try? parseOpenings(openingURL)) ?? []
        let transitions = (try? parseTransitions(transitionURL)) ?? []
        let anchors     = (try? parseAnchors(anchorURL)) ?? []
        let fixtures    = (try? parseFixtures(fixtureURL)) ?? []

        let navNodes    = (try? parseNavNodes(navNodesURL)) ?? []
        let navEdges    = (try? parseNavEdges(navEdgesURL, nodes: navNodes)) ?? []
        let navGraph    = (navNodes.isEmpty && navEdges.isEmpty) ? nil : IMDFNavGraph(nodes: navNodes, edges: navEdges)

        print("IMDFLoader: levels=\(levels.count) units=\(units.count) openings=\(openings.count) transitions=\(transitions.count) fixtures=\(fixtures.count) navNodes=\(navNodes.count) navEdges=\(navEdges.count)")

        return IMDFVenue(
            id: forcedId ?? UUID(),
            name: forcedName ?? folderURL.lastPathComponent,
            levels: levels,
            units: units,
            openings: openings,
            transitions: transitions,
            anchors: anchors,
            folderURL: folderURL,
            navGraph: navGraph,
            fixtures: fixtures
        )
    }

    // MARK: JSON + geometry helpers (unchanged from your version)

    private func json(_ url: URL?) throws -> [String: Any] {
        guard let url = url else { throw IMDFLoaderError.fileMissing("Unknown") }
        let data = try Data(contentsOf: url)
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw IMDFLoaderError.parseFailed("Invalid JSON at \(url.lastPathComponent)")
        }
        return obj
    }

    private func pointFromGeometry(_ geomAny: Any?) -> IMDFPoint {
        guard let geom = geomAny as? [String: Any], let type = geom["type"] as? String else {
            return IMDFPoint(x: 0, y: 0)
        }
        if type == "Point", let c = geom["coordinates"] as? [Double], c.count >= 2 {
            return IMDFPoint(x: c[0], y: c[1])
        }
        return centroidFromGeometry(geomAny)
    }

    private func polygonsFromGeometry(_ geomAny: Any?) -> [IMDFPolygon] {
        guard let geom = geomAny as? [String: Any], let type = geom["type"] as? String else { return [] }
        func toRing(_ raw: [[Double]]) -> [IMDFPoint] {
            raw.compactMap { $0.count >= 2 ? IMDFPoint(x: $0[0], y: $0[1]) : nil }
        }
        switch type {
        case "Polygon":
            if let rings = geom["coordinates"] as? [[[Double]]], let outerRaw = rings.first {
                let outer = toRing(outerRaw)
                let holes = Array(rings.dropFirst()).map { toRing($0) }
                return [IMDFPolygon(outer: outer, holes: holes)]
            }
        case "MultiPolygon":
            if let polys = geom["coordinates"] as? [[[[Double]]]] {
                return polys.compactMap { rings in
                    guard let outerRaw = rings.first else { return nil }
                    let outer = toRing(outerRaw)
                    let holes = Array(rings.dropFirst()).map { toRing($0) }
                    return IMDFPolygon(outer: outer, holes: holes)
                }
            }
        default: break
        }
        return []
    }

    private func centroidFromGeometry(_ geomAny: Any?) -> IMDFPoint {
        guard let geom = geomAny as? [String: Any], let type = geom["type"] as? String else { return IMDFPoint(x: 0, y: 0) }
        switch type {
        case "Polygon":
            if let rings = geom["coordinates"] as? [[[Double]]], let outer = rings.first { return average(outer) }
        case "MultiPolygon":
            if let polys = geom["coordinates"] as? [[[[Double]]]], let first = polys.first, let outer = first.first { return average(outer) }
        case "LineString":
            if let arr = geom["coordinates"] as? [[Double]] { return average(arr) }
        case "MultiLineString":
            if let arrs = geom["coordinates"] as? [[[Double]]], let first = arrs.first { return average(first) }
        case "Point":
            if let c = geom["coordinates"] as? [Double], c.count >= 2 { return IMDFPoint(x: c[0], y: c[1]) }
        default: break
        }
        return IMDFPoint(x: 0, y: 0)
    }

    private func average(_ arr: [[Double]]) -> IMDFPoint {
        guard !arr.isEmpty else { return IMDFPoint(x: 0, y: 0) }
        var sx = 0.0, sy = 0.0
        for p in arr where p.count >= 2 { sx += p[0]; sy += p[1] }
        let n = Double(arr.count)
        return IMDFPoint(x: sx/n, y: sy/n)
    }

    func parseLevels(_ url: URL) throws -> [IMDFLevel] {
        let root = try json(url)
        let features = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFLevel] = []
        for f in features {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let ordinal = (props["ordinal"] as? Int) ?? (props["level_index"] as? Int) ?? (props["z_index"] as? Int) ?? 0
            let name = (props["name"] as? String) ?? (props["displayName"] as? String)
            out.append(IMDFLevel(id: id, name: name, ordinal: ordinal))
        }
        return out.sorted { $0.ordinal < $1.ordinal }
    }

    func parseUnits(_ url: URL) throws -> [IMDFUnit] {
        let root = try json(url)
        let features = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFUnit] = []
        for f in features {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let name = (props["name"] as? String) ?? (props["displayName"] as? String)
            let levelId = (props["level_id"] as? String) ?? (props["levelId"] as? String) ?? (props["level"] as? String)
            let centroid = centroidFromGeometry(f["geometry"])
            let polygons = polygonsFromGeometry(f["geometry"])
            out.append(IMDFUnit(id: id, name: name, levelId: levelId, centroid: centroid, polygons: polygons))
        }
        return out
    }

    func parseOpenings(_ url: URL?) throws -> [IMDFOpening] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFOpening] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let unitIds = (props["unit_ids"] as? [String])
                       ?? (props["units"] as? [String])
                       ?? (props["spaces"] as? [String])
                       ?? (props["connects"] as? [String])
                       ?? []
            var lines: [[IMDFPoint]]? = nil
            if let g = f["geometry"] as? [String: Any], let type = g["type"] as? String {
                if type == "LineString", let coords = g["coordinates"] as? [[Double]] {
                    lines = [coords.compactMap { $0.count >= 2 ? IMDFPoint(x: $0[0], y: $0[1]) : nil }]
                } else if type == "MultiLineString", let m = g["coordinates"] as? [[[Double]]] {
                    lines = m.map { $0.compactMap { $0.count >= 2 ? IMDFPoint(x: $0[0], y: $0[1]) : nil } }
                }
            }
            out.append(IMDFOpening(id: id, unitIds: unitIds, centroid: centroidFromGeometry(f["geometry"]), lines: lines))
        }
        return out
    }

    func parseTransitions(_ url: URL?) throws -> [IMDFTransition] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFTransition] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let unitIds = (props["unit_ids"] as? [String]) ?? (props["units"] as? [String]) ?? (props["spaces"] as? [String]) ?? []
            let levelIds = (props["level_ids"] as? [String]) ?? (props["levels"] as? [String]) ?? []
            out.append(IMDFTransition(id: id, unitIds: unitIds, centroid: centroidFromGeometry(f["geometry"]), levelIds: levelIds))
        }
        return out
    }

    func parseAnchors(_ url: URL?) throws -> [IMDFAnchor] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFAnchor] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let name = (props["name"] as? String) ?? (props["displayName"] as? String)
            out.append(IMDFAnchor(id: id, name: name, point: pointFromGeometry(f["geometry"])))
        }
        return out
    }

    func parseFixtures(_ url: URL?) throws -> [IMDFFixture] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFFixture] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let kind = (props["category"] as? String) ?? (props["kind"] as? String)
            let levelId = (props["level_id"] as? String) ?? (props["levelId"] as? String)
            let polys = polygonsFromGeometry(f["geometry"])
            out.append(IMDFFixture(id: id, kind: kind, polygons: polys, levelId: levelId))
        }
        return out
    }

    func parseNavNodes(_ url: URL?) throws -> [IMDFNavNode] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFNavNode] = []
        for f in feats {
            guard let g = f["geometry"] as? [String: Any],
                  let type = g["type"] as? String, type == "Point",
                  let coords = g["coordinates"] as? [Double], coords.count >= 2 else { continue }
            let p = f["properties"] as? [String: Any] ?? [:]
            let id  = (p["id"] as? String) ?? (f["id"] as? String) ?? UUID().uuidString
            let lvl = (p["level_id"] as? String)
            let kind = (p["kind"] as? String)
            let walk = (p["walkable"] as? Bool)
            out.append(IMDFNavNode(id: id, levelId: lvl, point: IMDFPoint(x: coords[0], y: coords[1]), kind: kind, walkable: walk))
        }
        return out
    }

    func parseNavEdges(_ url: URL?, nodes: [IMDFNavNode]) throws -> [IMDFNavEdge] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        let nodeIds = Set(nodes.map { $0.id })
        var out: [IMDFNavEdge] = []
        for f in feats {
            let p = f["properties"] as? [String: Any] ?? [:]
            guard let from = p["from"] as? String, let to = p["to"] as? String else { continue }
            guard nodeIds.contains(from), nodeIds.contains(to) else { continue }
            let bidir  = (p["bidir"] as? Bool) ?? true
            let weight = p["weight"] as? Double
            let kind   = p["kind"] as? String
            out.append(IMDFNavEdge(fromId: from, toId: to, bidir: bidir, weight: weight, kind: kind))
        }
        return out
    }
}
