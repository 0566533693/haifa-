import UIKit
import MapKit

// MARK: - Overlay carrying the path and style (fixed screen-point dots)
final class RouteDotsOverlay: NSObject, MKOverlay {
    let coords: [CLLocationCoordinate2D]
    let dotRadius: CGFloat        // in screen points
    let spacing: CGFloat          // center-to-center spacing in points
    let color: UIColor
    let userLocation: CLLocationCoordinate2D?  // Optional: only show dots ahead of user

    private let _bounding: MKMapRect
    var coordinate: CLLocationCoordinate2D { coords.first ?? kCLLocationCoordinate2DInvalid }
    var boundingMapRect: MKMapRect { _bounding }

    init(coords: [CLLocationCoordinate2D],
         dotRadius: CGFloat = 4,
         spacing: CGFloat = 12,
         color: UIColor = .systemBlue,
         userLocation: CLLocationCoordinate2D? = nil) {
        self.coords = coords
        self.dotRadius = dotRadius
        self.spacing = spacing
        self.color = color
        self.userLocation = userLocation

        // Conservative bounding rect: include all vertices
        var rect = MKMapRect.null
        for c in coords {
            let p = MKMapPoint(c)
            let r = MKMapRect(x: p.x, y: p.y, width: 0.1, height: 0.1)
            rect = rect.isNull ? r : rect.union(r)
        }
        self._bounding = rect
        super.init()
    }
}

// MARK: - Renderer that draws dots in view space (constant on-screen size)
final class RouteDotsRenderer: MKOverlayRenderer {
    private var dots: RouteDotsOverlay { overlay as! RouteDotsOverlay }

    override func draw(_ mapRect: MKMapRect, zoomScale: MKZoomScale, in ctx: CGContext) {
        let coords = dots.coords
        guard coords.count >= 2 else { return }

        ctx.saveGState()
        defer { ctx.restoreGState() }
        ctx.setFillColor(dots.color.cgColor)

        // Project to screen points
        let pts: [CGPoint] = coords.map { point(for: MKMapPoint($0)) }

        // Find user's position along the route if provided
        var startIndex = 0
        if let userLoc = dots.userLocation {
            let userPoint = point(for: MKMapPoint(userLoc))

            // Find the closest point on the route to the user
            var closestDistance: CGFloat = .infinity
            var closestIndex = 0

            for (i, pt) in pts.enumerated() {
                let distance = hypot(pt.x - userPoint.x, pt.y - userPoint.y)
                if distance < closestDistance {
                    closestDistance = distance
                    closestIndex = i
                }
            }

            // Only show dots ahead of user (from closest point onwards)
            startIndex = closestIndex
        }

        let spacing = max(1, dots.spacing)
        let r = max(0.5, dots.dotRadius)

        // Always draw a dot at the start position (either route start or user position)
        if startIndex < pts.count {
            let first = pts[startIndex]
            ctx.fillEllipse(in: CGRect(x: first.x - r, y: first.y - r, width: 2*r, height: 2*r))
        }

        // Accumulate distance along the path, place a dot every spacing pts
        var carried: CGFloat = 0  // distance since last dot
        for i in startIndex..<(pts.count - 1) {
            var a = pts[i]
            let b = pts[i+1]
            var segLen = hypot(b.x - a.x, b.y - a.y)
            if segLen == 0 { continue }

            // Unit direction from a -> b
            let ux = (b.x - a.x) / segLen
            let uy = (b.y - a.y) / segLen

            // Place as many dots as fit on this segment, honoring carry from previous segments
            while carried + segLen >= spacing {
                let need = spacing - carried
                // Advance from 'a' by need
                let cx = a.x + ux * need
                let cy = a.y + uy * need
                ctx.fillEllipse(in: CGRect(x: cx - r, y: cy - r, width: 2*r, height: 2*r))

                // Update segment cursor and bookkeeping
                a = CGPoint(x: cx, y: cy)
                segLen -= need
                carried = 0
            }

            // Whatever distance left on this segment contributes to the next dot
            carried += segLen
        }
    }
}

// MARK: - User Heading Arrow Overlay

final class UserHeadingArrowOverlay: NSObject, MKOverlay {
    let coordinate: CLLocationCoordinate2D
    let heading: CLLocationDirection  // degrees, 0 = North

    var boundingMapRect: MKMapRect {
        let point = MKMapPoint(coordinate)
        return MKMapRect(x: point.x - 100, y: point.y - 100, width: 200, height: 200)
    }

    init(coordinate: CLLocationCoordinate2D, heading: CLLocationDirection) {
        self.coordinate = coordinate
        self.heading = heading
        super.init()
    }
}

// MARK: - User Heading Arrow Renderer

final class UserHeadingArrowRenderer: MKOverlayRenderer {
    private var arrow: UserHeadingArrowOverlay { overlay as! UserHeadingArrowOverlay }

    override func draw(_ mapRect: MKMapRect, zoomScale: MKZoomScale, in ctx: CGContext) {
        ctx.saveGState()
        defer { ctx.restoreGState() }

        // Get user position in view coordinates
        let userPoint = point(for: MKMapPoint(arrow.coordinate))

        // Arrow properties (in screen points)
        let arrowSize: CGFloat = 30
        let arrowWidth: CGFloat = 20

        // Move to user position
        ctx.translateBy(x: userPoint.x, y: userPoint.y)

        // Rotate based on heading (convert from degrees to radians, adjust for coordinate system)
        // MapKit Y axis points down, so we need to adjust
        let rotationAngle = (arrow.heading - 90) * .pi / 180.0
        ctx.rotate(by: CGFloat(rotationAngle))

        // Draw arrow pointing right (will be rotated to heading direction)
        let arrowPath = CGMutablePath()
        arrowPath.move(to: CGPoint(x: arrowSize, y: 0))
        arrowPath.addLine(to: CGPoint(x: 0, y: -arrowWidth/2))
        arrowPath.addLine(to: CGPoint(x: arrowSize * 0.3, y: 0))
        arrowPath.addLine(to: CGPoint(x: 0, y: arrowWidth/2))
        arrowPath.closeSubpath()

        // Fill with blue color
        ctx.setFillColor(UIColor.systemBlue.cgColor)
        ctx.addPath(arrowPath)
        ctx.fillPath()

        // Add white stroke for visibility
        ctx.setStrokeColor(UIColor.white.cgColor)
        ctx.setLineWidth(2.0)
        ctx.addPath(arrowPath)
        ctx.strokePath()
    }
}
