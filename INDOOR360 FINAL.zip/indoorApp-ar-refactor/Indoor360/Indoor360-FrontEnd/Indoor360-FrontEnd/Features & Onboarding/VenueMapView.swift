import SwiftUI

struct VenueMapView: View {
    @EnvironmentObject private var router: NavigationRouter
    @EnvironmentObject private var motion: MotionManager

    @State private var lockout = false
    @State private var goToAR = false

    struct PwCPoi: Identifiable {
        let id = UUID()
        let name: String
        let icon: String
        let unit: CGPoint   // 0..1 normalized
    }

    private let pois: [PwCPoi] = [
        .init(name: "Reception",      icon: "person.crop.circle.badge.checkmark", unit: .init(x: 0.62, y: 0.28)),
        .init(name: "Restroom North", icon: "toilet.fill",                        unit: .init(x: 0.70, y: 0.35)),
        .init(name: "Theater",        icon: "facemask",                           unit: .init(x: 0.35, y: 0.55)),
        .init(name: "Elevator East",  icon: "arrow.up.arrow.down.circle.fill",    unit: .init(x: 0.18, y: 0.82)),
    ]

    var body: some View {
        ZStack(alignment: .top) {
            GeometryReader { geo in
                ZStack {
                    gridBackground
                    ForEach(pois) { poi in
                        MapPinView(title: poi.name, systemIcon: poi.icon)
                            .position(point(from: poi.unit, in: geo.size))
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }

            // Optional manual AR button
            HStack {
                Spacer()
                Button {
                    router.pushToAR()
                } label: {
                    Image(systemName: "viewfinder.circle")
                        .font(.system(size: 28))
                        .foregroundStyle(DSColor.accent)
                }
            }
            .padding(.trailing, 12)
            .padding(.top, 12)
        }
        .navigationTitle("Venue Map")
        .navigationBarTitleDisplayMode(.inline)
        .background(AppBackgroundView().ignoresSafeArea())

        // iOS 17+ two-parameter onChange (no deprecation)
        .onChange(of: motion.isRaised) { oldValue, newValue in
            guard !lockout else { return }
            if newValue {       // phone up → go AR
                withAnimation(.easeInOut(duration: 0.45)) {
                    router.pushToAR()
                }
                engageLockout()
            }
        }
        .onAppear { motion.start() }
        .onDisappear { motion.stop() }
    }

    private func engageLockout() {
        lockout = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            lockout = false
        }
    }

    private var gridBackground: some View {
        Canvas { context, size in
            let spacing: CGFloat = 28
            var path = Path()

            var y: CGFloat = 0
            while y <= size.height {
                path.move(to: CGPoint(x: 0, y: y))
                path.addLine(to: CGPoint(x: size.width, y: y))
                y += spacing
            }

            var x: CGFloat = 0
            while x <= size.width {
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
                x += spacing
            }

            context.stroke(path, with: .color(.white.opacity(0.06)), lineWidth: 1)
        }
        .background(Color.black.opacity(0.86))
    }

    private func point(from unit: CGPoint, in size: CGSize) -> CGPoint {
        CGPoint(x: unit.x * size.width, y: unit.y * size.height)
    }
}

private struct MapPinView: View {
    let title: String
    let systemIcon: String
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: systemIcon)
                .foregroundStyle(Color.white)
                .frame(width: 26, height: 26)
                .background(Circle().fill(DSColor.accent))
            Text(title)
                .font(Typography.bodyEmphasis)
                .foregroundStyle(Color.white)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color.white.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}
