import SwiftUI

// MARK: - Models (lean & Codable ready if you later back them by an API)

struct HomeQuickAction: Identifiable {
    enum Route { case startNav, meetings, directory, arLive, facilities }
    let id = UUID()
    let icon: String
    let title: String
    let route: Route
}

extension HomeQuickAction {
    static let sample: [HomeQuickAction] = [
        .init(icon: "location",      title: "Start Nav",      route: .startNav),
        .init(icon: "calendar",      title: "My Meetings",    route: .meetings),
        .init(icon: "building.2",    title: "Directory",      route: .directory),
        .init(icon: "camera.viewfinder", title: "AR Live",    route: .arLive),
        .init(icon: "wrench.and.screwdriver", title: "Service Desk", route: .facilities),
        .init(icon: "printer",       title: "Find Printer",   route: .directory),
        .init(icon: "cup.and.saucer",title: "Find Café",      route: .directory),
        .init(icon: "person.2",      title: "Find Colleague", route: .directory)
    ]
}

struct MeetingCard: Identifiable {
    let id = UUID()
    let title: String
    let room: String
    let time: String
}
extension MeetingCard {
    static let sample: [MeetingCard] = [
        .init(title: "Sprint Planning", room: "E1 · Atlas", time: "09:30 – 10:15"),
        .init(title: "Client Sync",     room: "N2 · Mercury", time: "11:00 – 11:30"),
        .init(title: "Town Hall",       room: "Auditorium",   time: "16:00 – 17:00")
    ]
}

struct ServiceChip: Identifiable {
    enum Kind { case findRoom, findDesk, findColleague, findPrinter, findCafe, findRestroom, requestSupport }
    let id = UUID()
    let icon: String
    let title: String
    let kind: Kind
}
extension ServiceChip {
    static let sample: [ServiceChip] = [
        .init(icon: "door.left.hand.open", title: "Find Room",     kind: .findRoom),
        .init(icon: "deskview",            title: "Find Desk",     kind: .findDesk),
        .init(icon: "person.2",            title: "Find Colleague",kind: .findColleague),
        .init(icon: "printer",             title: "Find Printer",  kind: .findPrinter),
        .init(icon: "cup.and.saucer",      title: "Find Café",     kind: .findCafe),
        .init(icon: "toilet",              title: "Restrooms",     kind: .findRestroom),
        .init(icon: "exclamationmark.bubble", title: "Request Support", kind: .requestSupport)
    ]
}

struct Highlight: Identifiable {
    let id = UUID()
    let imageSystem: String
    let title: String
    let subtitle: String
}
extension Highlight {
    static let sample: [Highlight] = [
        .init(imageSystem: "person.3.sequence", title: "Innovation Hub", subtitle: "Level 7"),
        .init(imageSystem: "leaf",              title: "Green Terrace",   subtitle: "Level 5"),
        .init(imageSystem: "fork.knife",        title: "Main Café",       subtitle: "Level 3"),
        .init(imageSystem: "photo.on.rectangle",title: "Experience Lab",  subtitle: "Level 9")
    ]
}
