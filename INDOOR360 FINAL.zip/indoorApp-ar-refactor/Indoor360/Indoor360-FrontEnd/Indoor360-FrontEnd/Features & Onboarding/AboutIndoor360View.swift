import SwiftUI

struct AboutIndoor360View: View {
    private var version: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        let b = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
        return "Version \(v) (\(b))"
    }

    var body: some View {
        ScrollView {
            VStack(spacing: Space.lg) {

                Card {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Indoor360")
                            .font(Typography.headlineM)
                        Text(version)
                            .font(Typography.caption)
                            .foregroundStyle(DSColor.textSecondary)
                        Text("Indoor wayfinding with accessible, step-free routing, AR guidance, and personalized preferences.")
                            .font(Typography.body)
                            .foregroundStyle(DSColor.textPrimary)
                            .padding(.top, 4)
                    }
                }

                Card {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Key Features")
                            .font(Typography.bodyEmphasis)
                        FeatureRow(icon: "viewfinder", title: "AR Guidance",
                                   detail: "Camera-based arrows and callouts overlaid on the real world.")
                        FeatureRow(icon: "map", title: "2D Maps",
                                   detail: "Clear step-by-step paths with step-free options.")
                        FeatureRow(icon: "bookmark", title: "Saved Places",
                                   detail: "Quickly jump to your frequent destinations.")
                        FeatureRow(icon: "person.2.wave.2", title: "Accessibility",
                                   detail: "High contrast, text size control, voice input and haptics.")
                        FeatureRow(icon: "qrcode", title: "QR Anchors",
                                   detail: "Scan venue codes to calibrate indoor position and improve accuracy.")
                    }
                }

                Spacer(minLength: Space.xl)
            }
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.lg)
            .padding(.bottom, Space.xl)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .navigationTitle("About Indoor360")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct FeatureRow: View {
    let icon: String
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon).foregroundStyle(DSColor.accent).frame(width: 22)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(Typography.bodyEmphasis)
                Text(detail).font(Typography.caption).foregroundStyle(DSColor.textSecondary)
            }
        }
    }
}

private struct LinkRow: View {
    let title: String
    let systemImage: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack {
                Label(title, systemImage: systemImage)
                    .foregroundStyle(DSColor.textPrimary)
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.secondary)
            }
            .padding(.vertical, 8)
        }
        .buttonStyle(.plain)
    }
}
