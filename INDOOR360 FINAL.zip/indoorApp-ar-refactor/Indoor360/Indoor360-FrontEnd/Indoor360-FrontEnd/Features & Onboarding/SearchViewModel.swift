import Foundation
import Combine

// MARK: - Models used with the backend

/// Body for POST /api/user/{user_id}/navigation
struct NavigationLogRequest: Encodable {
    let fromPoiId: Int
    let toPoiId: Int
    let distanceM: Double
    let durationSec: Int
}

final class SearchViewModel: ObservableObject {
    @Published var query: String = ""
    @Published var results: [POI] = []
    @Published var recents: [String] = SearchHistoryStore.load()
    @Published var isSearching: Bool = false

    // Last backend route (used by SearchView / RouteDebugView)
    @Published var lastRoute: RouteResponseDTO? = nil

    // When NLP succeeds, this gets set (used for label in RouteDebugView)
    @Published var nlpResolved: (poiId: Int, name: String)? = nil

    // all NLP matches returned from backend
    @Published var nlpMatches: [NLPMatch] = []

    /// Starting POI ID for routing (set after QR scan, or use default)
    /// Default is 283 (first valid POI in database)
    var startPoiId: Int = 283

    private let service: POIService
    private var bag = Set<AnyCancellable>()

    /// Current backend user id from the session, if available.
    private var backendUserId: Int? {
        SessionStore.shared.current?.id
    }

    init(service: POIService = RemotePOIService()) {
        self.service = service
        bind()

        // Load recents from backend as soon as the VM is created
        Task {
            await self.refreshRecentsFromBackend()
        }
    }

    private func bind() {
        $query
            .removeDuplicates()
            .debounce(for: .milliseconds(250), scheduler: DispatchQueue.main)
            .sink { [weak self] q in
                guard let self else { return }

                if q.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    self.isSearching = false
                    self.results = []
                    return
                }

                self.isSearching = true

                self.service.searchPOIs(query: q)
                    .receive(on: DispatchQueue.main)
                    .sink { [weak self] items in
                        self?.isSearching = false
                        self?.results = items
                    }
                    .store(in: &self.bag)
            }
            .store(in: &bag)
    }

    func selectResult(_ poi: POI) {
        // Local history (existing behaviour)
        SearchHistoryStore.add(query)
        recents = SearchHistoryStore.load()
    }

    func tapRecent(_ term: String) {
        query = term
    }

    func clearRecents() {
        SearchHistoryStore.clear()
        recents = []
    }
}

// MARK: - NLP + Route + DB integration

@MainActor
extension SearchViewModel {

    /// Use backend NLP then backend /api/path/route.
    /// Called from SearchView (mic / Go button / keyboard submit).
    func resolveWithNLPAndRoute() async {
        let text = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }

        isSearching = true
        defer { isSearching = false }

        do {
            // 1) Call NLP backend → [NLPMatch]
            let matches = try await NLPBridge.resolve(text)
            self.nlpMatches = matches

            print("NLP decoded \(matches.count) matches for '\(text)'")
            for m in matches {
                print("  match id=\(m.poiId) name=\(m.poiName) floor=\(m.floorId) conf=\(m.confidence)")
            }

            // 2) Pick the best by confidence
            guard let best = matches.max(by: { $0.confidence < $1.confidence }) else {
                print("NLP: no match for '\(text)'")
                return
            }

            // Save NLP result for UI / debug sheet
            self.nlpResolved = (poiId: best.poiId, name: best.poiName)

            // 2.5) Save this search to PostgreSQL (fire-and-forget)
            Task {
                await self.saveSearchToBackend(
                    query: text,
                    poiId: best.poiId,
                    label: best.poiName
                )

                // After saving, reload recents from backend so UI shows them
                await self.refreshRecentsFromBackend()
            }

            // 3) Route from backend
            // Use startPoiId (set after QR scan) or default to 283
            let route = try await PathClient().route(from: startPoiId, to: best.poiId)
            print("Got backend route: \(route.path.count) segments, length \(route.lengthM)m")
            self.lastRoute = route

            // 4) Log navigation session to backend (fire-and-forget)
            let distance = route.lengthM
            let duration = max(1, Int(distance / 1.2)) // rough estimate, ~1.2 m/s walking

            Task {
                guard let userId = self.backendUserId else {
                    print("No backend user ID; skipping navigation log")
                    return
                }

                do {
                    // For now we log only the destination POI for both from/to.
                    let log = NavigationLogRequest(
                        fromPoiId: best.poiId,
                        toPoiId:   best.poiId,
                        distanceM: distance,
                        durationSec: duration
                    )

                    struct EmptyResponse: Decodable {}
                    _ = try await APIClient.shared.postJSON(
                        "/api/user/\(userId)/navigation",
                        body: log,
                        as: EmptyResponse.self
                    )

                    print("Logged navigation to backend")
                } catch {
                    print("Failed to log navigation:", error)
                }
            }

        } catch {
            self.nlpMatches = []     // clear on error
            print("Route / NLP error:", error)
        }
    }

    /// Simple health check button for debugging.
    func debugCheckNLPHealth() async {
        do {
            let ok = try await NLPBridge.health()
            print("NLP health =", ok)
        } catch {
            print("NLP health error:", error)
        }
    }

    /// Direct route test helper.
    func debugTestRouteDemo(from fromId: Int = 1, to toId: Int = 688) async {
        do {
            let client = PathClient()
            let route  = try await client.route(from: fromId, to: toId)
            print(
                "Debug route:",
                "segments =", route.path.count,
                "distance_m =", route.lengthM
            )
            self.lastRoute = route
        } catch {
            print("Debug route error:", error)
        }
    }

    // MARK: - DB helper methods

    /// Load latest N search queries from backend DB → fill recents
    func refreshRecentsFromBackend(limit: Int = 10) async {
        guard let userId = backendUserId else {
            print("No backend user ID; using local recents only")
            self.recents = SearchHistoryStore.load()
            return
        }

        do {
            let items: [SearchHistoryItem] = try await APIClient.shared.getJSON(
                "/api/user/\(userId)/searches",
                as: [SearchHistoryItem].self
            )

            let queries = items.map { $0.query }
            self.recents = queries
            print("Loaded \(queries.count) recents from backend")
        } catch {
            print("Failed to load backend recents:", error)
            self.recents = SearchHistoryStore.load()
        }
    }

    /// Save one search to backend DB
    private func saveSearchToBackend(query: String, poiId: Int, label: String) async {
        guard let userId = backendUserId else {
            print("No backend user ID; skipping saveSearchToBackend")
            return
        }

        let body = SearchHistoryIn(
            query: query,
            resolvedPoiId: poiId,
            resolvedLabel: label
        )

        do {
            _ = try await APIClient.shared.postJSON(
                "/api/user/\(userId)/searches",
                body: body,
                as: SearchHistoryItem.self
            )
            print("Saved search '\(query)' for poi \(poiId) to backend")
        } catch {
            print("Failed to save search:", error)
        }
    }
}
