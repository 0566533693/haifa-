import SwiftUI
import Combine

enum AppRoute: Hashable {
    case routeStart
    case venueMap
}

// Keep enum as-is; the computed `stage` below enforces the new order.
private enum Stage { case onboarding, permissions, auth, tabs }
private enum RootTab: Int, CaseIterable { case home = 0, more = 1 }

struct RootRouterView: View {

    // Stage flags
    @AppStorage("onboardingDone") private var onboardingDone: Bool = false
    @AppStorage("permissionsDone") private var permissionsDone: Bool = false
    @AppStorage("isAuthenticated") private var isAuthenticated: Bool = false
    @AppStorage("isGuest") private var isGuest: Bool = false

    // Theme (MoreView writes: "system" | "light" | "dark")
    @AppStorage("appTheme") private var appTheme: String = "system"

    // Home navigation (RouteStart → VenueMap)
    @State private var homePath: [AppRoute] = []

    // Tabs
    @State private var selectedTab: RootTab = .home
    @Namespace private var tabAnim

    // AR presentation
    @State private var isARPresented: Bool = false
    @State private var isVenueMapActive: Bool = false
    @State private var orientationCancellable: AnyCancellable?

    // QR presentation (center button)
    @State private var showQRScanner: Bool = false

    // ---------------------------------------------------------
    // MARK: BODY
    // ---------------------------------------------------------
    var body: some View {
        contentView
    }

    @ViewBuilder
    private var contentView: some View {
        switch stage {
        case .onboarding:
            OnboardingView().transition(.opacity)

        case .auth:
            AuthView().transition(.opacity)

        case .permissions:
            PermissionsView().transition(.opacity)

        case .tabs:
            mainTabsView
        }
    }

    // ---------------------------------------------------------
    // MARK: MAIN TABS VIEW
    // ---------------------------------------------------------
    @ViewBuilder
    private var mainTabsView: some View {
        ZStack {
            tabsContentView
            tabBarOverlay
        }
        .fullScreenCover(isPresented: $isARPresented, onDismiss: { isARPresented = false }) {
            ARNavView()
        }
        .sheet(isPresented: $showQRScanner) {
            NavigationStack { QRScanView() }
        }
        .preferredColorScheme(colorSchemeFor(appTheme))
        .onAppear(perform: startOrientationBinding)
        .onDisappear(perform: stopOrientationBinding)
    }

    // ---------------------------------------------------------
    // MARK: TABS SWITCH LOGIC
    // ---------------------------------------------------------
    @ViewBuilder
    private var tabsContentView: some View {
        switch selectedTab {
        case .home:
            NavigationStack(path: $homePath) {
                HomeView()
                    .navigationDestination(for: AppRoute.self) { route in
                        switch route {
                        case .routeStart:
                            RouteStartView()
                                .toolbar {
                                    ToolbarItem(placement: .navigationBarLeading) {
                                        Button { homePath.removeAll() } label: {
                                            Image(systemName: "chevron.backward")
                                            Text("Home")
                                        }
                                    }
                                }

                        case .venueMap:
                            VenueMapView()
                                .onAppear { isVenueMapActive = true }
                                .onDisappear { isVenueMapActive = false }
                                .toolbar {
                                    ToolbarItem(placement: .navigationBarLeading) {
                                        Button {
                                            if !homePath.isEmpty {
                                                _ = homePath.removeLast()
                                            }
                                        } label: {
                                            Image(systemName: "chevron.backward")
                                            Text("Start")
                                        }
                                    }
                                    ToolbarItem(placement: .navigationBarTrailing) {
                                        Button { isARPresented = true } label: {
                                            Image(systemName: "arkit")
                                        }
                                        .accessibilityLabel("Start AR")
                                    }
                                }
                        }
                    }
                    .onOpenURL { handleDeepLink($0) }
            }

        case .more:
            NavigationStack {
                MoreView()
            }
        }
    }

    // ---------------------------------------------------------
    // MARK: TAB BAR
    // ---------------------------------------------------------
    @ViewBuilder
    private var tabBarOverlay: some View {
        VStack {
            Spacer()
            CustomTabBar(
                selected: $selectedTab,
                namespace: tabAnim,
                qrTap: { showQRScanner = true }
            )
            .padding(.horizontal, 16)
            .padding(.bottom, 12)
        }
        .ignoresSafeArea(.keyboard)
    }

    // ---------------------------------------------------------
    // MARK: STAGE ORDER
    // ---------------------------------------------------------
    private var stage: Stage {
        if !onboardingDone { return .onboarding }
        if !isAuthenticated && !isGuest { return .auth }       // Auth BEFORE permissions
        if !permissionsDone { return .permissions }
        return .tabs
    }

    // ---------------------------------------------------------
    // MARK: ORIENTATION → AR
    // ---------------------------------------------------------
    private func startOrientationBinding() {
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
        orientationCancellable = NotificationCenter.default
            .publisher(for: UIDevice.orientationDidChangeNotification)
            .receive(on: DispatchQueue.main)
            .sink { _ in
                guard isVenueMapActive else { return }
                let o = UIDevice.current.orientation
                if (o == .portrait || o == .portraitUpsideDown || o == .faceUp) {
                    if !isARPresented { isARPresented = true }
                } else if (o == .landscapeLeft || o == .landscapeRight || o == .faceDown) {
                    if isARPresented { isARPresented = false }
                }
            }
    }

    private func stopOrientationBinding() {
        orientationCancellable?.cancel()
        orientationCancellable = nil
        UIDevice.current.endGeneratingDeviceOrientationNotifications()
    }

    // ---------------------------------------------------------
    // MARK: DEEP LINK
    // ---------------------------------------------------------
    private func handleDeepLink(_ url: URL) {
        guard url.scheme?.lowercased() == "indoor360" else { return }
        if homePath.isEmpty { homePath.append(.routeStart) }
        homePath.append(.venueMap)
    }

    // ---------------------------------------------------------
    // MARK: THEME
    // ---------------------------------------------------------
    private func colorSchemeFor(_ setting: String) -> ColorScheme? {
        switch setting.lowercased() {
        case "light": return .light
        case "dark":  return .dark
        default:      return nil // system
        }
    }
}

//
// MARK: ──────────────────────────────
// MARK: Custom Tab Bar
// MARK: ──────────────────────────────
//

private struct CustomTabBar: View {
    @Binding var selected: RootTab
    var namespace: Namespace.ID
    var qrTap: () -> Void

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .stroke(Color.white.opacity(0.08), lineWidth: 1)
                )
                .shadow(color: .black.opacity(0.35), radius: 16, x: 0, y: 8)

            HStack {
                Button {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.9)) {
                        selected = .home
                    }
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "house.fill")
                            .font(.title3.weight(.semibold))
                        Text("Home")
                            .font(.footnote.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity)
                }

                Spacer().frame(width: 72)

                Button {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.9)) {
                        selected = .more
                    }
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "line.3.horizontal.circle.fill")
                            .font(.title3.weight(.semibold))
                        Text("More")
                            .font(.footnote.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 18)

            VStack {
                Button(action: qrTap) {
                    Image(systemName: "qrcode.viewfinder")
                        .font(.title.weight(.bold))
                        .frame(width: 56, height: 56)
                        .background(Circle().fill(Color.white.opacity(0.20)))
                        .overlay(Circle().stroke(Color.white.opacity(0.25), lineWidth: 1))
                        .shadow(color: .black.opacity(0.35), radius: 12, x: 0, y: 6)
                }
                .buttonStyle(.plain)
            }
            .offset(y: -24)
        }
        .frame(height: 64)
    }
}
