import SwiftUI

// SavedPlace model is now imported from Models/SavedPlace.swift
// Category model is imported from Models/Category.swift

struct ProfileView: View {
    @EnvironmentObject private var appState: AppState

    // MARK: Routing
    @State private var goToRoute = false

    // MARK: Accessibility (persisted)
    @AppStorage("axHighContrast") private var axHighContrast: Bool = false
    @AppStorage("axTextScale")    private var axTextScale: Int = 100
    @AppStorage("axVoiceInput")   private var axVoiceInput: Bool = true
    @AppStorage("axHaptics")      private var axHaptics: Bool = true

    // Edit sheet
    @State private var showEdit = false
    @State private var draftName = ""
    @State private var draftEmail = ""
    @State private var draftPhone = ""
    @State private var draftDOB = ""

    // Change password sheet
    @State private var showChangePassword = false
    @State private var currentPassword = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    @State private var changePasswordError: String?
    @State private var isChangingPassword = false

    // Profile update state
    @State private var isSavingProfile = false
    @State private var profileUpdateError: String?

    // Saved places (from API)
    @State private var categories: [Category] = []
    @State private var savedPlaces: [SavedPlace] = []
    @State private var isLoadingSavedPlaces = false
    @State private var savedPlacesError: String?

    @State private var showAddPlace = false
    @State private var newPlaceTitle: String = ""
    @State private var newPlaceCategory: String = ""
    @State private var newPlaceNotes: String = ""
    @State private var isCreatingPlace = false

    private var isLoggedIn: Bool { appState.isAuthenticated && !appState.isGuest }

    // Change password validation
    private var isPasswordChangeValid: Bool {
        !currentPassword.isEmpty &&
        newPassword.count >= 8 &&
        newPassword == confirmPassword
    }

    // MARK: - Backend: load categories + saved places

    @MainActor
    private func loadCategoriesAndPlaces() async {
        do {
            // Load categories
            categories = try await SavedPlacesService.getCategories()

            // Set default category if not set
            if newPlaceCategory.isEmpty, let firstCategory = categories.first {
                newPlaceCategory = firstCategory.name
            }

            // Load saved places
            isLoadingSavedPlaces = true
            savedPlacesError = nil
            savedPlaces = try await SavedPlacesService.getSavedPlaces()
            isLoadingSavedPlaces = false
        } catch SavedPlacesError.unauthorized {
            savedPlacesError = "Please log in to view saved places"
            isLoadingSavedPlaces = false
        } catch {
            savedPlacesError = error.localizedDescription
            isLoadingSavedPlaces = false
        }
    }

    @MainActor
    private func createSavedPlace() async {
        let title = newPlaceTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty else { return }

        isCreatingPlace = true
        defer { isCreatingPlace = false }

        do {
            let newPlace = try await SavedPlacesService.createSavedPlace(
                title: title,
                categoryName: newPlaceCategory,
                notes: newPlaceNotes.isEmpty ? nil : newPlaceNotes
            )
            savedPlaces.insert(newPlace, at: 0)

            // Reset form
            newPlaceTitle = ""
            newPlaceNotes = ""
            if let firstCategory = categories.first {
                newPlaceCategory = firstCategory.name
            }

            if axHaptics { Haptics.light() }
            showAddPlace = false
        } catch {
            savedPlacesError = error.localizedDescription
        }
    }

    @MainActor
    private func deleteSavedPlace(_ place: SavedPlace) async {
        do {
            try await SavedPlacesService.deleteSavedPlace(id: place.id)
            withAnimation {
                savedPlaces.removeAll { $0.id == place.id }
            }
            if axHaptics { Haptics.light() }
        } catch {
            savedPlacesError = error.localizedDescription
        }
    }

    // MARK: - Backend: auth actions (profile + password)

    @MainActor
    private func handleChangePassword() async {
        changePasswordError = nil
        isChangingPassword = true
        defer { isChangingPassword = false }

        do {
            try await AuthService.changePassword(
                currentPassword: currentPassword,
                newPassword: newPassword
            )

            if axHaptics { Haptics.light() }
            showChangePassword = false

        } catch {
            changePasswordError = error.localizedDescription
            if axHaptics { Haptics.light() }
        }
    }

    @MainActor
    private func handleSaveProfile() async {
        profileUpdateError = nil
        isSavingProfile = true
        defer { isSavingProfile = false }

        do {
            let trimmedName = draftName.trimmingCharacters(in: .whitespacesAndNewlines)
            let trimmedPhone = draftPhone.trimmingCharacters(in: .whitespacesAndNewlines)
            let trimmedDOB = draftDOB.trimmingCharacters(in: .whitespacesAndNewlines)

            // Only send non-empty values
            let nameToSend = trimmedName.isEmpty ? nil : trimmedName
            let phoneToSend = trimmedPhone.isEmpty ? nil : trimmedPhone
            let dobToSend = trimmedDOB.isEmpty ? nil : trimmedDOB

            let updatedUser = try await AuthService.updateProfile(
                name: nameToSend,
                phone: phoneToSend,
                dateOfBirth: dobToSend
            )

            // Update appState with new user data
            appState.currentUser = updatedUser

            if axHaptics { Haptics.light() }
            showEdit = false

        } catch {
            profileUpdateError = error.localizedDescription
            if axHaptics { Haptics.light() }
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: Space.lg) {

                headerCard

                if isLoggedIn {
                    personalInfoCard
                    savedPlacesCard
                } else {
                    guestCalloutCard
                }

                accessibilityCard

                if isLoggedIn {
                    accountActionsCard
                }

                Spacer(minLength: Space.xl)
            }
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.lg)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)

        .navigationDestination(isPresented: $goToRoute) {
            RouteStartView()
        }

        .task {
            if isLoggedIn {
                await loadCategoriesAndPlaces()
            }
        }
        .onChange(of: axHighContrast) { _, v in appState.prefersHighContrast = v }

        // MARK: Edit Profile Sheet
        .sheet(isPresented: $showEdit, onDismiss: {
            profileUpdateError = nil
            isSavingProfile = false
        }) {
            NavigationStack {
                Form {
                    Section(header: Text("Personal Information")) {
                        TextField("Full Name", text: $draftName)

                        HStack {
                            Text("Email")
                                .foregroundStyle(.secondary)
                            Spacer()
                            Text(appState.currentUser?.email ?? "")
                                .foregroundStyle(.primary)
                        }

                        TextField("Phone", text: $draftPhone)
                            .keyboardType(.phonePad)

                        TextField("Date of Birth (YYYY-MM-DD)", text: $draftDOB)
                            .keyboardType(.numbersAndPunctuation)
                    }

                    if let error = profileUpdateError {
                        Section {
                            Text(error)
                                .foregroundStyle(.red)
                                .font(.caption)
                        }
                    }

                    Section {
                        Text("Email cannot be changed")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text("Date format: YYYY-MM-DD (e.g., 1988-05-15)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .navigationTitle("Edit Profile")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { showEdit = false }
                            .disabled(isSavingProfile)
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") {
                            Task { await handleSaveProfile() }
                        }
                        .bold()
                        .disabled(isSavingProfile)
                    }
                }
                .overlay {
                    if isSavingProfile {
                        ProgressView()
                    }
                }
            }
        }

        // MARK: Add Place Sheet
        .sheet(isPresented: $showAddPlace, onDismiss: {
            newPlaceTitle = ""
            newPlaceNotes = ""
            if let firstCategory = categories.first {
                newPlaceCategory = firstCategory.name
            }
            isCreatingPlace = false
        }) {
            NavigationStack {
                Form {
                    Section(header: Text("New Place")) {
                        TextField("Title (e.g. Café, PwC Reception)", text: $newPlaceTitle)

                        Picker("Category", selection: $newPlaceCategory) {
                            ForEach(categories) { category in
                                HStack {
                                    if let icon = category.icon {
                                        Image(systemName: icon)
                                    }
                                    Text(category.name)
                                }
                                .tag(category.name)
                            }
                        }

                        TextField("Notes (optional)", text: $newPlaceNotes, axis: .vertical)
                            .lineLimit(3...5)
                    }

                    if let error = savedPlacesError {
                        Section {
                            Text(error)
                                .foregroundStyle(.red)
                                .font(.caption)
                        }
                    }
                }
                .navigationTitle("Add Place")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") {
                            showAddPlace = false
                        }
                        .disabled(isCreatingPlace)
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Add") {
                            Task {
                                await createSavedPlace()
                            }
                        }
                        .bold()
                        .disabled(newPlaceTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isCreatingPlace)
                    }
                }
                .disabled(isCreatingPlace)
                .overlay {
                    if isCreatingPlace {
                        ProgressView()
                            .scaleEffect(1.5)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(Color.black.opacity(0.1))
                    }
                }
            }
        }

        // MARK: Change Password Sheet
        .sheet(isPresented: $showChangePassword, onDismiss: {
            currentPassword = ""
            newPassword = ""
            confirmPassword = ""
            changePasswordError = nil
            isChangingPassword = false
        }) {
            NavigationStack {
                Form {
                    Section(header: Text("Change Password")) {
                        SecureField("Current Password", text: $currentPassword)
                        SecureField("New Password", text: $newPassword)
                        SecureField("Confirm New Password", text: $confirmPassword)
                    }

                    if let error = changePasswordError {
                        Section {
                            Text(error)
                                .foregroundStyle(.red)
                                .font(.caption)
                        }
                    }

                    Section {
                        Text("New password must be at least 8 characters long")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .navigationTitle("Change Password")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") {
                            showChangePassword = false
                        }
                        .disabled(isChangingPassword)
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") {
                            Task { await handleChangePassword() }
                        }
                        .bold()
                        .disabled(!isPasswordChangeValid || isChangingPassword)
                    }
                }
                .overlay {
                    if isChangingPassword {
                        ProgressView()
                    }
                }
            }
        }
    }
}

// MARK: - Header

private extension ProfileView {
    var headerCard: some View {
        ZStack(alignment: .topTrailing) {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(LinearGradient(colors: [Color.orange, Color.orange.opacity(0.85)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(maxWidth: .infinity)
                .frame(height: 160)

            HStack(spacing: 16) {
                ZStack {
                    Circle().fill(Color.white.opacity(0.15)).frame(width: 72, height: 72)
                    Image(systemName: "person.fill")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundStyle(.white)
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text(isLoggedIn ? (appState.currentUser?.name ?? "User") : "Guest User")
                        .font(Typography.headlineM)
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    Text(isLoggedIn ? (appState.currentUser?.email ?? "No email") : "Not signed in")
                        .font(Typography.body)
                        .foregroundStyle(.white.opacity(0.9))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                }
                Spacer()
            }
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.lg)

            if isLoggedIn {
                Button {
                    draftName  = appState.currentUser?.name ?? ""
                    draftEmail = appState.currentUser?.email ?? ""
                    draftPhone = appState.currentUser?.phone ?? ""
                    draftDOB   = appState.currentUser?.dateOfBirth ?? ""
                    showEdit = true
                } label: {
                    Label("Edit", systemImage: "pencil")
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color.black.opacity(0.2), in: Capsule())
                        .foregroundStyle(.white)
                }
                .padding(.trailing, Space.lg)
                .padding(.top, Space.md)
                .buttonStyle(.plain)
            }
        }
    }
}

// MARK: - Sections

private extension ProfileView {
    var guestCalloutCard: some View {
        Card {
            VStack(spacing: Space.md) {
                Image(systemName: "person.badge.plus")
                    .font(.system(size: 56, weight: .semibold))
                    .foregroundStyle(DSColor.accent)
                    .padding(.top, Space.sm)

                Text("Create an Account")
                    .font(Typography.headlineM)
                    .foregroundStyle(DSColor.textPrimary)

                Text("Sign up to save your favorite places, customize your experience, and get personalized recommendations.")
                    .font(Typography.body)
                    .foregroundStyle(DSColor.textSecondary)
                    .multilineTextAlignment(.center)

                Button {
                    // To Auth (create account)
                    UserDefaults.standard.set("signUp", forKey: "authInitialMode")
                    appState.logoutUser()
                    SettingsStore.saveIsAuthenticated(false)
                    SettingsStore.saveIsGuest(false)
                } label: {
                    Text("Create Account").frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    // To Auth (sign in)
                    UserDefaults.standard.set("signIn", forKey: "authInitialMode")
                    appState.logoutUser()
                    SettingsStore.saveIsAuthenticated(false)
                    SettingsStore.saveIsGuest(false)
                } label: {
                    HStack { Image(systemName: "arrow.right"); Text("Sign In") }
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.secondary)
            }
            .padding(.vertical, Space.sm)
        }
    }

    var personalInfoCard: some View {
        Card {
            VStack(alignment: .leading, spacing: Space.md) {
                PVSectionHeader(title: "Personal Information", icon: "rectangle.split.3x1.fill") {
                    draftName  = appState.currentUser?.name ?? ""
                    draftEmail = appState.currentUser?.email ?? ""
                    draftPhone = appState.currentUser?.phone ?? ""
                    draftDOB   = appState.currentUser?.dateOfBirth ?? ""
                    showEdit = true
                }

                PVInfoRow(label: "Full Name",  value: appState.currentUser?.name ?? "Not set")
                PVInfoRow(label: "Phone",      value: appState.currentUser?.phone ?? "Not set")
                PVInfoRow(label: "Email",      value: appState.currentUser?.email ?? "Not set")
                PVInfoRow(label: "Date of Birth", value: appState.currentUser?.dateOfBirth ?? "Not set")
            }
        }
    }

    var savedPlacesCard: some View {
        Card {
            VStack(alignment: .leading, spacing: Space.md) {
                PVSectionHeader(title: "Saved Places", icon: "bookmark.fill") {
                    showAddPlace = true
                }

                if isLoadingSavedPlaces {
                    HStack {
                        Spacer()
                        ProgressView()
                        Spacer()
                    }
                    .padding()
                } else if let error = savedPlacesError {
                    VStack(spacing: Space.sm) {
                        Text(error)
                            .foregroundStyle(.red)
                            .font(.caption)
                            .multilineTextAlignment(.center)

                        Button("Retry") {
                            Task {
                                await loadCategoriesAndPlaces()
                            }
                        }
                        .font(.caption)
                    }
                    .padding()
                } else if savedPlaces.isEmpty {
                    Text("No saved places yet")
                        .foregroundStyle(.secondary)
                        .font(.callout)
                        .padding()
                } else {
                    ForEach(savedPlaces) { place in
                        PVSavedPlaceRow(
                            title: place.title,
                            subtitle: place.categoryName ?? "Unknown",
                            navigate: {
                                if axHaptics { Haptics.light() }
                                goToRoute = true
                            },
                            delete: {
                                Task {
                                    await deleteSavedPlace(place)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    var accessibilityCard: some View {
        Card {
            VStack(alignment: .leading, spacing: Space.md) {
                Text("Accessibility")
                    .font(Typography.headlineM)
                    .foregroundStyle(DSColor.textPrimary)

                PVToggleRow(icon: "circle.lefthalf.fill", title: "High Contrast Mode", isOn: $axHighContrast)

                HStack(spacing: Space.md) {
                    Label("Text Size", systemImage: "textformat.size")
                        .labelStyle(.titleAndIcon)
                        .foregroundStyle(DSColor.textPrimary)
                    Spacer()
                    Stepper(value: $axTextScale, in: 80...140, step: 10) { EmptyView() }
                    Text("\(axTextScale)%")
                        .font(Typography.bodyEmphasis)
                        .foregroundStyle(DSColor.textSecondary)
                }

                PVToggleRow(icon: "mic.fill",      title: "Voice Input",     isOn: $axVoiceInput)
                PVToggleRow(icon: "wave.3.left",   title: "Haptic Feedback", isOn: $axHaptics)
            }
        }
    }

    var accountActionsCard: some View {
        Card {
            VStack(spacing: Space.md) {
                Text("Account Actions")
                    .font(Typography.headlineM)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Button {
                    if axHaptics { Haptics.light() }
                    showChangePassword = true
                } label: {
                    Text("Change Password")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    if axHaptics { Haptics.light() }
                    Task {
                        try? await AuthService.logout()
                        await MainActor.run {
                            appState.logoutUser()
                        }
                    }
                } label: {
                    Text("Sign Out")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.bottom, Space.xl)
            }
        }
    }
}

// MARK: - Local helper views (prefixed types)

private struct PVSectionHeader: View {
    let title: String
    let icon: String
    let action: () -> Void

    var body: some View {
        HStack {
            Label(title, systemImage: icon)
                .font(Typography.headlineM)
                .foregroundStyle(DSColor.textPrimary)
            Spacer()
            Button(action: action) {
                Label("Add", systemImage: "plus.circle")
                    .font(Typography.captionEmphasis)
            }
            .buttonStyle(.plain)
        }
    }
}

private struct PVInfoRow: View {
    let label: String
    let value: String
    var body: some View {
        HStack {
            Text(label).foregroundStyle(DSColor.textSecondary)
            Spacer()
            Text(value).foregroundStyle(DSColor.textPrimary)
        }
        .font(Typography.body)
    }
}

private struct PVSavedPlaceRow: View {
    let title: String
    let subtitle: String
    let navigate: () -> Void
    let delete: () -> Void

    var body: some View {
        HStack(spacing: Space.md) {
            Image(systemName: "square.grid.2x2.fill")
                .foregroundStyle(DSColor.accent)
                .frame(width: 24)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(Typography.bodyEmphasis)
                    .foregroundStyle(DSColor.textPrimary)
                Text(subtitle)
                    .font(Typography.caption)
                    .foregroundStyle(DSColor.textSecondary)
            }

            Spacer()

            // Compact action buttons
            HStack(spacing: Space.sm) {
                Button(action: navigate) {
                    Image(systemName: "paperplane.fill")
                        .frame(width: 36, height: 36)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.regular)

                Button(action: delete) {
                    Image(systemName: "trash.fill")
                        .frame(width: 36, height: 36)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .controlSize(.regular)
            }
        }
        .contentShape(Rectangle())
    }
}

private struct PVToggleRow: View {
    let icon: String
    let title: String
    @Binding var isOn: Bool

    var body: some View {
        HStack {
            Label(title, systemImage: icon)
                .labelStyle(.titleAndIcon)
                .foregroundStyle(DSColor.textPrimary)
            Spacer()
            Toggle("", isOn: $isOn)
                .labelsHidden()
                .frame(width: 56)
        }
    }
}

#Preview {
    NavigationStack {
        ProfileView()
            .environmentObject(AppState())
    }
}
