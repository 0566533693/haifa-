import SwiftUI

struct HomeDashboard: View {
    // Local nav hooks (wire into your router as desired)
    @State private var toRoute = false
    @State private var toAR = false

    private var quickActions: [HDBQuickAction] {
        [
            .init(id: "start", icon: "location.north.line.fill", title: "Start Nav…", subtitle: "Pick destination") {
                toRoute = true
            },
            .init(id: "desk", icon: "key.fill", title: "My Office", subtitle: nil) {
                toRoute = true
            },
            .init(id: "rooms", icon: "person.3.sequence.fill", title: "Rooms", subtitle: nil) {
                toRoute = true
            },
            .init(id: "ar", icon: "camera.viewfinder", title: "AR Live", subtitle: nil) {
                toAR = true
            }
        ]
    }

    private var serviceChips: [HDBServiceChip] {
        [
            .init(id: "find-washroom", icon: "figure.and.child.holdinghands", title: "Find washroom") { toRoute = true },
            .init(id: "free-wifi",     icon: "wifi",                         title: "Free Wi-Fi") { },
            .init(id: "find-car",      icon: "car.rear",                    title: "Find my car") { },
            .init(id: "helpdesk",      icon: "questionmark.circle",         title: "Helpdesk") { }
        ]
    }

    private var highlight: HDBHighlight {
        .init(
            systemImage: "point.topleft.down.curvedto.point.bottomright.up",
            title: "Seamless 2D ⇄ AR",
            subtitle: "Follow the 2D path; we switch to AR as you approach your destination."
        )
    }

    var body: some View {
        VStack(spacing: Space.lg) {
            // Welcome
            Card {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Welcome to Indoor360")
                        .font(Typography.headlineM)
                        .foregroundStyle(DSColor.textPrimary)
                    Text("Search PwC offices and facilities. Navigate with AR or 2D maps.")
                        .font(Typography.body)
                        .foregroundStyle(DSColor.textSecondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            // Quick actions
            HDBQuickActionsGrid(items: quickActions)

            // Meetings
            HDBUpcomingMeetingsCard(meetings: HDBMeeting.sample)

            // Services chips
            HDBServicesChipsRow(chips: serviceChips)

            // Highlight
            HDBHighlightCard(item: highlight)
        }
        // iOS 16+ navigation API (no deprecation warnings)
        .navigationDestination(isPresented: $toRoute) {
            RouteStartView()
        }
        .navigationDestination(isPresented: $toAR) {
            // Replace with your actual AR view when ready
            RouteStartView()
        }
    }
}
