import SwiftUI

struct AuthView: View {
    @EnvironmentObject private var appState: AppState
    @StateObject private var vm: AuthViewModel

    init() {
        let initialMode: AuthViewModel.Mode
        if let modeString = UserDefaults.standard.string(forKey: "authInitialMode") {
            initialMode = modeString == "signUp" ? .signUp : .signIn
            // Clear it after reading so it only affects the next launch
            UserDefaults.standard.removeObject(forKey: "authInitialMode")
        } else {
            initialMode = .signIn
        }
        _vm = StateObject(wrappedValue: AuthViewModel(mode: initialMode))
    }

    // Toast
    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info

    private var titleText: String {
        vm.mode == .signIn ? "Sign in" : "Create account"
    }

    private var helperText: String {
        vm.mode == .signIn
        ? "Welcome back. Sign in to continue."
        : "Sign up to save favorites and history."
    }

    private var primaryCTAText: String {
        vm.mode == .signIn ? "Continue" : "Create account"
    }

    private var toggleText: AttributedString {
        AttributedString(
            vm.mode == .signIn
            ? "Don’t have an account? Sign up"
            : "Already have an account? Sign in"
        )
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Space.lg) {

                    // Top bar: title + helper
                    HStack {
                        VStack(alignment: .leading, spacing: Space.xs) {
                            Text(titleText)
                                .font(Typography.headlineL)
                                .foregroundColor(DSColor.textPrimary)

                            Text(helperText)
                                .font(Typography.body)
                                .foregroundColor(DSColor.textSecondary)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, Space.lg)
                    .padding(.top, Space.xl)

                    // Inputs
                    if vm.mode == .signUp {
                        TextFieldRow(
                            title: "Full name",
                            placeholder: "e.g., Sara Al Ali",
                            text: $vm.fullName,
                            helper: vm.isFullNameValid ? " " : "Please enter your full name.",
                            error: vm.hasAttemptedSubmit && !vm.isFullNameValid && !vm.fullName.isEmpty ? "Name looks too short." : nil
                        )
                    }

                    // Email field – trimmed & normalized
                    TextFieldRow(
                        title: "Email address",
                        placeholder: "name@example.com",
                        text: $vm.email,
                        helper: vm.isEmailValid ? " " : "Enter a valid email (example@domain.com).",
                        error: vm.hasAttemptedSubmit && !vm.isEmailValid && !vm.email.isEmpty ? "Invalid email format." : nil,
                        keyboard: .emailAddress,
                        contentType: .emailAddress
                    )
                    .onChange(of: vm.email) { _, newValue in
                        vm.email = newValue
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                    }

                    PasswordField(
                        title: "Password",
                        placeholder: "At least 8 characters",
                        text: $vm.password,
                        helper: vm.isPasswordValid ? " " : "Use 8+ characters for strong security.",
                        error: vm.hasAttemptedSubmit && !vm.isPasswordValid && !vm.password.isEmpty ? "Password too short." : nil
                    )

                    // Forgot password (front-end only for now)
                    Button("Forgot password?") {
                        vm.forgotPassword()
                        toast(.info, "If an account exists for this email, a reset link may be sent.")
                    }
                    .font(Typography.bodyEmphasis)
                    .foregroundColor(DSColor.accent)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .padding(.horizontal, Space.lg)

                    // Inline error from ViewModel (backend errors, validation, etc.)
                    if let error = vm.errorMessage, !error.isEmpty {
                        Text(error)
                            .font(Typography.caption)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, Space.lg)
                    }

                    // Primary CTA → uses AuthViewModel + backend
                    PrimaryButton(
                        title: primaryCTAText,
                        action: {
                            vm.primaryAction { success in
                                if success {
                                    Haptics.confirm()
                                    // Fetch and store user in AppState from backend
                                    Task {
                                        do {
                                            let user = try await AuthService.getCurrentUser()
                                            await MainActor.run {
                                                appState.loginUser(user)
                                            }
                                        } catch {
                                            // Fallback: mark authenticated even if /me fails
                                            await MainActor.run {
                                                appState.isAuthenticated = true
                                                appState.isGuest = false
                                                SettingsStore.saveIsAuthenticated(true)
                                                SettingsStore.saveIsGuest(false)
                                            }
                                        }
                                    }
                                } else {
                                    Haptics.critical()
                                    toast(.error, vm.errorMessage ?? "Check your details and try again.")
                                }
                            }
                        },
                        isLoading: vm.isLoading,
                        isDisabled: !vm.canSubmit
                    )
                    .padding(.horizontal, Space.lg)

                    // Divider + guest + toggle mode
                    VStack(spacing: Space.sm) {
                        Text("or")
                            .font(Typography.caption)
                            .foregroundColor(DSColor.textSecondary)

                        // Guest
                        Button("Continue as Guest") {
                            appState.isGuest = true
                            appState.isAuthenticated = true
                            SettingsStore.saveIsGuest(true)
                            SettingsStore.saveIsAuthenticated(true)
                            Haptics.confirm()
                        }
                        .font(Typography.bodyEmphasis)
                        .foregroundColor(DSColor.accent)
                        .minTapTarget()

                        // Toggle mode (Sign in <-> Sign up)
                        Button {
                            vm.toggleMode()
                        } label: {
                            Text(toggleText)
                                .font(Typography.body)
                                .foregroundColor(DSColor.textSecondary)
                        }
                        .padding(.bottom, Space.xl)
                    }
                }
            }
            .background(AppBackgroundView().ignoresSafeArea())
            .toast(
                isPresented: $showToast,
                style: toastStyle,
                message: toastMessage,
                duration: 2.0
            )
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    // MARK: - Helpers

    private func toast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }
}

#Preview {
    NavigationStack {
        AuthView()
            .environmentObject(AppState())
    }
}
