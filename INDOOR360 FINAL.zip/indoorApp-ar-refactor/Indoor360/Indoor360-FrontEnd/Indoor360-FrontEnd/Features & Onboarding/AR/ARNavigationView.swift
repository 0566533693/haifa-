import SwiftUI
import ARKit
import RealityKit

/// AR navigation screen that shows step-by-step directions with AR camera overlay.
/// Reads the currently active route from AppState.
struct ARNavigationView: View {
    @EnvironmentObject private var appState: AppState
    @Environment(\.dismiss) private var dismiss
    @StateObject private var poseService = DevicePoseService()

    @State private var currentStepIndex = 0
    @State private var showExitConfirmation = false

    var body: some View {
        ZStack {
            // AR Camera background
            ARCameraView()
                .ignoresSafeArea()

            // Semi-transparent overlay for readability
            Color.black.opacity(0.2)
                .ignoresSafeArea()

            // Main content
            VStack(spacing: 0) {
                // Top: Navigation header
                navigationHeader
                    .padding(.top, 60)

                Spacer()

                // Center: Current instruction
                if let route = appState.activeRoute, !route.path.isEmpty {
                    instructionCard(route: route)
                        .transition(.scale.combined(with: .opacity))
                }

                Spacer()

                // Bottom: Progress and controls
                bottomControls
                    .padding(.bottom, 40)
            }
            .padding(.horizontal)
        }
        .navigationBarHidden(true)
        .onAppear {
            poseService.start()
        }
        .onDisappear {
            poseService.stop()
        }
        .alert("Exit Navigation?", isPresented: $showExitConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Exit", role: .destructive) {
                appState.stopARNavigation()
                dismiss()
            }
        } message: {
            Text("Your progress will be lost.")
        }
    }

    // MARK: - Navigation Header

    private var navigationHeader: some View {
        HStack {
            // Close button
            Button {
                showExitConfirmation = true
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
                    .shadow(radius: 2)
            }

            Spacer()

            // Destination info
            VStack(alignment: .trailing, spacing: 2) {
                Text("Navigating to")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
                Text("Destination")
                    .font(.headline)
                    .foregroundColor(.white)
            }
        }
        .padding()
        .background(.ultraThinMaterial.opacity(0.8))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: - Instruction Card

    private func instructionCard(route: RouteResponse) -> some View {
        let totalSteps = max(1, route.path.count - 1)
        let safeIndex = min(currentStepIndex, totalSteps - 1)

        return VStack(spacing: 20) {
            // Direction arrow
            Image(systemName: directionIcon(for: safeIndex, in: route))
                .font(.system(size: 80, weight: .bold))
                .foregroundColor(.white)
                .shadow(color: .black.opacity(0.3), radius: 4)

            // Distance to next point
            Text(distanceText(for: safeIndex, in: route))
                .font(.title2.bold())
                .foregroundColor(.white)

            // Step description
            Text("Step \(safeIndex + 1) of \(totalSteps)")
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.8))
        }
        .padding(30)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 24))
    }

    // MARK: - Bottom Controls

    private var bottomControls: some View {
        HStack(spacing: 20) {
            // Previous step
            Button {
                if currentStepIndex > 0 {
                    withAnimation { currentStepIndex -= 1 }
                }
            } label: {
                Image(systemName: "chevron.left.circle.fill")
                    .font(.system(size: 44))
                    .foregroundColor(currentStepIndex > 0 ? .white : .gray)
            }
            .disabled(currentStepIndex == 0)

            // Progress indicator
            if let route = appState.activeRoute {
                let totalSteps = max(1, route.path.count - 1)
                Text("\(currentStepIndex + 1) / \(totalSteps)")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(minWidth: 60)
            }

            // Next step
            Button {
                if let route = appState.activeRoute {
                    let maxIndex = max(0, route.path.count - 2)
                    if currentStepIndex < maxIndex {
                        withAnimation { currentStepIndex += 1 }
                    } else {
                        // Arrived!
                        appState.stopARNavigation()
                        dismiss()
                    }
                }
            } label: {
                Image(systemName: isLastStep ? "checkmark.circle.fill" : "chevron.right.circle.fill")
                    .font(.system(size: 44))
                    .foregroundColor(isLastStep ? .green : .white)
            }
        }
        .padding()
        .background(.ultraThinMaterial.opacity(0.8))
        .clipShape(RoundedRectangle(cornerRadius: 22))
    }

    private var isLastStep: Bool {
        guard let route = appState.activeRoute else { return true }
        return currentStepIndex >= route.path.count - 2
    }

    // MARK: - Helpers

    private func directionIcon(for index: Int, in route: RouteResponse) -> String {
        guard index < route.path.count - 1 else { return "flag.fill" }

        let current = route.path[index]
        let next = route.path[index + 1]

        let dx = next.x - current.x
        let dy = next.y - current.y

        // Simple direction based on dominant axis
        if abs(dx) > abs(dy) {
            return dx > 0 ? "arrow.right" : "arrow.left"
        } else {
            return dy > 0 ? "arrow.up" : "arrow.down"
        }
    }

    private func distanceText(for index: Int, in route: RouteResponse) -> String {
        guard index < route.path.count - 1 else { return "Arrived!" }

        let current = route.path[index]
        let next = route.path[index + 1]

        let dx = next.x - current.x
        let dy = next.y - current.y
        let dz = next.z - current.z
        let distance = sqrt(dx*dx + dy*dy + dz*dz)

        return String(format: "%.1f m", distance)
    }
}

// MARK: - AR Camera View

/// Simple AR camera view wrapper using RealityKit
struct ARCameraView: UIViewRepresentable {

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)

        // Configure AR session
        let config = ARWorldTrackingConfiguration()
        config.worldAlignment = .gravityAndHeading
        config.planeDetection = []  // No plane detection needed
        config.environmentTexturing = .none

        arView.session.run(config)

        // Disable default AR coaching overlay
        arView.environment.background = .cameraFeed()

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        // Nothing to update
    }

    static func dismantleUIView(_ uiView: ARView, coordinator: ()) {
        uiView.session.pause()
    }
}