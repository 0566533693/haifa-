// ARStepNavigationView.swift
// AR navigation view with automatic step advancement and AR/2D mode switching

import SwiftUI
import ARKit
import RealityKit

/// AR navigation view that shows step-by-step directions with AR camera overlay.
/// Automatically switches between AR and 2D map based on device pitch.
/// Automatically advances steps based on ARKit displacement tracking.
struct ARStepNavigationView: View {
    @ObservedObject var session: NavigationSession
    @StateObject private var poseService = DevicePoseService()
    @StateObject private var arController = ARNavigationController()
    @Environment(\.dismiss) private var dismiss

    @State private var showExitConfirmation = false
    @State private var arTrackingState: ARCamera.TrackingState?

    var body: some View {
        ZStack {
            // Show AR or 2D Map based on device pitch (or user override)
            if shouldShowMapView {
                // 2D Map Mode
                map2DView
                    .transition(.opacity)
            } else {
                // AR Camera Mode
                arCameraView
                    .transition(.opacity)
            }

            // Mode indicator overlay (top center)
            VStack {
                modeIndicator
                    .padding(.top, 50)
                Spacer()
            }
        }
        .animation(.easeInOut(duration: 0.3), value: shouldShowMapView)
        .onAppear {
            startServices()
        }
        .onDisappear {
            stopServices()
        }
        .alert("Exit Navigation?", isPresented: $showExitConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Exit", role: .destructive) {
                session.finish()
                dismiss()
            }
        } message: {
            Text("Your progress will be lost.")
        }
        .onChange(of: arController.recentAutoAdvance) { _, didAdvance in
            if didAdvance {
                // Haptic feedback for auto-advance
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            }
        }
    }

    // MARK: - Mode Determination

    /// Whether to show 2D map view instead of AR
    private var shouldShowMapView: Bool {
        return poseService.navMode == .map2d
    }

    // MARK: - Mode Indicator

    private var modeIndicator: some View {
        Group {
            #if targetEnvironment(simulator)
            // Simulator: tappable button to toggle modes
            Button {
                poseService.toggleMode()
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            } label: {
                modeIndicatorContent(showToggleIcon: true)
            }
            .buttonStyle(.plain)
            #else
            // Real device: non-interactive indicator (uses tilt)
            modeIndicatorContent(showToggleIcon: false)
            #endif
        }
    }

    private func modeIndicatorContent(showToggleIcon: Bool) -> some View {
        HStack(spacing: 8) {
            Image(systemName: shouldShowMapView ? "map.fill" : "arkit")
                .font(.caption)
            Text(shouldShowMapView ? "2D Map Mode" : "AR Mode")
                .font(.caption.bold())

            // Tracking quality indicator
            if !shouldShowMapView {
                Circle()
                    .fill(trackingQualityColor)
                    .frame(width: 8, height: 8)
            }

            // Toggle icon hint (Simulator only)
            if showToggleIcon {
                Image(systemName: "arrow.2.squarepath")
                    .font(.caption2)
                    .opacity(0.6)
            }
        }
        .foregroundColor(.white)
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.black.opacity(0.6))
        .clipShape(Capsule())
    }

    private var trackingQualityColor: Color {
        guard let state = arTrackingState else { return .gray }
        switch state {
        case .normal: return .green
        case .limited: return .yellow
        case .notAvailable: return .red
        @unknown default: return .gray
        }
    }

    // MARK: - AR Camera View

    private var arCameraView: some View {
        ZStack {
            // AR Camera background with tracking delegate
            ARCameraViewWithTracking(trackingState: $arTrackingState)
                .ignoresSafeArea()

            // Semi-transparent overlay for readability
            Color.black.opacity(0.1)
                .ignoresSafeArea()

            // Main content
            VStack(spacing: 0) {
                // Top: Navigation header + instruction
                VStack(spacing: 12) {
                    navigationHeader
                        .padding(.top, 50)

                    // Current instruction at top
                    if let step = session.currentStep {
                        arTopInstructionCard(step)
                            .transition(.scale.combined(with: .opacity))
                    }
                }
                .padding(.horizontal)

                Spacer()

                // Center: Large AR arrow
                if let step = session.currentStep {
                    largeARArrow(step)
                        .transition(.scale.combined(with: .opacity))
                }

                Spacer()

                // Bottom: Progress and controls
                arBottomControls
                    .padding(.bottom, 30)
            }
            .padding(.horizontal)
        }
    }

    // MARK: - 2D Map View

    private var map2DView: some View {
        ZStack {
            // Map background - use embedded mode to avoid nested NavigationStack
            NavigationMapView(session: session, embedded: true)

            // Overlay controls to match AR view style
            VStack {
                // Navigation header (similar to AR)
                navigationHeader
                    .padding(.top, 60)
                    .padding(.horizontal)

                mapModeAutoHint
                    .padding(.top, 8)
                    .padding(.horizontal)

                Spacer()

                // Current step instruction card
                if let step = session.currentStep {
                    map2DInstructionCard(step)
                        .padding(.horizontal)
                }

                // Bottom progress
                map2DBottomControls
                    .padding(.horizontal)
                    .padding(.bottom, 20)
            }
        }
    }

    // MARK: - Navigation Header

    private var navigationHeader: some View {
        HStack {
            // Close button
            Button {
                showExitConfirmation = true
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
                    .shadow(radius: 2)
            }

            Spacer()

            // Destination info
            VStack(alignment: .trailing, spacing: 2) {
                Text("Navigating to")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
                Text(session.destinationName ?? "Destination")
                    .font(.headline)
                    .foregroundColor(.white)
            }
        }
        .padding()
        .background(.ultraThinMaterial.opacity(0.9))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: - AR Top Instruction Card

    private func arTopInstructionCard(_ step: NavigationStep) -> some View {
        VStack(spacing: 8) {
            // Auto-advance indicator
            if arController.recentAutoAdvance {
                Text("Step reached!")
                    .font(.caption.bold())
                    .foregroundColor(.green)
                    .transition(.scale.combined(with: .opacity))
            }

            // Instruction text
            Text(step.instruction)
                .font(.title2.bold())
                .foregroundColor(.white)
                .multilineTextAlignment(.center)

            // Distance info
            HStack(spacing: 16) {
                VStack(spacing: 2) {
                    Text(String(format: "%.1fm", arController.distanceToStepTarget))
                        .font(.title3.bold())
                        .foregroundColor(.white)
                    Text("to next")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                }

                Divider()
                    .frame(height: 20)
                    .background(Color.white.opacity(0.3))

                VStack(spacing: 2) {
                    Text("Step \(session.currentStepIndex + 1)/\(session.steps.count)")
                        .font(.caption.bold())
                        .foregroundColor(.white)
                    Text("traveled \(String(format: "%.1fm", arController.totalDistanceTraveled))")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                }
            }
        }
        .padding(20)
        .background(.ultraThinMaterial.opacity(0.95))
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(radius: 8)
    }

    // MARK: - Large AR Arrow (Center)

    private func largeARArrow(_ step: NavigationStep) -> some View {
        ZStack {
            // Outer glow
            Circle()
                .fill(
                    RadialGradient(
                        gradient: Gradient(colors: [
                            colorForStep(step.kind).opacity(0.4),
                            colorForStep(step.kind).opacity(0.0)
                        ]),
                        center: .center,
                        startRadius: 100,
                        endRadius: 160
                    )
                )
                .frame(width: 320, height: 320)

            // Main arrow circle
            Circle()
                .fill(colorForStep(step.kind))
                .frame(width: 200, height: 200)
                .shadow(color: colorForStep(step.kind).opacity(0.6), radius: 25, x: 0, y: 12)

            // Arrow icon - large and bold
            Image(systemName: step.kind.icon)
                .font(.system(size: 100, weight: .heavy))
                .foregroundColor(.white)
                .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 3)
        }
        .scaleEffect(arController.recentAutoAdvance ? 1.1 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: arController.recentAutoAdvance)
    }

    // MARK: - AR Instruction Card (deprecated, keeping for compatibility)

    private func arInstructionCard(_ step: NavigationStep) -> some View {
        VStack(spacing: 16) {
            // Auto-advance indicator
            if arController.recentAutoAdvance {
                Text("Step reached!")
                    .font(.caption.bold())
                    .foregroundColor(.green)
                    .transition(.scale.combined(with: .opacity))
            }

            // Large direction arrow/icon
            ZStack {
                Circle()
                    .fill(colorForStep(step.kind))
                    .frame(width: 100, height: 100)
                    .shadow(color: colorForStep(step.kind).opacity(0.5), radius: 15)

                Image(systemName: step.kind.icon)
                    .font(.system(size: 45, weight: .bold))
                    .foregroundColor(.white)
            }

            // Instruction text
            Text(step.instruction)
                .font(.title3.bold())
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .shadow(radius: 2)

            // Distance info
            HStack(spacing: 20) {
                // Distance to next step
                VStack(spacing: 2) {
                    Text(String(format: "%.1fm", arController.distanceToStepTarget))
                        .font(.title2.bold())
                        .foregroundColor(.white)
                    Text("to next")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                }

                Divider()
                    .frame(height: 30)
                    .background(Color.white.opacity(0.3))

                // Total traveled
                VStack(spacing: 2) {
                    Text(String(format: "%.1fm", arController.totalDistanceTraveled))
                        .font(.title2.bold())
                        .foregroundColor(.white)
                    Text("traveled")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                }
            }

            // Step counter
            Text("Step \(session.currentStepIndex + 1) of \(session.steps.count)")
                .font(.caption)
                .foregroundColor(.white.opacity(0.7))
        }
        .padding(24)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(radius: 8)
    }

    // MARK: - 2D Map Instruction Card

    private func map2DInstructionCard(_ step: NavigationStep) -> some View {
        HStack(spacing: 16) {
            // Direction icon
            ZStack {
                Circle()
                    .fill(colorForStep(step.kind))
                    .frame(width: 50, height: 50)

                Image(systemName: step.kind.icon)
                    .font(.title2.bold())
                    .foregroundColor(.white)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(step.instruction)
                    .font(.headline)
                    .foregroundColor(.primary)

                if let distance = step.distanceText {
                    Text(distance)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
            }

            Spacer()

            // Step indicator
            Text("\(session.currentStepIndex + 1)/\(session.steps.count)")
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(8)
                .background(Color.secondary.opacity(0.1))
                .clipShape(Capsule())
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var mapModeAutoHint: some View {
        HStack(spacing: 10) {
            Image(systemName: "iphone.gen3")
                .rotationEffect(.degrees(-20))
            VStack(alignment: .leading, spacing: 2) {
                Text("Viewing map")
                    .font(.caption.bold())
                Text("Raise the phone upright to return to AR mode.")
                    .font(.caption2)
            }
        }
        .foregroundColor(.white)
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial.opacity(0.9))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    // MARK: - AR Bottom Controls

    private var arBottomControls: some View {
        VStack(spacing: 8) {
            // Tracking status
            Text(arController.trackingQualityMessage)
                .font(.caption)
                .foregroundColor(.white.opacity(0.7))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial.opacity(0.9))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: - 2D Map Bottom Controls

    private var map2DBottomControls: some View {
        // Tip to raise phone
        HStack(spacing: 6) {
            Image(systemName: "iphone.gen3")
                .rotationEffect(.degrees(-20))
            Text("Raise phone for AR view")
                .font(.caption)
        }
        .foregroundColor(.secondary)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: - Progress Dots

    // MARK: - Helpers

    private func colorForStep(_ kind: NavigationStep.StepKind) -> Color {
        switch kind {
        case .start:    return .blue
        case .forward:  return .cyan
        case .left:     return .orange
        case .right:    return .orange
        case .finish:   return .green
        }
    }

    private func finishNavigation() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        session.finish()
        dismiss()
    }

    // MARK: - Service Management

    private func startServices() {
        poseService.start()
        arController.startTracking(with: session)

        // Auto-switch to Map mode if AR is not supported (e.g., Simulator)
        #if targetEnvironment(simulator)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if !self.arController.arService.isARSupported {
                print("[ARStepNav] AR not supported, switching to Map mode")
                self.poseService.manualModeOverride = .map2d
            }
        }
        #endif
    }

    private func stopServices() {
        poseService.stop()
        arController.stopTracking()
    }
}

// MARK: - Preview

#if DEBUG
struct ARStepNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        ARStepNavigationView(session: NavigationSession.mockSession())
    }
}
#endif
