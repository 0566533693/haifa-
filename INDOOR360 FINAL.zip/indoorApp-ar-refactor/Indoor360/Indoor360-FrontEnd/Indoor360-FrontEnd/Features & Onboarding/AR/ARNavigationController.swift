// ARNavigationController.swift
// Manages AR tracking and automatic step advancement based on user movement

import Foundation
import Combine
import ARKit
import RealityKit
import SwiftUI

/// Controller that integrates ARPrecisionService with NavigationSession
/// to automatically advance navigation steps based on user movement.
@MainActor
final class ARNavigationController: ObservableObject {

    // MARK: - Published State

    /// Current displacement from origin (east, north) in meters
    @Published private(set) var currentDisplacement: (east: Double, north: Double) = (0, 0)

    /// Total distance traveled since navigation started
    @Published private(set) var totalDistanceTraveled: Double = 0

    /// Distance remaining to the current step's target
    @Published private(set) var distanceToStepTarget: Double = 0

    /// Whether AR tracking is active and stable
    @Published private(set) var isTrackingStable: Bool = false

    /// AR tracking quality message
    @Published private(set) var trackingQualityMessage: String = "Initializing AR..."

    /// Whether auto-advance is enabled
    @Published var isAutoAdvanceEnabled: Bool = true

    /// Recent auto-advance event (for UI feedback)
    @Published private(set) var recentAutoAdvance: Bool = false

    // MARK: - AR Service

    let arService = ARPrecisionService()  // Public for AR support detection
    private var cancellables = Set<AnyCancellable>()

    // MARK: - State

    private weak var session: NavigationSession?
    private var lastSample: ARDisplacementSample?
    private var lastDisplacement: (east: Double, north: Double) = (0, 0)

    /// Threshold to consider the user has reached the step target (meters)
    private let arrivalThreshold: Double = 1.5

    /// Minimum time between auto-advances (seconds) to prevent rapid switching
    private let minAdvanceInterval: TimeInterval = 1.5
    private var lastAdvanceTime: TimeInterval = 0

    // MARK: - Initialization

    init() {
        setupARSubscription()
    }

    // MARK: - Public Methods

    /// Start AR tracking for navigation
    func startTracking(with session: NavigationSession) {
        self.session = session
        self.totalDistanceTraveled = 0
        self.lastDisplacement = (0, 0)
        self.lastAdvanceTime = CACurrentMediaTime()

        // Calculate initial distance to first step target
        if let nextStep = session.currentStepIndex < session.steps.count - 1 ? session.steps[session.currentStepIndex + 1] : nil {
            self.distanceToStepTarget = nextStep.segmentDistanceMeters
        }

        arService.start()
        print("[ARNavController] Started tracking")
    }

    /// Stop AR tracking
    func stopTracking() {
        arService.stop()
        session = nil
        cancellables.removeAll()
        setupARSubscription() // Re-setup for next use
        print("[ARNavController] Stopped tracking")
    }

    /// Reset AR origin (e.g., after rescanning QR)
    func resetOrigin() {
        arService.reset()
        totalDistanceTraveled = 0
        lastDisplacement = (0, 0)
        currentDisplacement = (0, 0)
        print("[ARNavController] Origin reset")
    }

    /// Manually trigger step advance (also called by auto-advance)
    func advanceToNextStep() {
        guard let session = session else { return }

        Task { @MainActor in
            session.advanceToNextStep()

            // Update distance to new step target
            if let nextStep = session.nextStep {
                self.distanceToStepTarget = nextStep.segmentDistanceMeters
            } else {
                self.distanceToStepTarget = 0
            }

            // Reset tracking state for new segment
            lastAdvanceTime = CACurrentMediaTime()

            // Trigger auto-advance feedback
            recentAutoAdvance = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
                self?.recentAutoAdvance = false
            }
        }
    }

    // MARK: - Private Methods

    private func setupARSubscription() {
        // Subscribe to AR displacement samples
        arService.$sample
            .compactMap { $0 }
            .receive(on: DispatchQueue.main)
            .sink { [weak self] sample in
                self?.processDisplacementSample(sample)
            }
            .store(in: &cancellables)
    }

    private func processDisplacementSample(_ sample: ARDisplacementSample) {
        // Update current displacement
        currentDisplacement = (east: sample.east, north: sample.north)

        // Calculate incremental distance traveled
        let dEast = sample.east - lastDisplacement.east
        let dNorth = sample.north - lastDisplacement.north
        let incrementalDistance = sqrt(dEast * dEast + dNorth * dNorth)

        // Only count significant movement (filter noise)
        if incrementalDistance > 0.05 { // 5cm threshold
            totalDistanceTraveled += incrementalDistance
            lastDisplacement = (east: sample.east, north: sample.north)
        }

        // Update tracking quality
        updateTrackingQuality()

        // Check for step advancement
        checkStepAdvancement(sample: sample)

        lastSample = sample
    }

    private func updateTrackingQuality() {
        // Simple heuristic based on displacement stability
        let displacement = sqrt(currentDisplacement.east * currentDisplacement.east +
                                currentDisplacement.north * currentDisplacement.north)

        if displacement < 100 { // Reasonable indoor range
            isTrackingStable = true
            trackingQualityMessage = "AR Tracking Active"
        } else {
            isTrackingStable = false
            trackingQualityMessage = "AR tracking may be drifting"
        }
    }

    private func checkStepAdvancement(sample: ARDisplacementSample) {
        guard isAutoAdvanceEnabled,
              let session = session,
              session.isNavigating,
              !session.isLastStep else { return }

        // Debounce rapid advances
        let now = CACurrentMediaTime()
        guard now - lastAdvanceTime >= minAdvanceInterval else { return }

        // Get current step info
        let currentIndex = session.currentStepIndex
        guard currentIndex < session.steps.count - 1 else { return }

        let currentStep = session.steps[currentIndex]
        let nextStep = session.steps[currentIndex + 1]

        // Calculate distance traveled along the route
        // Project displacement onto the route direction
        let totalDisplacement = sqrt(sample.east * sample.east + sample.north * sample.north)

        // Calculate how far we need to go to reach next step
        let targetCumulativeDistance = nextStep.cumulativeDistanceMeters
        let currentCumulativeDistance = currentStep.cumulativeDistanceMeters
        let segmentDistance = targetCumulativeDistance - currentCumulativeDistance

        // Update distance to target
        let progressAlongSegment = min(totalDisplacement, segmentDistance)
        distanceToStepTarget = max(0, segmentDistance - progressAlongSegment)

        // Check if we've reached the next step
        // Method 1: Compare total displacement to cumulative distance needed
        if totalDisplacement >= (targetCumulativeDistance - arrivalThreshold) {
            print("[ARNavController] Auto-advancing: displacement=\(String(format: "%.2f", totalDisplacement))m >= target=\(String(format: "%.2f", targetCumulativeDistance))m")
            advanceToNextStep()
            return
        }

        // Method 2: If we have direction vectors, project displacement onto segment direction
        if let direction = currentStep.directionVector {
            // Project user displacement onto segment direction
            // AR uses east/north, route uses x/y (map coordinates)
            // Assuming x=east, y=north for simplicity
            let projectedDistance = sample.east * direction.x + sample.north * direction.y

            if projectedDistance >= (segmentDistance - arrivalThreshold) {
                print("[ARNavController] Auto-advancing (projected): \(String(format: "%.2f", projectedDistance))m >= \(String(format: "%.2f", segmentDistance))m")
                advanceToNextStep()
                return
            }
        }
    }
}

// MARK: - AR Camera View with Tracking Delegate

/// AR camera view that reports tracking state changes
struct ARCameraViewWithTracking: UIViewRepresentable {
    @Binding var trackingState: ARCamera.TrackingState?

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)

        // Configure AR session
        let config = ARWorldTrackingConfiguration()
        config.worldAlignment = .gravityAndHeading
        config.planeDetection = []
        config.environmentTexturing = .none

        arView.session.delegate = context.coordinator
        arView.session.run(config)
        arView.environment.background = .cameraFeed()

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        // Nothing to update
    }

    static func dismantleUIView(_ uiView: ARView, coordinator: Coordinator) {
        uiView.session.pause()
    }

    class Coordinator: NSObject, ARSessionDelegate {
        var parent: ARCameraViewWithTracking

        init(_ parent: ARCameraViewWithTracking) {
            self.parent = parent
        }

        func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
            DispatchQueue.main.async {
                self.parent.trackingState = camera.trackingState
            }
        }
    }
}
