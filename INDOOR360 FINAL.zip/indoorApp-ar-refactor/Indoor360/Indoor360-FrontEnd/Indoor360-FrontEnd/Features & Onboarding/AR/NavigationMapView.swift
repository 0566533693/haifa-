// NavigationMapView.swift
// Map view showing the route during step navigation

import SwiftUI
import MapKit

/// A map view that displays the navigation route with start and end points.
/// Uses MapRouteView which will auto-compute the route using its internal A* algorithm.
struct NavigationMapView: View {
    @ObservedObject var session: NavigationSession
    var onDismiss: () -> Void = {}

    /// Whether to show as embedded (without NavigationStack) or standalone
    var embedded: Bool = false

    private let store = LocalBundleIMDFStore()

    // Get venue info
    private var venue: IMDFVenueMeta? {
        store.list().first
    }

    var body: some View {
        if embedded {
            // Embedded mode - just the map without navigation chrome
            embeddedMapContent
        } else {
            // Standalone mode with NavigationStack
            NavigationStack {
                mapContent
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button {
                                onDismiss()
                            } label: {
                                HStack(spacing: 4) {
                                    Image(systemName: "chevron.left")
                                    Text("Back to AR")
                                }
                            }
                        }
                    }
            }
        }
    }

    @ViewBuilder
    private var embeddedMapContent: some View {
        if let venue = venue {
            MapRouteView(
                venueId: venue.id,
                venueName: formatVenueName(venue.name),
                initialRoute: session.wgsRoutePoints,
                initialStartName: session.startPosition?.locationName,
                initialEndName: session.destinationName,
                initialDestinationPoint: session.destinationCoordinateWGS
            )
        } else {
            VStack {
                Text("No venue found")
                    .foregroundColor(.secondary)
            }
        }
    }

    @ViewBuilder
    private var mapContent: some View {
        if let venue = venue {
            // Use MapRouteView - it will auto-find the destination by name and compute route
            MapRouteView(
                venueId: venue.id,
                venueName: formatVenueName(venue.name),
                initialRoute: session.wgsRoutePoints,
                initialStartName: session.startPosition?.locationName,
                initialEndName: session.destinationName,
                initialDestinationPoint: session.destinationCoordinateWGS
            )
        } else {
            VStack {
                Text("No venue found")
                    .foregroundColor(.secondary)
                Button("Back to AR") {
                    onDismiss()
                }
            }
        }
    }

    // MARK: - Helpers

    private func formatVenueName(_ name: String) -> String {
        name.replacingOccurrences(of: "_", with: " ")
    }
}

// MARK: - Preview

#if DEBUG
struct NavigationMapView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationMapView(session: NavigationSession.mockSession(), onDismiss: {})
    }
}
#endif