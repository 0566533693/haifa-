import SwiftUI

struct RouteDebugView: View {
    let route: RouteResponseDTO
    let poiName: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Route debug")
                .font(.title2.bold())

            Text("Destination: \(poiName)")
                .font(.headline)

            Text("Segments: \(route.path.count)")
            Text(String(format: "Length: %.2f m", route.lengthM))

            Divider()

            List(Array(route.path.enumerated()), id: \.0) { (idx, p) in
                Text(
                    "#\(idx): " +
                    "x=\(String(format: "%.2f", p.x)), " +
                    "y=\(String(format: "%.2f", p.y)), " +
                    "z=\(String(format: "%.2f", p.z))"
                )
                .font(.caption)
            }
        }
        .padding()
    }
}
