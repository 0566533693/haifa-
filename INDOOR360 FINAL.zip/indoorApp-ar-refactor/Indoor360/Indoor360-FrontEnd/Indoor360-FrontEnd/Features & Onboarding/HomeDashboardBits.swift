import SwiftUI

// MARK: - Dashboard-local models (prefixed to avoid collisions)

struct HDBQuickAction: Identifiable {
    let id: String
    let icon: String
    let title: String
    let subtitle: String?
    let action: () -> Void
}

struct HDBMeeting: Identifiable {
    let id = UUID()
    let title: String
    let room: String
    let time: String

    static let sample: [HDBMeeting] = [
        .init(title: "Weekly Sync", room: "Room 3A", time: "10:00–10:30"),
        .init(title: "Client Review", room: "Room 14B", time: "11:00–12:00"),
        .init(title: "Design Crit", room: "Huddle N2", time: "14:30–15:00")
    ]
}

struct HDBServiceChip: Identifiable {
    let id: String
    let icon: String
    let title: String
    let action: () -> Void
}

struct HDBHighlight: Identifiable {
    let id = UUID()
    let systemImage: String
    let title: String
    let subtitle: String
}

// MARK: - Reusable bits

struct HDBSectionHeader: View {
    let title: String
    var trailing: AnyView? = nil

    init(title: String, trailing: AnyView? = nil) {
        self.title = title
        self.trailing = trailing
    }

    var body: some View {
        HStack {
            Text(title)
                .font(Typography.bodyEmphasis)
                .foregroundStyle(DSColor.textPrimary)
            Spacer()
            trailing
        }
        .padding(.horizontal, 2)
    }
}

struct HDBQuickActionsGrid: View {
    let items: [HDBQuickAction]

    var body: some View {
        VStack(alignment: .leading, spacing: Space.md) {
            HDBSectionHeader(title: "Quick Actions")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(alignment: .top, spacing: Space.md) {
                    ForEach(items) { item in
                        Button(action: item.action) {
                            VStack(spacing: 6) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .fill(Color(.secondarySystemBackground))
                                        .frame(width: 88, height: 88)
                                    Image(systemName: item.icon)
                                        .font(.system(size: 28, weight: .semibold))
                                        .foregroundStyle(DSColor.accent)
                                }
                                Text(item.title)
                                    .font(Typography.captionEmphasis)
                                    .foregroundStyle(DSColor.textPrimary)
                                    .lineLimit(1)
                                if let sub = item.subtitle {
                                    Text(sub)
                                        .font(Typography.caption)
                                        .foregroundStyle(DSColor.textSecondary)
                                        .lineLimit(1)
                                } else {
                                    // Placeholder to maintain consistent height
                                    Text(" ")
                                        .font(Typography.caption)
                                        .foregroundStyle(.clear)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.vertical, 2)
            }
        }
    }
}

struct HDBUpcomingMeetingsCard: View {
    let meetings: [HDBMeeting]

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: Space.md) {
                HDBSectionHeader(title: "My Meetings")
                ForEach(meetings) { m in
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "calendar")
                            .foregroundStyle(DSColor.accent)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(m.title)
                                .font(Typography.bodyEmphasis)
                                .foregroundStyle(DSColor.textPrimary)
                            Text("\(m.room) • \(m.time)")
                                .font(Typography.caption)
                                .foregroundStyle(DSColor.textSecondary)
                        }
                        Spacer()
                    }
                    .padding(.vertical, 2)
                    .contentShape(Rectangle())
                }
            }
        }
    }
}

struct HDBServicesChipsRow: View {
    let chips: [HDBServiceChip]

    var body: some View {
        VStack(alignment: .leading, spacing: Space.md) {
            HDBSectionHeader(title: "Services")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: Space.md) {
                    ForEach(chips) { chip in
                        Button(action: chip.action) {
                            HStack(spacing: 8) {
                                Image(systemName: chip.icon)
                                    .foregroundStyle(DSColor.accent)
                                Text(chip.title)
                                    .foregroundStyle(DSColor.textPrimary)
                            }
                            .font(Typography.body)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .background(
                                Capsule(style: .continuous)
                                    .fill(Color(.secondarySystemBackground))
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

struct HDBHighlightCard: View {
    let item: HDBHighlight

    var body: some View {
        Card {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: item.systemImage)
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(DSColor.accent)
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.title)
                        .font(Typography.bodyEmphasis)
                        .foregroundStyle(DSColor.textPrimary)
                    Text(item.subtitle)
                        .font(Typography.body)
                        .foregroundStyle(DSColor.textSecondary)
                }
                Spacer(minLength: 0)
            }
        }
    }
}
