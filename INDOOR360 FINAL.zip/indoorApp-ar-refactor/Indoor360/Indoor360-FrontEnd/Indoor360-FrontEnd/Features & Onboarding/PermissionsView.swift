//
//  PermissionsView.swift
//  Indoor360-FrontEnd
//
//  FULL replacement.
//  - Live Camera / Location / Notification status
//  - CTA changes to “Continue” when required permissions are granted
//  - Sets @AppStorage("permissionsDone") = true on continue
//  - Location + Camera are REQUIRED, Notifications OPTIONAL
//

import SwiftUI
import AVFoundation
import CoreLocation
import UserNotifications

final class PermissionsVM: NSObject, ObservableObject, CLLocationManagerDelegate {
    // Required permissions
    @Published var cameraGranted: Bool = false
    @Published var locationGranted: Bool = false
    // Optional
    @Published var notificationsGranted: Bool = false

    private var locationManager: CLLocationManager?

    override init() {
        super.init()
        refreshStatuses()
    }

    // MARK: - Status

    func refreshStatuses() {
        // Camera
        let cam = AVCaptureDevice.authorizationStatus(for: .video)
        cameraGranted = (cam == .authorized)

        
        // Location (WhenInUse is enough for indoor)
        let mgr = CLLocationManager()
        let loc = mgr.authorizationStatus
        locationGranted = (loc == .authorizedAlways || loc == .authorizedWhenInUse)


        // Notifications
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                self.notificationsGranted = (settings.authorizationStatus == .authorized ||
                                             settings.authorizationStatus == .provisional ||
                                             settings.authorizationStatus == .ephemeral)
            }
        }
    }

    // MARK: - Requests

    func requestCamera() {
        AVCaptureDevice.requestAccess(for: .video) { _ in
            DispatchQueue.main.async { self.refreshStatuses() }
        }
    }

    func requestLocation() {
        let mgr = CLLocationManager()
        mgr.delegate = self
        mgr.requestWhenInUseAuthorization()
        self.locationManager = mgr
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { _, _ in
            DispatchQueue.main.async { self.refreshStatuses() }
        }
    }

    // MARK: - CLLocationManagerDelegate

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        DispatchQueue.main.async { self.refreshStatuses() }
    }

    // MARK: - Derived

    var requiredGranted: Bool { cameraGranted && locationGranted }
}

struct PermissionsView: View {
    @StateObject private var vm = PermissionsVM()

    /// Must match what RootRouterView reads.
    @AppStorage("permissionsDone") private var permissionsDone: Bool = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Permissions")
                    .font(.largeTitle.bold())
                    .padding(.top, 8)

                // CAMERA
                PermissionCard(
                    title: "Camera",
                    subtitle: "We use the camera to place AR arrows and labels in your space.",
                    status: vm.cameraGranted ? .allowed : .notAllowed,
                    primaryTitle: vm.cameraGranted ? "Open Settings" : "Allow Camera",
                    primaryAction: {
                        if vm.cameraGranted {
                            openSettings()
                        } else {
                            vm.requestCamera()
                        }
                    },
                    secondaryTitle: "Not now"
                )

                // LOCATION
                PermissionCard(
                    title: "Location",
                    subtitle: "We use your location to position you indoors and calculate routes.",
                    status: vm.locationGranted ? .allowed : .notAllowed,
                    primaryTitle: vm.locationGranted ? "Open Settings" : "Allow Location",
                    primaryAction: {
                        if vm.locationGranted {
                            openSettings()
                        } else {
                            vm.requestLocation()
                        }
                    },
                    secondaryTitle: "Not now"
                )

                // NOTIFICATIONS (optional)
                PermissionCard(
                    title: "Notifications",
                    subtitle: "Get helpful updates like route changes or reminders. (Optional)",
                    status: vm.notificationsGranted ? .allowed : .notAllowed,
                    primaryTitle: vm.notificationsGranted ? "Open Settings" : "Allow Notifications",
                    primaryAction: {
                        if vm.notificationsGranted {
                            openSettings()
                        } else {
                            vm.requestNotifications()
                        }
                    },
                    secondaryTitle: "Not now"
                )

                // CTA
                VStack(spacing: 12) {
                    Button {
                        // Mark permissions screen complete. Router will advance.
                        permissionsDone = true
                    } label: {
                        Text(vm.requiredGranted ? "Continue" : "Continue without some permissions")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.orange)
                            .foregroundStyle(Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    .disabled(false) // allow continue even if optional/required not all set (text clarifies)
                    .padding(.top, 8)

                    if !vm.requiredGranted {
                        Text("Camera and Location are required for AR navigation. You can enable them later in Settings.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                }
                .padding(.top, 4)
            }
            .padding(16)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .onAppear { vm.refreshStatuses() }
        .navigationBarBackButtonHidden(true)
    }

    private func openSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }
}

// MARK: - UI card

private enum PermCardStatus {
    case allowed
    case notAllowed
}

private struct PermissionCard: View {
    let title: String
    let subtitle: String
    let status: PermCardStatus
    let primaryTitle: String
    let primaryAction: () -> Void
    let secondaryTitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(title)
                    .font(.title3.weight(.semibold))
                Spacer()
                Text(status == .allowed ? "Allowed" : "Required")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(status == .allowed ? Color.green : Color.red)
                    .clipShape(Capsule())
            }

            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            HStack(spacing: 12) {
                Button(action: primaryAction) {
                    Text(primaryTitle)
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }

                Button(secondaryTitle) { /* noop */ }
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.08), lineWidth: 1)
        )
    }
}
