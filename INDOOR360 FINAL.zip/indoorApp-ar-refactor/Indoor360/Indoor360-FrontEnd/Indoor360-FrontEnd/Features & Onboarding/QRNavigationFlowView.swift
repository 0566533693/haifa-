// QRNavigationFlowView.swift
// Complete QR-based navigation flow: Scan → Pick Destination → Navigate

import SwiftUI

/// Entry point for QR-based indoor navigation.
/// Handles the complete flow from QR scanning to AR step navigation.
struct QRNavigationFlowView: View {
    @EnvironmentObject private var appState: AppState
    @StateObject private var session = NavigationSession()
    @Environment(\.dismiss) private var dismiss

    /// Optional initial QR code passed from QRScanView (already scanned)
    var initialQRCode: String?

    @State private var currentStep: FlowStep = .scanQR
    @State private var showDestinationPicker = false
    @State private var showARNavigation = false
    @State private var hasProcessedInitialQR = false

    enum FlowStep {
        case scanQR
        case pickDestination
        case navigating
    }

    var body: some View {
        NavigationStack {
            Group {
                switch currentStep {
                case .scanQR:
                    scanQRStep
                case .pickDestination:
                    destinationPickerStep
                case .navigating:
                    EmptyView()  // AR navigation is shown as full screen cover
                }
            }
            .navigationTitle(navigationTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
        .task {
            // If we have an initial QR code from QRScanView, process it immediately
            if let qrCode = initialQRCode, !hasProcessedInitialQR {
                hasProcessedInitialQR = true
                await session.setPosition(from: qrCode)
                if session.startPosition != nil {
                    currentStep = .pickDestination
                }
            }
        }
        .fullScreenCover(isPresented: $showARNavigation) {
            ARStepNavigationView(session: session)
                .onDisappear {
                    // Reset when AR navigation completes
                    if !session.isNavigating {
                        session.reset()
                        currentStep = .scanQR
                    }
                }
        }
    }

    private var navigationTitle: String {
        switch currentStep {
        case .scanQR: return "Scan Position"
        case .pickDestination: return "Choose Destination"
        case .navigating: return "Navigating"
        }
    }

    // MARK: - Step 1: Scan QR

    private var scanQRStep: some View {
        VStack(spacing: 24) {
            // Instructions
            VStack(spacing: 8) {
                Image(systemName: "qrcode.viewfinder")
                    .font(.system(size: 60))
                    .foregroundColor(.accentColor)

                Text("Scan a Location QR Code")
                    .font(.title2.bold())

                Text("Find a QR code near an entrance or landmark to set your starting position.")
                    .font(.body)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .padding(.top, 40)

            Spacer()

            // Quick scan button (opens camera)
            NavigationLink {
                QRScannerForNavigationView(session: session, onScanComplete: {
                    if session.startPosition != nil {
                        currentStep = .pickDestination
                    }
                })
            } label: {
                Label("Open Scanner", systemImage: "camera.fill")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 56)
                    .background(Color.accentColor)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .padding(.horizontal, 24)

            // Manual entry (for testing)
            #if DEBUG
            Button {
                Task {
                    await session.setPosition(from: "anchor:reception")
                    if session.startPosition != nil {
                        currentStep = .pickDestination
                    }
                }
            } label: {
                Text("Use Test Position (Reception)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .padding(.bottom, 40)
            #endif

            Spacer()
        }
    }

    // MARK: - Step 2: Pick Destination

    private var destinationPickerStep: some View {
        VStack(spacing: 20) {
            // Current position card
            if let pos = session.startPosition {
                currentPositionCard(pos)
                    .padding(.horizontal)
            }

            Divider()

            // Destination picker
            Text("Where would you like to go?")
                .font(.headline)

            // Search destinations
            DestinationSearchView(onSelect: { poiId, name in
                Task {
                    await session.setDestination(poiId: poiId, name: name)
                    if session.canStartNavigation {
                        session.startNavigation()
                        showARNavigation = true
                        currentStep = .navigating
                    }
                }
            })

            // Loading indicator
            if session.isLoadingRoute {
                ProgressView("Loading route...")
                    .padding()
            }

            // Error message
            if let error = session.errorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
                    .padding()
            }

            Spacer()
        }
        .padding(.top)
    }

    private func currentPositionCard(_ position: QRPositionResponse) -> some View {
        HStack {
            Image(systemName: "mappin.circle.fill")
                .font(.title)
                .foregroundColor(.green)

            VStack(alignment: .leading, spacing: 2) {
                Text("Your Location")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(position.locationName)
                    .font(.headline)
                Text("Floor \(position.floor)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Button {
                session.reset()
                currentStep = .scanQR
            } label: {
                Text("Change")
                    .font(.caption)
                    .foregroundColor(.accentColor)
            }
        }
        .padding()
        .background(Color.green.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - QR Scanner for Navigation

/// Specialized QR scanner that triggers navigation flow on anchor scan
struct QRScannerForNavigationView: View {
    @ObservedObject var session: NavigationSession
    var onScanComplete: () -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var scanner = QRCodeScanner()
    @State private var isConfigured = false
    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info
    @State private var isProcessing = false

    var body: some View {
        ZStack {
            CameraPreview(scanner: scanner)
                .ignoresSafeArea()

            // Framing overlay
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.9), lineWidth: 2)
                .frame(width: 260, height: 260)
                .shadow(radius: 8)

            // Instruction
            VStack {
                Spacer()

                Text("Point camera at a location QR code")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black.opacity(0.5))
                    .clipShape(Capsule())
                    .padding(.bottom, 100)
            }

            // Processing overlay
            if isProcessing {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                VStack {
                    ProgressView()
                        .tint(.white)
                    Text("Setting position...")
                        .foregroundColor(.white)
                        .padding(.top, 8)
                }
            }
        }
        .navigationTitle("Scan QR")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            configureScanner()
            attachHandler()
        }
        .onDisappear {
            scanner.stop()
        }
        .toast(isPresented: $showToast, style: toastStyle, message: toastMessage, duration: 2.0)
    }

    private func configureScanner() {
        guard !isConfigured else { return }
        scanner.configure { ok in
            isConfigured = ok
            if ok { scanner.start() }
        }
    }

    private func attachHandler() {
        scanner.onCode = { raw in
            handleScan(raw)
        }
    }

    private func handleScan(_ raw: String) {
        let link = DeepLinkRouter.parse(raw)

        switch link {
        case .anchor(let id):
            // QR anchor found - resolve it
            scanner.pause()
            isProcessing = true

            Task {
                await session.setPosition(from: "anchor:\(id)")

                await MainActor.run {
                    isProcessing = false

                    if session.startPosition != nil {
                        toast(.success, "Position set: \(session.startPosition?.locationName ?? id)")
                        // Brief delay then navigate
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            dismiss()
                            onScanComplete()
                        }
                    } else {
                        toast(.error, session.errorMessage ?? "QR code not recognized")
                        scanner.resume()
                    }
                }
            }

        default:
            // Not an anchor QR - show message
            let message = DeepLinkRouter.description(for: link)
            toast(.info, "Not a location QR: \(message)")

            DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) {
                scanner.resume()
            }
        }
    }

    private func toast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }
}

// MARK: - Destination Search View

/// Simple destination search view - uses QR anchors as destinations
struct DestinationSearchView: View {
    var onSelect: (Int, String) -> Void
    var currentAnchorCode: String?  // To exclude current location from destinations

    @State private var searchText = ""
    @State private var allPOIs: [POIDestination] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    private var filteredPOIs: [POIDestination] {
        if searchText.isEmpty {
            return allPOIs
        }
        return allPOIs.filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.category.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        VStack {
            // Search field
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)

                TextField("Search for a destination...", text: $searchText)
                    .textFieldStyle(.plain)
                    .autocorrectionDisabled()

                if !searchText.isEmpty {
                    Button {
                        searchText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .padding()
            .background(Color(.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .padding(.horizontal)

            // Results
            if isLoading {
                ProgressView("Loading destinations...")
                    .padding()
            } else if let error = errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .font(.caption)
                    .padding()
            } else if filteredPOIs.isEmpty {
                Text(searchText.isEmpty ? "No destinations available" : "No results found")
                    .foregroundColor(.secondary)
                    .padding()
            } else {
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(filteredPOIs) { poi in
                            Button {
                                onSelect(poi.id, poi.name)
                            } label: {
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(poi.name)
                                            .font(.headline)
                                            .foregroundColor(.primary)
                                        HStack {
                                            Text(poi.category)
                                                .font(.caption)
                                                .foregroundColor(.accentColor)
                                            Text("•")
                                                .foregroundColor(.secondary)
                                            Text("Floor \(poi.floor)")
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                    }
                                    Spacer()
                                    Image(systemName: "arrow.right.circle")
                                        .foregroundColor(.accentColor)
                                }
                                .padding()
                                .background(Color(.systemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                        }
                    }
                    .padding(.horizontal)
                }
            }

            // Quick destinations by floor
            if searchText.isEmpty && !filteredPOIs.isEmpty {
                quickDestinations
            }
        }
        .task {
            await loadPOIs()
        }
    }

    private var quickDestinations: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Popular Destinations")
                .font(.subheadline.bold())
                .foregroundColor(.secondary)
                .padding(.horizontal)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    // Show first 4 POIs as quick picks
                    ForEach(filteredPOIs.prefix(4)) { poi in
                        quickDestinationButton(poi)
                    }
                }
                .padding(.horizontal)
            }
        }
        .padding(.vertical)
    }

    private func quickDestinationButton(_ poi: POIDestination) -> some View {
        Button {
            onSelect(poi.id, poi.name)
        } label: {
            VStack {
                Image(systemName: iconForPOI(poi))
                    .font(.title2)
                Text(poi.name)
                    .font(.caption)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
            }
            .foregroundColor(.primary)
            .frame(width: 80, height: 80)
            .background(Color(.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    private func iconForPOI(_ poi: POIDestination) -> String {
        let name = poi.name.lowercased()
        let category = poi.category.lowercased()
        if name.contains("cafe") || name.contains("food") || category.contains("food") { return "cup.and.saucer.fill" }
        if name.contains("restroom") || name.contains("toilet") || category.contains("restroom") { return "figure.dress.line.vertical.figure" }
        if name.contains("reception") { return "person.fill.questionmark" }
        if name.contains("elevator") || category.contains("elevator") { return "arrow.up.arrow.down" }
        if name.contains("stair") { return "stairs" }
        if name.contains("meeting") || name.contains("conference") || category.contains("conferenceroom") { return "person.3.fill" }
        if name.contains("office") || category.contains("office") { return "building.2.fill" }
        if name.contains("entrance") { return "door.left.hand.open" }
        if name.contains("theater") || name.contains("theatre") || category.contains("auditorium") { return "theatermasks.fill" }
        return "mappin.circle.fill"
    }

    private func loadPOIs() async {
        isLoading = true
        errorMessage = nil

        do {
            let pois = try await QRPositionClient().listPOIs()
            await MainActor.run {
                self.allPOIs = pois
                self.isLoading = false
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "Failed to load destinations"
                self.isLoading = false
                print("❌ Failed to load POIs: \(error)")
            }
        }
    }
}

// MARK: - Preview

#if DEBUG
struct QRNavigationFlowView_Previews: PreviewProvider {
    static var previews: some View {
        QRNavigationFlowView()
            .environmentObject(AppState())
    }
}
#endif
