import SwiftUI
import MapKit

struct RouteStartView: View {
    @Environment(\.dismiss) private var dismiss

    // MARK: - UI State
    @State private var query: String = ""
    @State private var selectedCategory: String? = nil
    @State private var selectedDestination: Destination? = nil

    // show client-side navigation flow
    @State private var showClientNav: Bool = false

    // MARK: - Mock Data

    private let categories: [String] = [
        "Offices", "Meeting Rooms", "War Rooms"
    ]

    private let allResults: [Destination] = [
        .init(name: "Reception"),
        .init(name: "Theater"),
        .init(name: "War Room A3"),
        .init(name: "War Room B1"),
        .init(name: "Meeting 2.14"),
        .init(name: "Elevator East"),
        .init(name: "Bathroom L2"),
        .init(name: "Office 501"),
        .init(name: "Office 502")
    ]

    // Filtered
    private var filteredResults: [Destination] {
        var res = allResults

        if let cat = selectedCategory {
            switch cat {
            case "Offices":
                res = res.filter { $0.name.localizedCaseInsensitiveContains("office") }
            case "Meeting Rooms":
                res = res.filter { $0.name.localizedCaseInsensitiveContains("meeting") }
            case "War Rooms":
                res = res.filter { $0.name.localizedCaseInsensitiveContains("war room") }
            default:
                break
            }
        }

        if !query.isEmpty {
            res = res.filter { $0.name.localizedCaseInsensitiveContains(query) }
        }

        return res
    }

    // MARK: - Body

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Space.lg) {

                // Title
                Text("Where to?")
                    .font(Typography.headlineL)
                    .foregroundStyle(DSColor.textPrimary)
                    .padding(.top, Space.md)

                Text("Search or pick a quick category to begin.")
                    .font(Typography.body)
                    .foregroundStyle(DSColor.textSecondary)

                // Search input
                TextFieldRow(
                    title: "Search",
                    placeholder: "Search destination",
                    text: $query
                )

                // Category chips
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: Space.sm) {
                        ForEach(categories, id: \.self) { cat in
                            Button {
                                selectedCategory = (selectedCategory == cat ? nil : cat)
                            } label: {
                                Text(cat)
                                    .font(Typography.body)
                                    .foregroundStyle(DSColor.textPrimary)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(
                                        Capsule(style: .continuous)
                                            .fill(
                                                selectedCategory == cat
                                                ? DSColor.accent.opacity(0.22)
                                                : Color(.secondarySystemFill)
                                            )
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 2)
                }

                // Results
                Text("Results")
                    .font(Typography.bodyEmphasis)
                    .foregroundStyle(DSColor.textPrimary)
                    .padding(.top, Space.sm)

                VStack(spacing: 8) {
                    ForEach(filteredResults) { item in
                        Button {
                            selectedDestination = item
                        } label: {
                            HStack {
                                Image(systemName: "mappin.and.ellipse")
                                    .foregroundStyle(DSColor.accent)
                                Text(item.name)
                                    .foregroundStyle(DSColor.textPrimary)
                                Spacer()
                                if selectedDestination == item {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(DSColor.accent)
                                }
                            }
                            .padding()
                            .background(Color(.secondarySystemFill))
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }

                // ✅ Start button – always opens client nav
                PrimaryButton(
                    title: "Start Navigation"
                ) {
                    showClientNav = true
                }
                .padding(.top, Space.md)
                .padding(.bottom, Space.xl)

                Spacer(minLength: Space.xl)
            }
            .padding(.horizontal, Space.lg)
            .padding(.bottom, Space.xl)
        }
        .navigationTitle("Start")
        .navigationBarTitleDisplayMode(.inline)
        .background(AppBackgroundView().ignoresSafeArea())
        .fullScreenCover(isPresented: $showClientNav) {
            NavigationStack {
                VenuePickerView()          // 👈 client-side picker
                    .navigationTitle("Choose a Venue")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Close") {
                                showClientNav = false
                            }
                        }
                    }
            }
        }
    }
}

private struct Destination: Identifiable, Equatable {
    let id = UUID()
    let name: String
}
