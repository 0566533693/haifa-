import SwiftUI

struct MeetingsListView: View {
    var body: some View {
        List(MeetingCard.sample) { m in
            VStack(alignment: .leading) {
                Text(m.title).font(Typography.bodyEmphasis)
                Text("\(m.room) • \(m.time)").font(Typography.caption).foregroundStyle(DSColor.textSecondary)
            }
        }
        .navigationTitle("My Meetings")
    }
}

struct FacilityDirectoryView: View {
    var body: some View {
        VStack(spacing: 16) {
            Text("Directory")
                .font(Typography.headlineM)
            Text("Search rooms, desks, printers, cafés and colleagues.")
                .font(Typography.body)
                .foregroundStyle(DSColor.textSecondary)
        }
        .padding()
        .navigationTitle("Directory")
    }
}

struct ARLiveView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "camera.viewfinder").font(.system(size: 48))
            Text("AR Live").font(Typography.headlineM)
            Text("Switches to AR guidance near destination.")
                .font(Typography.body)
                .foregroundStyle(DSColor.textSecondary)
        }
        .padding()
        .navigationTitle("AR")
    }
}

struct ServiceDeskView: View {
    var body: some View {
        List {
            Label("Report a facility issue", systemImage: "wrench.and.screwdriver")
            Label("IT Support",               systemImage: "desktopcomputer")
            Label("Request access",           systemImage: "key")
        }
        .navigationTitle("Service Desk")
    }
}
