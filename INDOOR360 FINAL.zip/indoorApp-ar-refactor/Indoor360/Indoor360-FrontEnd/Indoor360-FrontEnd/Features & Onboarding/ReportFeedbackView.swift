import SwiftUI
import MessageUI

struct ReportFeedbackView: View {
    @State private var category: FeedbackCategory = .bug
    @State private var subject: String = ""
    @State private var message: String = ""
    @State private var email: String = ""
    @State private var includeDiagnostics: Bool = true
    @State private var showMail = false
    @State private var mailUnavailableAlert = false

    var body: some View {
        ScrollView {
            VStack(spacing: Space.lg) {

                Card {
                    VStack(alignment: .leading, spacing: Space.md) {
                        Text("Tell us what’s going on")
                            .font(Typography.headlineM)

                        // Category
                        HStack {
                            Image(systemName: category.icon)
                                .foregroundStyle(DSColor.accent)
                            Picker("Category", selection: $category) {
                                ForEach(FeedbackCategory.allCases, id: \.self) { c in
                                    Text(c.title).tag(c)
                                }
                            }
                            .pickerStyle(.menu)
                        }

                        // Subject
                        LabeledField(title: "Subject", placeholder: "Short summary", text: $subject)

                        // Email
                        LabeledField(title: "Your Email (optional)", placeholder: "you@example.com", text: $email)
                            .textInputAutocapitalization(.never)
                            .keyboardType(.emailAddress)

                        // Message
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Details")
                                .font(Typography.captionEmphasis)
                                .foregroundStyle(DSColor.textSecondary)
                            TextEditor(text: $message)
                                .frame(minHeight: 160)
                                .padding(10)
                                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                                .overlay(RoundedRectangle(cornerRadius: 12).stroke(.white.opacity(0.08), lineWidth: 1))
                        }

                        Toggle(isOn: $includeDiagnostics) {
                            Label("Include anonymous diagnostics", systemImage: "doc.text.magnifyingglass")
                        }
                        .tint(DSColor.accent)

                        Button {
                            send()
                        } label: {
                            Text("Send Feedback")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                Card {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("What’s included?")
                            .font(Typography.bodyEmphasis)
                        Text("We attach app version, device model and iOS version to help reproduce issues. No personal content is collected.")
                            .font(Typography.caption)
                            .foregroundStyle(DSColor.textSecondary)
                    }
                }

                Spacer(minLength: Space.xl)
            }
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.lg)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .navigationTitle("Report & Feedback")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showMail) {
            MailView(
                subject: composeSubject(),
                body: composeBody(),
                to: ["support@indoor360.app"]
            )
        }
        .alert("Mail is not set up", isPresented: $mailUnavailableAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("We couldn’t open the Mail composer on this device. You can send feedback to support@indoor360.app.")
        }
    }

    private func composeSubject() -> String {
        let s = subject.isEmpty ? category.title : subject
        return "[Indoor360] \(category.title) – \(s)"
    }

    private func composeBody() -> String {
        var body = """
        Category: \(category.title)
        From: \(email.isEmpty ? "Not provided" : email)

        Details:
        \(message.isEmpty ? "(No details provided)" : message)
        """
        if includeDiagnostics {
            let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?"
            let build   = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "?"
            let device  = UIDevice.current.model
            let system  = UIDevice.current.systemVersion
            body += """



            ---
            Diagnostics
            App: \(version) (\(build))
            Device: \(device)
            iOS: \(system)
            """
        }
        return body
    }

    private func send() {
        if MFMailComposeViewController.canSendMail() {
            showMail = true
        } else {
            // Fallback to mailto:
            let subjectEncoded = composeSubject().addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
            let bodyEncoded = composeBody().addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
            if let url = URL(string: "mailto:support@indoor360.app?subject=\(subjectEncoded)&body=\(bodyEncoded)") {
                UIApplication.shared.open(url) { success in
                    if !success { mailUnavailableAlert = true }
                }
            } else {
                mailUnavailableAlert = true
            }
        }
    }
}

private enum FeedbackCategory: CaseIterable {
    case bug, idea, content, other

    var title: String {
        switch self {
        case .bug: return "Bug"
        case .idea: return "Feature Idea"
        case .content: return "Map/Content Issue"
        case .other: return "Other"
        }
    }
    var icon: String {
        switch self {
        case .bug: return "ladybug.fill"
        case .idea: return "lightbulb.fill"
        case .content: return "map.fill"
        case .other: return "bubble.left.and.bubble.right.fill"
        }
    }
}

private struct LabeledField: View {
    let title: String
    let placeholder: String
    @Binding var text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(Typography.captionEmphasis)
                .foregroundStyle(DSColor.textSecondary)
            TextField(placeholder, text: $text)
                .padding(.horizontal, 12).padding(.vertical, 10)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(.white.opacity(0.08), lineWidth: 1))
        }
    }
}

/// System Mail composer wrapper
struct MailView: UIViewControllerRepresentable {
    let subject: String
    let body: String
    let to: [String]

    func makeUIViewController(context: Context) -> MFMailComposeViewController {
        let vc = MFMailComposeViewController()
        vc.setSubject(subject)
        vc.setMessageBody(body, isHTML: false)
        vc.setToRecipients(to)
        vc.mailComposeDelegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: MFMailComposeViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator() }
    final class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
        func mailComposeController(_ controller: MFMailComposeViewController,
                                   didFinishWith result: MFMailComposeResult, error: Error?) {
            controller.dismiss(animated: true)
        }
    }
}
