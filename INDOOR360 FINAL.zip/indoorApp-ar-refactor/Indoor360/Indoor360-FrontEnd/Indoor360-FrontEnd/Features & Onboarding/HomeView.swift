/*
import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var appState: AppState

    // UI state
    @State private var arPreferred = false          // manual 2D <-> AR preference
    @State private var showARTip = false            // tiny one-time tip when AR is toggled

    // MARK: - Mock “context” used to personalize the page
    private var nextMeeting: (title: String, room: String, time: String)? {
        // If you already set this in AppState, read it from there instead.
        // This keeps the card looking “smart” even without a backend.
        ("Design Sync", "War Room A3", "10:45 AM")
    }

    // Dynamic quick actions (context + office essentials)
    private var quickActions: [HomeQuickAction] {
        var list: [HomeQuickAction] = []
        if let mtg = nextMeeting {
            list.append(.init(id: "nextMeeting",
                              icon: "person.3.fill",
                              title: "Next Meeting",
                              subtitle: "\(mtg.room) • \(mtg.time)",
                              action: .routeTo("meeting:\(mtg.room)")))
        }

        list.append(contentsOf: [
            .init(id: "reception", icon: "person.crop.circle.badge.questionmark", title: "Reception", subtitle: nil, action: .routeTo("facility:Reception")),
            .init(id: "myOffice", icon: "key.fill", title: "My Office", subtitle: nil, action: .routeTo("place:MyOffice")),
            .init(id: "cafeteria", icon: "fork.knife", title: "Cafeteria", subtitle: "Level 3", action: .routeTo("facility:Cafeteria"))
        ])
        return list
    }

    // High-level groups (chips) – cleaner than a long grid of similar buttons
    private let facilityChips: [Chip] = [
        .init(id: "workspaces", label: "Workspaces"),
        .init(id: "services",   label: "Services"),
        .init(id: "facilities", label: "Facilities")
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Space.lg) {

                    welcomeCard

                    // Quick Actions – dynamic tiles
                    VStack(alignment: .leading, spacing: Space.md) {
                        Text("Quick Actions")
                            .font(Typography.bodyEmphasis)
                            .foregroundStyle(DSColor.textPrimary)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: Space.md) {
                                ForEach(quickActions) { qa in
                                    NavigationLink {
                                        // Route preview screen; the AR/2D preference is on appState/arPreferred
                                        RouteStartView()
                                            .onAppear {
                                                appState.prefersAR = arPreferred
                                            }
                                    } label: {
                                        QuickActionTile(qa: qa)
                                    }
                                }
                            }
                            .padding(.horizontal, 2)
                        }
                    }

                    // Facilities (grouped)
                    VStack(alignment: .leading, spacing: Space.md) {
                        Text("Facilities")
                            .font(Typography.bodyEmphasis)
                            .foregroundStyle(DSColor.textPrimary)

                        FlowChips(chips: facilityChips) { chip in
                            // Push to a filtered venue map (2D first)
                            NavigationLink {
                                VenueMapView() // already in your project
                            } label: {
                                ChipView(label: chip.label)
                            }
                        }
                    }

                    // Recent destinations (optional polish)
                    if !appState.recentDestinations.isEmpty {
                        VStack(alignment: .leading, spacing: Space.md) {
                            Text("Recent")
                                .font(Typography.bodyEmphasis)
                                .foregroundStyle(DSColor.textPrimary)
                            VStack(spacing: 10) {
                                ForEach(appState.recentDestinations.prefix(3), id: \.self) { place in
                                    NavigationLink {
                                        RouteStartView()
                                            .onAppear { appState.prefersAR = arPreferred }
                                    } label: {
                                        RecentRow(title: place)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(minLength: Space.xl)
                }
                .padding(.horizontal, Space.lg)
                .padding(.top, Space.lg)
            }
            .background(AppBackgroundView().ignoresSafeArea())
            .navigationTitle("Indoor360")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    NavigationLink {
                        ProfileView()
                    } label: {
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 22, weight: .semibold))
                    }
                }

                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 18) {
                        // AR/2D toggle (small, subtle)
                        Button {
                            arPreferred.toggle()
                            showARTip = true
                            Haptics.light()
                        } label: {
                            Image(systemName: arPreferred ? "camera.viewfinder" : "map")
                                .font(.system(size: 20, weight: .semibold))
                                .symbolVariant(arPreferred ? .fill : .none)
                        }
                        .accessibilityLabel(arPreferred ? "AR Enabled" : "Map Enabled")

                        NavigationLink {
                            SearchView()
                        } label: {
                            Image(systemName: "magnifyingglass")
                                .font(.system(size: 20, weight: .semibold))
                        }
                    }
                }
            }
            .popover(isPresented: $showARTip, arrowEdge: .top) {
                Text(arPreferred ? "AR will start automatically when navigation begins. You can switch back to 2D anytime." :
                                   "Map preview will be used by default. Switch to AR from the top-right when needed.")
                    .font(Typography.caption)
                    .foregroundStyle(DSColor.textPrimary)
                    .padding()
                    .frame(maxWidth: 320)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .padding()
            }
        }
    }

    // MARK: - Sections

    private var welcomeCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 8) {
                Text("Welcome to Indoor360")
                    .font(Typography.headlineM)
                    .foregroundStyle(DSColor.textPrimary)

                if let mtg = nextMeeting {
                    Text("Your next meeting: \(mtg.title) — \(mtg.room) at \(mtg.time).")
                        .font(Typography.body)
                        .foregroundStyle(DSColor.textSecondary)
                } else {
                    Text("Search PwC offices and facilities. Navigate with AR or 2D maps.")
                        .font(Typography.body)
                        .foregroundStyle(DSColor.textSecondary)
                }
            }
        }
    }
}

// MARK: - Models

private struct HomeQuickAction: Identifiable {
    enum Action { case routeTo(String) }
    let id: String
    let icon: String
    let title: String
    let subtitle: String?
    let action: Action
}

private struct Chip: Identifiable {
    let id: String
    let label: String
}

// MARK: - Building Blocks

private struct QuickActionTile: View {
    let qa: HomeQuickAction

    var body: some View {
        VStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.white.opacity(0.06))
                    .frame(width: 72, height: 72)
                Image(systemName: qa.icon)
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(DSColor.accent)
            }
            VStack(spacing: 2) {
                Text(qa.title)
                    .font(Typography.bodyEmphasis)
                    .foregroundStyle(DSColor.textPrimary)
                if let sub = qa.subtitle {
                    Text(sub)
                        .font(Typography.caption)
                        .foregroundStyle(DSColor.textSecondary)
                        .lineLimit(1)
                }
            }
            .frame(width: 120)
        }
        .padding(10)
        .background(Color.white.opacity(0.03), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

private struct ChipView: View {
    let label: String
    var body: some View {
        Text(label)
            .font(Typography.body)
            .padding(.vertical, 10)
            .padding(.horizontal, 16)
            .background(Color.white.opacity(0.06), in: Capsule())
            .foregroundStyle(DSColor.textPrimary)
    }
}

private struct FlowChips<Content: View>: View {
    let chips: [Chip]
    let content: (Chip) -> Content

    private let spacing: CGFloat = 10

    var body: some View {
        // Simple wrap layout
        var width: CGFloat = 0
        var height: CGFloat = 0

        return GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                ForEach(chips) { chip in
                    content(chip)
                        .padding(.trailing, spacing)
                        .padding(.bottom, spacing)
                        .alignmentGuide(.leading) { dimension in
                            if (abs(width - dimension.width) > geo.size.width) {
                                width = 0
                                height -= dimension.height + spacing
                            }
                            let result = width
                            if chip.id == chips.last?.id { width = 0 } else { width -= dimension.width + spacing }
                            return result
                        }
                        .alignmentGuide(.top) { _ in height }
                }
            }
        }
        .frame(minHeight: 44) // prevents collapse
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct RecentRow: View {
    let title: String
    var body: some View {
        HStack {
            Image(systemName: "clock.arrow.circlepath")
                .foregroundStyle(DSColor.accent)
            Text(title)
                .foregroundStyle(DSColor.textPrimary)
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundStyle(.secondary)
        }
        .font(Typography.body)
        .padding(12)
        .background(Color.white.opacity(0.03), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        HomeView()
            .environmentObject(AppState()) // your existing global state
            .preferredColorScheme(.dark)
    }
}
*/

/*
import SwiftUI

// MARK: - Models

private struct HomeQuickAction: Identifiable {
    let id: String
    let icon: String
    let title: String
    let subtitle: String?
    let action: () -> Void
}

private struct Chip: Identifiable {
    let id: String
    let label: String
    let action: () -> Void
}

// MARK: - View

struct HomeView: View {
    @EnvironmentObject private var appState: AppState

    // Simple internal navigation flags (hook into your existing router as needed)
    @State private var goToRoute = false
    @State private var showProfile = false
    @State private var showSearch = false

    // Build quick actions in a computed prop so the closure captures are simple and typed
    private var quickActions: [HomeQuickAction] {
        [
            .init(id: "startNav", icon: "location.north.line.fill",
                  title: "Start Nav…", subtitle: "Pick destination") {
                goToRoute = true
            },
            .init(id: "myOffice", icon: "key.fill",
                  title: "My Office", subtitle: nil) {
                goToRoute = true
            },
            .init(id: "meetings", icon: "person.3.sequence.fill",
                  title: "Meeting Rooms", subtitle: nil) {
                goToRoute = true
            },
            .init(id: "warRooms", icon: "shield.fill",
                  title: "War Rooms", subtitle: nil) {
                goToRoute = true
            }
        ]
    }

    private var facilityChips: [Chip] {
        [
            .init(id: "theater",    label: "Theater")    { goToRoute = true },
            .init(id: "elevators",  label: "Elevators")  { goToRoute = true },
            .init(id: "bathrooms",  label: "Bathrooms")  { goToRoute = true }
        ]
    }

    // MARK: body

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Space.lg) {
                    // Keep your existing header area exactly as you have it.
                    // (Profile button + centered title + search button)
                    // If that’s already in a parent, remove the line below.
                    headerBar

                    WelcomeCard()

                    QuickActionsRow(items: quickActions)

                    FacilityChipsRow(chips: facilityChips)

                    Spacer(minLength: Space.xl)
                }
                .padding(.horizontal, Space.lg)
                .padding(.top, Space.lg)
                .padding(.bottom, Space.xl)
            }
            .background(AppBackgroundView().ignoresSafeArea())

            // Hidden pushes (keep your current destinations)
            .navigationDestination(isPresented: $showProfile) {
                ProfileView()
            }
            .navigationDestination(isPresented: $showSearch) {
                SearchView()
            }
            .navigationDestination(isPresented: $goToRoute) {
                RouteStartView()
            }
        }
    }

    // MARK: Header (matches your current layout: left profile, centered title, right search)

    private var headerBar: some View {
        HStack {
            Button {
                showProfile = true
            } label: {
                Image(systemName: "person.crop.circle.fill")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(DSColor.accent)
                    .padding(8)
                    .background(.ultraThinMaterial, in: Circle())
            }
            Spacer()
            Text("Indoor360")
                .font(Typography.bodyEmphasis)
                .foregroundStyle(DSColor.textPrimary)
            Spacer()
            Button {
                showSearch = true
            } label: {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(DSColor.accent)
                    .padding(8)
                    .background(.ultraThinMaterial, in: Circle())
            }
        }
        .padding(.horizontal, 2) // keeps alignment identical to your screenshot
    }
}

// MARK: - Subviews

private struct WelcomeCard: View {
    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                Text("Welcome to Indoor360")
                    .font(Typography.headlineM)
                    .foregroundStyle(DSColor.textPrimary)
                Text("Search PwC offices and facilities. Navigate with AR or 2D maps.")
                    .font(Typography.body)
                    .foregroundStyle(DSColor.textSecondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

private struct QuickActionsRow: View {
    let items: [HomeQuickAction]

    var body: some View {
        VStack(alignment: .leading, spacing: Space.md) {
            Text("Quick Actions")
                .font(Typography.bodyEmphasis)
                .foregroundStyle(DSColor.textPrimary)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: Space.md) {
                    ForEach(items) { item in
                        Button(action: item.action) {
                            VStack(spacing: 6) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .fill(Color(.secondarySystemBackground).opacity(0.35))
                                        .frame(width: 88, height: 88)
                                    Image(systemName: item.icon)
                                        .font(.system(size: 28, weight: .semibold))
                                        .foregroundStyle(DSColor.accent)
                                }
                                Text(item.title)
                                    .font(Typography.captionEmphasis)
                                    .foregroundStyle(DSColor.textPrimary)
                                    .lineLimit(1)
                                if let sub = item.subtitle {
                                    Text(sub)
                                        .font(Typography.caption)
                                        .foregroundStyle(DSColor.textSecondary)
                                        .lineLimit(1)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.vertical, 2)
            }
        }
    }
}

private struct FacilityChipsRow: View {
    let chips: [Chip]

    var body: some View {
        VStack(alignment: .leading, spacing: Space.md) {
            Text("Facilities")
                .font(Typography.bodyEmphasis)
                .foregroundStyle(DSColor.textPrimary)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: Space.md) {
                    ForEach(chips) { chip in
                        Button(action: chip.action) {
                            Text(chip.label)
                                .font(Typography.body)
                                .foregroundStyle(DSColor.textPrimary)
                                .padding(.horizontal, 18)
                                .padding(.vertical, 10)
                                .background(
                                    Capsule(style: .continuous)
                                        .fill(Color(.secondarySystemBackground).opacity(0.35))
                                )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

// MARK: - Preview

#Preview {
    HomeView()
        .environmentObject(AppState())
        .preferredColorScheme(.dark)
}
*/

import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var appState: AppState

    @State private var goToRoute = false
    @State private var showProfile = false
    @State private var showSearch = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Space.lg) {
                    // Header kept exactly like your app
                    headerBar

                    // Dashboard content (everything below header)
                    HomeDashboard()
                }
                .padding(.horizontal, Space.lg)
                .padding(.top, Space.lg)
                .padding(.bottom, 100) // Extra padding for custom tab bar
            }
            .background(AppBackgroundView().ignoresSafeArea())

            // Keep your hidden destinations if needed
            .navigationDestination(isPresented: $showProfile) { ProfileView() }
            .navigationDestination(isPresented: $showSearch) { SearchView() }
            .navigationDestination(isPresented: $goToRoute) { RouteStartView() }
        }
        .task {
            do {
                let ok = try await APIClient.shared.getJSON("/api/nlp/healthz", as: [String: Bool].self)
                print("✅ NLP health:", ok)
            } catch {
                print("❌ NLP health error:", error)
            }
        }

        .navigationDestination(isPresented: $appState.isShowingARNavigation) {
            ARNavigationView()
                .environmentObject(appState)
        }



    }

    // MARK: Header (unchanged)
    private var headerBar: some View {
        HStack {
            Button { showProfile = true } label: {
                Image(systemName: "person.crop.circle.fill")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(DSColor.accent)
                    .padding(8)
                    .background(.ultraThinMaterial, in: Circle())
            }
            Spacer()
            Text("Indoor360")
                .font(Typography.bodyEmphasis)
                .foregroundStyle(DSColor.textPrimary)
            Spacer()
            Button { showSearch = true } label: {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(DSColor.accent)
                    .padding(8)
                    .background(.ultraThinMaterial, in: Circle())
            }
        }
        .padding(.horizontal, 2)
    }
}

#Preview {
    HomeView()
        .environmentObject(AppState())
        .preferredColorScheme(.dark)
}

