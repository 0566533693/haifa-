/*
import SwiftUI

struct MoreView: View {
    @AppStorage("appTheme") private var appTheme: String = "system"

    var body: some View {
        ScrollView {
            VStack(spacing: Space.lg) {

                // ⚠️ Appearance moved to Profile — removed here.

                // Help & FAQ
                Card {
                    VStack(alignment: .leading, spacing: Space.sm) {
                        Text("Help & FAQ").font(Typography.headlineM)
                        Text("Find answers to common questions and tips for Indoor360.")
                            .foregroundStyle(DSColor.textSecondary)
                            .font(Typography.body)
                        PrimaryButton(title: "Open Help") { /* open your help url */ }
                    }
                }

                // Feedback
                Card {
                    VStack(alignment: .leading, spacing: Space.sm) {
                        Text("Report & Feedback").font(Typography.headlineM)
                        Text("Tell us if something isn’t working or share ideas to improve.")
                            .foregroundStyle(DSColor.textSecondary)
                            .font(Typography.body)
                        PrimaryButton(title: "Send Feedback") { /* mailto or form */ }
                    }
                }

                // About
                Card {
                    VStack(alignment: .leading, spacing: Space.sm) {
                        Text("About Indoor360").font(Typography.headlineM)
                        Text("Version 1.0 (1)")
                            .foregroundStyle(DSColor.textSecondary)
                            .font(Typography.caption)
                        Text("Indoor wayfinding with accessible, step-free routing and AR guidance.")
                            .foregroundStyle(DSColor.textSecondary)
                            .font(Typography.body)
                    }
                }
            }
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.lg)
            .padding(.bottom, Space.xl)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .navigationTitle("More")
        .navigationBarTitleDisplayMode(.inline)
    }
}
*/

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Space.lg) {

                    // Help
                    Card {
                        VStack(alignment: .leading, spacing: Space.md) {
                            Text("Help & FAQ")
                                .font(Typography.headlineM)
                                .foregroundStyle(DSColor.textPrimary)
                            Text("Find answers to common questions and tips for Indoor360.")
                                .font(Typography.body)
                                .foregroundStyle(DSColor.textSecondary)

                            NavigationLink {
                                HelpFAQView()
                            } label: {
                                Text("Open Help")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }

                    // Feedback
                    Card {
                        VStack(alignment: .leading, spacing: Space.md) {
                            Text("Report & Feedback")
                                .font(Typography.headlineM)
                            Text("Tell us if something isn’t working or share ideas to improve.")
                                .font(Typography.body)
                                .foregroundStyle(DSColor.textSecondary)

                            NavigationLink {
                                ReportFeedbackView()
                            } label: {
                                Text("Send Feedback")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }

                    // About
                    Card {
                        VStack(alignment: .leading, spacing: Space.md) {
                            Text("About Indoor360")
                                .font(Typography.headlineM)
                            Text("Indoor wayfinding with accessible, step-free routing and AR guidance.")
                                .font(Typography.body)
                                .foregroundStyle(DSColor.textSecondary)

                            NavigationLink {
                                AboutIndoor360View()
                            } label: {
                                Text("Learn More")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }

                    Spacer(minLength: Space.xl)
                }
                .padding(.horizontal, Space.lg)
                .padding(.top, Space.lg)
                .padding(.bottom, 100) // Extra padding for custom tab bar
            }
            .background(AppBackgroundView().ignoresSafeArea())
            .navigationTitle("More")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    MoreView()
        .environmentObject(AppState())
        .preferredColorScheme(.dark)
}

