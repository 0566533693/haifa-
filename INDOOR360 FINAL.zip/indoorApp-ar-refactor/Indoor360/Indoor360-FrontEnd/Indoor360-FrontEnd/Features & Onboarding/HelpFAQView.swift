import SwiftUI

// MARK: - Local model (self-contained so there are no missing-type errors)

private struct FAQItem: Identifiable, Hashable {
    let id: UUID = UUID()
    let category: String
    let question: String
    let answer: String

    static let defaultItems: [FAQItem] = [
        // Getting Started
        .init(
            category: "Getting Started",
            question: "What is Indoor360?",
            answer: "Indoor360 helps you search PwC offices and facilities, and navigate with step-by-step routes in AR or 2D."
        ),
        .init(
            category: "Getting Started",
            question: "Do I need an account?",
            answer: "You can browse and navigate as a guest. Create an account to save places, sync preferences, and get a personalized experience."
        ),
        .init(
            category: "Getting Started",
            question: "Which locations are supported?",
            answer: "Indoor360 supports PwC venues that are mapped in the system. Availability grows over time."
        ),

        // Navigation
        .init(
            category: "Navigation",
            question: "How do I start navigation?",
            answer: "Use the search button on the Home screen, choose a destination, then tap Start. You can follow AR guidance or 2D map steps."
        ),
        .init(
            category: "Navigation",
            question: "Why does the route look off?",
            answer: "Make sure camera permissions are granted and you’re standing near a known landmark. If issues persist, switch to 2D guidance."
        ),
        .init(
            category: "Navigation",
            question: "Can I save a place?",
            answer: "Yes. Open a POI and tap the bookmark icon. Saved places appear in your Profile."
        ),

        // Accessibility
        .init(
            category: "Accessibility",
            question: "How do I change text size?",
            answer: "Profile → Accessibility → Text Size. Adjust between 80% and 140% for comfortable reading."
        ),
        .init(
            category: "Accessibility",
            question: "What is High Contrast Mode?",
            answer: "High Contrast boosts UI contrast and can switch the app’s theme to improve legibility."
        ),
        .init(
            category: "Accessibility",
            question: "Can I enable haptic feedback?",
            answer: "Yes. Profile → Accessibility → Haptic Feedback."
        ),

        // Account & Privacy
        .init(
            category: "Account & Privacy",
            question: "How do I edit my profile?",
            answer: "Profile → Edit. You can change your name, email, phone and date of birth."
        ),
        .init(
            category: "Account & Privacy",
            question: "How do I change my password?",
            answer: "Profile → Account Actions → Change Password. You’ll be asked to confirm your current password first."
        ),
        .init(
            category: "Account & Privacy",
            question: "How is my data used?",
            answer: "Your data enables features like saved places and preferences. We don’t sell your personal data."
        ),

        // Troubleshooting
        .init(
            category: "Troubleshooting",
            question: "The camera view is black.",
            answer: "Check camera permissions in iOS Settings → Privacy → Camera. Restart the app after enabling."
        ),
        .init(
            category: "Troubleshooting",
            question: "Search can’t find my room.",
            answer: "Try a broader keyword (e.g., just the number). If it’s missing, tap Report & Feedback from the More tab."
        )
    ]
}

// MARK: - Main View

struct HelpFAQView: View {
    @State private var query: String = ""
    @State private var expandedIDs: Set<UUID> = []

    private let faqs: [FAQItem] = FAQItem.defaultItems

    private var filtered: [FAQItem] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return faqs }
        return faqs.filter { item in
            item.question.localizedCaseInsensitiveContains(q) ||
            item.answer.localizedCaseInsensitiveContains(q) ||
            item.category.localizedCaseInsensitiveContains(q)
        }
    }

    private var grouped: [(category: String, items: [FAQItem])] {
        let dict = Dictionary(grouping: filtered, by: { $0.category })
        return dict.keys.sorted().map { key in
            (category: key, items: dict[key] ?? [])
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: Space.md) {
                headerCard()
                searchField()

                ForEach(grouped, id: \.category) { section in
                    faqSection(category: section.category, items: section.items)
                }

                Spacer(minLength: Space.xl)
            }
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.lg)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .navigationTitle("Help & FAQ")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Pieces

    @ViewBuilder
    private func headerCard() -> some View {
        Card {
            VStack(alignment: .leading, spacing: 8) {
                Text("How can we help?")
                    .font(Typography.headlineM)
                    .foregroundStyle(DSColor.textPrimary)
                Text("Browse common questions or search by keyword.")
                    .font(Typography.body)
                    .foregroundStyle(DSColor.textSecondary)
            }
        }
    }

    @ViewBuilder
    private func searchField() -> some View {
        HStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(DSColor.textSecondary)
            TextField("Search questions…", text: $query)
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(.white.opacity(0.08), lineWidth: 1)
        )
    }

    @ViewBuilder
    private func faqSection(category: String, items: [FAQItem]) -> some View {
        Card {
            VStack(alignment: .leading, spacing: Space.sm) {
                Text(category)
                    .font(Typography.bodyEmphasis)
                    .foregroundStyle(DSColor.textPrimary)
                    .padding(.bottom, 4)

                ForEach(items) { item in
                    FAQRow(
                        item: item,
                        isExpanded: expandedIDs.contains(item.id),
                        onToggle: { toggleExpand(item.id) }
                    )
                    .padding(.vertical, 6)

                    if item.id != items.last?.id {
                        Divider().opacity(0.15)
                    }
                }
            }
        }
    }

    private func toggleExpand(_ id: UUID) {
        if expandedIDs.contains(id) {
            expandedIDs.remove(id)
        } else {
            expandedIDs.insert(id)
        }
    }
}

// MARK: - Row

private struct FAQRow: View {
    let item: FAQItem
    let isExpanded: Bool
    let onToggle: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: onToggle) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Image(systemName: isExpanded ? "chevron.down.circle.fill" : "chevron.right.circle.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(DSColor.accent)
                    Text(item.question)
                        .font(Typography.bodyEmphasis)
                        .foregroundStyle(DSColor.textPrimary)
                    Spacer()
                }
            }
            .buttonStyle(.plain)

            if isExpanded {
                Text(item.answer)
                    .font(Typography.body)
                    .foregroundStyle(DSColor.textSecondary)
                    .transition(.opacity)
            }
        }
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        HelpFAQView()
            .environmentObject(AppState())
    }
    .preferredColorScheme(.dark)
}
