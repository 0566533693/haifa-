//
//  ARCoordinator.swift
//  Indoor360-FrontEnd
//
//  Created by Shahad  on 09/11/2025.
//

//
//  ARCoordinator.swift
//  Indoor360-FrontEnd
//

//
//  ARCoordinator.swift
//  Indoor360-FrontEnd
//

import Foundation
import RealityKit
import ARKit

final class ARCoordinator: NSObject, ObservableObject {

    // Exposed ARView for SwiftUI
    let arView: ARView = {
        let view = ARView(frame: .zero)

        // Prevent RealityKit from auto-configuring so we manage it ourselves
        view.automaticallyConfigureSession = false

        // Reduce scene processing (MVP)
        view.environment.sceneUnderstanding.options = []

        return view
    }()

    // MARK: - Start AR Session
    func startSession() {
        let config = ARWorldTrackingConfiguration()

        // Horizontal plane anchors only (light)
        config.planeDetection = [.horizontal]

        // Realistic lighting
        config.environmentTexturing = .automatic

        // Reset & start
        arView.session.run(config, options: [.resetTracking, .removeExistingAnchors])
    }

    // MARK: - Stop AR Session
    func stopSession() {
        arView.session.pause()
    }
}
