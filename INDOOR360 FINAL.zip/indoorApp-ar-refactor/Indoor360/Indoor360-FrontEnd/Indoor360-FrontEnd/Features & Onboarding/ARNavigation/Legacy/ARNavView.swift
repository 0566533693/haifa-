import SwiftUI

struct ARNavView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var vm = ARNavViewModel()

    // 2D push when device lowered
    @State private var show2D = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()   // AR camera feed placeholder

                // Chevron path (static if Reduce Motion)
                chevrons
                    .accessibilityHidden(true)

                // Top banner
                VStack {
                    banner
                    Spacer()
                }

                // Bottom controls
                VStack {
                    Spacer()
                    HStack(spacing: 16) {
                        NavigationLink {
                            VenueMapView()     // your 2D map screen
                        } label: {
                            pill(icon: "map", title: "2D Map")
                        }
                        Spacer()
                        Button {
                            vm.reroute()
                        } label: {
                            pill(icon: "goforward", title: "Reroute")
                        }
                        .accessibilityLabel(Text("Reroute"))
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 24)
                }

                // Toast (very lightweight)
                if vm.showRerouteToast {
                    VStack {
                        Spacer()
                        Text("Rerouting…")
                            .font(.footnote.weight(.semibold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 12).padding(.vertical, 8)
                            .background(Color.black.opacity(0.6))
                            .clipShape(Capsule())
                            .padding(.bottom, 90)
                    }
                    .transition(.opacity)
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Label("Back", systemImage: "chevron.left")
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationTitle("AR")
            // Auto switch to 2D if phone lowered
            .onChange(of: vm.isRaised) { _, raised in
                if !raised { show2D = true }
            }
            .navigationDestination(isPresented: $show2D) {
                VenueMapView()
            }
            .onAppear { vm.start() }
            .onDisappear { vm.stop() }
        }
    }

    // MARK: - Pieces

    private var banner: some View {
        HStack(spacing: 10) {
            Image(systemName: vm.isAligned ? "arrow.turn.right.up" : "scope")
                .font(.headline.bold())
            Text(vm.bannerText)
                .font(.headline)
                .lineLimit(1)
            if !vm.isAligned {
                ProgressView(value: vm.aligningProgress)
                    .frame(width: 80)
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .padding(.top, 10)
        .accessibilityLabel(Text(vm.bannerText))
    }

    private var chevrons: some View {
        HStack(spacing: 36) {
            ForEach(0..<5, id: \.self) { i in
                Image(systemName: "chevron.right")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(Color.orange.opacity(0.3 + Double(i) * 0.175))
                    .offset(y: reduceMotion ? 0 : (i % 2 == 0 ? -4 : 4))
                    .animation(reduceMotion ? nil : .easeInOut(duration: 0.9).repeatForever(autoreverses: true), value: vm.isAligned)
            }
        }
    }

    private func pill(icon: String, title: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
            Text(title)
                .font(.body.weight(.semibold))
        }
        .foregroundColor(Color.blue)
        .padding(.horizontal, 14).padding(.vertical, 10)
        .background(Color.black.opacity(0.45))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}
