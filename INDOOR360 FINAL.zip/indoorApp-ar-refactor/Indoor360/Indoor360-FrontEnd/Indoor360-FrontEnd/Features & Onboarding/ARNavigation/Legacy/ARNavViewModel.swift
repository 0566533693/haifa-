import Foundation
import Combine

final class ARNavViewModel: ObservableObject {
    // UI state
    @Published var bannerText: String = "In 8m, turn right"
    @Published var showRerouteToast: Bool = false
    @Published var aligningProgress: Double = 0
    @Published var isAligned: Bool = false
    @Published var isRaised: Bool = true        // mirrored from MotionService

    private let alignment: AlignmentService
    private let motion: MotionService
    private var bag = Set<AnyCancellable>()

    // MARK: - Init
    init(alignment: AlignmentService = AlignmentServiceMock(),
         motion: MotionService = MotionService()) {
        self.alignment = alignment
        self.motion = motion
        observe()
    }

    // MARK: - Lifecycle
    func start() {
        alignment.startSession()
        motion.start()
        alignment.beginAlignment()
    }

    func stop() {
        alignment.stopSession()
        motion.stop()
    }

    // MARK: - Intents
    func reroute() {
        alignment.reroute()
        showRerouteToast = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) { [weak self] in
            self?.showRerouteToast = false
        }
    }

    func simulateDrift() { alignment.simulateDrift() }
    func relocalize()    { alignment.beginRelocalize() }

    // MARK: - Observe
    private func observe() {
        alignment.statePublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] state in
                guard let self else { return }
                switch state {
                case .idle:
                    self.isAligned = false
                    self.aligningProgress = 0
                    self.bannerText = "Aligning…"
                case .aligning(let p):
                    self.isAligned = false
                    self.aligningProgress = p
                    self.bannerText = "Aligning…"
                case .aligned:
                    self.isAligned = true
                    self.aligningProgress = 1
                    self.bannerText = "In 8m, turn right"
                case .drifting:
                    self.isAligned = false
                    self.bannerText = "Tracking lost • Relocalize"
                case .relocalizing:
                    self.isAligned = false
                    self.bannerText = "Relocalizing…"
                case .failed(let msg):
                    self.isAligned = false
                    self.bannerText = "Alignment failed: \(msg)"
                }
            }
            .store(in: &bag)

        motion.$isRaised
            .receive(on: DispatchQueue.main)
            .sink { [weak self] new in self?.isRaised = new }
            .store(in: &bag)
    }
}
