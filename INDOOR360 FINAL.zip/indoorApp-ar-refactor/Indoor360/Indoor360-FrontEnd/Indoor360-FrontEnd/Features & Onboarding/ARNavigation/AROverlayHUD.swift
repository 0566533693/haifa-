//
//  AROverlayHUD.swift
//  Indoor360-FrontEnd
//
//  Created by Shahad  on 09/11/2025.
//

//
//  AROverlayHUD.swift
//  Indoor360-FrontEnd
//

import SwiftUI

/// Placeholder HUD overlay.
/// Will host arrows, POI labels, instructions, etc.
struct AROverlayHUD: View {
    var body: some View {
        EmptyView()
    }
}

#Preview {
    AROverlayHUD()
}
