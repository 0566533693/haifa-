import SwiftUI

// MARK: - Local models for grouped suggestions

private enum SuggestionCategory: String, CaseIterable, Hashable {
    case facilities = "Facilities"
    case rooms      = "Rooms"
    case people     = "People"
    case recent     = "Recent"
}

private struct SuggestionItem: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let icon: String
    let category: SuggestionCategory
}

@MainActor
struct SearchView: View {
    @EnvironmentObject var appState: AppState
    @StateObject private var vm = SearchViewModel()
    @StateObject private var speechRecognizer = SpeechRecognizer()

    // Mic + toast state
    @State private var isListening = false
    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info

    // Navigation to map view
    @State private var showMapNavigation = false

    // MARK: - UI helpers

    private func toast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }

    // MARK: - Demo data (static suggestions)

    private let allFacilities: [SuggestionItem] = [
        .init(title: "Reception",      icon: "person.crop.circle.badge.checkmark", category: .facilities),
        .init(title: "Elevators",      icon: "arrow.up.arrow.down.circle.fill",    category: .facilities),
        .init(title: "Bathrooms",      icon: "toilet.fill",                        category: .facilities),
        .init(title: "Theater",        icon: "facemask",                           category: .facilities),
        .init(title: "Wellbeing Room", icon: "heart.circle.fill",                  category: .facilities)
    ]

    private let allRooms: [SuggestionItem] = [
        .init(title: "War Room A3",  icon: "shield.lefthalf.filled", category: .rooms),
        .init(title: "Meeting 2.14", icon: "person.2.fill",          category: .rooms),
        .init(title: "My Office",    icon: "person.badge.key.fill",  category: .rooms)
    ]

    private let allPeople: [SuggestionItem] = [
        .init(title: "Sarah Lee", icon: "person.fill", category: .people),
        .init(title: "Omar Khan", icon: "person.fill", category: .people)
    ]

    private var groupedSuggestions: [(SuggestionCategory, [SuggestionItem])] {
        let q = vm.query.trimmingCharacters(in: .whitespacesAndNewlines)
        let recents = vm.recents.map { SuggestionItem(title: $0, icon: "clock.fill", category: .recent) }

        // When query is empty, don't show suggestions here - mainResultsSection shows recentList
        if q.isEmpty {
            return []
        }

        let fac = allFacilities.filter { $0.title.localizedCaseInsensitiveContains(q) }
        let rms = allRooms.filter      { $0.title.localizedCaseInsensitiveContains(q) }
        let ppl = allPeople.filter     { $0.title.localizedCaseInsensitiveContains(q) }
        let rct = recents.filter       { $0.title.localizedCaseInsensitiveContains(q) }

        var result: [(SuggestionCategory, [SuggestionItem])] = []
        if !fac.isEmpty { result.append((.facilities, Array(fac.prefix(5)))) }
        if !rms.isEmpty { result.append((.rooms,      Array(rms.prefix(5)))) }
        if !ppl.isEmpty { result.append((.people,     Array(ppl.prefix(5)))) }
        if !rct.isEmpty { result.append((.recent,     Array(rct.prefix(4)))) }
        return result
    }

    // MARK: - NLP + Routing

    private func tapGoNLP() async {
        let raw = vm.query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else {
            toast(.info, "Type or say a query first")
            return
        }

        await vm.resolveWithNLPAndRoute()
    }

    private func runRouteIfPossible(to toId: Int) async {
        do {
            let client = PathClient()
            let route  = try await client.route(from: vm.startPoiId, to: toId)
            vm.lastRoute = route

            Swift.print("🧭 route from SearchView:",
                        route.path.count, "segments, distance:",
                        route.lengthM)
        } catch {
            Swift.print("❌ route error:", error.localizedDescription)
            toast(.error, "Route error: \(error.localizedDescription)")
        }
    }

    // MARK: - Body

    var body: some View {
        VStack(spacing: Space.md) {
            searchBarSection
            nlpMatchesSection
            suggestionsSection
            mainResultsSection
            Spacer(minLength: Space.md)
        }
        .onChange(of: vm.lastRoute?.path.count ?? 0) { _ in
            if vm.lastRoute != nil {
                // Open the real indoor map navigation view
                showMapNavigation = true
            }
        }
        .fullScreenCover(isPresented: $showMapNavigation) {
            NavigationStack {
                VenuePickerView()
                    .navigationTitle("Choose a Venue")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Close") {
                                showMapNavigation = false
                            }
                        }
                    }
            }
        }
        .toast(isPresented: $showToast,
               style: toastStyle,
               message: toastMessage,
               duration: 2.0)
        .background(AppBackgroundView())
        .navigationTitle("Search")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Sections split out

    private var searchBarSection: some View {
        VStack(spacing: 4) {
            HStack(spacing: Space.sm) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(DSColor.textSecondary)

                TextField("Search for shops, toilets, elevators…", text: $vm.query)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .foregroundColor(DSColor.textPrimary)
                    .tint(DSColor.accent)
                    .submitLabel(.search)
                    .onSubmit {
                        Task { await tapGoNLP() }
                    }

                Button(action: {
                    if speechRecognizer.isRecording {
                        speechRecognizer.stopRecording()
                        isListening = false

                        let spoken = speechRecognizer.transcript
                            .trimmingCharacters(in: .whitespacesAndNewlines)

                        if !spoken.isEmpty {
                            vm.query = spoken
                            Task { await tapGoNLP() }
                        }
                    } else {
                        speechRecognizer.startRecording()
                        isListening = true
                    }
                }) {
                    Image(systemName: isListening ? "mic.fill" : "mic")
                        .foregroundColor(isListening ? .red : DSColor.accent)
                        .frame(width: AX.minTapSize, height: AX.minTapSize)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(Text("Voice search"))
            }
            .padding(.horizontal, Space.md)
            .frame(height: 52)
            .background(DSColor.surface)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.md)
            .onChange(of: speechRecognizer.transcript) { text in
                vm.query = text
            }

            if isListening {
                Text("🎙️ Listening…")
                    .font(Typography.captionEmphasis)
                    .foregroundColor(.red)
            }
        }
    }

    private var nlpMatchesSection: some View {
        Group {
            if !vm.nlpMatches.isEmpty {
                VStack(spacing: 0) {
                    HStack {
                        Text("Voice / NLP matches")
                            .font(Typography.captionEmphasis)
                            .foregroundStyle(.secondary)
                        Spacer()
                    }
                    .padding(.horizontal, Space.lg)
                    .padding(.top, Space.sm)

                    ForEach(vm.nlpMatches.prefix(5), id: \.poiId) { match in
                        Button {
                            Task {
                                vm.nlpResolved = (poiId: match.poiId, name: match.poiName)
                                await runRouteIfPossible(to: match.poiId)
                            }
                        } label: {
                            HStack(spacing: Space.md) {
                                Image(systemName: "location.circle.fill")
                                    .foregroundColor(DSColor.accent)
                                    .frame(width: 24, height: 24)

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(match.poiName)
                                        .font(Typography.bodyEmphasis)
                                        .foregroundColor(DSColor.textPrimary)
                                    Text("Floor \(match.floorId) • conf \(String(format: "%.2f", match.confidence))")
                                        .font(Typography.caption)
                                        .foregroundColor(DSColor.textSecondary)
                                }

                                Spacer()
                            }
                            .padding(.horizontal, Space.lg)
                            .padding(.vertical, 8)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var suggestionsSection: some View {
        Group {
            if !groupedSuggestions.isEmpty {
                VStack(spacing: 0) {
                    ScrollView(.vertical, showsIndicators: true) {
                        LazyVStack(spacing: 0) {
                            ForEach(groupedSuggestions, id: \.0) { (category, items) in
                                HStack {
                                    Text(category.rawValue)
                                        .font(Typography.captionEmphasis)
                                        .foregroundStyle(.secondary)
                                    Spacer()
                                }
                                .padding(.horizontal, Space.lg)
                                .padding(.top, Space.sm)

                                ForEach(items) { item in
                                    SearchSuggestionRow(item: item) {
                                        selectSuggestion(item.title)
                                    }
                                    Divider().opacity(item.id == items.last?.id ? 0 : 0.12)
                                }
                            }
                        }
                        .padding(.vertical, Space.xs)
                    }
                    .frame(maxHeight: 260)
                }
                .background(.ultraThinMaterial,
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(.white.opacity(0.08), lineWidth: 1)
                )
                .padding(.horizontal, Space.lg)
            }
        }
    }

    private var mainResultsSection: some View {
        Group {
            if vm.isSearching {
                VStack(spacing: Space.sm) {
                    Skeleton(); Skeleton(); Skeleton()
                }
                .padding(.horizontal, Space.lg)
            } else if vm.query.isEmpty {
                recentList
            } else if vm.results.isEmpty {
                emptyState
            } else {
                resultsList
            }
        }
    }

    // MARK: - Subviews

    private var recentList: some View {
        VStack(alignment: .leading, spacing: Space.sm) {
            HStack {
                Text("Recents")
                    .font(Typography.headlineM)
                Spacer()
                Button(action: { vm.clearRecents() }) { Text("Clear") }
                    .font(Typography.captionEmphasis)
                    .foregroundColor(DSColor.accent)
                    .minTapTarget()
            }
            .padding(.horizontal, Space.lg)

            if vm.recents.isEmpty {
                Text("No recent searches yet.")
                    .font(Typography.caption)
                    .foregroundColor(DSColor.textSecondary)
                    .padding(.horizontal, Space.lg)
            } else {
                ForEach(Array(vm.recents.enumerated()), id: \.offset) { index, term in
                    Button(action: { selectSuggestion(term) }) {
                        HStack {
                            Image(systemName: "clock")
                                .foregroundColor(DSColor.textSecondary)
                            Text(term)
                                .foregroundColor(DSColor.textPrimary)
                            Spacer()
                        }
                        .padding(.vertical, Space.xs)
                        .padding(.horizontal, Space.lg)
                    }
                    .buttonStyle(.plain)
                    .minTapTarget()
                }
            }
        }
    }

    private var resultsList: some View {
        List {
            ForEach(vm.results) { poi in
                Button(action: {
                    vm.selectResult(poi)
                    // Trigger navigation by setting the query and calling NLP
                    vm.query = poi.name
                    Task { await tapGoNLP() }
                }) {
                    HStack(spacing: Space.md) {
                        Image(systemName: icon(for: poi.category))
                            .foregroundColor(DSColor.accent)
                            .frame(width: 28)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(poi.name)
                                .font(Typography.bodyEmphasis)
                                .foregroundColor(DSColor.textPrimary)
                            Text("\(poi.category.rawValue.capitalized) • floor \(poi.floor)\(poi.distanceMeters != nil ? " • \(poi.distanceMeters!)m" : "")")
                                .font(Typography.caption)
                                .foregroundColor(DSColor.textSecondary)
                        }
                        Spacer()
                    }
                    .contentShape(Rectangle())
                }
                .accessibilityLabel(Text("\(poi.name), \(poi.category.rawValue) on floor \(poi.floor)"))
            }
        }
        .listStyle(.plain)
    }

    private var emptyState: some View {
        VStack(spacing: Space.sm) {
            Image(systemName: "magnifyingglass.circle")
                .font(.system(size: 44))
                .foregroundColor(DSColor.textSecondary)
            Text("No results").font(Typography.headlineM)
            Text("Try a different keyword, like “elevator” or “toilet”.")
                .font(Typography.caption)
                .foregroundColor(DSColor.textSecondary)
        }
        .padding(.top, Space.xl)
    }

    // MARK: - Helpers

    private func selectSuggestion(_ term: String) {
        vm.query = term
        SearchHistoryStore.add(term)
        Task { await tapGoNLP() }
    }

    private func icon(for cat: POICategory) -> String {
        switch cat {
        case .shop:       return "bag"
        case .restaurant: return "fork.knife"
        case .toilet:     return "toilet.circle"
        case .elevator:   return "arrow.up.and.down.circle"
        case .exit:       return "door.left.hand.open"
        case .info:       return "info.circle"
        case .atm:        return "banknote"
        }
    }
}

// MARK: - Suggestion Row

private struct SearchSuggestionRow: View {
    let item: SuggestionItem
    let tap: () -> Void

    var body: some View {
        Button(action: tap) {
            HStack(spacing: 10) {
                Image(systemName: item.icon)
                    .foregroundStyle(item.category == .recent ? .secondary : DSColor.accent)
                    .frame(width: 22)
                Text(item.title)
                    .foregroundStyle(DSColor.textPrimary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.horizontal, Space.md)
            .padding(.vertical, 10)
        }
        .buttonStyle(.plain)
    }
}

#if DEBUG
struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            SearchView().environmentObject(AppState())
        }
    }
}
#endif
