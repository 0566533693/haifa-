import SwiftUI
import Combine

struct OTPVerifyView: View {
    @Environment(\.dismiss) private var dismiss

    let phoneDisplay: String
    @State private var code: String = ""
    @State private var countdown: Int = 30
    @State private var isLoading: Bool = false
    @State private var timerCancellable: AnyCancellable?

    var body: some View {
        VStack(spacing: Space.lg) {
            Text("Enter the 6-digit code")
                .font(Typography.headlineL)
                .frame(maxWidth: .infinity, alignment: .leading)

            Text("We sent a code to \(phoneDisplay).")
                .foregroundColor(DSColor.textSecondary)
                .frame(maxWidth: .infinity, alignment: .leading)

            OTPInput(code: $code)       // your existing component
                .onChange(of: code) { _, new in
                    if new.count > 6 { code = String(new.prefix(6)) }
                }

            PrimaryButton(title: "Verify", action: verify, isLoading: isLoading, isDisabled: code.count != 6)

            Button(countdown > 0 ? "Resend in \(countdown)s" : "Resend code") {
                resend()
            }
            .disabled(countdown > 0)
            .foregroundColor(DSColor.accent)

            Spacer()
        }
        .padding(.horizontal, Space.lg)
        .padding(.top, Space.xl)
        .background(AppBackgroundView().ignoresSafeArea())
        .onAppear { startTimer() }
        .onDisappear { timerCancellable?.cancel() }
        .navigationBarTitleDisplayMode(.inline)
    }

    private func verify() {
        isLoading = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            isLoading = false
            // In a real app you’d verify then pop.
            dismiss()
        }
    }

    private func resend() {
        countdown = 30
        startTimer()
    }

    private func startTimer() {
        timerCancellable?.cancel()
        timerCancellable = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { _ in
                if countdown > 0 { countdown -= 1 }
            }
    }
}

#Preview {
    OTPVerifyView(phoneDisplay: "55 555 5561")
}
