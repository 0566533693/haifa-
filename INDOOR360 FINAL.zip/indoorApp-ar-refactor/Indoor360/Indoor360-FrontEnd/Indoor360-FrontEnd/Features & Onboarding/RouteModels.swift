import Foundation

/// One point on the route returned by /api/path/route.
struct RouteSegment: Decodable {
    let x: Double
    let y: Double
    let z: Double
}

/// Must match backend JSON: {"path":[...], "length_m": 662.63}
struct RouteResponse: Decodable {
    let path: [RouteSegment]
    let lengthM: Double   // ⚠️ keep the underscore, same as backend
}
