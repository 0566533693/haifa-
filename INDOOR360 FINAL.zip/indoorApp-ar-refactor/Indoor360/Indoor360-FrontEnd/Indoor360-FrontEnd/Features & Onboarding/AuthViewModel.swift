import Foundation
import Combine

final class AuthViewModel: ObservableObject {
    enum Mode {
        case signIn
        case signUp
    }

    // MARK: - Published state

    @Published var mode: Mode

    @Published var fullName: String = ""
    @Published var email: String = ""
    @Published var password: String = ""

    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil

    /// Tracks whether user has attempted to submit - validation errors only show after this is true
    @Published var hasAttemptedSubmit: Bool = false

    init(mode: Mode = .signIn) {
        self.mode = mode
    }

    // MARK: - Validation

    /// Full name must be at least 2 non-whitespace characters (matches backend SignUpRequest)
    var isFullNameValid: Bool {
        fullName.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2
    }

    /// Email validation with a more robust regex (similar to your first version)
    var isEmailValid: Bool {
        let text = email.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return false }

        // Simple but solid email regex
        let pattern = #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#
        let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive])
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        return regex?.firstMatch(in: text, options: [], range: range) != nil
    }

    /// Backend requires at least 8 characters (SignUpRequest / LoginRequest)
    var isPasswordMinLengthValid: Bool {
        password.count >= 8
    }

    /// Bcrypt limit: max 72 bytes when UTF-8 encoded (matches your backend validators)
    var isPasswordWithinBackendLimit: Bool {
        password.utf8.count <= 72
    }

    var isPasswordValid: Bool {
        isPasswordMinLengthValid && isPasswordWithinBackendLimit
    }

    /// Overall form validity for current mode
    var canSubmit: Bool {
        if isLoading { return false }

        switch mode {
        case .signIn:
            return isEmailValid && isPasswordValid
        case .signUp:
            return isEmailValid && isPasswordValid && isFullNameValid
        }
    }

    // MARK: - Actions

    func toggleMode() {
        mode = (mode == .signIn ? .signUp : .signIn)
        errorMessage = nil
        hasAttemptedSubmit = false
        // Optional: clear password when changing mode for safety
        password = ""
    }

    /// Placeholder – you can later hook this to a FastAPI "forgot password" endpoint if you add one.
    func forgotPassword() {
        // Currently not implemented in backend – just clear error for now.
        errorMessage = nil
    }

    /// Main CTA handler - calls your real backend API via AuthService
    func primaryAction(completion: @escaping (Bool) -> Void) {
        // Mark that user has attempted to submit - this enables inline validation errors
        hasAttemptedSubmit = true

        // Frontend-side validation before hitting backend
        guard canSubmit else {
            if !isEmailValid {
                errorMessage = "Please enter a valid email address."
            } else if !isPasswordMinLengthValid {
                errorMessage = "Password must be at least 8 characters long."
            } else if !isPasswordWithinBackendLimit {
                errorMessage = "Password must not exceed 72 bytes."
            } else if mode == .signUp && !isFullNameValid {
                errorMessage = "Name must be at least 2 characters."
            } else {
                errorMessage = "Please check your details and try again."
            }
            completion(false)
            return
        }

        isLoading = true
        errorMessage = nil

        Task {
            do {
                let response: AuthResponse

                if mode == .signUp {
                    response = try await AuthService.signUp(
                        name: fullName.trimmingCharacters(in: .whitespacesAndNewlines),
                        email: email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(),
                        password: password
                    )
                } else {
                    response = try await AuthService.login(
                        email: email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(),
                        password: password
                    )
                }

                // Here AuthService should internally:
                // - store JWT token
                // - update AppState.currentUser or similar (depending on your architecture)

                await MainActor.run {
                    isLoading = false
                    errorMessage = nil
                    completion(true)
                }
            } catch let error as AuthService.AuthError {
                await MainActor.run {
                    isLoading = false
                    errorMessage = error.localizedDescription
                    completion(false)
                }
            } catch {
                await MainActor.run {
                    isLoading = false
                    errorMessage = "An unexpected error occurred. Please try again."
                    completion(false)
                }
            }
        }
    }
}
