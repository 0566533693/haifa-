
import SwiftUI
import Combine

/// Persistent accessibility & account prefs for Profile screen.
/// Uses @AppStorage so settings survive app restarts.
final class ProfileViewModel: ObservableObject {

    // MARK: - Accessibility (persisted)
    @AppStorage("ax_highContrast") var highContrast: Bool = false
    @AppStorage("ax_textScale")   var textScale: Int   = 100  // percent
    @AppStorage("ax_voiceInput")  var voiceInput: Bool = true
    @AppStorage("ax_haptics")     var haptics: Bool    = true

    // Bounds for text scaling (match UI preview)
    let minScale = 80
    let maxScale = 130

    func decreaseTextScale() {
        textScale = max(minScale, textScale - 5)
    }

    func increaseTextScale() {
        textScale = min(maxScale, textScale + 5)
    }
}

