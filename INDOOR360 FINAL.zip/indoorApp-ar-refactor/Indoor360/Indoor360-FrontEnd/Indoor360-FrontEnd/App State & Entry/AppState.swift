import SwiftUI
import Combine

/// Global application state shared across features.
final class AppState: ObservableObject {
    // MARK: - Product / Session

    @Published var hasCompletedOnboarding: Bool
    @Published var hasCompletedCorePermissions: Bool
    @Published var isAuthenticated: Bool
    @Published var isGuest: Bool = false
    @Published var currentUser: User? = nil

    // MARK: - Accessibility & UI preferences

    @Published var prefersReducedMotion: Bool = UIAccessibility.isReduceMotionEnabled
    @Published var prefersHighContrast: Bool = UIAccessibility.isDarkerSystemColorsEnabled
    /// nil = follow system
    @Published var appTheme: ColorScheme? = nil

    // MARK: - Routing (text / list)

    @Published var startDestinationPOIId: String? = nil

    // MARK: - AR routing (Phase 8)

    /// Controls whether the AR navigation experience is visible.
    @Published var isShowingARNavigation: Bool = false
    /// Optional extra flag if you need “active vs just presented”
    @Published var isARNavigationActive: Bool = false
    /// The currently active route (if any).
    @Published var activeRoute: RouteResponse? = nil

    // MARK: - Init

    init() {
        self.hasCompletedOnboarding      = SettingsStore.loadOnboardingDone()
        self.hasCompletedCorePermissions = SettingsStore.loadCorePermissionsDone()
        self.isAuthenticated             = SettingsStore.loadIsAuthenticated()
        self.isGuest                     = SettingsStore.loadIsGuest()
        self.appTheme                    = SettingsStore.loadTheme()

        // Try to restore user session on startup (if we think they’re authenticated).
        Task { @MainActor in
            await restoreUserSession()
        }
    }

    // MARK: - AR helpers

    func startARNavigation(with route: RouteResponse) {
        self.activeRoute = route
        self.isShowingARNavigation = true
        self.isARNavigationActive = true
    }

    func stopARNavigation() {
        self.isARNavigationActive = false
        self.isShowingARNavigation = false
        self.activeRoute = nil
    }

    // MARK: - Auth Helpers

    /// Called after a successful login/signup + /api/auth/me
    func loginUser(_ user: User) {
        self.currentUser = user
        self.isAuthenticated = true
        self.isGuest = false
        SettingsStore.saveIsAuthenticated(true)
        SettingsStore.saveIsGuest(false)
    }

    /// Clear all local auth state (used after logout / token failure).
    func logoutUser() {
        self.currentUser = nil
        self.isAuthenticated = false
        self.isGuest = false

        KeychainHelper.delete()
        SettingsStore.saveIsAuthenticated(false)
        SettingsStore.saveIsGuest(false)
    }

    /// Restore user session from stored JWT on app launch.
    @MainActor
    func restoreUserSession() async {
        // Only restore if the app thinks user was authenticated and not a guest
        guard isAuthenticated && !isGuest else { return }

        // Check if a token exists
        guard KeychainHelper.get() != nil else {
            // No token → just clear state
            logoutUser()
            return
        }

        do {
            // Ask backend who this user is
            let user = try await AuthService.getCurrentUser()
            self.currentUser = user
        } catch {
            // Token invalid/expired or network error → log out locally
            print("[AppState] Failed to restore user session: \(error)")
            logoutUser()
        }
    }
}
