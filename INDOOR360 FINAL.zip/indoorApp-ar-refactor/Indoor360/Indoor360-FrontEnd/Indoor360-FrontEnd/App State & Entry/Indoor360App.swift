/*
import SwiftUI

@main
struct Indoor360App: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootRouterView()
                .environmentObject(appState)
                .onAppear {
                    appState.hasCompletedOnboarding      = SettingsStore.loadOnboardingDone()
                    appState.hasCompletedCorePermissions = SettingsStore.loadCorePermissionsDone()
                    appState.isAuthenticated             = SettingsStore.loadIsAuthenticated()
                    appState.isGuest                     = SettingsStore.loadIsGuest()
                    appState.appTheme                    = SettingsStore.loadTheme()
                }
        }
    }
}
*/
import SwiftUI

@main
struct Indoor360App: App {
    @StateObject private var appState = AppState()
    @StateObject private var router = NavigationRouter()
    @StateObject private var motionManager = MotionManager.shared
    @StateObject private var sessionStore = SessionStore.shared

    init() {
        // Firebase removed - using direct backend authentication
    }

    var body: some Scene {
        WindowGroup {
            RootRouterView()
                .environmentObject(sessionStore)
                .environmentObject(appState)
                .environmentObject(router)
                .environmentObject(motionManager)
                .onAppear {
                    appState.hasCompletedOnboarding      = SettingsStore.loadOnboardingDone()
                    appState.hasCompletedCorePermissions = SettingsStore.loadCorePermissionsDone()
                    appState.isAuthenticated             = SettingsStore.loadIsAuthenticated()
                    appState.isGuest                     = SettingsStore.loadIsGuest()
                    appState.appTheme                    = SettingsStore.loadTheme()
                }
        }
    }
}

