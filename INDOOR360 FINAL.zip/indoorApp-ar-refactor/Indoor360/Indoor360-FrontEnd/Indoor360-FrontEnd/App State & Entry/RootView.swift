import SwiftUI

struct RootView: View {
    @EnvironmentObject var appState: AppState

    // Global router lives here
    @StateObject var router = NavigationRouter()

    // Hold the shared MotionManager as a StateObject without calling init()
    @StateObject var motion = MotionManager.shared

    var body: some View {
        Group {
            // Your normal gating for onboarding/auth/permissions → tabs
            content
                // Router-driven 2D/AR stack
                .background(
                    NavigationStack {
                        switch router.current {
                        case .venueMap:
                            VenueMapView()
                        case .arNavigation:
                            ARNavigationView()
                        }
                    }
                    .opacity(0)   // hosted for routing only; your app may present differently
                )
        }
        .environmentObject(router)
        .environmentObject(motion)
    }

    @ViewBuilder
    private var content: some View {
        if !appState.hasCompletedOnboarding {
            OnboardingView()
        } else if (!appState.isAuthenticated && !appState.isGuest) {
            AuthView()
        } else if !appState.hasCompletedCorePermissions {
            PermissionsView()
        } else {
            RootRouterView()
        }
    }
}
