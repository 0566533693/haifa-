//
//  NavigationRouter.swift
//  Indoor360-FrontEnd
//
//  Created by Shahad  on 09/11/2025.
//


import SwiftUI

/// Controls global navigation transitions between 2D ↔ AR.
@MainActor
final class NavigationRouter: ObservableObject {

    // Where we are now
    @Published var current: Screen = .venueMap

    /// All possible destinations
    enum Screen: Equatable {
        case venueMap
        case arNavigation
    }

    // MARK: - Push

    func pushToAR() {
        current = .arNavigation
    }

    func pushToVenueMap() {
        current = .venueMap
    }

    // MARK: - Pop Helpers

    func popToVenueMap() {
        current = .venueMap
    }
}
