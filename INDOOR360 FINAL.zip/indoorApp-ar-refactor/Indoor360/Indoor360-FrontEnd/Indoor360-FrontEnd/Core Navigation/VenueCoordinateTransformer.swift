import Foundation

/// Converts between the backend's local meter-based coordinate system and
/// WGS84 longitude/latitude, keeping iOS map overlays in sync with the
/// navigation graph that ships inside the IMDF bundle.
enum VenueCoordinateTransformer {
    // These constants must match the values used when exporting nav_nodes /
    // nav_edges via scripts/export_nav_graph_geojson.py.
    private static let originLongitude: Double = 55.2746839
    private static let originLatitude: Double = 25.2007704
    private static let metersPerDegreeLat: Double = 111_320.0
    private static let metersPerDegreeLon: Double = {
        let radians = originLatitude * .pi / 180.0
        return 111_320.0 * cos(radians)
    }()

    /// Convert local (meter) coordinates back to IMDF-friendly WGS84.
    static func localToWGS(x: Double, y: Double) -> IMDFPoint {
        let lon = x / metersPerDegreeLon + originLongitude
        let lat = y / metersPerDegreeLat + originLatitude
        return IMDFPoint(x: lon, y: lat)
    }

    /// Convert a tuple of local coordinates to WGS84.
    static func localToWGS(_ point: (x: Double, y: Double)) -> IMDFPoint {
        localToWGS(x: point.x, y: point.y)
    }

    /// Convert WGS84 coordinates into the backend's local meter system.
    static func wgsToLocal(lon: Double, lat: Double) -> (x: Double, y: Double) {
        let x = (lon - originLongitude) * metersPerDegreeLon
        let y = (lat - originLatitude) * metersPerDegreeLat
        return (x, y)
    }

    /// Convenience overload for IMDFPoint → local meters.
    static func wgsToLocal(_ point: IMDFPoint) -> (x: Double, y: Double) {
        wgsToLocal(lon: point.x, lat: point.y)
    }
}
