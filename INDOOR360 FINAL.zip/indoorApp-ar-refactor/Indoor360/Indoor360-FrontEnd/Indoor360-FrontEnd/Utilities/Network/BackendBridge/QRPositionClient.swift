// QRPositionClient.swift
// API client for QR code positioning

import Foundation

// MARK: - DTOs from backend /api/qr

/// Response from /api/qr/resolve
struct QRPositionResponse: Codable {
    let poiId: Int
    let poiName: String
    let locationName: String
    let x: Double
    let y: Double
    let z: Double
    let floor: Int
    let description: String?

    private enum CodingKeys: String, CodingKey {
        case poiId = "poi_id"
        case poiName = "poi_name"
        case locationName = "location_name"
        case x, y, z, floor, description
    }
}

/// Response from /api/qr/list
struct QRAnchorInfo: Codable, Identifiable {
    let qrCode: String
    let locationName: String
    let floor: Int
    let poiId: Int?  // Optional - some anchors may not have linked POIs
    let description: String?

    var id: String { qrCode }

    private enum CodingKeys: String, CodingKey {
        case qrCode = "qr_code"
        case locationName = "location_name"
        case floor
        case poiId = "poi_id"
        case description
    }
}

/// POI info from /api/poi/list for destination selection
struct POIDestination: Codable, Identifiable {
    let id: Int
    let name: String
    let category: String
    let floor: String
    let x: Double
    let y: Double
    let z: Double
}

/// Wrapper for /api/poi/list response
struct POIListResponse: Codable {
    let pois: [POIDestination]
}

// MARK: - QR Position Errors

enum QRPositionError: LocalizedError {
    case invalidURL
    case httpError(statusCode: Int, message: String)
    case decodingError(Error)
    case networkError(Error)
    case qrNotFound(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid server URL"
        case .httpError(let code, let message):
            return "Server error (\(code)): \(message)"
        case .decodingError(let error):
            return "Failed to decode response: \(error.localizedDescription)"
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .qrNotFound(let qrCode):
            return "QR code '\(qrCode)' not recognized"
        }
    }
}

// MARK: - Client

final class QRPositionClient {

    /// Central configuration from AppConfig
    private var baseURL: String { AppConfig.baseURL.absoluteString }

    /// Resolve a QR code (e.g., "anchor:reception") to POI coordinates.
    /// This is the main method called when a user scans a QR code.
    func resolve(_ qrCode: String) async throws -> QRPositionResponse {
        guard let url = URL(string: "\(baseURL)/api/qr/resolve") else {
            throw QRPositionError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = ["qr_code": qrCode]
        request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            if let http = response as? HTTPURLResponse {
                if http.statusCode == 404 {
                    throw QRPositionError.qrNotFound(qrCode)
                }
                if !(200..<300).contains(http.statusCode) {
                    let text = String(data: data, encoding: .utf8) ?? "Unknown error"
                    print("❌ QR resolve HTTP \(http.statusCode): \(text)")
                    throw QRPositionError.httpError(statusCode: http.statusCode, message: text)
                }
            }

            let decoder = JSONDecoder()
            return try decoder.decode(QRPositionResponse.self, from: data)

        } catch let error as QRPositionError {
            throw error
        } catch let error as DecodingError {
            throw QRPositionError.decodingError(error)
        } catch {
            throw QRPositionError.networkError(error)
        }
    }

    /// List all available QR anchors, optionally filtered by floor.
    /// Useful for debugging or showing available entry points.
    func listAnchors(floor: Int? = nil) async throws -> [QRAnchorInfo] {
        var urlString = "\(baseURL)/api/qr/list"
        if let floor = floor {
            urlString += "?floor=\(floor)"
        }

        guard let url = URL(string: urlString) else {
            throw QRPositionError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            if let http = response as? HTTPURLResponse,
               !(200..<300).contains(http.statusCode) {
                let text = String(data: data, encoding: .utf8) ?? "Unknown error"
                print("❌ QR list HTTP \(http.statusCode): \(text)")
                throw QRPositionError.httpError(statusCode: http.statusCode, message: text)
            }

            let decoder = JSONDecoder()
            return try decoder.decode([QRAnchorInfo].self, from: data)

        } catch let error as QRPositionError {
            throw error
        } catch let error as DecodingError {
            throw QRPositionError.decodingError(error)
        } catch {
            throw QRPositionError.networkError(error)
        }
    }

    /// List all POIs for destination selection.
    /// Returns all navigable destinations including rooms, facilities, etc.
    func listPOIs() async throws -> [POIDestination] {
        guard let url = URL(string: "\(baseURL)/api/poi/list") else {
            throw QRPositionError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            if let http = response as? HTTPURLResponse,
               !(200..<300).contains(http.statusCode) {
                let text = String(data: data, encoding: .utf8) ?? "Unknown error"
                print("❌ POI list HTTP \(http.statusCode): \(text)")
                throw QRPositionError.httpError(statusCode: http.statusCode, message: text)
            }

            let decoder = JSONDecoder()
            let poiResponse = try decoder.decode(POIListResponse.self, from: data)
            return poiResponse.pois

        } catch let error as QRPositionError {
            throw error
        } catch let error as DecodingError {
            throw QRPositionError.decodingError(error)
        } catch {
            throw QRPositionError.networkError(error)
        }
    }

    /// Get a specific QR anchor by its code (alternative to resolve for GET requests)
    func getAnchor(_ qrCode: String) async throws -> QRPositionResponse {
        let encodedQR = qrCode.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? qrCode
        guard let url = URL(string: "\(baseURL)/api/qr/anchor/\(encodedQR)") else {
            throw QRPositionError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            if let http = response as? HTTPURLResponse {
                if http.statusCode == 404 {
                    throw QRPositionError.qrNotFound(qrCode)
                }
                if !(200..<300).contains(http.statusCode) {
                    let text = String(data: data, encoding: .utf8) ?? "Unknown error"
                    throw QRPositionError.httpError(statusCode: http.statusCode, message: text)
                }
            }

            let decoder = JSONDecoder()
            return try decoder.decode(QRPositionResponse.self, from: data)

        } catch let error as QRPositionError {
            throw error
        } catch let error as DecodingError {
            throw QRPositionError.decodingError(error)
        } catch {
            throw QRPositionError.networkError(error)
        }
    }
}
