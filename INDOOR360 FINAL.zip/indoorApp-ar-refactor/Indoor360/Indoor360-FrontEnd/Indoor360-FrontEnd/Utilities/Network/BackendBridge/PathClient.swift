// PathClient.swift
import Foundation

// MARK: - DTOs from backend /api/path/route

struct RoutePointDTO: Codable {
    let x: Double
    let y: Double
    let z: Double
}

/// Matches backend JSON:
/// {
///   "path": [ { "x": .., "y": .., "z": .. }, ... ],
///   "length_m": 3.21
/// }
struct RouteResponseDTO: Codable {
    let path: [RoutePointDTO]
    let lengthM: Double

    private enum CodingKeys: String, CodingKey {
        case path
        case lengthM = "length_m"   // snake_case → camelCase
    }
}

// MARK: - Client

final class PathClient {

    /// Calls backend /api/path/route with a simple from/to POI id.
    func route(from fromId: Int, to toId: Int) async throws -> RouteResponseDTO {
        let url = AppConfig.baseURL.appendingPathComponent("api/path/route")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "fromPoiId": fromId,
            "toPoiId": toId
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])

        let (data, response) = try await URLSession.shared.data(for: req)

        if let http = response as? HTTPURLResponse,
           !(200..<300).contains(http.statusCode) {
            let text = String(data: data, encoding: .utf8) ?? ""
            print("❌ Route HTTP \(http.statusCode): \(text)")
            throw NSError(
                domain: "PathClient",
                code: http.statusCode,
                userInfo: [NSLocalizedDescriptionKey: text]
            )
        }

        let decoder = JSONDecoder()
        let route = try decoder.decode(RouteResponseDTO.self, from: data)
        return route
    }
}
