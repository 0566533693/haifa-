// NLPBridge.swift
import Foundation

// MARK: - DTOs

struct NLPMatch: Codable {
    let poiId: Int
    let poiName: String
    let buildingId: Int
    let floorId: Int
    let confidence: Double
}

private struct NLPRequestBody: Codable {
    let query: String
}

// MARK: - Client

enum NLPBridge {
    /// Central configuration from AppConfig
    private static var baseURL: URL { AppConfig.baseURL }

    // /api/nlp/resolve  →  [NLPMatch]
    static func resolve(_ query: String) async throws -> [NLPMatch] {
        var url = baseURL
        url.appendPathComponent("api/nlp/resolve")

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = NLPRequestBody(query: query)
        req.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: req)

        if let http = response as? HTTPURLResponse,
           !(200..<300).contains(http.statusCode) {
            let text = String(data: data, encoding: .utf8) ?? ""
            print("❌ NLP HTTP \(http.statusCode): \(text)")
            // no APIError.httpStatus – just a simple NSError
            throw NSError(
                domain: "NLPBridge",
                code: http.statusCode,
                userInfo: [NSLocalizedDescriptionKey: text]
            )
        }

        let matches = try JSONDecoder().decode([NLPMatch].self, from: data)
        return matches
    }

    // GET /healthz  → { "ok": true }
    static func health() async throws -> [String: Bool] {
            var url = baseURL
            url.appendPathComponent("healthz")        // <-- IMPORTANT

            let (data, response) = try await URLSession.shared.data(from: url)

            if let http = response as? HTTPURLResponse,
               !(200..<300).contains(http.statusCode) {
                let text = String(data: data, encoding: .utf8) ?? ""
                print("❌ NLP health HTTP \(http.statusCode): \(text)")
                throw NSError(
                    domain: "NLPBridge",
                    code: http.statusCode,
                    userInfo: [NSLocalizedDescriptionKey: text]
                )
            }

            let json = try JSONDecoder().decode([String: Bool].self, from: data)
            return json
        }
    }
