import Foundation

struct NLPResolveReq: Encodable { let q: String }
struct NLPResolveRes: Decodable {
    let intent: String
    let target_poi_id: Int?
    let target_name: String?
    let confidence: Double
    let strategy: String?
}

final class NLPClient {
    static let shared = NLPClient()          // ← ensure this exists

    func resolve(_ query: String) async throws -> NLPResolveRes {
        try await APIClient.shared.postJSON("/api/nlp/resolve",
                                            body: NLPResolveReq(q: query),
                                            as: NLPResolveRes.self)
    }

    func health() async throws -> [String: Bool] {
        try await APIClient.shared.getJSON("/api/nlp/healthz", as: [String: Bool].self)
    }
}
