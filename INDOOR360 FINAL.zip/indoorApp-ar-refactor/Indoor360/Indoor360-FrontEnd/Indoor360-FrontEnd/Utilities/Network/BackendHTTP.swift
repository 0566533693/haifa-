//
//  BackendHTTP.swift
//  Indoor360-FrontEnd
//
//  Created by Haifa  on 11/11/2025.
//

import Foundation

enum BackendHTTPError: Error { case badURL, badStatus(Int), decode, offline }

final class BackendHTTP {
    static let shared = BackendHTTP()
    private init() {}

    // Central configuration from AppConfig
    static var baseURL: URL { AppConfig.baseURL }

    func postJSON<T: Encodable, U: Decodable>(_ path: String, body: T, as: U.Type) async throws -> U {
        var req = URLRequest(url: Self.baseURL.appendingPathComponent(path))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONEncoder().encode(body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw BackendHTTPError.offline }
        guard (200..<300).contains(http.statusCode) else { throw BackendHTTPError.badStatus(http.statusCode) }
        return try JSONDecoder().decode(U.self, from: data)
    }

    func getJSON<U: Decodable>(_ path: String, as: U.Type) async throws -> U {
        let url = Self.baseURL.appendingPathComponent(path)
        let (data, resp) = try await URLSession.shared.data(from: url)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw BackendHTTPError.offline
        }
        return try JSONDecoder().decode(U.self, from: data)
    }
}
