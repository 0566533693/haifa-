//
//  FeaturFlags.swift
//  Indoor360-FrontEnd
//
//  Created by Haifa  on 11/11/2025.
//

enum FeatureFlags {
    static let USE_BACKEND_ROUTE = true     // backend /api/path/route
    static let USE_BACKEND_POSITION = false // keep device pose for now
}
