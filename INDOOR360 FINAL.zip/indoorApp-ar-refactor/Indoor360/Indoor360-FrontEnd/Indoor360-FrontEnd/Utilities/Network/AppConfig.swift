import Foundation

/// Central configuration for the Indoor360 app.
/// All network services should reference this file for the base URL.
///
/// To switch between simulator and physical device:
/// - Simulator: Use "http://localhost:8000"
/// - Physical device: Use your Mac's LAN IP, e.g., "http://192.168.1.180:8000"
enum AppConfig {

    #if targetEnvironment(simulator)
    // Simulator can use localhost
    static let baseURL: URL = {
        let s = "http://localhost:8000"
        guard let url = URL(string: s) else {
            preconditionFailure("Invalid AppConfig.baseURL: \\(s)")
        }
        return url
    }()
    #else
    // Physical device needs the Mac's LAN IP
    static let baseURL: URL = {
        // TODO: Update this to your Mac's current LAN IP for physical device testing
        let s = "http://192.168.1.180:8000"
        guard let url = URL(string: s) else {
            preconditionFailure("Invalid AppConfig.baseURL: \\(s)")
        }
        return url
    }()
    #endif
}
