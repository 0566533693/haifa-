import Foundation

// MARK: - Error type

enum APIError: Error, CustomStringConvertible {
    case badURL
    case badStatus(Int, String)
    case decode(String)
    case offline(String)

    var description: String {
        switch self {
        case .badURL:
            return "Bad URL"
        case .badStatus(let code, let body):
            return "HTTP \(code): \(body)"
        case .decode(let msg):
            return "Decode error: \(msg)"
        case .offline(let msg):
            return "Offline: \(msg)"
        }
    }
}

// MARK: - API client

final class APIClient {
    static let shared = APIClient()
    private init() {}

    private let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.keyEncodingStrategy = .convertToSnakeCase
        return e
    }()

    private let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .convertFromSnakeCase
        return d
    }()

    // MARK: - POST JSON (relative path)

    func postJSON<T: Encodable, U: Decodable>(
        _ path: String,
        body: T,
        as: U.Type
    ) async throws -> U {
        let url = AppConfig.baseURL.appendingPathComponent(path)
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try encoder.encode(body)

        print("➡️ POST", url.absoluteString)

        let data: Data
        let resp: URLResponse

        do {
            (data, resp) = try await URLSession.shared.data(for: req)
        } catch {
            throw APIError.offline(error.localizedDescription)
        }

        guard let http = resp as? HTTPURLResponse else {
            throw APIError.offline("No HTTPURLResponse")
        }

        if !(200..<300).contains(http.statusCode) {
            let bodyStr = String(data: data, encoding: .utf8) ?? "<non-utf8>"
            throw APIError.badStatus(http.statusCode, bodyStr)
        }

        do {
            // Normal path: decode into requested type
            return try decoder.decode(U.self, from: data)
        } catch {
            // Special case for route endpoint which may return bare RouteResponse
            if path == "/api/path/route" {
                if let route = try? decoder.decode(RouteResponse.self, from: data),
                   let casted = route as? U {
                    print("🧭 [APIClient] decoded RouteResponse via special case")
                    return casted
                }
            }

            let bodyStr = String(data: data, encoding: .utf8) ?? "<non-utf8>"
            print("🟠 Decode failed, raw body:", bodyStr)
            throw APIError.decode(error.localizedDescription)
        }
    }

    // MARK: - GET JSON (relative path)

    func getJSON<U: Decodable>(
        _ path: String,
        as: U.Type
    ) async throws -> U {
        let url = AppConfig.baseURL.appendingPathComponent(path)
        print("➡️ GET", url.absoluteString)

        let data: Data
        let resp: URLResponse

        do {
            (data, resp) = try await URLSession.shared.data(from: url)
        } catch {
            throw APIError.offline(error.localizedDescription)
        }

        guard let http = resp as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            let http = resp as? HTTPURLResponse
            let code = http?.statusCode ?? -1
            let bodyStr = String(data: data, encoding: .utf8) ?? "<non-utf8>"
            throw APIError.badStatus(code, bodyStr)
        }

        do {
            return try decoder.decode(U.self, from: data)
        } catch {
            let bodyStr = String(data: data, encoding: .utf8) ?? "<non-utf8>"
            print("🟠 Decode failed, raw body:", bodyStr)
            throw APIError.decode(error.localizedDescription)
        }
    }

    // MARK: - GET JSON with full URL (used when we already build URL with query items)

    func getJSONAbsolute<U: Decodable>(
        _ url: URL,
        as: U.Type
    ) async throws -> U {
        print("➡️ GET", url.absoluteString)

        let data: Data
        let resp: URLResponse

        do {
            (data, resp) = try await URLSession.shared.data(from: url)
        } catch {
            throw APIError.offline(error.localizedDescription)
        }

        guard let http = resp as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            let http = resp as? HTTPURLResponse
            let code = http?.statusCode ?? -1
            let bodyStr = String(data: data, encoding: .utf8) ?? "<non-utf8>"
            throw APIError.badStatus(code, bodyStr)
        }

        do {
            return try decoder.decode(U.self, from: data)
        } catch {
            let bodyStr = String(data: data, encoding: .utf8) ?? "<non-utf8>"
            print("🟠 Decode failed, raw body:", bodyStr)
            throw APIError.decode(error.localizedDescription)
        }
    }
}
