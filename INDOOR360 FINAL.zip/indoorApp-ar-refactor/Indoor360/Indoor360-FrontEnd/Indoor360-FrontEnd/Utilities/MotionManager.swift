import CoreMotion
import Foundation
import SwiftUI

@MainActor
final class MotionManager: ObservableObject {

    static let shared = MotionManager()   // Keep shared

    @Published var isRaised: Bool = false

    private let manager = CMMotionManager()
    private var timer: Timer?
    private let threshold: Double = -0.35


    
    init() {}

    func start() {
        guard manager.isDeviceMotionAvailable else { return }

        manager.startDeviceMotionUpdates()

        stopTimer()

        timer = Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.readTilt()
            }
        }
    }



    func stop() {
        stopTimer()
        manager.stopDeviceMotionUpdates()
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    private func readTilt() {
        guard let attitude = manager.deviceMotion?.attitude else { return }
        let pitch = attitude.pitch
        let newRaised = pitch > threshold

        if newRaised != isRaised {
            isRaised = newRaised
        }
    }
}
