//
//  Untitled.swift
//  
//
//  Created by Haifa  on 23/11/2025.
//
// Indoor360-FrontEnd/Utilities/KeychainHelper.swift
import Foundation
import Security

/// Helper class for securely storing JWT tokens in the Keychain
enum KeychainHelper {

    private static let service = "com.indoor360.auth"
    private static let account = "jwt_token"

    /// Save JWT token to Keychain
    /// - Parameter token: The JWT token string to save
    /// - Returns: True if save was successful
    @discardableResult
    static func save(token: String) -> Bool {
        guard let data = token.data(using: .utf8) else {
            print("[KeychainHelper] Failed to encode token")
            return false
        }

        // Delete any existing item first
        delete()

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock
        ]

        let status = SecItemAdd(query as CFDictionary, nil)

        if status == errSecSuccess {
            print("[KeychainHelper] Token saved successfully")
            return true
        } else {
            print("[KeychainHelper] Failed to save token: \(status)")
            return false
        }
    }

    /// Retrieve JWT token from Keychain
    /// - Returns: The JWT token string if found, nil otherwise
    static func get() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var dataTypeRef: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)

        if status == errSecSuccess {
            if let data = dataTypeRef as? Data,
               let token = String(data: data, encoding: .utf8) {
                print("[KeychainHelper] Token retrieved successfully")
                return token
            }
        } else if status == errSecItemNotFound {
            print("[KeychainHelper] No token found in Keychain")
        } else {
            print("[KeychainHelper] Failed to retrieve token: \(status)")
        }

        return nil
    }

    /// Delete JWT token from Keychain
    /// - Returns: True if delete was successful or item didn't exist
    @discardableResult
    static func delete() -> Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]

        let status = SecItemDelete(query as CFDictionary)

        if status == errSecSuccess || status == errSecItemNotFound {
            print("[KeychainHelper] Token deleted successfully")
            return true
        } else {
            print("[KeychainHelper] Failed to delete token: \(status)")
            return false
        }
    }

    /// Check if a token exists in Keychain
    /// - Returns: True if token exists
    static func hasToken() -> Bool {
        return get() != nil
    }
}

