//
//  Untitled.swift
//  Indoor360-FrontEnd
//
//  Created by Haifa  on 22/11/2025.
//

import Foundation

struct SearchHistoryItem: Codable, Identifiable {
    let searchId: Int
    let userId: Int
    let query: String
    let resolvedPoiId: Int?
    let resolvedLabel: String?
    let searchedAt: String

    var id: Int { searchId }   // allow Identifiable
}

    enum CodingKeys: String, CodingKey {
        case id
        case userId = "user_id"
        case query
        case resolvedPoiId = "resolved_poi_id"
        case resolvedLabel = "resolved_label"
        case createdAt = "created_at"
    }


struct SearchHistoryIn: Encodable {
    let query: String
    let resolvedPoiId: Int?
    let resolvedLabel: String?

    enum CodingKeys: String, CodingKey {
        case query
        case resolvedPoiId = "resolved_poi_id"
        case resolvedLabel = "resolved_label"
    }
}
