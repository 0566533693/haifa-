import Foundation
import Combine

// MARK: - Alignment state
enum AlignmentState: Equatable {
    case idle
    case aligning(progress: Double)   // 0...1
    case aligned
    case drifting
    case relocalizing
    case failed(String)
}

// MARK: - Protocol
protocol AlignmentService {
    var statePublisher: AnyPublisher<AlignmentState, Never> { get }
    func startSession()
    func stopSession()
    func beginAlignment()
    func simulateDrift()           // mock-only helper
    func beginRelocalize()         // mock-only helper
    func reroute()                 // mock-only helper
}

// MARK: - Mock implementation
final class AlignmentServiceMock: AlignmentService {
    @Published private var state: AlignmentState = .idle
    var statePublisher: AnyPublisher<AlignmentState, Never> { $state.eraseToAnyPublisher() }

    private var timer: Timer?

    func startSession() { /* noop for mock */ }
    func stopSession()  { timer?.invalidate(); timer = nil; state = .idle }

    func beginAlignment() {
        state = .aligning(progress: 0)
        timer?.invalidate()
        var p = 0.0
        timer = Timer.scheduledTimer(withTimeInterval: 0.45, repeats: true) { [weak self] t in
            guard let self else { return }
            p = min(1.0, p + 0.22)
            if p >= 1.0 {
                t.invalidate()
                self.state = .aligned
            } else {
                self.state = .aligning(progress: p)
            }
        }
    }

    func simulateDrift() { state = .drifting }
    func beginRelocalize() {
        state = .relocalizing
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.state = .aligned
        }
    }

    func reroute() {
        // In a real build you’d recompute route; here we just bounce banner
        state = .aligned
    }
}
