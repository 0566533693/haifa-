import Foundation

/// Very small mock router that parses QR payloads into intents we can act on later.
/// For now we just return a human-readable description for toasts/VO.
enum DeepLink {
    case url(URL)
    case venue(id: String)
    case poi(id: String)
    case nav(from: String?, to: String?)
    case anchor(id: String)  // QR anchor for indoor positioning
    case unknown(raw: String)
}

enum DeepLinkRouter {
    static func parse(_ raw: String) -> DeepLink {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)

        // Check custom prefixes FIRST (before URL check, since "anchor:x" looks like a URL scheme)
        if trimmed.hasPrefix("venue:") {
            return .venue(id: String(trimmed.dropFirst(6)))
        }
        if trimmed.hasPrefix("poi:") {
            return .poi(id: String(trimmed.dropFirst(4)))
        }
        if trimmed.hasPrefix("nav:") {
            // nav:from=FOO&to=BAR
            let query = String(trimmed.dropFirst(4))
            var from: String? = nil
            var to: String? = nil
            query.split(separator: "&").forEach { pair in
                let parts = pair.split(separator: "=", maxSplits: 1).map(String.init)
                if parts.count == 2 {
                    if parts[0] == "from" { from = parts[1] }
                    if parts[0] == "to" { to = parts[1] }
                }
            }
            return .nav(from: from, to: to)
        }
        // QR anchor for indoor positioning (e.g., "anchor:reception")
        if trimmed.hasPrefix("anchor:") {
            return .anchor(id: String(trimmed.dropFirst(7)))
        }

        // Check for real URLs (http/https) AFTER custom prefixes
        if let url = URL(string: trimmed),
           let scheme = url.scheme?.lowercased(),
           scheme == "http" || scheme == "https" {
            return .url(url)
        }

        return .unknown(raw: trimmed)
    }

    static func description(for link: DeepLink) -> String {
        switch link {
        case .url(let u):           return "Opening \(u.host ?? u.absoluteString)"
        case .venue(let id):        return "Opening venue \(id)"
        case .poi(let id):          return "Opening POI \(id)"
        case .nav(let f, let t):    return "Starting route \(f ?? "current") → \(t ?? "destination")"
        case .anchor(let id):       return "Position set: \(id)"
        case .unknown(let raw):     return "Scanned: \(raw)"
        }
    }
}
