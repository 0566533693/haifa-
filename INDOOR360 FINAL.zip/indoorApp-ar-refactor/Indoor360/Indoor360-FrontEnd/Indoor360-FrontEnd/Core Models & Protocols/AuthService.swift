// Indoor360-FrontEnd/Services/AuthService.swift
import Foundation

/// Service for handling authentication API calls to the FastAPI backend.
enum AuthService {

    // MARK: - Configuration

    /// Base URL from central AppConfig
    private static var baseURL: String { AppConfig.baseURL.absoluteString }

    // MARK: - Errors

    enum AuthError: LocalizedError {
        case invalidURL
        case networkError(Error)
        case invalidResponse
        case serverError(String)
        case decodingError(Error)
        case unauthorized

        var errorDescription: String? {
            switch self {
            case .invalidURL:
                return "Invalid server URL."
            case .networkError(let error):
                return "Network error: \(error.localizedDescription)"
            case .invalidResponse:
                return "Invalid response from server."
            case .serverError(let message):
                return message
            case .decodingError(let error):
                return "Failed to decode response: \(error.localizedDescription)"
            case .unauthorized:
                return "Unauthorized. Please log in again."
            }
        }
    }

    // MARK: - Shared JSON decoder

    /// Custom date decoder that understands several ISO8601 variants (with/without microseconds).
    private static var customDateDecoder: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let dateString = try container.decode(String.self)

            // Try custom formatters
            let formatters: [DateFormatter] = [
                {
                    let f = DateFormatter()
                    f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS"
                    f.locale = Locale(identifier: "en_US_POSIX")
                    f.timeZone = TimeZone(secondsFromGMT: 0)
                    return f
                }(),
                {
                    let f = DateFormatter()
                    f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                    f.locale = Locale(identifier: "en_US_POSIX")
                    f.timeZone = TimeZone(secondsFromGMT: 0)
                    return f
                }()
            ]

            for formatter in formatters {
                if let date = formatter.date(from: dateString) {
                    return date
                }
            }

            // Fallback to ISO8601
            let iso8601 = ISO8601DateFormatter()
            iso8601.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = iso8601.date(from: dateString) {
                return date
            }

            iso8601.formatOptions = [.withInternetDateTime]
            if let date = iso8601.date(from: dateString) {
                return date
            }

            throw DecodingError.dataCorruptedError(
                in: container,
                debugDescription: "Invalid date format: \(dateString)"
            )
        }
        return decoder
    }

    // MARK: - Sign Up

    /// Create a new user account.
    /// Maps to FastAPI SignUpRequest and AuthResponse.
    static func signUp(name: String, email: String, password: String) async throws -> AuthResponse {
        guard let url = URL(string: "\(baseURL)/api/auth/signup") else {
            throw AuthError.invalidURL
        }

        let body: [String: String] = [
            "name": name,
            "email": email,
            "password": password
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(body)

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw AuthError.invalidResponse
            }

            if (200...201).contains(httpResponse.statusCode) {
                let decoder = customDateDecoder
                let authResponse = try decoder.decode(AuthResponse.self, from: data)

                // Save token to Keychain
                KeychainHelper.save(token: authResponse.accessToken)
                return authResponse
            } else {
                // Try to decode error from backend
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw AuthError.serverError(errorResponse.detail)
                } else if let raw = String(data: data, encoding: .utf8) {
                    throw AuthError.serverError("HTTP \(httpResponse.statusCode): \(raw)")
                } else {
                    throw AuthError.serverError("HTTP \(httpResponse.statusCode)")
                }
            }
        } catch let error as AuthError {
            throw error
        } catch let error as URLError {
            if error.code == .cannotConnectToHost || error.code == .networkConnectionLost {
                throw AuthError.serverError("Cannot connect to server. Make sure the backend is running on \(baseURL)")
            }
            throw AuthError.networkError(error)
        } catch {
            throw AuthError.networkError(error)
        }
    }

    // MARK: - Login

    /// Login with email and password.
    /// Maps to FastAPI LoginRequest and AuthResponse.
    static func login(email: String, password: String) async throws -> AuthResponse {
        guard let url = URL(string: "\(baseURL)/api/auth/login") else {
            throw AuthError.invalidURL
        }

        let body: [String: String] = [
            "email": email,
            "password": password
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(body)

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw AuthError.invalidResponse
            }

            if httpResponse.statusCode == 200 {
                let decoder = customDateDecoder
                do {
                    let authResponse = try decoder.decode(AuthResponse.self, from: data)
                    KeychainHelper.save(token: authResponse.accessToken)
                    return authResponse
                } catch {
                    // Print raw JSON in debug to help diagnose mismatch
                    if let jsonString = String(data: data, encoding: .utf8) {
                        print("❌ Failed to decode AuthResponse: \(jsonString)")
                    }
                    throw AuthError.decodingError(error)
                }
            } else {
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw AuthError.serverError(errorResponse.detail)
                } else if let errorString = String(data: data, encoding: .utf8) {
                    throw AuthError.serverError("HTTP \(httpResponse.statusCode): \(errorString)")
                } else {
                    throw AuthError.serverError("HTTP \(httpResponse.statusCode)")
                }
            }
        } catch let error as AuthError {
            throw error
        } catch let error as URLError {
            if error.code == .cannotConnectToHost || error.code == .networkConnectionLost {
                throw AuthError.serverError("Cannot connect to server. Make sure the backend is running on \(baseURL)")
            }
            throw AuthError.networkError(error)
        } catch {
            throw AuthError.networkError(error)
        }
    }

    // MARK: - Get Current User

    /// Get current user profile (requires authentication).
    /// Maps to a /api/auth/me endpoint returning UserResponse.
    static func getCurrentUser() async throws -> User {
        guard let token = KeychainHelper.get() else {
            throw AuthError.unauthorized
        }

        guard let url = URL(string: "\(baseURL)/api/auth/me") else {
            throw AuthError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw AuthError.invalidResponse
            }

            if httpResponse.statusCode == 200 {
                let decoder = customDateDecoder
                return try decoder.decode(User.self, from: data)
            } else if httpResponse.statusCode == 401 {
                // Token expired or invalid
                KeychainHelper.delete()
                throw AuthError.unauthorized
            } else {
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw AuthError.serverError(errorResponse.detail)
                }
                throw AuthError.serverError("HTTP \(httpResponse.statusCode)")
            }
        } catch let error as AuthError {
            throw error
        } catch {
            throw AuthError.networkError(error)
        }
    }

    // MARK: - Logout

    /// Logout the current user (best-effort server call, always deletes local token).
    static func logout() async throws {
        guard let token = KeychainHelper.get() else {
            // Already logged out locally
            return
        }

        guard let url = URL(string: "\(baseURL)/api/auth/logout") else {
            // Delete token locally even if URL is invalid
            KeychainHelper.delete()
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        do {
            let (_, response) = try await URLSession.shared.data(for: request)

            // Delete token regardless of response outcome
            KeychainHelper.delete()

            if let httpResponse = response as? HTTPURLResponse,
               httpResponse.statusCode != 200 {
                print("[AuthService] Logout returned status: \(httpResponse.statusCode)")
            }
        } catch {
            // Delete token even if network request fails
            KeychainHelper.delete()
            print("[AuthService] Logout error (token deleted anyway): \(error)")
        }
    }

    // MARK: - Change Password

    /// Change the authenticated user's password.
    /// Maps to FastAPI ChangePasswordRequest.
    static func changePassword(currentPassword: String, newPassword: String) async throws {
        guard let token = KeychainHelper.get() else {
            throw AuthError.unauthorized
        }

        guard let url = URL(string: "\(baseURL)/api/auth/change-password") else {
            throw AuthError.invalidURL
        }

        let body: [String: String] = [
            "current_password": currentPassword,
            "new_password": newPassword
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(body)

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw AuthError.invalidResponse
            }

            if httpResponse.statusCode == 200 {
                return
            } else if httpResponse.statusCode == 400 {
                // Wrong current password or validation error
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw AuthError.serverError(errorResponse.detail)
                }
                throw AuthError.serverError("Current password is incorrect.")
            } else if httpResponse.statusCode == 401 {
                KeychainHelper.delete()
                throw AuthError.unauthorized
            } else {
                throw AuthError.serverError("HTTP \(httpResponse.statusCode)")
            }
        } catch let error as AuthError {
            throw error
        } catch {
            throw AuthError.networkError(error)
        }
    }

    // MARK: - Update Profile

    /// Update the authenticated user's profile.
    /// Maps to FastAPI UpdateProfileRequest and returns updated UserResponse.
    static func updateProfile(name: String?, phone: String?, dateOfBirth: String?) async throws -> User {
        guard let token = KeychainHelper.get() else {
            throw AuthError.unauthorized
        }

        guard let url = URL(string: "\(baseURL)/api/auth/profile") else {
            throw AuthError.invalidURL
        }

        let body = UpdateProfileRequest(name: name, phone: phone, dateOfBirth: dateOfBirth)

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(body)

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw AuthError.invalidResponse
            }

            if httpResponse.statusCode == 200 {
                let decoder = customDateDecoder
                return try decoder.decode(User.self, from: data)
            } else if httpResponse.statusCode == 400 {
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw AuthError.serverError(errorResponse.detail)
                }
                throw AuthError.serverError("Validation error.")
            } else if httpResponse.statusCode == 401 {
                KeychainHelper.delete()
                throw AuthError.unauthorized
            } else {
                throw AuthError.serverError("HTTP \(httpResponse.statusCode)")
            }
        } catch let error as AuthError {
            throw error
        } catch {
            throw AuthError.networkError(error)
        }
    }
}
