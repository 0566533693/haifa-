// NavigationSession.swift
// State management for QR-based indoor AR navigation

import Foundation
import Combine
import SwiftUI

// MARK: - Navigation Step Model

/// Represents a single navigation step derived from PathPostProcessor.TurnHint
struct NavigationStep: Identifiable {
    let id: Int
    let kind: StepKind
    let instruction: String
    let distanceText: String?
    let position: (x: Double, y: Double)
    let angleDegrees: Double?
    /// Distance in meters to reach this step's position from the previous step
    let segmentDistanceMeters: Double
    /// Cumulative distance from the start to reach this step
    let cumulativeDistanceMeters: Double
    /// Direction vector (normalized) from previous step to this step
    let directionVector: (x: Double, y: Double)?

    enum StepKind: String {
        case start = "start"
        case forward = "forward"
        case left = "left"
        case right = "right"
        case finish = "finish"

        var icon: String {
            switch self {
            case .start:    return "figure.walk"
            case .forward:  return "arrow.up"
            case .left:     return "arrow.left"
            case .right:    return "arrow.right"
            case .finish:   return "flag.checkered"
            }
        }

        var instruction: String {
            switch self {
            case .start:    return "Start walking"
            case .forward:  return "Continue straight"
            case .left:     return "Turn left"
            case .right:    return "Turn right"
            case .finish:   return "You have arrived!"
            }
        }
    }

    /// Initializer with all parameters
    init(id: Int, kind: StepKind, instruction: String, distanceText: String?, position: (x: Double, y: Double), angleDegrees: Double?, segmentDistanceMeters: Double = 0, cumulativeDistanceMeters: Double = 0, directionVector: (x: Double, y: Double)? = nil) {
        self.id = id
        self.kind = kind
        self.instruction = instruction
        self.distanceText = distanceText
        self.position = position
        self.angleDegrees = angleDegrees
        self.segmentDistanceMeters = segmentDistanceMeters
        self.cumulativeDistanceMeters = cumulativeDistanceMeters
        self.directionVector = directionVector
    }
}

// MARK: - Navigation Session

/// Main state manager for QR-based AR navigation flow.
/// Tracks the user's position, destination, and current step in the route.
@MainActor
final class NavigationSession: ObservableObject {

    // MARK: - Published State

    /// Position set by scanning QR code
    @Published var startPosition: QRPositionResponse?

    /// Target POI ID (selected by user after scanning)
    @Published var destinationPoiId: Int?

    /// Destination name for display
    @Published var destinationName: String?

    /// Current step index in the navigation
    @Published var currentStepIndex: Int = 0

    /// Whether navigation is actively in progress
    @Published var isNavigating: Bool = false

    /// Error message if something goes wrong
    @Published var errorMessage: String?

    /// Whether currently loading route
    @Published var isLoadingRoute: Bool = false

    /// All navigation steps (converted from TurnHints)
    @Published private(set) var steps: [NavigationStep] = []

    /// Raw path points for AR visualization (local meter coordinates)
    @Published private(set) var pathPoints: [(x: Double, y: Double, z: Double)] = []

    /// Route points converted to WGS84 for MapKit overlays
    @Published private(set) var wgsRoutePoints: [IMDFPoint] = []

    /// Convenience access to the final WGS84 coordinate in the current route
    @Published private(set) var destinationCoordinateWGS: IMDFPoint?

    /// Total route distance in meters
    @Published private(set) var totalDistanceMeters: Double = 0

    /// Total distance traveled (tracked by AR)
    @Published var totalDistanceTraveled: Double = 0

    /// Distance remaining to current step target
    @Published var distanceToCurrentStepTarget: Double = 0

    /// Whether step was auto-advanced (for UI feedback)
    @Published var didAutoAdvance: Bool = false

    // MARK: - Computed Properties

    /// Current navigation step
    var currentStep: NavigationStep? {
        guard currentStepIndex >= 0 && currentStepIndex < steps.count else { return nil }
        return steps[currentStepIndex]
    }

    /// Next navigation step (for preview)
    var nextStep: NavigationStep? {
        let nextIndex = currentStepIndex + 1
        guard nextIndex >= 0 && nextIndex < steps.count else { return nil }
        return steps[nextIndex]
    }

    /// Whether on the last step (arrival)
    var isLastStep: Bool {
        currentStepIndex >= steps.count - 1
    }

    /// Whether at the first step
    var isFirstStep: Bool {
        currentStepIndex == 0
    }

    /// Progress through the route (0.0 to 1.0)
    var progress: Double {
        guard steps.count > 1 else { return 0 }
        return Double(currentStepIndex) / Double(steps.count - 1)
    }

    /// Remaining steps count
    var remainingSteps: Int {
        max(0, steps.count - currentStepIndex - 1)
    }

    /// Whether session is ready to start navigation
    var canStartNavigation: Bool {
        startPosition != nil && destinationName != nil && !steps.isEmpty
    }

    /// Distance threshold for auto-advancing to next step (meters)
    let stepAdvanceThreshold: Double = 1.5

    /// The initial heading angle when navigation started (degrees, 0 = north)
    @Published var initialHeadingDegrees: Double = 0

    // MARK: - Dependencies

    private let qrClient = QRPositionClient()
    private let pathClient = PathClient()

    // MARK: - Public Methods

    /// Set position from a scanned QR code
    func setPosition(from qrCode: String) async {
        errorMessage = nil

        do {
            let position = try await qrClient.resolve(qrCode)
            self.startPosition = position
            print("✅ QR Position set: \(position.locationName) (Floor \(position.floor))")
        } catch let error as QRPositionError {
            self.errorMessage = error.localizedDescription
            print("❌ QR resolve error: \(error.localizedDescription)")
        } catch {
            self.errorMessage = "Failed to resolve QR code"
            print("❌ QR resolve error: \(error)")
        }
    }

    /// Set the destination and fetch the route
    func setDestination(poiId: Int, name: String) async {
        guard let start = startPosition else {
            errorMessage = "Please scan a QR code first"
            return
        }

        errorMessage = nil
        isLoadingRoute = true
        destinationPoiId = poiId
        destinationName = name

        defer { isLoadingRoute = false }

        // If we don't have valid POI IDs (anchor-only navigation), create mock steps
        if start.poiId == 0 || poiId == 0 {
            // For demo: fetch destination anchor info and create simple route
            await createMockRouteToDestination(name: name, from: start)
            return
        }

        do {
            // Fetch route from backend
            let route = try await pathClient.route(from: start.poiId, to: poiId)

            // Store path points
            self.pathPoints = route.path.map { (x: $0.x, y: $0.y, z: $0.z) }
            self.updateDerivedRouteRepresentations(fromLocal: route.path.map { ($0.x, $0.y) })
            self.totalDistanceMeters = route.lengthM

            // Convert to navigation steps
            // Note: In production, you'd call PathPostProcessor here
            // For now, create simple steps from path
            self.steps = createStepsFromPath(route.path)

            print("✅ Route loaded: \(route.path.count) points, \(String(format: "%.1f", route.lengthM))m")

        } catch {
            self.errorMessage = "Failed to load route: \(error.localizedDescription)"
            print("❌ Route error: \(error)")
        }
    }

    /// Create mock navigation steps when we don't have real POI-based routing
    private func createMockRouteToDestination(name: String, from start: QRPositionResponse) async {
        // Try to get destination coordinates from the anchor
        do {
            // Search for destination anchor by name
            let anchors = try await qrClient.listAnchors()
            if let destAnchor = anchors.first(where: { $0.locationName == name }) {
                // Get full anchor details
                let destPosition = try await qrClient.resolve(destAnchor.qrCode)

                // Calculate distance
                let dx = destPosition.x - start.x
                let dy = destPosition.y - start.y
                let distance = sqrt(dx * dx + dy * dy)
                self.totalDistanceMeters = distance

                // Create simple path points
                self.pathPoints = [
                    (x: start.x, y: start.y, z: start.z),
                    (x: destPosition.x, y: destPosition.y, z: destPosition.z)
                ]
                self.updateDerivedRouteRepresentations(fromLocal: [
                    (start.x, start.y),
                    (destPosition.x, destPosition.y)
                ])

                // Create navigation steps
                self.steps = createSimpleSteps(
                    from: start,
                    to: destPosition,
                    distance: distance
                )

                print("✅ Mock route created: \(String(format: "%.1f", distance))m to \(name)")
                return
            }
        } catch {
            print("⚠️ Could not find destination anchor: \(error)")
        }

        // Fallback: create very simple demo steps
        self.totalDistanceMeters = 50
        self.pathPoints = [
            (x: start.x, y: start.y, z: start.z),
            (x: start.x + 50, y: start.y, z: start.z)
        ]
        self.updateDerivedRouteRepresentations(fromLocal: [
            (start.x, start.y),
            (start.x + 50, start.y)
        ])
        self.steps = [
            NavigationStep(
                id: 0,
                kind: .start,
                instruction: "Start walking towards \(name)",
                distanceText: nil,
                position: (x: start.x, y: start.y),
                angleDegrees: nil,
                segmentDistanceMeters: 0,
                cumulativeDistanceMeters: 0,
                directionVector: (x: 1.0, y: 0.0)
            ),
            NavigationStep(
                id: 1,
                kind: .forward,
                instruction: "Continue straight ahead",
                distanceText: "~25m",
                position: (x: start.x + 25, y: start.y),
                angleDegrees: nil,
                segmentDistanceMeters: 25,
                cumulativeDistanceMeters: 25,
                directionVector: (x: 1.0, y: 0.0)
            ),
            NavigationStep(
                id: 2,
                kind: .finish,
                instruction: "Look for \(name) on your left",
                distanceText: nil,
                position: (x: start.x + 50, y: start.y),
                angleDegrees: nil,
                segmentDistanceMeters: 25,
                cumulativeDistanceMeters: 50,
                directionVector: (x: 1.0, y: 0.0)
            )
        ]
        print("✅ Fallback mock route created to \(name)")
    }

    /// Create simple navigation steps between two positions
    private func createSimpleSteps(from start: QRPositionResponse, to end: QRPositionResponse, distance: Double) -> [NavigationStep] {
        var result: [NavigationStep] = []

        // Calculate direction
        let dx = end.x - start.x
        let dy = end.y - start.y
        let angle = atan2(dy, dx) * 180.0 / .pi

        // Normalize direction vector
        let length = sqrt(dx * dx + dy * dy)
        let dirX = length > 0 ? dx / length : 1.0
        let dirY = length > 0 ? dy / length : 0.0

        // Start step
        result.append(NavigationStep(
            id: 0,
            kind: .start,
            instruction: "Start walking towards \(end.locationName)",
            distanceText: nil,
            position: (x: start.x, y: start.y),
            angleDegrees: angle,
            segmentDistanceMeters: 0,
            cumulativeDistanceMeters: 0,
            directionVector: (x: dirX, y: dirY)
        ))

        // If on different floors, add floor transition
        if start.floor != end.floor {
            let transition = end.floor > start.floor ? "Go up" : "Go down"
            let floors = abs(end.floor - start.floor)
            result.append(NavigationStep(
                id: 1,
                kind: .forward,
                instruction: "\(transition) \(floors) floor\(floors > 1 ? "s" : "")",
                distanceText: "Use elevator or stairs",
                position: (x: start.x, y: start.y),
                angleDegrees: nil,
                segmentDistanceMeters: 3.0, // Approximate elevator/stair distance
                cumulativeDistanceMeters: 3.0,
                directionVector: nil
            ))
        }

        // Continue step
        let midCumulative = start.floor != end.floor ? 3.0 + distance / 2 : distance / 2
        result.append(NavigationStep(
            id: result.count,
            kind: .forward,
            instruction: "Continue towards \(end.locationName)",
            distanceText: String(format: "%.0fm", distance),
            position: (x: (start.x + end.x) / 2, y: (start.y + end.y) / 2),
            angleDegrees: nil,
            segmentDistanceMeters: distance / 2,
            cumulativeDistanceMeters: midCumulative,
            directionVector: (x: dirX, y: dirY)
        ))

        // Finish step
        result.append(NavigationStep(
            id: result.count,
            kind: .finish,
            instruction: "You have arrived at \(end.locationName)",
            distanceText: nil,
            position: (x: end.x, y: end.y),
            angleDegrees: nil,
            segmentDistanceMeters: distance / 2,
            cumulativeDistanceMeters: distance + (start.floor != end.floor ? 3.0 : 0),
            directionVector: (x: dirX, y: dirY)
        ))

        return result
    }

    /// Start the navigation session
    func startNavigation() {
        guard canStartNavigation else {
            errorMessage = "Cannot start navigation - missing position or destination"
            return
        }
        currentStepIndex = 0
        isNavigating = true
        print("🚀 Navigation started to \(destinationName ?? "destination")")
    }

    /// Advance to the next step
    func advanceToNextStep() {
        guard !isLastStep else { return }
        currentStepIndex += 1
        print("➡️ Step \(currentStepIndex + 1)/\(steps.count): \(currentStep?.instruction ?? "")")
    }

    /// Go back to previous step
    func previousStep() {
        guard !isFirstStep else { return }
        currentStepIndex -= 1
    }

    /// Complete the navigation
    func finish() {
        isNavigating = false
        print("🏁 Navigation completed!")
    }

    /// Reset the entire session
    func reset() {
        startPosition = nil
        destinationPoiId = nil
        destinationName = nil
        currentStepIndex = 0
        isNavigating = false
        errorMessage = nil
        isLoadingRoute = false
        steps = []
        pathPoints = []
        totalDistanceMeters = 0
        wgsRoutePoints = []
        destinationCoordinateWGS = nil
        print("🔄 Session reset")
    }

    // MARK: - Private Helpers

    private func updateDerivedRouteRepresentations(fromLocal points: [(Double, Double)]) {
        let wgsPoints = points.map { VenueCoordinateTransformer.localToWGS(x: $0.0, y: $0.1) }
        wgsRoutePoints = wgsPoints
        destinationCoordinateWGS = wgsPoints.last
    }

    /// Convert raw path points to navigation steps
    /// In production, this would use PathPostProcessor.makeDisplayPath()
    private func createStepsFromPath(_ points: [RoutePointDTO]) -> [NavigationStep] {
        guard points.count >= 2 else { return [] }

        var result: [NavigationStep] = []
        var cumulativeDistance: Double = 0

        // Calculate initial direction
        let firstDx = points[1].x - points[0].x
        let firstDy = points[1].y - points[0].y
        let firstLen = sqrt(firstDx * firstDx + firstDy * firstDy)
        let firstDirX = firstLen > 0 ? firstDx / firstLen : 1.0
        let firstDirY = firstLen > 0 ? firstDy / firstLen : 0.0

        // Start step
        result.append(NavigationStep(
            id: 0,
            kind: .start,
            instruction: "Start walking towards your destination",
            distanceText: nil,
            position: (x: points[0].x, y: points[0].y),
            angleDegrees: nil,
            segmentDistanceMeters: 0,
            cumulativeDistanceMeters: 0,
            directionVector: (x: firstDirX, y: firstDirY)
        ))

        // Calculate turn hints along the path
        for i in 1..<(points.count - 1) {
            let a = points[i - 1]
            let b = points[i]
            let c = points[i + 1]

            let angle = calculateTurnAngle(from: a, through: b, to: c)
            let absAngle = abs(angle)

            // Calculate segment distance
            let segDx = b.x - a.x
            let segDy = b.y - a.y
            let segmentDistance = sqrt(segDx * segDx + segDy * segDy)
            cumulativeDistance += segmentDistance

            // Direction to next point
            let nextDx = c.x - b.x
            let nextDy = c.y - b.y
            let nextLen = sqrt(nextDx * nextDx + nextDy * nextDy)
            let nextDirX = nextLen > 0 ? nextDx / nextLen : 1.0
            let nextDirY = nextLen > 0 ? nextDy / nextLen : 0.0

            // Only add step if there's a significant turn
            if absAngle >= 30 {
                let kind: NavigationStep.StepKind = angle > 0 ? .left : .right
                result.append(NavigationStep(
                    id: result.count,
                    kind: kind,
                    instruction: kind.instruction,
                    distanceText: String(format: "%.0fm to turn", segmentDistance),
                    position: (x: b.x, y: b.y),
                    angleDegrees: angle,
                    segmentDistanceMeters: segmentDistance,
                    cumulativeDistanceMeters: cumulativeDistance,
                    directionVector: (x: nextDirX, y: nextDirY)
                ))
            }
        }

        // Calculate final segment distance
        let lastA = points[points.count - 2]
        let lastB = points[points.count - 1]
        let lastSegDx = lastB.x - lastA.x
        let lastSegDy = lastB.y - lastA.y
        let lastSegmentDistance = sqrt(lastSegDx * lastSegDx + lastSegDy * lastSegDy)
        cumulativeDistance += lastSegmentDistance

        // Finish step
        let lastPoint = points[points.count - 1]
        result.append(NavigationStep(
            id: result.count,
            kind: .finish,
            instruction: "You have arrived at your destination",
            distanceText: String(format: "Total: %.0fm", totalDistanceMeters),
            position: (x: lastPoint.x, y: lastPoint.y),
            angleDegrees: nil,
            segmentDistanceMeters: lastSegmentDistance,
            cumulativeDistanceMeters: cumulativeDistance,
            directionVector: nil
        ))

        return result
    }

    /// Calculate signed turn angle in degrees (+left, -right)
    private func calculateTurnAngle(from a: RoutePointDTO, through b: RoutePointDTO, to c: RoutePointDTO) -> Double {
        let v1 = (x: b.x - a.x, y: b.y - a.y)
        let v2 = (x: c.x - b.x, y: c.y - b.y)
        let cross = v1.x * v2.y - v1.y * v2.x
        let dot = v1.x * v2.x + v1.y * v2.y
        return atan2(cross, dot) * 180.0 / .pi
    }
}

// MARK: - Preview Helpers

#if DEBUG
extension NavigationSession {
    /// Create a session with mock data for previews
    static func mockSession() -> NavigationSession {
        let session = NavigationSession()
        session.startPosition = QRPositionResponse(
            poiId: 1,
            poiName: "Reception",
            locationName: "Main Reception",
            x: 0,
            y: 0,
            z: 0,
            floor: 1,
            description: nil
        )
        session.destinationName = "Cafeteria"
        session.destinationPoiId = 5
        session.steps = [
            NavigationStep(id: 0, kind: .start, instruction: "Start walking", distanceText: nil, position: (x: 0, y: 0), angleDegrees: nil, segmentDistanceMeters: 0, cumulativeDistanceMeters: 0, directionVector: (x: 1.0, y: 0.0)),
            NavigationStep(id: 1, kind: .forward, instruction: "Continue straight", distanceText: "20m", position: (x: 20, y: 0), angleDegrees: nil, segmentDistanceMeters: 20, cumulativeDistanceMeters: 20, directionVector: (x: 0.0, y: 1.0)),
            NavigationStep(id: 2, kind: .left, instruction: "Turn left", distanceText: nil, position: (x: 20, y: 10), angleDegrees: 90, segmentDistanceMeters: 10, cumulativeDistanceMeters: 30, directionVector: (x: 0.0, y: 1.0)),
            NavigationStep(id: 3, kind: .forward, instruction: "Continue straight", distanceText: "15m", position: (x: 20, y: 25), angleDegrees: nil, segmentDistanceMeters: 15, cumulativeDistanceMeters: 45, directionVector: (x: 0.0, y: 1.0)),
            NavigationStep(id: 4, kind: .finish, instruction: "You have arrived!", distanceText: "Total: 45m", position: (x: 20, y: 40), angleDegrees: nil, segmentDistanceMeters: 15, cumulativeDistanceMeters: 60, directionVector: nil)
        ]
        session.totalDistanceMeters = 60
        return session
    }
}
#endif
