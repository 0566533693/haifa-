//
//  UserSession.swift
//  Indoor360-FrontEnd
//
//  Created by Haifa  on 21/11/2025.
//
import Foundation
import Combine

/// One row from the users table in PostgreSQL.
struct UserSession: Codable, Identifiable {
    /// DB primary key (can be nil before the first link)
    let id: Int?
    let firebaseUid: String
    let email: String
    let name: String?
    let authProvider: String?

    var displayName: String {
        name ?? email
    }
}

/// Body we send to POST /api/auth/link
struct AuthLinkBody: Encodable {
    let firebase_uid: String
    let email: String
    let display_name: String?
    let auth_provider: String
}

/// Observable store for the current logged-in user (DB + Firebase)
final class SessionStore: ObservableObject {

    static let shared = SessionStore()   // simple singleton

    @Published private(set) var current: UserSession?

    private init() {}

    /// Call the FastAPI backend to link Firebase user → DB user row.
    @MainActor
    func linkWithBackend(firebaseUid: String,
                         email: String,
                         displayName: String?,
                         provider: String = "firebase") async {

        let body = AuthLinkBody(
            firebase_uid: firebaseUid,
            email: email,
            display_name : displayName,
            auth_provider: provider
        )

        do {
            // Backend returns the upserted user row
            let user: UserSession = try await APIClient.shared.postJSON(
                "/api/auth/link",
                body: body,
                as: UserSession.self
            )
            self.current = user
            print("✅ Linked user with backend, user_id =", user.id ?? -1)
        } catch {
            print("⚠️ Failed to link user with backend:", error)
        }
    }

    /// Simple helper for sign-out – clear in-memory session
    @MainActor
    func clear() {
        current = nil
    }
}
