import Foundation
import CoreMotion
import Combine

/// Very light “raised vs not” detector.
/// Treat device as *raised* if pitch is roughly upright (>-40°) and not flat.
final class MotionService: ObservableObject {
    @Published private(set) var isRaised: Bool = true

    private let motion = CMMotionManager()
    private var timer: Timer?

    func start() {
        guard motion.isDeviceMotionAvailable else { return }
        motion.deviceMotionUpdateInterval = 0.15
        motion.startDeviceMotionUpdates(using: .xArbitraryZVertical)

        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { [weak self] _ in
            guard let self, let dm = self.motion.deviceMotion else { return }
            // pitch in radians: 0 = vertical upright, -π/2 ≈ face up
            let pitch = dm.attitude.pitch
            let raised = pitch > (-.pi/3.0)   // ~ -60°
            if raised != self.isRaised { self.isRaised = raised }
        }
    }

    func stop() {
        motion.stopDeviceMotionUpdates()
        timer?.invalidate()
        timer = nil
    }
}
