import Foundation
import Combine

/// DTO that matches the JSON from /api/poi/search
struct POIDTO: Decodable {
    let id: Int
    let name: String
    let category: String
    let floor: String
    let distanceM: Double?
}

/// Remote implementation that calls the FastAPI backend.
final class RemotePOIService: POIService {

    // MARK: - Search

    func searchPOIs(query: String) -> AnyPublisher<[POI], Never> {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            return Just([]).eraseToAnyPublisher()
        }

        // Build full URL: http://BASE/api/poi/search?q=...
        var comps = URLComponents(
            url: AppConfig.baseURL.appendingPathComponent("/api/poi/search"),
            resolvingAgainstBaseURL: false
        )
        comps?.queryItems = [URLQueryItem(name: "q", value: trimmed)]

        guard let url = comps?.url else {
            print("❌ RemotePOIService: bad URL components")
            return Just([]).eraseToAnyPublisher()
        }

        return Future<[POI], Never> { promise in
            Task {
                do {
                    // 1) Call backend → [POIDTO]
                    let dtos: [POIDTO] = try await APIClient.shared.getJSONAbsolute(
                        url,
                        as: [POIDTO].self
                    )

                    // 2) Map DTO → your existing POI model
                    let pois: [POI] = dtos.map { dto in
                        // Backend id is Int; your POI.id is UUID → make stable UUID from Int
                        let uuidString = String(
                            format: "00000000-0000-0000-0000-%012d",
                            dto.id
                        )
                        let uuid = UUID(uuidString: uuidString) ?? UUID()

                        // distanceM: Double? → Int?
                        let distanceInt: Int?
                        if let d = dto.distanceM {
                            distanceInt = Int(d.rounded())
                        } else {
                            distanceInt = nil
                        }

                        return POI(
                            id: uuid,
                            name: dto.name,
                            category: POICategory(rawValue: dto.category) ?? .info,
                            floor: dto.floor,
                            distanceMeters: distanceInt
                        )
                    }

                    await MainActor.run {
                        promise(.success(pois))
                    }
                } catch {
                    print("❌ RemotePOIService search error:", error)
                    await MainActor.run {
                        promise(.success([]))
                    }
                }
            }
        }
        .eraseToAnyPublisher()
    }

    // MARK: - Popular (protocol requirement)

    func popularPOIs() -> AnyPublisher<[POI], Never> {
        // You can later call a real endpoint here.
        return Just([]).eraseToAnyPublisher()
    }
}
