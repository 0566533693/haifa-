import Foundation
import AVFoundation
import Speech

@MainActor
private func srLog(_ msg: String) { print("🎤 [SR]", msg) }

@MainActor
final class SpeechRecognizer: NSObject, ObservableObject {

    @Published var transcript: String = ""
    @Published var isRecording: Bool = false

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    override init() {
        super.init()
        SFSpeechRecognizer.requestAuthorization { status in
            DispatchQueue.main.async {
                srLog("Auth status: \(status.rawValue)")
            }
        }
    }

    // MARK: - Public API

    func startRecording() {
        Task { @MainActor in
            guard !isRecording else { return }

            guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
                srLog("Speech not authorized")
                return
            }

            // Reset previous session
            stopInternal()

            transcript = ""
            isRecording = true

            let session = AVAudioSession.sharedInstance()
            do {
                try session.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
                try session.setActive(true, options: .notifyOthersOnDeactivation)
            } catch {
                srLog("AudioSession error: \(error.localizedDescription)")
                isRecording = false
                return
            }

            let request = SFSpeechAudioBufferRecognitionRequest()
            request.shouldReportPartialResults = true

            recognitionRequest = request

            let inputNode = audioEngine.inputNode
            let format = inputNode.outputFormat(forBus: 0)

            inputNode.removeTap(onBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
                self?.recognitionRequest?.append(buffer)
            }

            do {
                audioEngine.prepare()
                try audioEngine.start()
                srLog("Listening started")
            } catch {
                srLog("AudioEngine start error: \(error.localizedDescription)")
                stopInternal()
                return
            }

            recognitionTask = recognizer?.recognitionTask(with: request) { [weak self] result, error in
                Task { @MainActor in
                    guard let self else { return }

                    if let result = result {
                        self.transcript = result.bestTranscription.formattedString
                    }

                    if let error = error {
                        let nsError = error as NSError
                        // Ignore "canceled" / local assistant noise
                        if nsError.domain == "kAFAssistantErrorDomain" && nsError.code == 1101 {
                            srLog("Recognition canceled (safe to ignore)")
                        } else {
                            srLog("Recognition error: \(error.localizedDescription)")
                        }
                        self.stopInternal()
                    } else if result?.isFinal == true {
                        srLog("Recognition finished (final)")
                        self.stopInternal()
                    }
                }
            }
        }
    }

    func stopRecording() {
        Task { @MainActor in
            stopInternal()
        }
    }

    // MARK: - Internal cleanup

    private func stopInternal() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        isRecording = false
        srLog("Listening stopped")
    }
}
