//
//  SavedPlacesService.swift
//
//
//  Created by Haifa  on 23/11/2025.
//
//
//  SavedPlacesService.swift
//  Indoor360
//
//  Service for managing saved places
//

import Foundation

class SavedPlacesService {
    /// Central configuration from AppConfig + endpoint path
    private static var baseURL: String { "\(AppConfig.baseURL.absoluteString)/api/saved-places" }

    // Custom date decoder to handle ISO8601 dates with microseconds
    private static let customDateDecoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let dateString = try container.decode(String.self)

            // ISO8601DateFormatter with fractional seconds
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

            if let date = formatter.date(from: dateString) {
                return date
            }

            // Fallback: Try without fractional seconds
            formatter.formatOptions = [.withInternetDateTime]
            if let date = formatter.date(from: dateString) {
                return date
            }

            // Fallback: Try DateFormatter for Python datetime format with microseconds
            let pythonFormatter = DateFormatter()
            pythonFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS"
            pythonFormatter.locale = Locale(identifier: "en_US_POSIX")
            pythonFormatter.timeZone = TimeZone(secondsFromGMT: 0)

            if let date = pythonFormatter.date(from: dateString) {
                return date
            }

            throw DecodingError.dataCorruptedError(
                in: container,
                debugDescription: "Cannot decode date string: \(dateString)"
            )
        }
        return decoder
    }()

    // MARK: - Get Categories
    static func getCategories() async throws -> [Category] {
        guard let url = URL(string: "\(baseURL)/categories") else {
            throw SavedPlacesError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw SavedPlacesError.networkError("Invalid response")
            }

            guard httpResponse.statusCode == 200 else {
                throw SavedPlacesError.serverError("Server returned status code \(httpResponse.statusCode)")
            }

            let categories = try customDateDecoder.decode([Category].self, from: data)
            return categories

        } catch let error as DecodingError {
            throw SavedPlacesError.decodingError(error.localizedDescription)
        } catch let error as SavedPlacesError {
            throw error
        } catch {
            throw SavedPlacesError.networkError(error.localizedDescription)
        }
    }

    // MARK: - Get Saved Places
    static func getSavedPlaces() async throws -> [SavedPlace] {
        guard let url = URL(string: baseURL) else {
            throw SavedPlacesError.invalidURL
        }

        guard let token = KeychainHelper.get() else {
            throw SavedPlacesError.unauthorized
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw SavedPlacesError.networkError("Invalid response")
            }

            if httpResponse.statusCode == 401 {
                throw SavedPlacesError.unauthorized
            }

            guard httpResponse.statusCode == 200 else {
                throw SavedPlacesError.serverError("Server returned status code \(httpResponse.statusCode)")
            }

            let places = try customDateDecoder.decode([SavedPlace].self, from: data)
            return places

        } catch let error as DecodingError {
            throw SavedPlacesError.decodingError(error.localizedDescription)
        } catch let error as SavedPlacesError {
            throw error
        } catch {
            throw SavedPlacesError.networkError(error.localizedDescription)
        }
    }

    // MARK: - Create Saved Place
    static func createSavedPlace(
        title: String,
        categoryName: String,
        poiId: Int? = nil,
        notes: String? = nil
    ) async throws -> SavedPlace {
        guard let url = URL(string: baseURL) else {
            throw SavedPlacesError.invalidURL
        }

        guard let token = KeychainHelper.get() else {
            throw SavedPlacesError.unauthorized
        }

        let requestBody = CreateSavedPlaceRequest(
            poiId: poiId,
            title: title,
            categoryName: categoryName,
            notes: notes
        )

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(requestBody)

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw SavedPlacesError.networkError("Invalid response")
            }

            if httpResponse.statusCode == 401 {
                throw SavedPlacesError.unauthorized
            }

            if httpResponse.statusCode == 409 {
                throw SavedPlacesError.serverError("This place is already saved")
            }

            guard httpResponse.statusCode == 201 else {
                // Try to decode error response
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw SavedPlacesError.serverError(errorResponse.detail)
                }
                throw SavedPlacesError.serverError("Server returned status code \(httpResponse.statusCode)")
            }

            let place = try customDateDecoder.decode(SavedPlace.self, from: data)
            return place

        } catch let error as DecodingError {
            throw SavedPlacesError.decodingError(error.localizedDescription)
        } catch let error as SavedPlacesError {
            throw error
        } catch {
            throw SavedPlacesError.networkError(error.localizedDescription)
        }
    }

    // MARK: - Update Saved Place
    static func updateSavedPlace(
        id: Int,
        title: String? = nil,
        categoryName: String? = nil,
        notes: String? = nil
    ) async throws -> SavedPlace {
        guard let url = URL(string: "\(baseURL)/\(id)") else {
            throw SavedPlacesError.invalidURL
        }

        guard let token = KeychainHelper.get() else {
            throw SavedPlacesError.unauthorized
        }

        let requestBody = UpdateSavedPlaceRequest(
            title: title,
            categoryName: categoryName,
            notes: notes
        )

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(requestBody)

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw SavedPlacesError.networkError("Invalid response")
            }

            if httpResponse.statusCode == 401 {
                throw SavedPlacesError.unauthorized
            }

            if httpResponse.statusCode == 404 {
                throw SavedPlacesError.notFound
            }

            guard httpResponse.statusCode == 200 else {
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw SavedPlacesError.serverError(errorResponse.detail)
                }
                throw SavedPlacesError.serverError("Server returned status code \(httpResponse.statusCode)")
            }

            let place = try customDateDecoder.decode(SavedPlace.self, from: data)
            return place

        } catch let error as DecodingError {
            throw SavedPlacesError.decodingError(error.localizedDescription)
        } catch let error as SavedPlacesError {
            throw error
        } catch {
            throw SavedPlacesError.networkError(error.localizedDescription)
        }
    }

    // MARK: - Delete Saved Place
    static func deleteSavedPlace(id: Int) async throws {
        guard let url = URL(string: "\(baseURL)/\(id)") else {
            throw SavedPlacesError.invalidURL
        }

        guard let token = KeychainHelper.get() else {
            throw SavedPlacesError.unauthorized
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw SavedPlacesError.networkError("Invalid response")
            }

            if httpResponse.statusCode == 401 {
                throw SavedPlacesError.unauthorized
            }

            if httpResponse.statusCode == 404 {
                throw SavedPlacesError.notFound
            }

            guard httpResponse.statusCode == 204 else {
                if let errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data) {
                    throw SavedPlacesError.serverError(errorResponse.detail)
                }
                throw SavedPlacesError.serverError("Server returned status code \(httpResponse.statusCode)")
            }

        } catch let error as SavedPlacesError {
            throw error
        } catch {
            throw SavedPlacesError.networkError(error.localizedDescription)
        }
    }
}

