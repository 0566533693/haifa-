//
//  User.swift
//  Indoor360-FrontEnd
//
//  Created by Haifa  on 23/11/2025.
//
// Indoor360-FrontEnd/Models/User.swift
import Foundation

/// User model matching backend UserResponse
struct User: Codable, Identifiable {
    let id: Int
    var name: String
    let email: String
    var phone: String?
    var dateOfBirth: String?
    let role: String?
    let createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id = "user_id"
        case name
        case email
        case phone
        case dateOfBirth = "date_of_birth"
        case role
        case createdAt = "created_at"
    }
}

/// Update profile request
struct UpdateProfileRequest: Codable {
    let name: String?
    let phone: String?
    let dateOfBirth: String?

    enum CodingKeys: String, CodingKey {
        case name
        case phone
        case dateOfBirth = "date_of_birth"
    }
}

/// Auth response from backend
struct AuthResponse: Codable {
    let accessToken: String
    let tokenType: String
    let user: User

    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case tokenType = "token_type"
        case user
    }
}

/// Error response from backend
struct ErrorResponse: Codable {
    let detail: String
    let errorCode: String?

    enum CodingKeys: String, CodingKey {
        case detail
        case errorCode = "error_code"
    }
}

