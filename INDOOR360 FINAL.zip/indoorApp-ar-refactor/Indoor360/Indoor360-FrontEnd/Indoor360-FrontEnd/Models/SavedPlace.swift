//
//  SavedPlace.swift
//  Indoor360-FrontEnd
//
//  Created by Haifa  on 23/11/2025.
//

//
//  SavedPlace.swift
//  Indoor360
//
//  Models for saved places and categories
//

import Foundation

// MARK: - Category
struct Category: Codable, Identifiable, Hashable {
    let id: Int
    let name: String
    let icon: String?
    let createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id = "category_id"
        case name
        case icon
        case createdAt = "created_at"
    }
}

// MARK: - SavedPlace
struct SavedPlace: Codable, Identifiable, Hashable {
    let id: Int
    let userId: Int
    let poiId: Int?
    let title: String
    let categoryId: Int?
    let categoryName: String?
    let categoryIcon: String?
    let notes: String?
    let createdAt: Date
    let updatedAt: Date

    enum CodingKeys: String, CodingKey {
        case id = "saved_place_id"
        case userId = "user_id"
        case poiId = "poi_id"
        case title
        case categoryId = "category_id"
        case categoryName = "category_name"
        case categoryIcon = "category_icon"
        case notes
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

// MARK: - Request Models
struct CreateSavedPlaceRequest: Codable {
    let poiId: Int?
    let title: String
    let categoryName: String
    let notes: String?

    enum CodingKeys: String, CodingKey {
        case poiId = "poi_id"
        case title
        case categoryName = "category_name"
        case notes
    }
}

struct UpdateSavedPlaceRequest: Codable {
    let title: String?
    let categoryName: String?
    let notes: String?

    enum CodingKeys: String, CodingKey {
        case title
        case categoryName = "category_name"
        case notes
    }
}

// MARK: - Error
enum SavedPlacesError: LocalizedError {
    case invalidURL
    case networkError(String)
    case decodingError(String)
    case serverError(String)
    case unauthorized
    case notFound

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid URL"
        case .networkError(let message):
            return "Network error: \(message)"
        case .decodingError(let message):
            return "Failed to decode response: \(message)"
        case .serverError(let message):
            return message
        case .unauthorized:
            return "Please log in to continue"
        case .notFound:
            return "Saved place not found"
        }
    }
}
