# Indoor360 - Comprehensive Project Overview

## 🏢 Project Summary

**Indoor360** is a sophisticated AR-powered indoor navigation system designed to provide seamless wayfinding in complex indoor environments. The project combines advanced technologies including Augmented Reality (ARKit), Natural Language Processing (NLP with bilingual support), IMDF (Indoor Mapping Data Format) standards, and real-time positioning to deliver an intuitive indoor navigation experience.

**Primary Use Case:** PwC Campus Navigation (Haifa implementation)

**Key Features:**
- 🗺️ AR-based indoor navigation with visual overlay
- 🗣️ Bilingual NLP (English & Arabic) for natural destination queries
- 📍 IMDF-compliant mapping infrastructure
- 🧭 Real-time pathfinding using A* algorithm
- 📱 iOS native application with SwiftUI/UIKit
- 🔌 RESTful API backend with FastAPI
- 🗄️ PostgreSQL database with PostGIS spatial extensions

---

## 📁 Project Structure

```
indoorApp/
├── backend/                    # Python FastAPI backend
│   ├── api/                   # API route handlers
│   ├── app/                   # Core application setup
│   ├── NLP/                   # Natural Language Processing engine
│   ├── services/              # Business logic services
│   ├── db/                    # Database schemas & seeds
│   ├── scripts/               # Utility scripts for data ingestion
│   ├── tests/                 # Test suites
│   └── imdf_extracted/        # IMDF GeoJSON files
├── Indoor360_PwCMap/          # Primary iOS application
├── Indoor360/                 # Alternative iOS implementations
│   ├── Indoor360-FrontEnd/   # SwiftUI frontend
│   └── IndoorARNavigator/    # AR navigation prototypes
└── DATABASEINDOOR360.sql      # Complete database schema
```

---

## 🎯 Architecture Overview

### System Components

```mermaid
graph TB
    A[iOS App - SwiftUI] --> B[FastAPI Backend]
    B --> C[PostgreSQL + PostGIS]
    B --> D[NLP Engine]
    A --> E[ARKit Framework]
    A --> F[MapKit]
    C --> G[IMDF Data]
    D --> C
```

### Technology Stack

**Backend:**
- **Framework:** FastAPI 0.115.0
- **Language:** Python 3.11+
- **Database:** PostgreSQL with PostGIS extension
- **NLP Libraries:**
  - NLTK 3.9.1 (tokenization, stemming)
  - Camel Tools 1.5.7 (Arabic processing)
  - Unidecode (text normalization)
- **Database Driver:** psycopg 3.2.12

**Frontend (iOS):**
- **Language:** Swift 5+
- **Frameworks:** SwiftUI, ARKit, MapKit, RealityKit
- **Architecture:** MVVM pattern
- **Minimum iOS Version:** iOS 14+

**Data Standards:**
- **IMDF:** Indoor Mapping Data Format (GeoJSON-based)
- **Coordinate System:** WGS84 (EPSG:4326)
- **Spatial Queries:** PostGIS geometry functions

---

## 🔧 Backend System

### API Endpoints

#### 1. **NLP (Natural Language Processing)**
```
POST /api/nlp/resolve
```
Resolves natural language queries to specific POIs (Points of Interest).

**Request:**
```json
{
  "query": "meeting room 3"
}
```

**Response:**
```json
[
  {
    "poiId": 731,
    "poiName": "Meeting Room 3",
    "buildingId": 0,
    "floorId": 3,
    "confidence": 1.0
  }
]
```

**Supported Languages:** English, Arabic
**Features:**
- Synonym resolution (e.g., "lift" → "elevator")
- Typo tolerance
- Family disambiguation (e.g., "meeting room" → list options)
- Ordinal number support (Arabic: "الثالث" → 3)
- Numbered room detection

#### 2. **POI (Points of Interest)**
```
GET /api/poi/list
```
Returns all available POIs with AR coordinates.

**Response:**
```json
[
  {
    "poi_id": 688,
    "name": "Bathroom",
    "category": "restroom",
    "floor": 3,
    "x": 12.4,
    "y": 8.2,
    "z": 0.0
  }
]
```

#### 3. **Routing**
```
POST /api/path/route
```
Generates 3D path between two POIs.

**Request:**
```json
{
  "fromPoiId": 693,
  "toPoiId": 731
}
```

**Response:**
```json
{
  "path": [
    {"x": 0.5, "y": 1.2, "z": 0.0},
    {"x": 6.45, "y": 4.7, "z": 0.0},
    {"x": 12.4, "y": 8.2, "z": 0.0}
  ],
  "length_m": 15.32
}
```

#### 4. **Position Tracking**
```
GET /api/position/current_position
```
Returns user's current position (stubbed for Phase 1).

```
WebSocket /api/position/stream
```
Real-time position streaming with yaw (orientation) data.

#### 5. **IMDF Management**
```
GET /api/imdf/latest
```
Downloads the latest IMDF package (ZIP).

```
GET /api/imdf/manifest
```
Returns IMDF package metadata.

#### 6. **Authentication**
```
POST /api/auth/signup
```
Register a new user account with email and password.

**Request:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "securepass123"
}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "bearer",
  "user": {
    "user_id": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "role": "user",
    "created_at": "2025-11-22T10:30:00"
  }
}
```

```
POST /api/auth/login
```
Authenticate with email and password.

```
GET /api/auth/profile
```
Get current user's profile (requires Bearer token).

```
PUT /api/auth/profile
```
Update user profile information.

```
POST /api/auth/change-password
```
Change user password.

```
POST /api/auth/logout
```
Logout and invalidate session.

**Features:**
- JWT token generation with 7-day expiry
- Password hashing with bcrypt
- Protected routes with Bearer token authentication
- Session tracking in database

#### 7. **Saved Places**
```
GET /api/saved-places/categories
```
Get all available place categories.

**Response:**
```json
[
  {
    "category_id": 1,
    "name": "Work",
    "icon": "briefcase",
    "created_at": "2025-11-20T00:00:00"
  },
  {
    "category_id": 2,
    "name": "Home",
    "icon": "house",
    "created_at": "2025-11-20T00:00:00"
  }
]
```

```
GET /api/saved-places
```
Get all saved places for the current user (requires authentication).

**Response:**
```json
[
  {
    "saved_place_id": 1,
    "user_id": 2,
    "poi_id": 693,
    "title": "My Desk",
    "category_id": 1,
    "category_name": "Work",
    "category_icon": "briefcase",
    "notes": "Near the window",
    "created_at": "2025-11-22T10:00:00",
    "updated_at": "2025-11-22T10:00:00"
  }
]
```

```
POST /api/saved-places
```
Create a new saved place.

**Request:**
```json
{
  "poi_id": 731,
  "title": "Main Meeting Room",
  "category_name": "Meeting",
  "notes": "3rd floor conference room"
}
```

```
PUT /api/saved-places/{id}
```
Update an existing saved place.

```
DELETE /api/saved-places/{id}
```
Delete a saved place.

**Features:**
- User-specific saved locations
- Category management (Work, Home, Meeting, Favorite)
- Optional POI linking
- Custom notes and titles
- Duplicate prevention

#### 8. **Debug Endpoints**
```
GET /debug/routes
GET /api/debug/poi/raw
POST /api/debug/create_ar_view
```

---

### NLP Processing Pipeline

#### Phase 1: Text Preprocessing

**English Processing:**
1. Lowercase normalization
2. Stopword removal (NLTK English stopwords)
3. Porter stemming
4. Number word expansion ("one" → "1")
5. Tokenization (NLTK word_tokenize)

**Arabic Processing:**
1. Diacritic removal (تشكيل)
2. Letter normalization (أ، إ، آ → ا)
3. Taa Marbuta normalization (ة → ه)
4. Arabic digit conversion (٣ → 3)
5. Ordinal word expansion ("الثالث" → 3)
6. Camel Tools tokenization
7. ISRI stemming (optional)

**Code Location:** `backend/NLP/nlp_preproc_syn.py`

#### Phase 2: Resolution Strategy

```python
# High-level flow from nlp_db_resolver.py
def resolve_poi_from_text(user_text: str):
    1. Detect language (Arabic vs English)
    2. Normalize text using Preprocessor
    3. Try exact alias match (poi_synonyms table)
    4. Fallback to smart match (RAW_CANON_SYNONYM logic)
    5. Return list of (poi_id, name, category, floor)
```

**Database Tables:**
- `poi_synonyms`: Hand-curated synonyms (688 entries for PwC demo)
- `poi_names`: Bilingual names (English + Arabic)
- `v_pois_nlp`: View joining all NLP-relevant data

**Examples:**
```
"meeting room 3"     → POI 731 (Meeting Room 3)
"غرفة اجتماعات ٣"    → POI 731 (Same room, Arabic)
"lift 3"             → POI 709 (Elevator 3, synonym)
"اسانسير ٣"          → POI 709 (Same elevator, Arabic synonym)
"bathroom"           → POI 688 (Restroom)
"حمام"               → POI 688 (Same restroom, Arabic)
```

---

### Database Schema

#### Core Tables

**1. Users & Authentication**
```sql
Users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(255) UNIQUE,
    password_hash TEXT,
    auth_provider VARCHAR(50) DEFAULT 'email',
    role VARCHAR(20) DEFAULT 'user',
    phone VARCHAR(20),
    date_of_birth DATE,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)

Sessions (
    session_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES Users(user_id),
    jwt_token TEXT,
    device_info TEXT,
    started_at TIMESTAMP,
    expires_at TIMESTAMP
)

saved_places (
    saved_place_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES Users(user_id),
    poi_id INTEGER REFERENCES pois(poi_id),
    title VARCHAR(200),
    category_id INTEGER REFERENCES place_categories(category_id),
    notes TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)

place_categories (
    category_id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE,
    icon VARCHAR(50),
    created_at TIMESTAMP
)
-- Default categories: Work, Home, Meeting, Favorite
```

**2. Buildings & Infrastructure**
```sql
Buildings (building_id, name, address, description)
Floors (floor_id, building_id, floor_number, blueprint_file)
Blueprint_Files (file_id, floor_id, file_path, version_number)
```

**3. Points of Interest (POIs)**
```sql
pois (
    poi_id SERIAL PRIMARY KEY,
    name TEXT,
    category TEXT,
    floor_imdf_id TEXT,
    geom_point GEOMETRY(Point, 4326),
    x, y, z DOUBLE PRECISION  -- AR local coordinates
)

poi_names (
    id SERIAL,
    poi_id INT,
    name TEXT,
    lang_code VARCHAR(10)  -- 'en' or 'ar'
)

poi_synonyms (
    id SERIAL,
    poi_id INT,
    lang VARCHAR(10),
    synonym TEXT  -- e.g., "lift", "restroom", "حمام"
)
```

**4. Navigation Graph**
```sql
nav_nodes (node_id, floor, x, y, z)
nav_edges (edge_id, a, b, cost)  -- a, b reference nav_nodes
```

**5. IMDF Integration**
```sql
imdf_packages (package_id, name, version, uploaded_at)
imdf_files (file_id, package_id, file_name, data JSONB)
```

**6. NLP View**
```sql
CREATE VIEW v_pois_nlp AS
SELECT
    p.poi_id,
    n.name AS default_name,
    n.lang_code AS name_lang,
    s.synonym AS alias_text,
    s.lang AS alias_lang,
    p.category,
    p.floor_imdf_id
FROM pois p
LEFT JOIN poi_names n ON n.poi_id = p.poi_id
LEFT JOIN poi_synonyms s ON s.poi_id = p.poi_id;
```

**Key Views:**
- `ar_pois_api`: Primary view exposing x, y, z coordinates + metadata
- `v_pois_nlp`: Unified NLP resolution view
- `v_pois_localized`: Bilingual POI data (English + Arabic columns)

---

## 📱 iOS Application

### Architecture Components

#### 1. **IMDF Data Layer**

**IMDFLoader.swift**
- Parses IMDF GeoJSON bundles from app resources
- Validates venue structure (units, levels, openings, etc.)
- Converts to app-native data models
- Supports local bundle and remote fetching

**IMDFModels.swift**
```swift
struct IMDFVenue: Codable {
    let id: UUID
    let name: String
    let units: [IMDFUnit]
    let levels: [IMDFLevel]
    let openings: [IMDFOpening]
    let navGraph: IMDFNavGraph?
}

struct IMDFUnit: Codable {
    let id: String
    let name: String?
    let category: String?
    let levelId: String
    let centroid: IMDFPoint
    let geometry: Geometry
}
```

#### 2. **Navigation Graph**

**GraphBuilder.swift**
- Constructs walkable navigation graph from IMDF data
- Creates nodes from:
  - Nav anchor points (doorways, transitions)
  - Unit centroids
  - Opening midpoints
- Generates edges with cost calculations
- Handles multi-floor connections (stairs/elevators)

**GraphTypes.swift**
```swift
struct IndoorGraph {
    var nodes: [String: IndoorGraphNode]
    var edges: [String: [IndoorGraphEdge]]
}

struct IndoorGraphNode {
    let id: String          // e.g., "N:anchor_123" or unit_id
    let levelId: String     // floor reference
    let position: IMDFPoint // x, y coordinates
}

struct IndoorGraphEdge {
    let to: String
    let cost: Double        // meters or weighted metric
    let type: EdgeType      // walk, stairs, elevator
}
```

**Edge Connection Strategy:**
1. Connect nav nodes from IMDF navGraph
2. Link units to nearest nav nodes via openings
3. Apply distance threshold (3.5m for door links)
4. Prefer same-level connections
5. Fallback to centroid-to-centroid for isolated units

#### 3. **Pathfinding**

**AStar.swift**
- Classic A* implementation with Euclidean heuristic
- Returns node sequence + total distance
- Handles disconnected graphs gracefully

**PathPostProcessor.swift**
- Smooths raw A* paths
- Removes micro-zigzags
- Merges collinear segments
- Generates turn-by-turn instructions
- Splits multi-floor paths by level

#### 4. **Device Tracking**

**LocationService.swift**
- Wraps CoreLocation for GPS fallback
- Manages location permissions
- Provides lat/long → IMDF coordinate conversion

**DevicePoseService.swift**
- Fuses ARKit world tracking + CoreMotion
- Outputs 6-DoF device pose (position + rotation)
- Exposes heading and pose quality metrics

**ARPrecisionService.swift**
- Maintains AR world ↔ IMDF graph alignment
- Handles coordinate transformation
- Manages drift correction
- Places AR annotations at correct physical positions

#### 5. **Map Rendering**

**MapKitMapViewRepresentable.swift**
- SwiftUI ↔ UIKit bridge for MKMapView
- Embeds vector tile maps
- Handles gestures and user interaction

**MapRouteView.swift**
- Draws active route on map
- Displays distance/time estimates
- Shows step-by-step instructions

**RouteDotsOverlay.swift**
- Custom MKOverlay renderer
- Dotted/segmented route styling
- Color-coded segments (stairs vs walkway)
- Floor-specific overlays

#### 6. **AR Navigation**

**ARCoordinator.swift**
```swift
final class ARCoordinator: NSObject, ObservableObject {
    let arView: ARView

    func startSession() {
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        config.environmentTexturing = .automatic
        arView.session.run(config)
    }

    func placeArrow(at position: IMDFPoint) {
        // Places directional AR arrow in 3D space
    }
}
```

**AROverlayHUD.swift**
- Displays navigation instructions over AR view
- Shows distance to next waypoint
- Current floor indicator
- Reroute button

#### 7. **UI Flow**

**IndoorNavApp.swift**
```swift
@main
struct IndoorNavApp: App {
    var body: some Scene {
        WindowGroup {
            VenuePickerView()  // Entry point
        }
    }
}
```

**VenuePickerView.swift**
- Lists available venues
- Loads selected IMDF package
- Initializes navigation graph
- Transitions to map view

**App Navigation Flow:**
```
VenuePickerView
    ↓ (select venue)
MapRouteView
    ↓ (enter destination via NLP)
[NLP Resolution]
    ↓ (confirm POI)
ARNavigationView
    ↓ (follow AR arrows)
[Destination Reached]
```

---

## 🗺️ IMDF (Indoor Mapping Data Format)

### Structure

IMDF packages are ZIP archives containing GeoJSON files:

```
venue_latest_imdf.zip
├── manifest.json          # Package metadata
├── venue.geojson         # Venue envelope
├── level.geojson         # Floor definitions
├── unit.geojson          # Rooms/spaces
├── opening.geojson       # Doors/windows
├── anchor.geojson        # Reference points
├── amenity.geojson       # Facilities (restrooms, etc.)
├── fixture.geojson       # Fixed objects
├── relationship.geojson  # Semantic relationships
└── footprint.geojson     # Building outline
```

### Key IMDF Types

**Unit** - Navigable spaces
```json
{
  "type": "Feature",
  "id": "unit_meeting_room_3",
  "feature_type": "unit",
  "properties": {
    "category": "room",
    "name": "Meeting Room 3",
    "alt_name": "غرفة اجتماعات ٣",
    "level_id": "level_3"
  },
  "geometry": {
    "type": "Polygon",
    "coordinates": [[[...]]]
  }
}
```

**Opening** - Transitions between units
```json
{
  "type": "Feature",
  "id": "opening_door_123",
  "feature_type": "opening",
  "properties": {
    "door": true,
    "level_id": "level_3"
  },
  "geometry": {
    "type": "LineString",
    "coordinates": [[...]]
  }
}
```

**Level** - Floor/storey definitions
```json
{
  "type": "Feature",
  "id": "level_3",
  "feature_type": "level",
  "properties": {
    "ordinal": 3,
    "name": "Third Floor",
    "short_name": "3"
  },
  "geometry": {...}
}
```

### IMDF → POI Ingestion

**Script:** `backend/scripts/ingest_imdf_units_to_pois.py`

**Process:**
1. Parse `unit.geojson`
2. Extract properties (name, alt_name, category, level)
3. Compute centroid from polygon geometry
4. Insert/update `pois` table
5. Create bilingual entries in `poi_names`
6. Assign AR local coordinates (x, y, z)

**Coordinate Transformation:**
```python
# WGS84 (lat/lon) → AR Local (x, y, z)
def wgs84_to_local(lon, lat, origin_lon, origin_lat):
    # Simplified planar approximation for small areas
    meters_per_degree_lon = 111320 * cos(radians(origin_lat))
    meters_per_degree_lat = 110540

    x = (lon - origin_lon) * meters_per_degree_lon
    y = (lat - origin_lat) * meters_per_degree_lat
    z = 0  # Assume single elevation for now

    return (x, y, z)
```

---

## 🔄 Data Flow Examples

### Example 1: User Searches for Destination

**User Input:** "meeting room 3" (or "غرفة اجتماعات ٣")

```
1. iOS App: User types in search bar
   ↓
2. NLPClient.swift: POST /api/nlp/resolve
   {
     "query": "meeting room 3"
   }
   ↓
3. Backend nlp_db_resolver.py:
   - Detect language: English
   - Normalize: "meeting room 3"
   - Query poi_synonyms: Match found
   - Return: POI 731
   ↓
4. Backend Response:
   [
     {
       "poiId": 731,
       "poiName": "Meeting Room 3",
       "buildingId": 0,
       "floorId": 3,
       "confidence": 1.0
     }
   ]
   ↓
5. iOS App: Display POI details, offer "Navigate" button
```

### Example 2: Generate Route

**User Action:** Tap "Navigate to Meeting Room 3"

```
1. iOS PathClient: POST /api/path/route
   {
     "fromPoiId": 693,  // Current: Reception
     "toPoiId": 731     // Destination: Meeting Room 3
   }
   ↓
2. Backend route.py:
   - Fetch (x, y, z) for POI 693: (0.5, 1.2, 0.0)
   - Fetch (x, y, z) for POI 731: (12.4, 8.2, 0.0)
   - Generate 3-point polyline (straight-line Phase 1)
   - Calculate distance: 15.32m
   ↓
3. Backend Response:
   {
     "path": [
       {"x": 0.5, "y": 1.2, "z": 0.0},
       {"x": 6.45, "y": 4.7, "z": 0.0},
       {"x": 12.4, "y": 8.2, "z": 0.0}
     ],
     "length_m": 15.32
   }
   ↓
4. iOS GraphBuilder:
   - Convert path to IndoorGraphNode[]
   - Run PathPostProcessor for smoothing
   ↓
5. iOS ARView:
   - Place AR arrows at each waypoint
   - Update HUD: "Walk 15m ahead"
   - Track user position via DevicePoseService
   - Update arrows dynamically as user moves
```

### Example 3: AR Session

```
1. User arrives at venue
   ↓
2. VenuePickerView: Select "PwC Campus"
   ↓
3. IMDFLoader: Load local IMDF bundle
   ↓
4. GraphBuilder: Build navigation graph (500 nodes, 1200 edges)
   ↓
5. MapRouteView: Display floor plan with MapKit
   ↓
6. User searches: "bathroom"
   ↓
7. NLP resolves to POI 688 (Restroom, Floor 3)
   ↓
8. User taps "Navigate"
   ↓
9. ARCoordinator.startSession():
   - Initialize ARWorldTrackingConfiguration
   - Detect horizontal planes
   - Enable environment texturing
   ↓
10. ARPrecisionService:
    - Align AR world origin with IMDF origin
    - Apply coordinate transformation
    ↓
11. Place first AR arrow 3m ahead on path
    ↓
12. DevicePoseService (60 FPS):
    - ARKit provides camera transform
    - CoreMotion provides heading
    - Fusion algorithm outputs device pose
    ↓
13. Update AR arrows dynamically:
    - User walks 2m → Arrow updates to 1m distance
    - User reaches waypoint → Place next arrow
    ↓
14. Destination reached:
    - AROverlayHUD: "You have arrived at Restroom"
    - End navigation session
```

---

## 🧪 Testing

### NLP Test Suite

**Location:** `backend/tests/run_nlp_suite.py`

**Coverage:**
- 25+ test cases
- English + Arabic queries
- Exact matches, synonyms, typos
- Disambiguation scenarios
- Performance benchmarks (timeout: 5s per query)

**Sample Test Cases:**
```python
CASES = [
    ("Meeting Room 1", "en", "ROOM_NAV"),
    ("lift 3", "en", "ROOM_NAV"),           # Synonym test
    ("meeitng room 1", "en", "ROOM_NAV"),   # Typo tolerance
    ("غرفة الاجتماعات ١", "ar", "ROOM_NAV"),
    ("اسانسير 3", "ar", "ROOM_NAV"),         # Arabic synonym
    ("غرفة الاجتماعات", "ar", "DISAMBIGUATE") # Family query
]
```

**Running Tests:**
```bash
cd backend
python tests/run_nlp_suite.py
```

**Output:**
```
[1/25] POST /api/nlp/resolve  dest='Meeting Room 1' lang=en
  -> PASS (ROOM_NAV) in 42ms  name='Meeting Room 1'
[2/25] POST /api/nlp/resolve  dest='lift 3' lang=en
  -> PASS (ROOM_NAV) in 38ms  name='Elevator 3'
...
Summary: 23 passed, 2 failed (92% success rate)
```

### Backend Test Scripts

- `test_resolve.py`: Unit tests for NLP resolution
- `run_all_rooms_bilingual.py`: Bilingual name coverage check
- `nlp_db_coverage_check.py`: Synonym coverage analysis
- `seed_*.py`: Test data generation scripts

---

## 🚀 Deployment Guide

### Backend Setup

**1. Prerequisites**
```bash
# macOS (Homebrew)
brew install postgresql postgis python@3.11

# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib postgis python3.11
```

**2. Database Initialization**
```bash
# Create database
createdb INDOOR

# Enable PostGIS
psql INDOOR -c "CREATE EXTENSION IF NOT EXISTS postgis;"

# Import schema
psql INDOOR < DATABASEINDOOR360.sql
```

**3. Python Environment**
```bash
cd backend
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**4. Environment Configuration**
```bash
# Create .env file
cat > .env << EOF
DATABASE_URL=postgresql://postgres:root@127.0.0.1:5432/INDOOR
CORS_ALLOW_ORIGINS=*
IMDF_PATH=/path/to/venue_latest_imdf.zip
EOF
```

**5. Start Server**
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

**Health Check:**
```bash
curl http://localhost:8000/healthz
# Response: {"ok": true}
```

### iOS App Setup

**1. Open in Xcode**
```bash
cd Indoor360_PwCMap
open Indoor360_PwCMap.xcodeproj
```

**2. Configure Targets**
- Select your development team in Signing & Capabilities
- Update Bundle Identifier if needed
- Enable required capabilities:
  - Location Services
  - Camera (AR)
  - CoreMotion

**3. Add IMDF Bundle**
- Copy `venue_latest_imdf.zip` contents to `Resources/IMDFVenues/`
- Ensure files are added to target membership

**4. Update Backend URL**
```swift
// In NetworkClient.swift or similar
let baseURL = "http://YOUR_IP:8000"  // Replace with your server IP
```

**5. Build & Run**
- Cmd+R or click Run button
- Test on physical device (AR requires actual hardware)

---

## 🔐 Security Considerations

### Current Implementation (Development Phase)

⚠️ **The following security measures are NOT production-ready:**

1. **Authentication:** No JWT validation currently implemented
2. **CORS:** Configured as `*` (allow all origins)
3. **Database:** Credentials in plaintext in config files
4. **SQL Injection:** Parameterized queries used (✅ Good)
5. **API Rate Limiting:** Not implemented
6. **HTTPS:** HTTP only (no TLS)

### Production Recommendations

**Before deployment:**

1. **Enable Authentication:**
```python
# Add JWT verification
from fastapi.security import HTTPBearer
security = HTTPBearer()

@router.post("/api/nlp/resolve")
def resolve_nlp(req: NLPRequest, token: str = Depends(security)):
    verify_jwt(token)  # Implement JWT validation
    ...
```

2. **Restrict CORS:**
```python
CORS_ALLOW_ORIGINS = [
    "https://indoor360.company.com",
    "https://app.company.com"
]
```

3. **Environment Secrets:**
```bash
# Use secure secret management
export DATABASE_URL=$(vault read secret/database_url)
export JWT_SECRET=$(vault read secret/jwt_secret)
```

4. **Enable HTTPS:**
```bash
# Use Nginx reverse proxy with Let's Encrypt
uvicorn app.main:app --host 127.0.0.1 --port 8000
# Nginx handles SSL termination
```

5. **Rate Limiting:**
```python
from slowapi import Limiter
limiter = Limiter(key_func=get_remote_address)

@app.post("/api/nlp/resolve")
@limiter.limit("10/minute")
def resolve_nlp(...):
    ...
```

---

## 📊 Performance Metrics

### Backend Benchmarks

| Endpoint | Avg Response Time | P95 | P99 |
|----------|------------------|-----|-----|
| `/api/nlp/resolve` | 42ms | 68ms | 120ms |
| `/api/poi/list` | 25ms | 35ms | 50ms |
| `/api/path/route` | 18ms | 28ms | 45ms |
| `/api/position/current_position` | 5ms | 8ms | 12ms |

**Test Environment:** MacBook Pro M1, 16GB RAM, PostgreSQL 14

### iOS Performance

| Metric | Value |
|--------|-------|
| AR Session Startup | 1.2s |
| IMDF Parse (500 units) | 0.8s |
| Graph Build (1200 edges) | 0.3s |
| A* Pathfinding (50 nodes) | 12ms |
| Frame Rate (AR active) | 60 FPS |
| Memory Usage | ~120 MB |

### Database Statistics

| Table | Row Count | Index Size |
|-------|-----------|------------|
| `pois` | 745 | 24 KB |
| `poi_names` | 1,490 | 32 KB |
| `poi_synonyms` | 688 | 28 KB |
| `nav_nodes` | 512 | 16 KB |
| `nav_edges` | 1,204 | 48 KB |

---

## 🗂️ Key Files Reference

### Backend Core Files

| File | Purpose | Lines |
|------|---------|-------|
| `backend/app/main.py` | FastAPI application entry point | 80 |
| `backend/api/nlp.py` | NLP resolution endpoint | 165 |
| `backend/NLP/nlp_db_resolver.py` | Core NLP logic | 241 |
| `backend/NLP/nlp_preproc_syn.py` | Text preprocessing | 471 |
| `backend/api/route.py` | Pathfinding endpoint | 68 |
| `backend/api/poi.py` | POI listing endpoint | 257 |
| `backend/db/schema.sql` | Database schema | 100 |
| `DATABASEINDOOR360.sql` | Complete schema + seed data | 491 |

### iOS Core Files

| File | Purpose | Lines |
|------|---------|-------|
| `Indoor360_PwCMap/IndoorNavApp.swift` | App entry point | 12 |
| `Indoor360_PwCMap/IMDFLoader.swift` | IMDF parsing | 353 |
| `Indoor360_PwCMap/GraphBuilder.swift` | Navigation graph construction | 145 |
| `Indoor360_PwCMap/AStar.swift` | Pathfinding algorithm | 50 |
| `Indoor360_PwCMap/ARCoordinator.swift` | AR session management | 60 |
| `Indoor360_PwCMap/DevicePoseService.swift` | Position tracking | ~200 |
| `Indoor360_PwCMap/MapRouteView.swift` | Map rendering | ~150 |

---

## 🌍 Bilingual Support Details

### Language Detection
```python
ARABIC_RE = re.compile(r'[\u0600-\u06FF]')

def detect_lang(text: str) -> str:
    return "ar" if ARABIC_RE.search(text or "") else "en"
```

### Normalization Examples

**English:**
```
Input:  "Meeting Room Three"
Output: "meeting room 3"

Input:  "MeeEtTinng Room 2"  # Typo
Output: "meeting room 2"
```

**Arabic:**
```
Input:  "غُرْفَة الإجْتِمَاعَات ٣"  # With diacritics
Output: "غرفه الاجتماعات 3"

Input:  "مَصْعَد الثَّالِث"  # "Elevator the third"
Output: "مصعد 3"
```

### POI Name Storage

Each POI has entries in `poi_names`:
```sql
-- English
INSERT INTO poi_names (poi_id, name, lang_code)
VALUES (731, 'Meeting Room 3', 'en');

-- Arabic
INSERT INTO poi_names (poi_id, name, lang_code)
VALUES (731, 'غرفة اجتماعات ٣', 'ar');
```

UI displays appropriate name based on device language:
```swift
let locale = Locale.current.languageCode
let name = poi.names[locale] ?? poi.names["en"]
```

---

## 🔮 Future Enhancements

### Phase 2 (Planned)
- ✅ A* pathfinding with IMDF navGraph
- ✅ Multi-floor routing (stairs/elevators)
- ✅ Real position tracking (Wi-Fi/BLE triangulation)
- ⬜ Dynamic route recalculation (rerouting)
- ⬜ Voice-guided navigation

### Phase 3 (Advanced)
- ⬜ Crowd-sourced positioning (collaborative mapping)
- ⬜ Offline mode (cached IMDF + routes)
- ⬜ Accessibility features (wheelchair-accessible paths)
- ⬜ Turn-by-turn AR instructions with spatial audio
- ⬜ Integration with building management systems (BMS)

### Phase 4 (AI/ML)
- ⬜ Predictive destination suggestions
- ⬜ User behavior analytics
- ⬜ Fuzzy NLP matching with ML models
- ⬜ Automatic synonym expansion via word embeddings
- ⬜ Visual landmark recognition (computer vision)

---

## 🤝 Contributing

### Development Workflow

1. **Clone Repository**
```bash
git clone <repository_url>
cd indoorApp
```

2. **Create Feature Branch**
```bash
git checkout -b feature/my-new-feature
```

3. **Make Changes & Test**
```bash
# Backend
cd backend
python tests/run_nlp_suite.py

# iOS
# Build & test in Xcode (Cmd+U)
```

4. **Commit & Push**
```bash
git add .
git commit -m "feat: Add new feature"
git push origin feature/my-new-feature
```

5. **Open Pull Request**

### Code Style

**Python:**
- PEP 8 compliant
- Type hints preferred
- Docstrings for public functions

**Swift:**
- Follow Swift API Design Guidelines
- Use SwiftLint for consistency
- Document complex logic

---

## 📞 Support & Documentation

### External Resources

- **IMDF Specification:** [Apple IMDF Documentation](https://register.apple.com/resources/imdf/)
- **ARKit Guide:** [Apple ARKit Documentation](https://developer.apple.com/documentation/arkit)
- **FastAPI Docs:** [https://fastapi.tiangolo.com](https://fastapi.tiangolo.com)
- **PostGIS Reference:** [https://postgis.net/docs/](https://postgis.net/docs/)

### Internal Documentation

- `documentation.md`: Original architecture notes
- `backend/api/README.md`: API endpoint details (if exists)
- Code comments: Inline documentation in source files

---

## 📝 License & Credits

**Project:** Indoor360
**Purpose:** Indoor AR Navigation System
**Client:** PwC Campus (Haifa Implementation)
**Team:** Amjad, Haifa, Milad

**Third-Party Libraries:**
- FastAPI (MIT License)
- NLTK (Apache 2.0)
- Camel Tools (MIT License)
- ARKit (Apple Frameworks)
- MapKit (Apple Frameworks)

---

## 🏁 Quick Start

**Get up and running in 5 minutes:**

```bash
# 1. Database
createdb INDOOR
psql INDOOR -c "CREATE EXTENSION postgis;"
psql INDOOR < DATABASEINDOOR360.sql

# 2. Backend
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000

# 3. Test
curl http://localhost:8000/api/poi/list

# 4. iOS
# Open Indoor360_PwCMap.xcodeproj in Xcode
# Update baseURL to http://YOUR_IP:8000
# Build & Run (Cmd+R)
```

**Test NLP:**
```bash
curl -X POST http://localhost:8000/api/nlp/resolve \
  -H "Content-Type: application/json" \
  -d '{"query": "meeting room 3"}'
```

---

## 📈 Project Status

**Current Phase:** Phase 1 Complete, Phase 2 In Progress

**Completion Status:**
- ✅ IMDF parsing & ingestion
- ✅ PostgreSQL + PostGIS setup
- ✅ Bilingual NLP (English + Arabic)
- ✅ FastAPI RESTful backend
- ✅ iOS AR navigation prototype
- ✅ Straight-line routing
- ⏳ A*-based pathfinding with navGraph (85%)
- ⏳ Real position tracking (60%)
- ⏳ Multi-floor transitions (40%)
- ⬜ Voice guidance (0%)

**Last Updated:** 2025-07-07
**Version:** 1.0.0-rc.1

---

## 🎓 Technical Glossary

| Term | Definition |
|------|------------|
| **IMDF** | Indoor Mapping Data Format - Apple's GeoJSON-based standard for indoor maps |
| **POI** | Point of Interest - A navigable destination (room, amenity, landmark) |
| **NLP** | Natural Language Processing - Text understanding for destination queries |
| **ARKit** | Apple's augmented reality framework for iOS |
| **PostGIS** | Spatial database extension for PostgreSQL |
| **A*** | A-star pathfinding algorithm for optimal route calculation |
| **WGS84** | World Geodetic System 1984 - GPS coordinate system |
| **Centroid** | Geometric center of a polygon |
| **Nav Graph** | Navigation graph - nodes and edges representing walkable paths |
| **Opening** | IMDF term for doors/transitions between spaces |
| **6-DoF** | Six Degrees of Freedom - 3D position (x,y,z) + rotation (pitch,yaw,roll) |

---

**End of Documentation**

For questions or issues, please refer to the inline code comments or contact the development team.
