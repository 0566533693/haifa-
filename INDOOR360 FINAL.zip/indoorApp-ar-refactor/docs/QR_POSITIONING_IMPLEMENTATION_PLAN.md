# QR Code-Based Indoor AR Navigation - Implementation Plan

**Project:** Indoor360 - QR Positioning MVP
**Timeline:** 1-2 days (reduced from 2-4 due to existing components)
**Target:** Demo-ready AR navigation without WiFi/BLE infrastructure
**Last Updated:** November 25, 2025

---

## 🎯 Executive Summary

This plan implements **QR code-based positioning** for Indoor360's AR navigation system. Users scan a QR code at a known location (e.g., room entrance), select their destination, and receive step-by-step AR arrow guidance.

**Key Benefits:**
- ✅ No special iOS entitlements required
- ✅ Zero hardware costs (WiFi/BLE beacons not needed)
- ✅ 100% reliable for demos (no tracking drift)
- ✅ Fast implementation (1-2 days with existing components)
- ✅ Scalable to production (add more QR codes = more entry points)

---

## 📋 What Already Exists (Reusable Components)

### ✅ Backend Infrastructure (PRODUCTION READY)
1. **POI Database** (`pois` table with 745 locations)
   - Contains (x, y, z) coordinates in IMDF system
   - Bilingual names (English/Arabic)
   - Floor/level information

2. **Routing API** (`POST /api/path/route`)
   - Takes `fromPoiId` and `toPoiId`
   - Returns path with distance
   - Connected to PathClient on iOS

3. **NLP Resolution** (`POST /api/nlp/resolve`)
   - Convert destination names to POI IDs
   - Integrated with SearchViewModel

4. **AR Anchors Endpoint** (`GET /api/ar/anchor/{anchor_id}`) ✅ NEW
   - Returns anchor position (poi_id, floor, x, y, z, label)
   - Uses `ar_anchors` table (needs to be created/populated)

5. **Navigation Logging** (`POST /api/user/{user_id}/navigation`) ✅ NEW
   - Logs navigation sessions for analytics
   - Already integrated with iOS SearchViewModel

### ✅ iOS Components - ClientSide (FULLY IMPLEMENTED) 🆕

1. **Full A* Pathfinding** (`AStar.swift`) ✅
   - Complete A* implementation with proper heuristics
   - Returns path array and total distance

2. **Graph Builder** (`GraphBuilder.swift`) ✅
   - Builds IndoorGraph from IMDF venue data
   - Proper door/opening connectivity (max 3.5m link distance)
   - Cross-level transitions support
   - Nav node and edge parsing

3. **IMDF Loader** (`IMDFLoader.swift`) ✅
   - Full IMDF package parsing (levels, units, openings, transitions)
   - Nav graph support (`nav_nodes.geojson`, `nav_edges.geojson`)
   - Local bundle store with venue discovery

4. **Map-Based Navigation** (`MapRouteView.swift`) ✅
   - Complete UI with start mode selection (tap/GPS)
   - Real-time location tracking with CoreLocation
   - Route visualization with dots overlay
   - Live rerouting capability
   - Arrival detection (3m threshold)

5. **Path Processing** (`PathPostProcessor.swift`) ✅
   - Douglas-Peucker simplification
   - Chaikin smoothing
   - **Turn hints generation** (left/right/forward/start/finish)
   - Densification for consistent sampling

6. **Location Service** (`LocationService.swift`) ✅
   - CoreLocation wrapper with quality gating
   - Max age (10s) and accuracy (40m) filters
   - Mode switching (selecting vs navigating)

7. **AR Precision Service** (`ARPrecisionService.swift`) ✅
   - ARKit-based displacement tracking
   - Gravity+heading world alignment
   - EMA smoothing (α=0.25)
   - East/North displacement in meters

8. **Device Pose Service** (`DevicePoseService.swift`) ✅
   - Pitch detection via CoreMotion
   - Hysteresis-based AR/2D mode switching
   - AR threshold: -55° (phone upright)
   - 2D threshold: -35° (phone flat)

### ✅ iOS Components - QR & Deep Links (FULLY IMPLEMENTED)

1. **QR Scanner** (`QRCodeScanner.swift`) ✅
   - Complete AVFoundation-based scanner
   - Torch control, pause/resume
   - Simulator support (`simulateScan()`)

2. **QR Scan View** (`QRScanView.swift`) ✅
   - Full UI with framing overlay
   - Camera permission handling
   - Torch toggle in toolbar
   - Toast feedback on scan

3. **Deep Link Router** (`DeepLinkRouter.swift`) ✅
   - Parses QR payloads: `poi:ID`, `venue:ID`, `nav:from=X&to=Y`, URLs
   - Human-readable descriptions for toasts

### ✅ iOS Components - State & Services

1. **App State** (`AppState.swift`) ✅
   - AR navigation flags: `isShowingARNavigation`, `activeRoute`
   - `startARNavigation(with:)` and `stopARNavigation()` helpers

2. **Search + NLP Integration** (`SearchViewModel.swift`) ✅
   - NLP resolution via backend
   - Route fetching via PathClient
   - Navigation session logging

3. **Remote POI Service** (`RemotePOIService.swift`) ✅
   - Search POIs via `/api/poi/search`
   - Maps backend DTO to local POI model

### 🟡 iOS Components - AR View (STUB ONLY)

1. **AR Navigation View** (`ARNavigationView.swift`) 🟡
   - Basic stub that reads `appState.activeRoute`
   - **Needs:** Arrow rendering, step navigation, camera overlay

### 🔧 What Needs Building (REDUCED SCOPE)

1. **QR → POI Mapping** (Backend)
   - Create/populate `qr_anchors` table (or use existing `ar_anchors`)
   - Add QR resolution endpoint that maps `anchor:xxx` → POI coordinates

2. **Step-Based Navigation State** (iOS)
   - Wrap existing turn hints in NavigationStep model
   - Add manual "Next Step" advancement

3. **AR Arrow Rendering** (iOS)
   - Place 3D arrow in ARKit scene
   - Rotate based on `ARPrecisionService` displacement + compass heading
   - Use `DevicePoseService` for AR/2D mode switching

4. **QR → Navigation Flow Integration** (iOS)
   - Connect QRScanView → destination picker → ARNavigationView
   - Use existing `DeepLinkRouter` to parse `anchor:` prefix

---

## 🗓️ Revised Day-by-Day Implementation Plan

> **Note:** This plan is significantly reduced because most infrastructure already exists.
> The original 4-day estimate is now **1-2 days** due to existing components.

### **Day 1: Backend QR Mapping + iOS Integration** (6-8 hours)

#### Morning (3 hours): Backend Setup

##### Task 1.1: Create/Populate QR Anchors Table

The existing `ar_anchors` table in `backend/api/ar.py` can be reused, but we need to add a QR code field or create a dedicated mapping table.

**Option A: Extend existing `ar_anchors` table**
```sql
-- Add QR code column to existing ar_anchors
ALTER TABLE ar_anchors ADD COLUMN IF NOT EXISTS qr_code VARCHAR(100) UNIQUE;

-- Populate with demo anchors
UPDATE ar_anchors SET qr_code = 'anchor:' || label WHERE label IS NOT NULL;
```

**Option B: Create dedicated `qr_anchors` table**
```sql
-- File: backend/db/qr_anchors.sql
CREATE TABLE IF NOT EXISTS qr_anchors (
    qr_id SERIAL PRIMARY KEY,
    qr_code VARCHAR(100) UNIQUE NOT NULL,
    poi_id INT REFERENCES pois(poi_id) NOT NULL,
    location_name VARCHAR(255),
    floor_level INT NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_qr_code ON qr_anchors(qr_code);

-- Sample demo data (adjust POI IDs based on your actual data)
INSERT INTO qr_anchors (qr_code, poi_id, location_name, floor_level) VALUES
('anchor:reception', 1, 'Main Reception', 1),
('anchor:elevator-f1', 2, 'Elevator Floor 1', 1),
('anchor:cafeteria', 3, 'Cafeteria Entrance', 2)
ON CONFLICT (qr_code) DO NOTHING;
```

##### Task 1.2: Create QR Resolution Endpoint

```python
# File: backend/api/qr_position.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from api.nlp import get_db

router = APIRouter(prefix="/api/qr", tags=["QR Positioning"])

class QRResolveRequest(BaseModel):
    qr_code: str

class QRPositionResponse(BaseModel):
    poi_id: int
    poi_name: str
    location_name: str
    x: float
    y: float
    z: float
    floor: int

@router.post("/resolve", response_model=QRPositionResponse)
def resolve_qr_anchor(req: QRResolveRequest):
    """Resolve QR code (e.g., 'anchor:reception') to POI coordinates."""
    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT qa.poi_id, qa.location_name, qa.floor_level,
                   p.x, p.y, p.z, p.name
            FROM qr_anchors qa
            JOIN pois p ON qa.poi_id = p.poi_id
            WHERE qa.qr_code = %s AND qa.active = TRUE
        """, (req.qr_code,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, f"QR code '{req.qr_code}' not found")
        return QRPositionResponse(
            poi_id=row[0], location_name=row[1], floor=row[2],
            x=float(row[3]), y=float(row[4]), z=float(row[5]),
            poi_name=row[6] or row[1]
        )
    finally:
        cur.close()
        conn.close()

@router.get("/list")
def list_qr_anchors():
    """List all active QR anchors (for admin/debug)."""
    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT qr_code, location_name, floor_level, poi_id
            FROM qr_anchors WHERE active = TRUE
            ORDER BY floor_level, location_name
        """)
        return [{"qr_code": r[0], "location_name": r[1], "floor": r[2], "poi_id": r[3]}
                for r in cur.fetchall()]
    finally:
        cur.close()
        conn.close()
```

**Register in `backend/app/main.py`:**
```python
from api import qr_position
app.include_router(qr_position.router)
```

#### Afternoon (3-4 hours): iOS QR → Navigation Flow

##### Task 1.3: Extend DeepLinkRouter for `anchor:` Prefix

The existing `DeepLinkRouter.swift` already handles `poi:`, `venue:`, `nav:`. Add `anchor:`:

```swift
// In DeepLinkRouter.swift, add to DeepLink enum:
case anchor(id: String)

// In parse() function, add:
if trimmed.hasPrefix("anchor:") {
    return .anchor(id: String(trimmed.dropFirst(7)))
}

// In description(for:), add:
case .anchor(let id): return "Position set: \(id)"
```

##### Task 1.4: Create QR Position Client

```swift
// File: Indoor360-FrontEnd/Utilities/Network/QRPositionClient.swift
import Foundation

struct QRPositionResponse: Codable {
    let poiId: Int
    let poiName: String
    let locationName: String
    let x: Double
    let y: Double
    let z: Double
    let floor: Int

    enum CodingKeys: String, CodingKey {
        case poiId = "poi_id"
        case poiName = "poi_name"
        case locationName = "location_name"
        case x, y, z, floor
    }
}

class QRPositionClient {
    func resolve(_ qrCode: String) async throws -> QRPositionResponse {
        struct Body: Encodable { let qr_code: String }
        return try await APIClient.shared.postJSON(
            "/api/qr/resolve",
            body: Body(qr_code: qrCode),
            as: QRPositionResponse.self
        )
    }
}
```

##### Task 1.5: Update QRScanView to Trigger Navigation

Modify `handleScanResult` in `QRScanView.swift`:

```swift
private func handleScanResult(_ raw: String) {
    let link = DeepLinkRouter.parse(raw)

    switch link {
    case .anchor(let id):
        // Resolve QR and start navigation flow
        Task {
            do {
                let position = try await QRPositionClient().resolve("anchor:\(id)")
                await MainActor.run {
                    // Store position in AppState or navigate to destination picker
                    // appState.qrStartPosition = position
                    toast(.success, "Position: \(position.locationName)")
                }
            } catch {
                toast(.error, "QR not recognized")
            }
        }
    default:
        let message = DeepLinkRouter.description(for: link)
        toast(.info, message)
    }

    DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) {
        scanner.resume()
    }
}
```

**Day 1 Deliverables:**
- ✅ QR anchors database table populated
- ✅ `/api/qr/resolve` endpoint working
- ✅ iOS QRPositionClient calling backend
- ✅ QRScanView resolving `anchor:` codes

---

### **Day 2: AR Arrow & Step Navigation** (4-6 hours)

#### Morning (2-3 hours): Navigation Session State

##### Task 2.1: Create Navigation Session Model

```swift
// File: Indoor360-FrontEnd/Core Models & Protocols/NavigationSession.swift
import Foundation
import Combine

class NavigationSession: ObservableObject {
    @Published var startPosition: QRPositionResponse?
    @Published var destinationPoiId: Int?
    @Published var destinationName: String?
    @Published var currentStepIndex: Int = 0
    @Published var isNavigating: Bool = false

    // Use existing PathPostProcessor.TurnHint as steps
    @Published var turnHints: [PathPostProcessor.TurnHint] = []

    var currentHint: PathPostProcessor.TurnHint? {
        guard currentStepIndex < turnHints.count else { return nil }
        return turnHints[currentStepIndex]
    }

    var isLastStep: Bool {
        currentStepIndex >= turnHints.count - 1
    }

    func nextStep() {
        guard !isLastStep else { return }
        currentStepIndex += 1
    }

    func reset() {
        startPosition = nil
        destinationPoiId = nil
        destinationName = nil
        currentStepIndex = 0
        isNavigating = false
        turnHints = []
    }
}
```

##### Task 2.2: Build AR Arrow View

Leverage existing `ARPrecisionService` for displacement tracking:

```swift
// File: Indoor360-FrontEnd/Features & Onboarding/AR/ARStepNavigationView.swift
import SwiftUI
import RealityKit
import ARKit

struct ARStepNavigationView: View {
    @ObservedObject var session: NavigationSession
    @StateObject private var arService = ARPrecisionService()
    @StateObject private var poseService = DevicePoseService()
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            // AR Camera
            ARViewContainer(arService: arService)
                .ignoresSafeArea()

            // Instruction Banner
            VStack {
                if let hint = session.currentHint {
                    instructionBanner(hint)
                        .padding(.top, 60)
                }
                Spacer()

                // Progress + Next Button
                controlsSection
                    .padding(.bottom, 40)
            }
        }
        .onAppear {
            arService.start()
            poseService.start()
        }
        .onDisappear {
            arService.stop()
            poseService.stop()
        }
    }

    private func instructionBanner(_ hint: PathPostProcessor.TurnHint) -> some View {
        VStack(spacing: 8) {
            Image(systemName: iconFor(hint.kind))
                .font(.largeTitle)
                .foregroundColor(.blue)

            Text(textFor(hint))
                .font(.headline)
                .multilineTextAlignment(.center)
        }
        .padding()
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .padding(.horizontal)
    }

    private var controlsSection: some View {
        VStack(spacing: 16) {
            // Progress dots
            HStack(spacing: 8) {
                ForEach(0..<session.turnHints.count, id: \.self) { i in
                    Circle()
                        .fill(i <= session.currentStepIndex ? Color.blue : Color.gray.opacity(0.3))
                        .frame(width: 10, height: 10)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(.ultraThinMaterial)
            .clipShape(Capsule())

            // Next / Finish button
            Button(action: session.isLastStep ? finish : advanceStep) {
                Label(session.isLastStep ? "Finish" : "Next Step",
                      systemImage: session.isLastStep ? "checkmark.circle.fill" : "arrow.right.circle.fill")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(session.isLastStep ? Color.green : Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
            }
            .padding(.horizontal)
        }
    }

    private func advanceStep() {
        session.nextStep()
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    private func finish() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        dismiss()
    }

    private func iconFor(_ kind: PathPostProcessor.TurnHint.Kind) -> String {
        switch kind {
        case .start: return "figure.walk"
        case .forward: return "arrow.up"
        case .left: return "arrow.turn.up.left"
        case .right: return "arrow.turn.up.right"
        case .finish: return "flag.checkered"
        }
    }

    private func textFor(_ hint: PathPostProcessor.TurnHint) -> String {
        switch hint.kind {
        case .start: return "Start walking"
        case .forward: return "Continue straight"
        case .left: return "Turn left"
        case .right: return "Turn right"
        case .finish: return "You have arrived!"
        }
    }
}

// Simple AR View wrapper
struct ARViewContainer: UIViewRepresentable {
    let arService: ARPrecisionService

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        // ARPrecisionService already manages the session
        // We could add 3D arrow anchors here
        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {}
}
```

#### Afternoon (2-3 hours): Connect the Flow

##### Task 2.3: Create QR Navigation Start View

```swift
// File: Indoor360-FrontEnd/Features & Onboarding/QRNavigationStartView.swift
import SwiftUI

struct QRNavigationStartView: View {
    @StateObject private var session = NavigationSession()
    @State private var showQRScanner = false
    @State private var showDestinationPicker = false
    @State private var showARNavigation = false

    var body: some View {
        VStack(spacing: 24) {
            if session.startPosition == nil {
                // Step 1: Scan QR
                scanQRSection
            } else if session.destinationPoiId == nil {
                // Step 2: Pick destination
                pickDestinationSection
            } else {
                // Step 3: Ready to navigate
                readyToNavigateSection
            }
        }
        .padding()
        .sheet(isPresented: $showQRScanner) {
            QRScanView() // Existing view
        }
        .sheet(isPresented: $showDestinationPicker) {
            SearchView() // Reuse existing search
        }
        .fullScreenCover(isPresented: $showARNavigation) {
            ARStepNavigationView(session: session)
        }
    }

    // ... sections omitted for brevity
}
```

**Day 2 Deliverables:**
- ✅ NavigationSession state management
- ✅ ARStepNavigationView with step progression
- ✅ Full QR → Destination → AR flow working
- ✅ Turn hints from PathPostProcessor displayed

---

## 📊 Revised Implementation Summary

### Total Effort: 1-2 Days (down from 2-4)

| Day | Focus | Hours | Key Deliverables |
|-----|-------|-------|------------------|
| **Day 1** | Backend QR + iOS integration | 6-8 | QR table, resolve endpoint, iOS client |
| **Day 2** | AR view + flow | 4-6 | Step navigation UI, full flow |

### What's Already Done (No Work Needed)

| Component | Status | Location |
|-----------|--------|----------|
| QR Scanner | ✅ Complete | `QRCodeScanner.swift`, `QRScanView.swift` |
| Deep Link Parsing | ✅ Complete | `DeepLinkRouter.swift` |
| A* Pathfinding | ✅ Complete | `AStar.swift` (ClientSide) |
| Graph Building | ✅ Complete | `GraphBuilder.swift` (ClientSide) |
| IMDF Loading | ✅ Complete | `IMDFLoader.swift` (ClientSide) |
| Turn Hints | ✅ Complete | `PathPostProcessor.swift` (ClientSide) |
| AR Displacement | ✅ Complete | `ARPrecisionService.swift` (ClientSide) |
| Device Pose | ✅ Complete | `DevicePoseService.swift` (ClientSide) |
| Location Service | ✅ Complete | `LocationService.swift` (ClientSide) |
| POI Search | ✅ Complete | `RemotePOIService.swift` |
| NLP Resolution | ✅ Complete | `NLPBridge.swift` |
| Route API | ✅ Complete | `PathClient.swift` |
| Map Navigation | ✅ Complete | `MapRouteView.swift` (ClientSide) |
| AR Anchors API | ✅ Complete | `backend/api/ar.py` |
| Navigation Logging | ✅ Complete | `backend/api/navigation.py` |

### What Still Needs Work

| Component | Effort | Notes |
|-----------|--------|-------|
| QR anchors DB table | 30 min | SQL migration, populate with demo data |
| `/api/qr/resolve` endpoint | 1 hour | Simple POST endpoint |
| `QRPositionClient.swift` | 30 min | API client on iOS |
| `NavigationSession.swift` | 1 hour | State wrapper for navigation flow |
| `ARStepNavigationView.swift` | 2-3 hours | UI + turn hint display |
| QR → Navigation flow | 1-2 hours | Connect QRScanView to destination picker |

---

## 🔄 Future Enhancements (Post-MVP)

### Phase 2: Enhanced Routing ✅ (Already Partially Done)
- ✅ A* graph routing exists in `AStar.swift`
- ✅ Graph building from IMDF in `GraphBuilder.swift`
- ✅ Turn hints generation in `PathPostProcessor.swift`
- 🔲 Multi-floor navigation (stairs/elevators) - cross-level transitions exist
- 🔲 Alternative routes

### Phase 3: Continuous Tracking (Future)
- Add BLE beacons for between-QR tracking
- IMU sensor fusion with `ARPrecisionService`
- Automatic step detection using `DevicePoseService`
- Dynamic rerouting if off-path

### Phase 4: Production Features (Future)
- Voice guidance ("In 10 meters, turn left")
- Accessibility options (wheelchair routes)
- Offline mode with cached maps
- Analytics dashboard

---

## 🎯 Why This Approach Works

### ✅ Advantages
1. **Fast to implement** - Reuses 90%+ of existing code (improved!)
2. **Reliable for demos** - No tracking drift or positioning failures
3. **Zero infrastructure cost** - Just print QR codes
4. **Scales easily** - Add more QR codes as needed
5. **Apple approved** - No special entitlements required

### ⚠️ Limitations
1. **Requires QR scan** - Not fully automatic
2. **Manual steps** - User must tap to advance (can be automated later with ARPrecisionService)
3. **No continuous tracking** - Between QRs, limited position updates
4. **Fixed routes** - Can't dynamically reroute yet (but `MapRouteView` shows it's possible)

### 🚀 Production Path
This isn't a hack - it's a legitimate MVP that can evolve:
- Museums use QR/NFC check-ins extensively
- Hospitals combine QR anchors with BLE beacons
- Airports use QR codes at gate entrances
- Malls place QR codes at store entrances

**Start with QR positioning → Add BLE beacons later → Full sensor fusion eventually**

---

## 📞 Support & Resources

**Backend API:** http://localhost:8000/docs (FastAPI auto-docs)

**iOS Simulator Testing:**
- QR scanner has simulator mode with hardcoded test codes (`simulateScan()`)
- Use simulator to test entire flow without physical QR codes
- Test code in `QRScanView.swift`: `scanner.simulateScan("poi:CAFENOOR")`

**Physical Device Testing:**
- Requires actual QR code printouts
- Test camera permissions first
- Ensure good lighting for scanning

**QR Generator:** https://www.qr-code-generator.com/

**Troubleshooting:**
- Check backend logs: `tail -f backend/logs/app.log`
- Check iOS console in Xcode for AR errors
- Verify database with: `psql -d indoor360_db -c "SELECT * FROM qr_anchors"`

---

## 📁 Key File Locations

### Backend
- `backend/api/ar.py` - AR anchors endpoint (existing)
- `backend/api/navigation.py` - Navigation session logging (existing)
- `backend/api/qr_position.py` - **TO CREATE** QR resolution endpoint
- `backend/db/qr_anchors.sql` - **TO CREATE** QR anchors table

### iOS - ClientSide (Routing/Navigation Core)
- `Indoor360-ClientSide/AStar.swift` - A* pathfinding
- `Indoor360-ClientSide/GraphBuilder.swift` - Graph from IMDF
- `Indoor360-ClientSide/PathPostProcessor.swift` - Turn hints
- `Indoor360-ClientSide/ARPrecisionService.swift` - AR displacement
- `Indoor360-ClientSide/DevicePoseService.swift` - AR/2D mode switching
- `Indoor360-ClientSide/MapRouteView.swift` - Map navigation UI

### iOS - FrontEnd (Features/Services)
- `Features & Onboarding/QRScanView.swift` - QR scanner UI
- `Core Models & Protocols/QRCodeScanner.swift` - QR capture
- `Core Models & Protocols/DeepLinkRouter.swift` - QR payload parsing
- `Features & Onboarding/AR/ARNavigationView.swift` - AR stub (needs work)
- `Utilities/Network/PathClient.swift` - Route API client

---

**Ready to implement? Start with Day 1, Task 1.1!** 🚀
