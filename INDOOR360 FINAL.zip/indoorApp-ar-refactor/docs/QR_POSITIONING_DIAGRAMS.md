# QR Code Positioning System - Mermaid Diagrams

This document contains visual diagrams explaining the QR code positioning system flow using Mermaid syntax.

---

## 1. High-Level System Flow

```mermaid
flowchart TB
    subgraph User["👤 User Actions"]
        A[Open App] --> B[Navigate to QR Scanner]
        B --> C[Point Camera at QR Code]
    end

    subgraph iOS["📱 iOS Application"]
        C --> D[QRScanView Detects Code]
        D --> E[DeepLinkRouter Parses Payload]
        E --> F[QRPositionClient Resolves]
        F --> G[NavigationSession Updates Position]
        G --> H[User Picks Destination]
        H --> I[PathClient Gets Route]
        I --> J[ARStepNavigationView Displays]
    end

    subgraph Backend["🖥️ FastAPI Backend"]
        F -.->|POST /api/qr/resolve| K[QR Position Router]
        K --> L[(PostgreSQL)]
        L --> K
        K -.->|JSON Response| F

        I -.->|POST /api/route/calculate| M[Routing Service]
        M --> L
        M -.->|Route Steps| I
    end

    subgraph Navigation["🧭 AR Navigation"]
        J --> N[Display Step 1]
        N --> O{User taps Next?}
        O -->|Yes| P[Display Step N]
        P --> Q{Last Step?}
        Q -->|No| O
        Q -->|Yes| R[🎉 Destination Reached]
    end

    style A fill:#e1f5fe
    style R fill:#c8e6c9
    style L fill:#fff3e0
```

---

## 2. QR Code Scanning Sequence

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Camera as QRScanView
    participant Router as DeepLinkRouter
    participant Client as QRPositionClient
    participant API as Backend API
    participant DB as PostgreSQL

    User->>Camera: Point at QR Code
    Camera->>Camera: Detect QR Code
    Camera->>Router: Parse "anchor:reception"
    Router-->>Camera: .anchor(id: "reception")

    Camera->>Client: resolve("anchor:reception")
    Client->>API: POST /api/qr/resolve
    API->>DB: SELECT * FROM qr_anchors
    DB-->>API: Anchor data
    API-->>Client: QRPositionResponse
    Client-->>Camera: Position resolved

    Camera->>User: Show "You are at: Reception"
```

---

## 3. Complete Navigation Flow

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Scan as QRScanView
    participant Session as NavigationSession
    participant Picker as DestinationPicker
    participant Path as PathClient
    participant AR as ARStepNavigationView
    participant API as Backend

    rect rgb(230, 245, 255)
        Note over User,API: Phase 1: Position Fix
        User->>Scan: Scan QR Code
        Scan->>API: POST /api/qr/resolve
        API-->>Scan: Position + POI data
        Scan->>Session: setPosition(from: response)
    end

    rect rgb(255, 245, 230)
        Note over User,API: Phase 2: Destination Selection
        Session->>Picker: Show available destinations
        Picker->>API: GET /api/poi/list
        API-->>Picker: List of POIs
        User->>Picker: Select "Conference Room A"
        Picker->>Session: setDestination(poiId: 78)
    end

    rect rgb(230, 255, 230)
        Note over User,API: Phase 3: Route Calculation
        Session->>Path: requestRoute()
        Path->>API: POST /api/route/calculate
        API-->>Path: Route with steps
        Path->>Session: loadRoute(steps)
    end

    rect rgb(255, 230, 245)
        Note over User,API: Phase 4: AR Navigation
        Session->>AR: Start navigation
        loop Each Step
            AR->>User: Display instruction
            User->>AR: Tap "Next"
            AR->>Session: nextStep()
        end
        AR->>User: 🎉 You have arrived!
    end
```

---

## 4. System Components Diagram

```mermaid
flowchart LR
    subgraph iOS["iOS Application"]
        direction TB
        QR[QRScanView<br/>Camera Scanner]
        DL[DeepLinkRouter<br/>Payload Parser]
        QRC[QRPositionClient<br/>API Client]
        NS[NavigationSession<br/>State Manager]
        PC[PathClient<br/>Route API]
        AR[ARStepNavigationView<br/>AR Display]

        QR --> DL
        DL --> QRC
        QRC --> NS
        NS --> PC
        PC --> NS
        NS --> AR
    end

    subgraph Backend["FastAPI Backend"]
        direction TB
        QRP[/api/qr/*<br/>QR Endpoints/]
        RTE[/api/route/*<br/>Routing/]
        POI[/api/poi/*<br/>POI Search/]
    end

    subgraph Database["PostgreSQL"]
        direction TB
        QRA[(qr_anchors)]
        POIS[(pois)]
        NAV[(navigation_graph)]
    end

    QRC <-->|HTTP| QRP
    PC <-->|HTTP| RTE

    QRP <--> QRA
    QRP <--> POIS
    RTE <--> NAV
    POI <--> POIS

    style iOS fill:#e3f2fd
    style Backend fill:#fff8e1
    style Database fill:#fce4ec
```

---

## 5. QR Code Resolution Flow

```mermaid
flowchart TD
    A[QR Code Scanned] --> B{Valid Format?}
    B -->|No| C[❌ Show Error:<br/>Invalid QR Code]
    B -->|Yes| D[Extract anchor ID]

    D --> E[Call API:<br/>POST /api/qr/resolve]

    E --> F{API Response?}
    F -->|Network Error| G[❌ Show Error:<br/>Check Connection]
    F -->|404 Not Found| H[❌ Show Error:<br/>Unknown Location]
    F -->|200 OK| I[✅ Parse Response]

    I --> J[Extract Position:<br/>x, y, z, floor]
    J --> K[Extract POI ID]
    K --> L[Update NavigationSession]
    L --> M[✅ Show Success:<br/>You are at: Location Name]

    style A fill:#bbdefb
    style C fill:#ffcdd2
    style G fill:#ffcdd2
    style H fill:#ffcdd2
    style M fill:#c8e6c9
```

---

## 6. Navigation State Machine

```mermaid
stateDiagram-v2
    [*] --> Idle: App Launch

    Idle --> Scanning: User opens scanner
    Scanning --> Idle: User cancels

    Scanning --> PositionFixed: QR resolved successfully
    Scanning --> Error: QR resolution failed
    Error --> Scanning: User retries

    PositionFixed --> SelectingDestination: Show destination picker
    SelectingDestination --> PositionFixed: User cancels

    SelectingDestination --> CalculatingRoute: User selects destination
    CalculatingRoute --> SelectingDestination: Route failed
    CalculatingRoute --> Navigating: Route calculated

    Navigating --> StepComplete: User completes step
    StepComplete --> Navigating: More steps remaining
    StepComplete --> Arrived: Last step completed

    Navigating --> Idle: User cancels navigation
    Arrived --> Idle: User dismisses

    state Navigating {
        [*] --> DisplayingStep
        DisplayingStep --> WaitingForNext: Instruction shown
        WaitingForNext --> DisplayingStep: Next tapped
    }
```

---

## 7. Database Entity Relationship

```mermaid
erDiagram
    QR_ANCHORS {
        int id PK
        string qr_code UK
        int poi_id FK
        string location_name
        int floor_level
        float x
        float y
        float z
        boolean active
        timestamp created_at
        timestamp updated_at
    }

    POIS {
        int id PK
        string name
        string name_ar
        string category
        int floor
        float x
        float y
        geometry point
    }

    NAVIGATION_NODES {
        int id PK
        int floor
        float x
        float y
        string node_type
    }

    NAVIGATION_EDGES {
        int id PK
        int from_node FK
        int to_node FK
        float distance
        boolean accessible
    }

    QR_ANCHORS ||--o| POIS : "links to"
    NAVIGATION_EDGES }|--|| NAVIGATION_NODES : "from"
    NAVIGATION_EDGES }|--|| NAVIGATION_NODES : "to"
    POIS ||--o{ NAVIGATION_NODES : "nearest"
```

---

## 8. Error Handling Flow

```mermaid
flowchart TD
    subgraph Errors["Error Types"]
        E1[Network Error]
        E2[Invalid QR Format]
        E3[Anchor Not Found]
        E4[Route Not Possible]
        E5[Server Error]
    end

    subgraph Handling["Error Handling"]
        E1 --> H1[Show Retry Button<br/>Check WiFi Connection]
        E2 --> H2[Show Format Info<br/>Scan Valid QR]
        E3 --> H3[Show Unknown Location<br/>Try Different QR]
        E4 --> H4[Show Alternative Routes<br/>Check Floor Access]
        E5 --> H5[Show Contact Support<br/>Try Again Later]
    end

    subgraph Recovery["Recovery Actions"]
        H1 --> R1[Retry API Call]
        H2 --> R2[Return to Scanner]
        H3 --> R2
        H4 --> R3[Show Nearby POIs]
        H5 --> R4[Log Error & Report]
    end

    style E1 fill:#ffcdd2
    style E2 fill:#ffcdd2
    style E3 fill:#ffcdd2
    style E4 fill:#ffcdd2
    style E5 fill:#ffcdd2
    style R1 fill:#c8e6c9
    style R2 fill:#c8e6c9
    style R3 fill:#c8e6c9
    style R4 fill:#fff9c4
```

---

## 9. AR Navigation Step Display

```mermaid
flowchart LR
    subgraph Screen["AR Navigation Screen"]
        direction TB

        subgraph Header["Header"]
            DEST[🎯 Conference Room A]
            PROG[● ● ○ ○ ○]
        end

        subgraph Camera["AR Camera View"]
            CAM[📷 Live Camera Feed<br/>with AR Overlays]
        end

        subgraph Card["Instruction Card"]
            ICON[➡️]
            INST[Walk straight 20m]
            LAND[Past the elevator]
        end

        subgraph Controls["Navigation Controls"]
            PREV[◀ Previous]
            NEXT[Next ▶]
        end
    end

    style DEST fill:#2196f3,color:white
    style PROG fill:#e3f2fd
    style CAM fill:#263238,color:white
    style INST fill:#fff
    style NEXT fill:#4caf50,color:white
    style PREV fill:#9e9e9e,color:white
```

---

## 10. Multi-Floor Navigation

```mermaid
flowchart TB
    subgraph Floor1["Floor 1"]
        A1[🚪 Main Entrance] --> B1[📍 Reception]
        B1 --> C1[🛗 Elevator F1]
        B1 --> D1[🚶 Stairs F1]
    end

    subgraph Floor2["Floor 2"]
        C2[🛗 Elevator F2] --> E2[🪑 Meeting Area]
        D2[🚶 Stairs F2] --> E2
        E2 --> F2[☕ Break Room]
    end

    subgraph Floor3["Floor 3"]
        C3[🛗 Elevator F3] --> G3[🏢 Office Wing]
        D3[🚶 Stairs F3] --> G3
        G3 --> H3[🎯 Conference Room A]
    end

    C1 -.->|Elevator| C2
    C2 -.->|Elevator| C3
    D1 -.->|Stairs| D2
    D2 -.->|Stairs| D3

    style A1 fill:#a5d6a7
    style H3 fill:#ef5350,color:white
    style C1 fill:#64b5f6
    style C2 fill:#64b5f6
    style C3 fill:#64b5f6
    style D1 fill:#ffb74d
    style D2 fill:#ffb74d
    style D3 fill:#ffb74d
```

---

## How to View These Diagrams

These Mermaid diagrams can be viewed in:

1. **GitHub** - Renders Mermaid automatically in markdown files
2. **VS Code** - Install "Markdown Preview Mermaid Support" extension
3. **Mermaid Live Editor** - https://mermaid.live/
4. **Notion** - Supports Mermaid code blocks
5. **GitLab** - Native Mermaid support

To use in your documentation, simply copy the code blocks and paste into any Mermaid-compatible viewer.
