# QR Code Positioning System - Detailed Flow Documentation

## Table of Contents
1. [Overview](#overview)
2. [System Architecture](#system-architecture)
3. [Component Breakdown](#component-breakdown)
4. [Detailed User Flow](#detailed-user-flow)
5. [API Reference](#api-reference)
6. [Data Models](#data-models)
7. [Error Handling](#error-handling)
8. [Configuration](#configuration)

---

## Overview

The QR Code Positioning System provides precise indoor positioning by allowing users to scan QR codes placed at known locations within a building. When a user scans a QR code, the system:

1. **Identifies their exact position** using pre-registered anchor coordinates
2. **Links to a Point of Interest (POI)** for context-aware navigation
3. **Enables step-by-step AR navigation** to any destination within the building

### Key Benefits
- **No GPS Required**: Works entirely indoors where GPS signals are unavailable
- **High Accuracy**: Position accuracy depends on QR code placement precision
- **Low Infrastructure Cost**: Only requires printed QR codes at strategic locations
- **Instant Positioning**: Immediate location fix upon scanning

---

## System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         iOS Application                              │
├─────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │  QRScanView  │  │ Navigation   │  │  ARStepNavigationView    │  │
│  │  (Camera)    │──│   Session    │──│  (AR Guidance)           │  │
│  └──────────────┘  └──────────────┘  └──────────────────────────┘  │
│         │                │                        │                 │
│         ▼                ▼                        ▼                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │DeepLinkRouter│  │QRPosition    │  │     PathClient           │  │
│  │              │  │   Client     │  │  (Route API)             │  │
│  └──────────────┘  └──────────────┘  └──────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼ HTTP/REST
┌─────────────────────────────────────────────────────────────────────┐
│                       FastAPI Backend                                │
├─────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │ /api/qr/     │  │ /api/route/  │  │    /api/poi/             │  │
│  │   resolve    │  │   calculate  │  │    search                │  │
│  └──────────────┘  └──────────────┘  └──────────────────────────┘  │
│         │                │                        │                 │
│         ▼                ▼                        ▼                 │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    PostgreSQL Database                       │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │   │
│  │  │ qr_anchors  │  │    pois     │  │   navigation_graph  │  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────┘  │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Component Breakdown

### iOS Components

| Component | File | Purpose |
|-----------|------|---------|
| `QRScanView` | `QRScanView.swift` | Camera view for scanning QR codes |
| `DeepLinkRouter` | `DeepLinkRouter.swift` | Parses QR payload strings (e.g., `anchor:reception`) |
| `QRPositionClient` | `QRPositionClient.swift` | API client for QR resolution |
| `NavigationSession` | `NavigationSession.swift` | State management for navigation flow |
| `ARStepNavigationView` | `ARStepNavigationView.swift` | AR camera with step-by-step UI |
| `QRNavigationFlowView` | `QRNavigationFlowView.swift` | Complete QR → destination → AR flow |
| `PathClient` | `PathClient.swift` | API client for route calculation |

### Backend Components

| Component | File | Purpose |
|-----------|------|---------|
| QR Position Router | `api/qr_position.py` | Handles QR resolution endpoints |
| Route Service | `services/routing.py` | Calculates navigation paths |
| POI Service | `api/poi.py` | Manages Points of Interest |

### Database Tables

| Table | Purpose |
|-------|---------|
| `qr_anchors` | Stores QR code positions and metadata |
| `pois` | Points of Interest with coordinates |
| `navigation_nodes` | Graph nodes for pathfinding |
| `navigation_edges` | Graph edges connecting nodes |

---

## Detailed User Flow

### Phase 1: QR Code Scanning

1. **User opens the app** and navigates to the QR scan feature
2. **Camera activates** via `QRScanView` using AVFoundation
3. **User points camera** at a QR code placed in the building
4. **QR code detected** - the system reads the payload string

### Phase 2: Position Resolution

5. **Payload parsed** by `DeepLinkRouter`
   - Format: `anchor:<location-id>` (e.g., `anchor:reception`)
   - Router returns `.anchor(id: "reception")`

6. **API call** to resolve the QR code:
   ```
   POST /api/qr/resolve
   Body: { "qr_code": "anchor:reception" }
   ```

7. **Backend response** with anchor details:
   ```json
   {
     "qr_code": "anchor:reception",
     "poi_id": 42,
     "location_name": "Main Reception",
     "floor_level": 1,
     "x": 120.5,
     "y": 85.3,
     "z": 0.0
   }
   ```

8. **Position set** in `NavigationSession`:
   - Current position stored as (x, y, z, floor)
   - Location name displayed to user

### Phase 3: Destination Selection

9. **User sees destination picker** with available POIs
10. **POI list loaded** from `/api/poi/list`
11. **User selects destination** (e.g., "Conference Room A")
12. **Destination set** in `NavigationSession`

### Phase 4: Route Calculation

13. **Route requested** from backend:
    ```
    POST /api/route/calculate
    Body: {
      "from_poi_id": 42,
      "to_poi_id": 78,
      "floor": 1
    }
    ```

14. **Backend calculates** shortest path using navigation graph
15. **Route returned** as sequence of steps:
    ```json
    {
      "steps": [
        {
          "instruction": "Walk straight 20 meters",
          "distance": 20.0,
          "direction": "straight",
          "landmark": "Past the elevator"
        },
        {
          "instruction": "Turn right",
          "distance": 0,
          "direction": "right",
          "landmark": "At the water fountain"
        },
        {
          "instruction": "Continue 15 meters",
          "distance": 15.0,
          "direction": "straight",
          "landmark": "Conference Room A on left"
        }
      ],
      "total_distance": 35.0,
      "estimated_time": 45
    }
    ```

### Phase 5: AR Navigation

16. **AR view launches** with `ARStepNavigationView`
17. **First step displayed** with instruction and landmark
18. **User follows instructions** - can see through camera
19. **User taps "Next"** to advance to next step
20. **Progress dots update** showing current position in route
21. **Destination reached** - completion message shown

---

## API Reference

### QR Resolution Endpoints

#### POST /api/qr/resolve
Resolves a QR code to its anchor position.

**Request:**
```json
{
  "qr_code": "anchor:reception"
}
```

**Response (200 OK):**
```json
{
  "qr_code": "anchor:reception",
  "poi_id": 42,
  "location_name": "Main Reception",
  "floor_level": 1,
  "x": 120.5,
  "y": 85.3,
  "z": 0.0,
  "active": true
}
```

**Response (404 Not Found):**
```json
{
  "detail": "QR anchor not found"
}
```

#### GET /api/qr/list
Lists all registered QR anchors.

**Response:**
```json
{
  "anchors": [
    {
      "qr_code": "anchor:reception",
      "location_name": "Main Reception",
      "floor_level": 1
    },
    {
      "qr_code": "anchor:elevator-f1",
      "location_name": "Elevator - Floor 1",
      "floor_level": 1
    }
  ]
}
```

#### GET /api/qr/anchor/{qr_code}
Gets a specific anchor by its QR code.

**Response:**
```json
{
  "qr_code": "anchor:reception",
  "poi_id": 42,
  "location_name": "Main Reception",
  "floor_level": 1,
  "x": 120.5,
  "y": 85.3,
  "z": 0.0
}
```

---

## Data Models

### QR Anchor (Database)

```sql
CREATE TABLE qr_anchors (
    id SERIAL PRIMARY KEY,
    qr_code VARCHAR(100) UNIQUE NOT NULL,  -- e.g., "anchor:reception"
    poi_id INTEGER REFERENCES pois(id),     -- Optional link to POI
    location_name VARCHAR(255) NOT NULL,    -- Human-readable name
    floor_level INTEGER NOT NULL,           -- Floor number
    x DOUBLE PRECISION NOT NULL,            -- X coordinate (meters)
    y DOUBLE PRECISION NOT NULL,            -- Y coordinate (meters)
    z DOUBLE PRECISION DEFAULT 0.0,         -- Z coordinate (height)
    active BOOLEAN DEFAULT TRUE,            -- Is anchor active?
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

### QRPositionResponse (iOS)

```swift
struct QRPositionResponse: Codable {
    let qrCode: String
    let poiId: Int?
    let locationName: String
    let floorLevel: Int
    let x: Double
    let y: Double
    let z: Double
}
```

### NavigationStep (iOS)

```swift
struct NavigationStep: Identifiable {
    let id: Int
    let instruction: String
    let distance: Double
    let direction: String
    let landmark: String?
}
```

---

## Error Handling

### iOS Error States

| Error | Cause | User Message |
|-------|-------|--------------|
| `invalidQRCode` | Scanned QR not in `anchor:` format | "Invalid QR code format" |
| `anchorNotFound` | QR code not registered in backend | "Location not recognized" |
| `networkError` | No connection to backend | "Check your network connection" |
| `serverError` | Backend returned 5xx | "Server error. Try again." |

### Backend Error Responses

```python
# 400 Bad Request
{"detail": "Invalid QR code format"}

# 404 Not Found
{"detail": "QR anchor not found"}

# 500 Internal Server Error
{"detail": "Database connection failed"}
```

---

## Configuration

### iOS Configuration

In `QRPositionClient.swift`:
```swift
// For physical device testing, use Mac's LAN IP
private let baseURL = "http://192.168.1.180:8000"

// For simulator testing
// private let baseURL = "http://127.0.0.1:8000"
```

### Backend Configuration

In `backend/app/config.py`:
```python
DATABASE_URL = "postgresql://user:pass@localhost/indoor360"
API_HOST = "0.0.0.0"  # Listen on all interfaces
API_PORT = 8000
```

### QR Code Format

QR codes must contain text in the format:
```
anchor:<location-id>
```

Examples:
- `anchor:main-entrance`
- `anchor:reception`
- `anchor:elevator-f1`
- `anchor:stairs-f2`
- `anchor:cafe-entrance`

---

## Demo QR Anchors

The following anchors are pre-seeded in the database:

| QR Code | Location | Floor | Coordinates |
|---------|----------|-------|-------------|
| `anchor:main-entrance` | Main Entrance | 1 | (0, 0, 0) |
| `anchor:reception` | Reception Desk | 1 | (10, 5, 0) |
| `anchor:elevator-f1` | Elevator - Floor 1 | 1 | (20, 10, 0) |
| `anchor:stairs-f1` | Staircase - Floor 1 | 1 | (25, 10, 0) |
| `anchor:cafe-entrance` | Café Entrance | 1 | (15, 20, 0) |
| `anchor:elevator-f2` | Elevator - Floor 2 | 2 | (20, 10, 0) |
| `anchor:stairs-f2` | Staircase - Floor 2 | 2 | (25, 10, 0) |
| `anchor:meeting-area` | Meeting Area | 2 | (30, 15, 0) |
| `anchor:elevator-f3` | Elevator - Floor 3 | 3 | (20, 10, 0) |
| `anchor:office-wing` | Office Wing | 3 | (40, 20, 0) |

---

## Next Steps

1. **Day 2**: Implement IMU dead-reckoning for position tracking between scans
2. **Day 3**: Add floor transitions and multi-floor navigation
3. **Day 4**: Implement AR waypoint overlays with CoreLocation heading
4. **Day 5**: Integration testing and refinement
