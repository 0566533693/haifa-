Core navigation & graph

AStar.swift
Implements the A* pathfinding algorithm. Given start/goal nodes and a graph, it returns the optimal node/edge sequence. Likely supports heuristic (euclidean/Manhattan) and costs (distance, stairs, accessibility, etc).

GraphBuilder.swift
Builds the indoor navigation graph from IMDF data: creates nodes (doorways, transitions, unit centroids) and edges (walkable connections, level transitions), attaches weights/metadata, and indexes them for fast lookup.

GraphTypes.swift
Type definitions for the graph layer—Node, Edge, Level, Venue, Coordinate, plus enums (e.g., EdgeType.walk, EdgeType.stairs, Constraint.accessible). Also might include helpers like distance(::).

PathPostProcessor.swift
Cleans up raw paths from A*: snapping to unit centroids, removing micro-zigzags, merging collinear segments, inserting turn-by-turn instructions, and possibly splitting by floor to support “go to stair/elevator” steps.

IMDF (Indoor Mapping Data Format)

IMDFLoader.swift
Loads and parses IMDF bundles (GeoJSON). Handles venues, levels, units, openings, amenities, transitions, addresses. Validates geometry, transforms coordinate systems, and yields IMDF model structs.

IMDFModels.swift
Codable models mirroring the IMDF spec (Venue, Level, Unit, Opening, Anchor, etc.). Keeps IMDF parsing separate from app-specific graph types.

Device pose, AR, and location

DevicePoseService.swift
Fuses ARKit world tracking + CoreMotion (and possibly CoreLocation) to produce a 6-DoF device pose in the app’s coordinate frame. Exposes current transform, heading, and pose quality.

ARPrecisionService.swift
Calibrates & maintains alignment between the AR world and the map/IMDF graph. Handles scale/origin offsets, drift checks, re-anchors, and placement helpers (e.g., “place AR arrow 3.2 m ahead on edge #123”).

LocationService.swift
Wraps CoreLocation (and any indoor positioning provider) to output the user’s lat/long (or indoor XY), floor/level, and heading updates with permissions & accuracy filtering.

Map & UI rendering

MapKitMapViewRepresentable.swift
A SwiftUI <-> UIKit bridge (via UIViewRepresentable) that embeds MKMapView so SwiftUI views can display vector tiles, overlays, annotations, and handle gestures.

MapRouteView.swift
SwiftUI view responsible for drawing the current route on the map and presenting step list / distance remaining. Consumes the path from AStar/PathPostProcessor, adds overlays/annotations via the representable.

RouteDotsOverlay.swift
Custom MKOverlay/MKOverlayRenderer (or similar) for dotted/segmented route styling, turn arrows, segment colors (e.g., stairs vs elevator), and maybe per-floor overlays.

VenuePickerView.swift
SwiftUI picker to choose a venue (or building/floor). Likely lists IMDF venues with search and loads a selection through IMDFLoader → GraphBuilder.

App shell & resources

IndoorNavApp.swift
App entry point (@main) for SwiftUI: constructs app state (services, dependency injection), sets up initial scene, and routes to the venue picker or map.

Launchscreen.storyboard
Static launch screen shown while the app initializes (matching brand colors/logo).

Info (Properties file…)/Info.plist
App configuration: permissions (Location, Motion, Camera), bundle IDs, ARKit usage descriptions, supported orientations, etc.

How these pieces typically work together

IMDFLoader → IMDFModels to parse the indoor dataset.

GraphBuilder + GraphTypes produce a navigable graph.

AStar finds a route between two nodes.

PathPostProcessor smooths the route and yields steps/turns.

LocationService + DevicePoseService track user position/heading.

ARPrecisionService keeps AR world aligned so arrows/markers appear exactly on the path.

MapKitMapViewRepresentable + MapRouteView + RouteDotsOverlay render the map and route.

VenuePickerView and IndoorNavApp tie the UI flow together.

Launchscreen.storyboard and Info.plist cover boot + configuration.
