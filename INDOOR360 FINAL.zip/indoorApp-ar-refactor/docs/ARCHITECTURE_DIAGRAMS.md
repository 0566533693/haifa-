# Indoor360 - Architecture Diagrams

This document provides comprehensive Mermaid diagrams illustrating the Indoor360 system architecture, data flows, and component interactions.

---

## 1. High-Level System Architecture

```mermaid
graph TB
    subgraph "iOS Client"
        UI[SwiftUI Views]
        VM[ViewModels]
        Services[Services Layer]
        AR[ARKit Components]
        Map[MapKit Components]
        IMDF_Local[Local IMDF Store]
    end

    subgraph "Backend API - FastAPI"
        Gateway[API Gateway]
        Auth_API[Auth Service]
        SavedPlaces_API[Saved Places Service]
        NLP_API[NLP Resolver]
        POI_API[POI Service]
        Route_API[Route Service]
        Position_API[Position Service]
        IMDF_API[IMDF Service]
        Debug_API[Debug/Admin]
    end

    subgraph "Data Layer"
        DB[(PostgreSQL + PostGIS)]
        IMDF_Files[IMDF Packages]
        Cache[Redis Cache - Future]
    end

    subgraph "External Services - Future"
        Auth[OAuth Providers]
        BLE[BLE Beacons]
        WiFi[WiFi Positioning]
        Analytics[Analytics Service]
    end

    UI --> VM
    VM --> Services
    Services --> AR
    Services --> Map
    Services --> IMDF_Local

    Services -->|HTTP/REST| Gateway
    Gateway --> Auth_API
    Gateway --> SavedPlaces_API
    Gateway --> NLP_API
    Gateway --> POI_API
    Gateway --> Route_API
    Gateway --> Position_API
    Gateway --> IMDF_API
    Gateway --> Debug_API

    Auth_API --> DB
    SavedPlaces_API --> DB
    NLP_API --> DB
    POI_API --> DB
    Route_API --> DB
    Position_API --> DB
    IMDF_API --> IMDF_Files
    Debug_API --> DB

    Services -.->|Future| Auth
    Services -.->|Future| BLE
    Services -.->|Future| WiFi
    Gateway -.->|Future| Analytics
    Gateway -.->|Future| Cache

    style Services fill:#4CAF50
    style Gateway fill:#2196F3
    style DB fill:#FF9800
    style AR fill:#9C27B0
    style Map fill:#9C27B0
```

---

## 2. iOS Application Architecture (MVVM + Services)

```mermaid
graph TB
    subgraph "Presentation Layer"
        VenuePicker[VenuePickerView]
        RouteStart[RouteStartView]
        SearchView[SearchView]
        MapView[MapRouteView]
        ARView[ARNavigationView]
        Auth[AuthView]
        Profile[ProfileView]
        Settings[SettingsView]
        Feedback[ReportFeedbackView]
    end

    subgraph "ViewModel Layer"
        SearchVM[SearchViewModel]
        RouteVM[RouteViewModel]
        MapVM[MapViewModel]
        ARVM[ARViewModel]
    end

    subgraph "Service Layer"
        AuthService[AuthService]
        SavedPlacesService[SavedPlacesService]
        NLPClient[NLPClient]
        PathClient[PathClient]
        POIService[POIService]
        VenueService[VenueService]
        AlignmentService[AlignmentService]
        MotionService[MotionService]
        PermissionService[PermissionService]
        KeychainHelper[KeychainHelper]
    end

    subgraph "Core Components"
        IMDFLoader[IMDFLoader]
        GraphBuilder[GraphBuilder]
        AStar[A* Algorithm]
        PathProcessor[PathPostProcessor]
        LocationService[LocationService]
        DevicePose[DevicePoseService]
        ARPrecision[ARPrecisionService]
    end

    subgraph "State Management"
        AppState[AppState - @EnvironmentObject]
    end

    VenuePicker --> VenueService
    SearchView --> SearchVM
    RouteStart --> SearchVM
    MapView --> MapVM
    ARView --> ARVM

    SearchVM --> NLPClient
    SearchVM --> PathClient
    RouteVM --> PathClient
    MapVM --> POIService
    ARVM --> AlignmentService
    ARVM --> MotionService

    VenueService --> IMDFLoader
    IMDFLoader --> GraphBuilder
    GraphBuilder --> AStar
    PathClient --> PathProcessor

    AlignmentService --> ARPrecision
    AlignmentService --> DevicePose
    DevicePose --> LocationService

    AppState -.->|Injected| SearchVM
    AppState -.->|Injected| MapVM
    AppState -.->|Injected| ARVM

    Auth --> AuthService
    Settings --> PermissionService
    Feedback --> PathClient

    style NLPClient fill:#4CAF50
    style PathClient fill:#4CAF50
    style IMDFLoader fill:#FF9800
    style GraphBuilder fill:#FF9800
    style AStar fill:#FF9800
    style AppState fill:#E91E63
```

---

## 3. Backend API Architecture

```mermaid
graph LR
    subgraph "FastAPI Application"
        Main[app/main.py]
        Config[app/config.py]

        subgraph "API Routers"
            NLP_Router[api/nlp.py]
            POI_Router[api/poi.py]
            Route_Router[api/route.py]
            Position_Router[api/position.py]
            IMDF_Router[api/imdf.py]
            Debug_Router[api/debug.py]
            Alias_Router[api/debug_aliases.py]
        end

        subgraph "Business Logic"
            NLP_Resolver[NLP/nlp_db_resolver.py]
            NLP_Preproc[NLP/nlp_preproc_syn.py]
            Routing_Service[services/routing.py]
            Position_Service[services/position_service.py]
        end

        subgraph "Data Access"
            DB_Deps[app/deps.py]
            Schema[db/schema.sql]
        end
    end

    Main --> Config
    Main --> NLP_Router
    Main --> POI_Router
    Main --> Route_Router
    Main --> Position_Router
    Main --> IMDF_Router
    Main --> Debug_Router
    Main --> Alias_Router

    NLP_Router --> NLP_Resolver
    NLP_Resolver --> NLP_Preproc
    Route_Router --> Routing_Service
    Position_Router --> Position_Service

    NLP_Router --> DB_Deps
    POI_Router --> DB_Deps
    Route_Router --> DB_Deps
    Position_Router --> DB_Deps

    DB_Deps --> Schema

    style Main fill:#2196F3
    style NLP_Resolver fill:#4CAF50
    style NLP_Preproc fill:#4CAF50
    style DB_Deps fill:#FF9800
```

---

## 4. NLP Resolution Flow

```mermaid
sequenceDiagram
    participant User
    participant iOS as iOS SearchView
    participant NLPClient
    participant Backend as /api/nlp/resolve
    participant Detector as Language Detector
    participant Preprocessor
    participant DB as PostgreSQL
    participant Resolver as NLP Resolver

    User->>iOS: Types "meeting room 3"
    iOS->>NLPClient: resolve(query: "meeting room 3")
    NLPClient->>Backend: POST /api/nlp/resolve

    Backend->>Detector: detect_lang("meeting room 3")
    Detector-->>Backend: "en"

    Backend->>Preprocessor: norm_en("meeting room 3")
    Preprocessor->>Preprocessor: lowercase
    Preprocessor->>Preprocessor: expand numbers
    Preprocessor->>Preprocessor: stemming
    Preprocessor-->>Backend: "meeting room 3"

    Backend->>Resolver: resolve_poi_from_text("meeting room 3", lang="en")

    Resolver->>DB: SELECT FROM poi_synonyms WHERE synonym = 'meeting room 3'
    alt Synonym Match Found
        DB-->>Resolver: [(731, "Meeting Room 3", "room", 3)]
        Resolver-->>Backend: Success Result
    else No Synonym Match
        Resolver->>DB: SELECT FROM poi_names WHERE name LIKE '%meeting room 3%'
        DB-->>Resolver: Fuzzy matches
        Resolver-->>Backend: Partial matches
    end

    Backend-->>NLPClient: [{"poiId": 731, "poiName": "Meeting Room 3", ...}]
    NLPClient-->>iOS: NLPResolveRes
    iOS-->>User: Display "Meeting Room 3" in results
```

---

## 5. Route Computation & AR Navigation Flow

```mermaid
sequenceDiagram
    participant User
    participant iOS as iOS App
    participant PathClient
    participant Backend as /api/path/route
    participant DB as PostgreSQL
    participant GraphBuilder
    participant AStar as A* Algorithm
    participant ARView
    participant ARKit

    User->>iOS: Select destination POI 731
    iOS->>PathClient: route(from: 693, to: 731)
    PathClient->>Backend: POST /api/path/route {fromPoiId: 693, toPoiId: 731}

    Backend->>DB: SELECT x,y,z FROM ar_pois_api WHERE poi_id=693
    DB-->>Backend: (0.5, 1.2, 0.0)

    Backend->>DB: SELECT x,y,z FROM ar_pois_api WHERE poi_id=731
    DB-->>Backend: (12.4, 8.2, 0.0)

    Note over Backend: Phase 1: Straight-line routing<br/>Phase 2: A* with nav graph

    Backend->>Backend: Generate 3-point path
    Backend-->>PathClient: {path: [{x,y,z}, ...], length_m: 15.32}

    PathClient-->>iOS: RouteResponseDTO

    iOS->>GraphBuilder: Convert to local graph nodes
    GraphBuilder->>AStar: findPath(start: "693", goal: "731")

    alt A* Available (Phase 2)
        AStar-->>GraphBuilder: Optimal node path
        GraphBuilder->>iOS: Smoothed waypoints
    else Straight-line (Phase 1)
        iOS->>iOS: Use backend path as-is
    end

    iOS->>ARView: Display route
    ARView->>ARKit: Start AR session
    ARKit-->>ARView: Camera transform

    ARView->>ARView: Place AR arrows at waypoints
    ARView-->>User: Show AR navigation overlay

    loop Every frame (60 FPS)
        ARKit->>ARView: Update camera position
        ARView->>ARView: Update arrow positions
        ARView-->>User: Real-time AR guidance
    end
```

---

## 6. Authentication & Saved Places Flow

```mermaid
sequenceDiagram
    participant User
    participant iOS as iOS App
    participant AuthService
    participant Backend as /api/auth
    participant DB as PostgreSQL
    participant Keychain

    Note over User,DB: User Registration Flow
    User->>iOS: Enter name, email, password
    iOS->>AuthService: signup(name, email, password)
    AuthService->>Backend: POST /api/auth/signup

    Backend->>DB: Check if email exists
    alt Email Already Exists
        DB-->>Backend: Email found
        Backend-->>AuthService: 400 Bad Request
        AuthService-->>iOS: Error: Email already registered
        iOS-->>User: Show error message
    else Email Available
        DB-->>Backend: Email not found
        Backend->>Backend: Hash password with bcrypt
        Backend->>DB: INSERT INTO Users
        DB-->>Backend: User created (user_id, name, email)
        Backend->>Backend: Generate JWT token (7-day expiry)
        Backend->>DB: INSERT INTO Sessions
        Backend-->>AuthService: {access_token, user}
        AuthService->>Keychain: Store JWT token securely
        AuthService-->>iOS: Success with user data
        iOS-->>User: Navigate to home screen
    end

    Note over User,DB: Login Flow
    User->>iOS: Enter email, password
    iOS->>AuthService: login(email, password)
    AuthService->>Backend: POST /api/auth/login

    Backend->>DB: SELECT user WHERE email
    alt User Not Found
        DB-->>Backend: No user
        Backend-->>AuthService: 401 Unauthorized
        AuthService-->>iOS: Invalid credentials
        iOS-->>User: Show error
    else User Found
        DB-->>Backend: User data with password_hash
        Backend->>Backend: Verify password with bcrypt
        alt Password Invalid
            Backend-->>AuthService: 401 Unauthorized
            AuthService-->>iOS: Invalid credentials
            iOS-->>User: Show error
        else Password Valid
            Backend->>Backend: Generate JWT token
            Backend->>DB: INSERT INTO Sessions
            Backend-->>AuthService: {access_token, user}
            AuthService->>Keychain: Store JWT token
            AuthService-->>iOS: Success with user data
            iOS-->>User: Navigate to home screen
        end
    end

    Note over User,DB: Saved Places Flow
    User->>iOS: View Profile
    iOS->>AuthService: Get stored JWT
    AuthService->>Keychain: Retrieve token
    Keychain-->>AuthService: JWT token
    AuthService-->>iOS: Token available

    iOS->>SavedPlacesService: getSavedPlaces()
    SavedPlacesService->>Backend: GET /api/saved-places (Bearer token)
    Backend->>Backend: Validate JWT token
    Backend->>DB: SELECT saved_places WHERE user_id
    DB-->>Backend: User's saved places
    Backend-->>SavedPlacesService: [{saved_place_id, title, ...}]
    SavedPlacesService-->>iOS: Parsed SavedPlace objects
    iOS-->>User: Display saved places list

    User->>iOS: Add new saved place
    iOS->>SavedPlacesService: createSavedPlace(title, category, notes)
    SavedPlacesService->>Backend: POST /api/saved-places (Bearer token)
    Backend->>Backend: Validate JWT token
    Backend->>DB: Check category exists
    Backend->>DB: INSERT INTO saved_places
    DB-->>Backend: New saved place
    Backend-->>SavedPlacesService: Saved place with ID
    SavedPlacesService-->>iOS: Success
    iOS-->>User: Show confirmation & refresh list
```

---

## 7. Database Schema Relationships

```mermaid
erDiagram
    Users ||--o{ Sessions : has
    Users ||--o{ saved_places : owns
    Users ||--o{ Navigation_History : records
    Users ||--o{ Error_Reports : submits

    saved_places }o--|| place_categories : categorized_as
    saved_places }o--o| pois : references

    Buildings ||--o{ Floors : contains
    Floors ||--o{ pois : contains
    Floors ||--o{ Blueprint_Files : has

    pois ||--o{ poi_names : has
    pois ||--o{ poi_synonyms : has
    pois ||--o{ Routes : "start/end"

    nav_nodes ||--o{ nav_edges : connects
    pois }o--|| nav_nodes : "nearest_node"

    imdf_packages ||--o{ imdf_files : contains

    Users {
        int user_id PK
        string name
        string email UK
        string password_hash
        string auth_provider
        string role
        string phone
        date date_of_birth
        timestamp created_at
        timestamp updated_at
    }

    Sessions {
        int session_id PK
        int user_id FK
        string jwt_token
        string device_info
        timestamp started_at
        timestamp expires_at
    }

    saved_places {
        int saved_place_id PK
        int user_id FK
        int poi_id FK
        string title
        int category_id FK
        string notes
        timestamp created_at
        timestamp updated_at
    }

    place_categories {
        int category_id PK
        string name UK
        string icon
        timestamp created_at
    }

    pois {
        int poi_id PK
        string name
        string category
        int floor
        float x
        float y
        float z
        geometry wgs84_geom
        string imdf_id UK
    }

    poi_names {
        int id PK
        int poi_id FK
        string name
        string lang_code
    }

    poi_synonyms {
        int id PK
        int poi_id FK
        string lang
        string synonym
    }

    nav_nodes {
        int node_id PK
        int floor
        float x
        float y
        float z
    }

    nav_edges {
        int edge_id PK
        int a FK
        int b FK
        float cost
    }

    Routes {
        int route_id PK
        int start_poi FK
        int end_poi FK
        geometry path_geometry
        float distance_meters
    }
```

---

## 7. IMDF Data Processing Pipeline

```mermaid
graph TB
    subgraph "IMDF Package"
        ZIP[venue_latest_imdf.zip]
        Manifest[manifest.json]
        Venue[venue.geojson]
        Level[level.geojson]
        Unit[unit.geojson]
        Opening[opening.geojson]
        Anchor[anchor.geojson]
        Amenity[amenity.geojson]
    end

    subgraph "Backend Processing"
        Script[scripts/ingest_imdf_units_to_pois.py]
        Parser[GeoJSON Parser]
        Transformer[Coordinate Transformer]
        Validator[Schema Validator]
    end

    subgraph "Database"
        POI_Table[(pois table)]
        POI_Names[(poi_names table)]
        IMDF_Raw[(imdf_files JSONB)]
    end

    subgraph "iOS Processing"
        IMDFLoader[IMDFLoader.swift]
        IMDFModels[IMDFModels.swift]
        GraphBuilder[GraphBuilder.swift]
        NavGraph[IndoorGraph]
    end

    ZIP --> Script
    Unit --> Script
    Level --> Script
    Opening --> Script

    Script --> Parser
    Parser --> Transformer
    Transformer --> Validator
    Validator --> POI_Table
    Validator --> POI_Names
    Validator --> IMDF_Raw

    ZIP --> IMDFLoader
    Manifest --> IMDFLoader
    Venue --> IMDFLoader
    Level --> IMDFLoader
    Unit --> IMDFLoader
    Opening --> IMDFLoader
    Anchor --> IMDFLoader

    IMDFLoader --> IMDFModels
    IMDFModels --> GraphBuilder
    GraphBuilder --> NavGraph

    style Script fill:#4CAF50
    style IMDFLoader fill:#2196F3
    style GraphBuilder fill:#FF9800
    style NavGraph fill:#9C27B0
```

---

## 8. Real-time Position Tracking (WebSocket)

```mermaid
sequenceDiagram
    participant iOS as iOS App
    participant WS as WebSocket /api/position/ws
    participant Position as Position Service
    participant DB as PostgreSQL
    participant BLE as BLE Beacons (Future)
    participant WiFi as WiFi Positioning (Future)

    iOS->>WS: Connect to WebSocket
    WS-->>iOS: Connection accepted

    Note over Position: Current: Simulated position<br/>Future: Real positioning

    loop Every 1 second
        Position->>Position: Calculate position

        alt Phase 1: Simulated
            Position->>Position: x += 0.15 * cos(yaw)
            Position->>Position: y += 0.15 * sin(yaw)
        else Phase 2: Real Positioning
            Position->>BLE: Request trilateration
            BLE-->>Position: (x, y, z)
            Position->>WiFi: Request WiFi RSSI
            WiFi-->>Position: Fingerprint match
            Position->>Position: Sensor fusion
        end

        Position->>DB: Get target POI if set
        DB-->>Position: Target (x, y, z)

        Position->>Position: Calculate yaw toward target

        WS->>iOS: {"x": 0.5, "y": 1.2, "z": 0.0, "yaw": 1.23, "floor": "3"}
        iOS->>iOS: Update user position marker
        iOS->>iOS: Recalculate if off-route
    end

    iOS->>WS: Disconnect
```

---

## 9. Component Integration Status

```mermaid
graph TB
    subgraph "✅ Fully Implemented"
        Auth[Authentication<br/>JWT + bcrypt]
        SavedPlaces[Saved Places<br/>CRUD API]
        Profile[User Profile<br/>iOS + Backend]
        NLP[NLP Resolution<br/>English + Arabic]
        POI_List[POI Listing]
        IMDF_Parse[IMDF Parsing]
        Straight_Route[Straight-line Routing]
        DB_Schema[Database Schema]
        SwiftUI_Views[SwiftUI Views]
        Keychain[Keychain Storage]
    end

    subgraph "🟡 Partially Implemented"
        AR_Basic[AR Session Management]
        Map_Display[MapKit Display]
        Position_Sim[Simulated Positioning]
        Graph_Build[Graph Building]
        AStar_Impl[A* Implementation]
        Backend_Route[Backend Routing]
    end

    subgraph "❌ Not Yet Implemented"
        OAuth[OAuth Providers<br/>Google/Apple]
        Biometric[Biometric Auth<br/>Face ID/Touch ID]
        BLE_Position[BLE Positioning]
        WiFi_Position[WiFi Positioning]
        Multi_Floor[Multi-floor Navigation]
        Voice_Guide[Voice Guidance]
        Offline_Mode[Offline Mode]
        Rate_Limit[API Rate Limiting]
        Analytics[User Analytics]
        Push_Notif[Push Notifications]
    end

    subgraph "🔄 Frontend Integration Needed"
        AR_Arrows[AR Arrow Placement]
        Real_Position[Real Position Tracking]
        Graph_Route[Graph-based Routing]
        WebSocket[WebSocket Connection]
        Reroute[Dynamic Rerouting]
    end

    style Auth fill:#4CAF50
    style SavedPlaces fill:#4CAF50
    style Profile fill:#4CAF50
    style NLP fill:#4CAF50
    style POI_List fill:#4CAF50
    style IMDF_Parse fill:#4CAF50
    style Straight_Route fill:#4CAF50
    style Keychain fill:#4CAF50

    style AR_Basic fill:#FFC107
    style Map_Display fill:#FFC107
    style Position_Sim fill:#FFC107

    style OAuth fill:#F44336
    style Biometric fill:#F44336
    style BLE_Position fill:#F44336
    style WiFi_Position fill:#F44336

    style AR_Arrows fill:#2196F3
    style Real_Position fill:#2196F3
    style Graph_Route fill:#2196F3
```

---

## 10. Deployment Architecture (Current & Future)

```mermaid
graph TB
    subgraph "Current Development Setup"
        Dev_Mac[Developer MacBook]
        Local_PG[PostgreSQL Local<br/>localhost:5432]
        Local_API[FastAPI Dev Server<br/>localhost:8000]
        Xcode[Xcode + iOS Simulator]
        Physical_Device[Physical iPhone<br/>for AR Testing]
    end

    subgraph "Proposed Production Setup"
        subgraph "Cloud Infrastructure"
            LB[Load Balancer<br/>AWS ALB / Nginx]
            API1[FastAPI Instance 1]
            API2[FastAPI Instance 2]
            API3[FastAPI Instance 3]

            RDS[(AWS RDS PostgreSQL<br/>+ PostGIS Extension)]
            S3[AWS S3<br/>IMDF Packages]
            Redis_Cache[(Redis Cache<br/>Session + Query Results)]
        end

        subgraph "CDN & Static Assets"
            CloudFront[AWS CloudFront<br/>Static Assets]
        end

        subgraph "Monitoring & Logging"
            CloudWatch[CloudWatch Logs]
            Sentry[Sentry Error Tracking]
            DataDog[DataDog APM]
        end

        subgraph "Client Devices"
            iPhone[iPhone App<br/>App Store]
            iPad[iPad Version]
        end
    end

    Dev_Mac --> Local_API
    Local_API --> Local_PG
    Xcode --> Local_API
    Physical_Device --> Local_API

    iPhone --> LB
    iPad --> LB
    LB --> API1
    LB --> API2
    LB --> API3

    API1 --> RDS
    API2 --> RDS
    API3 --> RDS

    API1 --> S3
    API2 --> Redis_Cache
    API3 --> CloudWatch

    iPhone --> CloudFront

    API1 --> Sentry
    API2 --> DataDog

    style Dev_Mac fill:#FFC107
    style Local_PG fill:#FFC107
    style Local_API fill:#FFC107

    style LB fill:#4CAF50
    style RDS fill:#4CAF50
    style Redis_Cache fill:#4CAF50
```

---

## 11. User Flow - Complete Navigation Journey

```mermaid
stateDiagram-v2
    [*] --> AppLaunch

    AppLaunch --> Permissions: First Launch
    AppLaunch --> VenueSelection: Returning User

    Permissions --> Location: Request Location
    Location --> Camera: Request Camera
    Camera --> Motion: Request Motion
    Motion --> VenueSelection: All Granted

    VenueSelection --> LoadIMDF: Select Venue
    LoadIMDF --> BuildGraph: Parse IMDF
    BuildGraph --> MapView: Graph Ready

    MapView --> Search: Tap Search
    Search --> NLP: Enter Query
    NLP --> Results: Resolve POI
    Results --> SelectPOI: Choose from List

    SelectPOI --> ComputeRoute: Backend Call
    ComputeRoute --> RoutePreview: Display Path
    RoutePreview --> ARNavigation: Start AR

    ARNavigation --> Following: User Walking
    Following --> Reroute: Off-route Detected
    Reroute --> Following: Recalculated

    Following --> Arrived: Reached Destination
    Arrived --> MapView: End Navigation

    MapView --> [*]: Exit App

    state ARNavigation {
        [*] --> InitAR
        InitAR --> PlaneDetection
        PlaneDetection --> PlaceArrows
        PlaceArrows --> Tracking
        Tracking --> UpdatePose: 60 FPS
        UpdatePose --> Tracking
    }
```

---

## 12. NLP Processing Pipeline - Detailed

```mermaid
graph TB
    subgraph "Input Processing"
        Input[User Input Text]
        LangDetect{Detect Language}
        Arabic[Arabic Path]
        English[English Path]
    end

    subgraph "Arabic Preprocessing"
        AR_Dediac[Remove Diacritics<br/>تشكيل removal]
        AR_Norm[Normalize Letters<br/>أ إ آ → ا]
        AR_Digits[Convert Arabic Digits<br/>٣ → 3]
        AR_Ordinal[Ordinal Words<br/>الثالث → 3]
        AR_Stem[ISRI Stemming]
        AR_Stop[Remove Stopwords]
    end

    subgraph "English Preprocessing"
        EN_Lower[Lowercase]
        EN_Numbers[Word to Number<br/>three → 3]
        EN_Stop[Remove Stopwords]
        EN_Stem[Porter Stemming]
        EN_Token[Tokenization]
    end

    subgraph "Resolution Strategy"
        ExactMatch{Exact Alias<br/>Match?}
        FuzzyMatch[Fuzzy Matching]
        FamilyMatch[Family Grouping<br/>meeting room → list all]
        NumberExtract[Extract Numbers<br/>meeting room 3]
    end

    subgraph "Database Queries"
        SynonymTable[(poi_synonyms)]
        NamesTable[(poi_names)]
        POITable[(pois)]
        NLPView[(v_pois_nlp)]
    end

    subgraph "Response Building"
        Scoring[Confidence Scoring]
        Ranking[Sort by Relevance]
        Format[Format Response]
        Output[JSON Output]
    end

    Input --> LangDetect
    LangDetect -->|Arabic| Arabic
    LangDetect -->|English| English

    Arabic --> AR_Dediac
    AR_Dediac --> AR_Norm
    AR_Norm --> AR_Digits
    AR_Digits --> AR_Ordinal
    AR_Ordinal --> AR_Stem
    AR_Stem --> AR_Stop

    English --> EN_Lower
    EN_Lower --> EN_Numbers
    EN_Numbers --> EN_Stop
    EN_Stop --> EN_Stem
    EN_Stem --> EN_Token

    AR_Stop --> ExactMatch
    EN_Token --> ExactMatch

    ExactMatch -->|Yes| SynonymTable
    ExactMatch -->|No| FuzzyMatch
    FuzzyMatch --> NamesTable

    SynonymTable --> Scoring
    NamesTable --> Scoring
    NLPView --> Scoring

    NumberExtract --> Scoring
    FamilyMatch --> Scoring

    Scoring --> Ranking
    Ranking --> Format
    Format --> Output

    style Input fill:#2196F3
    style Arabic fill:#FF9800
    style English fill:#4CAF50
    style Output fill:#9C27B0
```

---

## Summary

These diagrams illustrate:

1. **System Architecture** - Overall component relationships
2. **iOS MVVM Structure** - Frontend architecture patterns
3. **Backend API Organization** - FastAPI module structure
4. **NLP Flow** - Natural language processing sequence
5. **Route & AR Flow** - Navigation computation and AR rendering
6. **Database Schema** - Entity relationships
7. **IMDF Pipeline** - Data ingestion workflow
8. **WebSocket Positioning** - Real-time updates
9. **Implementation Status** - What's done vs what's missing
10. **Deployment Architecture** - Current dev vs future production
11. **User Journey** - State machine of user interactions
12. **NLP Pipeline Details** - Preprocessing and resolution logic

These diagrams can be rendered in any Mermaid-compatible tool or directly in GitHub/GitLab markdown viewers.
