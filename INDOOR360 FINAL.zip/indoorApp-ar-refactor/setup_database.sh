#!/bin/bash

# Setup script for Indoor360 PostgreSQL database with PostGIS

PSQL="/opt/homebrew/opt/postgresql@18/bin/psql"
DB_NAME="indoor360"
DB_USER="postgres"
DB_PASSWORD="admin1234"
DB_HOST="127.0.0.1"
DB_PORT="5432"

echo "🔧 Setting up Indoor360 database with PostGIS..."

# Set PGPASSWORD environment variable to avoid password prompts
export PGPASSWORD="$DB_PASSWORD"

# Check if database exists, if not create it
echo "📦 Checking if database '$DB_NAME' exists..."
DB_EXISTS=$($PSQL -h $DB_HOST -p $DB_PORT -U $DB_USER -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'")

if [ "$DB_EXISTS" != "1" ]; then
    echo "➕ Creating database '$DB_NAME'..."
    $PSQL -h $DB_HOST -p $DB_PORT -U $DB_USER -d postgres -c "CREATE DATABASE $DB_NAME;"
    if [ $? -eq 0 ]; then
        echo "✅ Database created successfully"
    else
        echo "❌ Failed to create database"
        exit 1
    fi
else
    echo "✅ Database already exists"
fi

# Enable PostGIS extension
echo "🌍 Enabling PostGIS extension..."
$PSQL -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "CREATE EXTENSION IF NOT EXISTS postgis;"

if [ $? -eq 0 ]; then
    echo "✅ PostGIS extension enabled"
else
    echo "❌ Failed to enable PostGIS extension"
    exit 1
fi

# Run the main schema script
echo "📝 Running database schema script..."
$PSQL -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f "DATABASEINDOOR360.sql"

if [ $? -eq 0 ]; then
    echo "✅ Database schema created successfully"
else
    echo "❌ Failed to create database schema"
    exit 1
fi

# Verify PostGIS installation
echo "🔍 Verifying PostGIS installation..."
$PSQL -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "SELECT PostGIS_version();"

echo ""
echo "✨ Database setup complete!"
echo "📊 Database: $DB_NAME"
echo "🌍 PostGIS: Enabled"
echo "👤 User: $DB_USER"
echo "🏠 Host: $DB_HOST:$DB_PORT"

# Unset password for security
unset PGPASSWORD
