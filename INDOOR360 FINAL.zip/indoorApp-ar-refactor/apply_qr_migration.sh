#!/bin/bash

# Apply QR anchors migration for Indoor360 database

PSQL="/opt/homebrew/opt/postgresql@18/bin/psql"
DB_NAME="indoor360"
DB_USER="postgres"
DB_PASSWORD="admin1234"
DB_HOST="127.0.0.1"
DB_PORT="5432"

echo "🔧 Applying QR anchors migration..."

export PGPASSWORD="$DB_PASSWORD"

# Run the migration
$PSQL -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f "backend/db/qr_anchors.sql"

if [ $? -eq 0 ]; then
    echo "✅ QR anchors table created successfully"

    # Verify the table
    echo ""
    echo "📊 Verifying qr_anchors table:"
    $PSQL -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "SELECT qr_code, location_name, floor_level, poi_id FROM qr_anchors;"
else
    echo "❌ Failed to create QR anchors table"
    exit 1
fi

echo ""
echo "✅ Migration complete!"
