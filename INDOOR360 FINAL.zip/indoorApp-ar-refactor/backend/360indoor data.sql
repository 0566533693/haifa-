

-- Enable PostGIS extension for spatial data
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE Users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(150) UNIQUE,
    phone VARCHAR(20),
    password_hash TEXT,
    auth_provider VARCHAR(50), -- email, google, facebook, guest
    role VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);


CREATE TABLE OTP_Tokens (
    otp_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    otp_code VARCHAR(10),
    expires_at TIMESTAMP,
    is_used BOOLEAN DEFAULT FALSE
);

CREATE TABLE Sessions (
    session_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    jwt_token TEXT,
    device_info TEXT,
    started_at TIMESTAMP DEFAULT NOW(),
    ended_at TIMESTAMP
);



-- BUILDINGS & FLOORS
-- =====================

CREATE TABLE Buildings (
    building_id SERIAL PRIMARY KEY,
    name VARCHAR(150),
    address TEXT,
    description TEXT
);

CREATE TABLE Floors (
    floor_id SERIAL PRIMARY KEY,
    building_id INT REFERENCES Buildings(building_id) ON DELETE CASCADE,
    floor_number INT,
    name VARCHAR(100),
    blueprint_file TEXT,
    version VARCHAR(50),
    uploaded_by INT REFERENCES Users(user_id),
    uploaded_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE Blueprint_Files (
    file_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    file_path TEXT,
    version_number VARCHAR(50),
    uploaded_by INT REFERENCES Users(user_id),
    timestamp TIMESTAMP DEFAULT NOW()
);




-- POINTS OF INTEREST (POI)
-- =====================

CREATE TABLE POIs (
    poi_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    name VARCHAR(150),
    type VARCHAR(50), -- restroom, shop, exit, etc.
    coordinates GEOGRAPHY(POINT, 4326), -- PostGIS point
    description TEXT,
    accessible_features TEXT
);

CREATE TABLE POI_Metadata (
    metadata_id SERIAL PRIMARY KEY,
    poi_id INT REFERENCES POIs(poi_id) ON DELETE CASCADE,
    language VARCHAR(10),
    label VARCHAR(150),
    description TEXT,
    offers TEXT
);

-- =====================
-- NAVIGATION & ROUTES
-- =====================

CREATE TABLE Routes (
    route_id SERIAL PRIMARY KEY,
    start_poi INT REFERENCES POIs(poi_id),
    end_poi INT REFERENCES POIs(poi_id),
    path_geometry GEOGRAPHY(LINESTRING, 4326),
    distance_meters FLOAT,
    estimated_time INT
);

CREATE TABLE Anchors (
    anchor_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    coordinates GEOGRAPHY(POINT, 4326),
    anchor_type VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);

-- =====================
-- WIFI HEATMAP & SENSOR DATA
-- =====================

CREATE TABLE Access_Points (
    ap_id SERIAL PRIMARY KEY,
    building_id INT REFERENCES Buildings(building_id) ON DELETE CASCADE,
    ssid VARCHAR(100),
    mac_address VARCHAR(50) UNIQUE,
    location GEOGRAPHY(POINT, 4326)
);

CREATE TABLE Heatmap_Readings (
    reading_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    ap_id INT REFERENCES Access_Points(ap_id) ON DELETE CASCADE,
    coordinates GEOGRAPHY(POINT, 4326),
    rssi_value INT,
    timestamp TIMESTAMP DEFAULT NOW()
);

CREATE TABLE Sensor_Data (
    sensor_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    type VARCHAR(50), -- IMU, BLE, Wi-Fi
    reading JSONB,
    timestamp TIMESTAMP DEFAULT NOW()
);




-- ADMIN & ACCESS CONTROL
-- =====================

CREATE TABLE Roles (
    role_id SERIAL PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE,
    description TEXT
);

CREATE TABLE User_Roles (
    user_role_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    role_id INT REFERENCES Roles(role_id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE Audit_Logs (
    log_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(user_id),
    action VARCHAR(150),
    details TEXT,
    timestamp TIMESTAMP DEFAULT NOW()
);

-- POINTS OF INTEREST (POI)
-- =====================

CREATE TABLE POIs (
    poi_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    name VARCHAR(150),
    type VARCHAR(50), -- restroom, shop, exit, etc.
    coordinates GEOGRAPHY(POINT, 4326), -- PostGIS point
    description TEXT,
    accessible_features TEXT
);

CREATE TABLE POI_Metadata (
    metadata_id SERIAL PRIMARY KEY,
    poi_id INT REFERENCES POIs(poi_id) ON DELETE CASCADE,
    language VARCHAR(10),
    label VARCHAR(150),
    description TEXT,
    offers TEXT
);





-- NAVIGATION & ROUTES
-- =====================

CREATE TABLE Routes (
    route_id SERIAL PRIMARY KEY,
    start_poi INT REFERENCES POIs(poi_id),
    end_poi INT REFERENCES POIs(poi_id),
    path_geometry GEOGRAPHY(LINESTRING, 4326),
    distance_meters FLOAT,
    estimated_time INT
);

CREATE TABLE Anchors (
    anchor_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    coordinates GEOGRAPHY(POINT, 4326),
    anchor_type VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);


CREATE TABLE Navigation_History (
    history_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(user_id),
    route_id INT REFERENCES Routes(route_id),
    start_time TIMESTAMP DEFAULT NOW(),
    end_time TIMESTAMP
);

CREATE TABLE Error_Reports (
    error_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES Users(user_id),
    error_type VARCHAR(100),
    description TEXT,
    timestamp TIMESTAMP DEFAULT NOW()
);





-- Table for the IMDF package
CREATE TABLE imdf_packages (
    package_id SERIAL PRIMARY KEY,
    name TEXT,                          -- name of the package (ex: "Campus July 2025")
    version TEXT,
    uploaded_by INT REFERENCES Users(user_id),
    uploaded_at TIMESTAMP DEFAULT NOW()
);




-- Table for JSON files inside the package
CREATE TABLE imdf_files (
    file_id SERIAL PRIMARY KEY,
    package_id INT REFERENCES imdf_packages(package_id) ON DELETE CASCADE,
    file_name TEXT,                     -- e.g., "unit.json"
    data JSONB,                         -- the actual JSON content
    uploaded_at TIMESTAMP DEFAULT NOW()
);

SELECT * FROM imdf_packages WHERE name = 'University Campus - July 2025';

select * from imdf_packages;






