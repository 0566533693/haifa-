﻿import json, psycopg, sys
from pathlib import Path

# Add backend directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import settings

IMDF = r"C:\\Users\\hhs39\\OneDrive - University of Wollongong\\Desktop\\1\\.vscode\\Indoor360\\backend\\unit (1).geojson"

data = json.loads(Path(IMDF).read_text(encoding="utf-8"))
feats = data.get("features", [])
up, errors = 0, 0

def to_cat(raw):
    return (str(raw).lower() if raw else "room")

with psycopg.connect(settings.DATABASE_URL, autocommit=True) as conn:
    for ft in feats:
        props = ft.get("properties") or {}
        geom  = ft.get("geometry")
        if not geom:
            continue

        # only ingest UNITs
        ftype = ft.get("feature_type") or props.get("feature_type") or "unit"
        if ftype != "unit":
            continue

        imdf_id = props.get("id") or ft.get("id") or props.get("identifier") or props.get("unit_id")
        if not imdf_id:
            continue

        name = (props.get("name") or "").strip()
        alt  = (props.get("alt_name") or "").strip()
        cat  = to_cat(props.get("category") or props.get("category_group"))
        lvl  = props.get("level_id") or props.get("level") or props.get("levelIdentifier")
        display = name or alt or cat

        try:
            # derive a centroid POINT from whatever geometry IMDF gives (Polygon, MultiPolygon, etc.)
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO pois (imdf_id, name, category, floor_imdf_id, geom_point)
                    VALUES (%s,%s,%s,%s,
                      ST_Centroid(
                        ST_SetSRID(
                          ST_GeomFromGeoJSON(%s), 4326
                        )
                      )
                    )
                    ON CONFLICT (imdf_id) DO UPDATE SET
                      name=EXCLUDED.name,
                      category=EXCLUDED.category,
                      floor_imdf_id=EXCLUDED.floor_imdf_id,
                      geom_point=EXCLUDED.geom_point;
                """, (imdf_id, display, cat, lvl, json.dumps(geom)))
                if cur.rowcount > 0:
                    up += 1
        except Exception as e:
            errors += 1
            print(f"[ERROR] imdf_id={imdf_id} name='{display}' cat='{cat}' -> {e}")
            try:
                with conn.cursor() as c2: c2.execute("ROLLBACK;")
            except Exception: pass

print(f"✅ upserted {up}, errors {errors}")
