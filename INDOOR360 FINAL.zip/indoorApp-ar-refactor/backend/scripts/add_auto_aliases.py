﻿# backend/scripts/add_auto_aliases.py
import os, re, psycopg
DB = os.getenv("DATABASE_URL"); assert DB, "DATABASE_URL not set"

AR_ELEV = ["مصعد", "اسانسير", "أسانسير", "اسنصير"]
AR_WC   = ["حمام", "دورة المياه"]
AR_MR   = ["غرفة الاجتماعات", "غرفه الاجتماعات"]

with psycopg.connect(DB) as conn, conn.cursor() as cur:
    cur.execute("""
    CREATE TABLE IF NOT EXISTS poi_aliases(
      poi_id  INT REFERENCES pois(id) ON DELETE CASCADE,
      alias_text TEXT NOT NULL,
      alias_text_norm TEXT GENERATED ALWAYS AS (lower(regexp_replace(alias_text,'\\s+',' ','g'))) STORED,
      lang TEXT DEFAULT 'en',
      UNIQUE(poi_id, alias_text_norm)
    );
    """)

    cur.execute("SELECT id, name, category FROM pois ORDER BY id;")
    rows = cur.fetchall()

    def add(poi_id, text, lang="en"):
        if not text: return
        cur.execute("""
          INSERT INTO poi_aliases(poi_id, alias_text, lang)
          VALUES (%s,%s,%s)
          ON CONFLICT ON CONSTRAINT poi_aliases_poi_id_alias_text_norm_key DO NOTHING;
        """, (poi_id, text.strip(), lang))

    for poi_id, name, cat in rows:
        n = (name or "").strip()
        cat = (cat or "").lower()
        add(poi_id, n, "en")

        m = re.search(r"(\d{1,3})", n.lower())
        num = m.group(1) if m else None

        if cat == "meeting room":
            if num:
                add(poi_id, f"meeting room {num}", "en")
                for base in AR_MR: add(poi_id, f"{base} {num}", "ar")
        elif cat == "elevator":
            if num:
                add(poi_id, f"elevator {num}", "en")
                for base in AR_ELEV: add(poi_id, f"{base} {num}", "ar")
            else:
                add(poi_id, "elevator","en")
                for base in AR_ELEV: add(poi_id, base, "ar")
        elif cat == "restroom":
            add(poi_id, "restroom","en")
            for base in AR_WC: add(poi_id, base, "ar")
        elif cat in {"phone booth","quiet room","war room","board room","idf room",
                     "store room","production room","testing room","studio","reception / cafe"}:
            add(poi_id, cat, "en")

    conn.commit()
    print("aliases_done")
