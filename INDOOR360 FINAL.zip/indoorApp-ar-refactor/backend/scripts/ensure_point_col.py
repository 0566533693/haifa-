﻿import os, psycopg

DB = os.environ["DATABASE_URL"]
assert DB, "DATABASE_URL not set"

with psycopg.connect(DB, autocommit=True) as conn, conn.cursor() as cur:
    # Make sure PostGIS is available (no-op if already installed)
    cur.execute("CREATE EXTENSION IF NOT EXISTS postgis;")

    # Add a point column for AR client if missing
    cur.execute("""
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_name='pois' AND column_name='geom_point'
          ) THEN
            ALTER TABLE pois ADD COLUMN geom_point geometry(Point,4326);
          END IF;
        END$$;
    """)

    # Back-fill geom_point from existing geom of any type
    # 1) If geom is already a Point
    cur.execute("""
        UPDATE pois
        SET geom_point = ST_SetSRID(geom::geometry(Point),4326)
        WHERE geom_point IS NULL AND GeometryType(geom) LIKE 'POINT%';
    """)

    # 2) If geom is Polygon/MultiPolygon -> use a stable interior point
    cur.execute("""
        UPDATE pois
        SET geom_point = ST_PointOnSurface(geom)
        WHERE geom_point IS NULL AND (GeometryType(geom) LIKE 'POLYGON%' OR GeometryType(geom) LIKE 'MULTIPOLYGON%');
    """)

    # 3) If geom is LineString/MultiLineString -> centroid as fallback
    cur.execute("""
        UPDATE pois
        SET geom_point = ST_Centroid(geom)
        WHERE geom_point IS NULL AND (GeometryType(geom) LIKE 'LINESTRING%' OR GeometryType(geom) LIKE 'MULTILINESTRING%');
    """)

    # Ensure a unique index on imdf_id to avoid duplicates
    cur.execute("""
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM pg_indexes
            WHERE schemaname='public' AND indexname='uq_pois_imdf_id'
          ) THEN
            CREATE UNIQUE INDEX uq_pois_imdf_id ON pois (imdf_id);
          END IF;
        END$$;
    """)

print("✅ geom_point ready and back-filled")
