# scripts/add_elevator_aliases.py
import os, re, psycopg

DB = os.environ.get("DATABASE_URL")
assert DB, "DATABASE_URL not set"

AR_SPELLINGS = ["اسنصير", "اسنسير", "مصعد"]   # common variants
EN_SHORT     = ["lift", "elv"]

def main():
    up = 0
    with psycopg.connect(DB) as conn, conn.cursor() as cur:
        # Find all exact "Elevator N" already in your view
        cur.execute("""
            SELECT poi_id, name
            FROM ar_pois_api
            WHERE lower(name) ~ '^elevator\\s+\\d+$'
            ORDER BY poi_id
        """)
        rows = cur.fetchall()

        for poi_id, name in rows:
            m = re.search(r'(\d+)$', name or "", re.I)
            if not m: continue
            n = int(m.group(1))

            # Arabic aliases
            for base in AR_SPELLINGS:
                alias = f"{base} {n}"
                cur.execute("""
                    INSERT INTO poi_aliases(poi_id, alias_text, lang)
                    VALUES (%s,%s,'ar')
                    ON CONFLICT DO NOTHING
                """, (poi_id, alias))
                if cur.rowcount > 0: up += 1

            # English short forms
            for base in EN_SHORT:
                alias = f"{base} {n}"
                cur.execute("""
                    INSERT INTO poi_aliases(poi_id, alias_text, lang)
                    VALUES (%s,%s,'en')
                    ON CONFLICT DO NOTHING
                """, (poi_id, alias))
                if cur.rowcount > 0: up += 1

        conn.commit()
    print(f"aliases upserted {up}")

if __name__ == "__main__":
    main()
