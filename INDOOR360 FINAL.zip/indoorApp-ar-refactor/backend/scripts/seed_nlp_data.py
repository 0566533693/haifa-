#!/usr/bin/env python3
"""
Populate poi_names and poi_synonyms tables from ar_pois_api.
This enables the NLP resolve endpoint to find POIs by name.
"""

import sys
import os

# Add backend directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import psycopg2
from app.config import settings


def main():
    conn = psycopg2.connect(settings.DATABASE_URL)
    cur = conn.cursor()

    # Check if tables exist and their structure
    cur.execute("""
        SELECT column_name FROM information_schema.columns
        WHERE table_name = 'poi_names';
    """)
    existing_cols = [row[0] for row in cur.fetchall()]

    if not existing_cols:
        # Create tables if they don't exist
        cur.execute("""
            CREATE TABLE IF NOT EXISTS poi_names (
                id SERIAL PRIMARY KEY,
                poi_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                UNIQUE(poi_id, name)
            );
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS poi_synonyms (
                id SERIAL PRIMARY KEY,
                poi_id INTEGER NOT NULL,
                synonym TEXT NOT NULL,
                UNIQUE(poi_id, synonym)
            );
        """)
        conn.commit()

    # Clear existing data
    cur.execute("DELETE FROM poi_names;")
    cur.execute("DELETE FROM poi_synonyms;")
    conn.commit()

    # Load all POIs from ar_pois_api
    cur.execute("SELECT poi_id, name, category FROM ar_pois_api WHERE name IS NOT NULL;")
    pois = cur.fetchall()

    print(f"Found {len(pois)} POIs in ar_pois_api")

    names_inserted = 0
    synonyms_inserted = 0

    for poi_id, name, category in pois:
        if not name:
            continue

        # Insert the main name
        cur.execute("""
            INSERT INTO poi_names (poi_id, name)
            VALUES (%s, %s)
            ON CONFLICT DO NOTHING;
        """, (poi_id, name))
        names_inserted += 1

        # Add synonyms based on common patterns
        synonyms = set()

        name_lower = name.lower()

        # Add the exact name as a synonym too (for exact match)
        synonyms.add(name)

        # Handle "Meeting Room X" -> "meeting X", "room X", "meeting room X"
        if "meeting room" in name_lower:
            parts = name.split()
            if len(parts) >= 3:
                room_num = parts[-1]  # e.g., "10"
                synonyms.add(f"meeting {room_num}")
                synonyms.add(f"room {room_num}")
                synonyms.add(name_lower)

        # Handle "RestroomX" -> "restroom X", "toilet", "bathroom", "wc"
        if "restroom" in name_lower:
            synonyms.add("restroom")
            synonyms.add("toilet")
            synonyms.add("bathroom")
            synonyms.add("wc")
            # Extract number if present
            import re
            match = re.search(r'(\d+)', name)
            if match:
                num = match.group(1)
                synonyms.add(f"restroom {num}")
                synonyms.add(f"toilet {num}")

        # Handle Theatre/Theater
        if "theatre" in name_lower or "theater" in name_lower:
            synonyms.add("theatre")
            synonyms.add("theater")
            synonyms.add("auditorium")

        # Handle Elevator
        if "elevator" in name_lower:
            synonyms.add("elevator")
            synonyms.add("lift")

        # Handle Reception
        if "reception" in name_lower:
            synonyms.add("reception")
            synonyms.add("front desk")
            synonyms.add("lobby")

        # Handle Cafe/Coffee
        if "cafe" in name_lower or "coffee" in name_lower:
            synonyms.add("cafe")
            synonyms.add("coffee")
            synonyms.add("cafeteria")

        # Handle Stairs
        if "stair" in name_lower:
            synonyms.add("stairs")
            synonyms.add("stairway")
            synonyms.add("staircase")

        # Add category as synonym if relevant
        if category:
            cat_lower = category.lower()
            if cat_lower not in ['room', 'unit']:
                synonyms.add(cat_lower)

        # Insert all synonyms
        for syn in synonyms:
            if syn and syn.strip():
                cur.execute("""
                    INSERT INTO poi_synonyms (poi_id, synonym)
                    VALUES (%s, %s)
                    ON CONFLICT DO NOTHING;
                """, (poi_id, syn.strip().lower()))
                synonyms_inserted += 1

    conn.commit()

    # Verify counts
    cur.execute("SELECT COUNT(*) FROM poi_names;")
    names_count = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM poi_synonyms;")
    synonyms_count = cur.fetchone()[0]

    print(f"\n✅ NLP data seeded:")
    print(f"   - poi_names: {names_count} entries")
    print(f"   - poi_synonyms: {synonyms_count} entries")

    # Show some examples
    print("\nSample poi_names:")
    cur.execute("SELECT poi_id, name FROM poi_names LIMIT 5;")
    for row in cur.fetchall():
        print(f"   {row[0]}: {row[1]}")

    print("\nSample poi_synonyms:")
    cur.execute("SELECT poi_id, synonym FROM poi_synonyms LIMIT 10;")
    for row in cur.fetchall():
        print(f"   {row[0]}: {row[1]}")

    cur.close()
    conn.close()

    print("\n✅ Done! NLP resolve should now work.")

if __name__ == "__main__":
    main()
