﻿import os, psycopg
DB = os.environ["DATABASE_URL"]

with psycopg.connect(DB, autocommit=True) as conn, conn.cursor() as cur:
    # clear any broken transaction
    try:
        cur.execute("ROLLBACK;")
    except Exception:
        pass
    # allow ANY geometry type (Polygon, MultiPolygon, Point) with SRID 4326
    cur.execute("""
        ALTER TABLE pois
        ALTER COLUMN geom TYPE geometry(Geometry,4326)
        USING ST_SetSRID(geom::geometry,4326);
    """)
print("✅ geom column set to geometry(Geometry,4326) and transaction cleared")
