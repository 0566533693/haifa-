#!/usr/bin/env python3
"""
Seed the database with real data from IMDF files.
Creates POIs, navigation nodes, and links QR anchors.
"""

import json
import sys
import psycopg2
from pathlib import Path

# Add backend directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import settings

def get_polygon_centroid(coordinates):
    """Calculate centroid of a polygon."""
    if not coordinates or not coordinates[0]:
        return None, None

    ring = coordinates[0]  # Outer ring
    n = len(ring)
    if n == 0:
        return None, None

    # Simple average for centroid
    sum_x = sum(p[0] for p in ring)
    sum_y = sum(p[1] for p in ring)
    return sum_x / n, sum_y / n

def load_imdf_units(imdf_path):
    """Load units from IMDF file."""
    unit_file = imdf_path / "unit (1).geojson"
    if not unit_file.exists():
        unit_file = imdf_path / "unit.geojson"

    if not unit_file.exists():
        print(f"❌ No unit file found in {imdf_path}")
        return []

    with open(unit_file, 'r') as f:
        data = json.load(f)

    units = []
    for feature in data.get('features', []):
        props = feature.get('properties', {})
        geom = feature.get('geometry', {})

        name = props.get('name')
        if not name:  # Skip unnamed units
            continue

        category = props.get('category', 'room')

        # Get centroid
        coords = geom.get('coordinates', [])
        lon, lat = get_polygon_centroid(coords)

        if lon is None:
            continue

        units.append({
            'id': feature.get('id'),
            'name': name,
            'alt_name': props.get('alt_name'),
            'category': category,
            'level_id': props.get('level_id'),
            'lon': lon,
            'lat': lat,
            'floor': 1  # Default floor, will update based on level
        })

    return units

def seed_database(units):
    """Seed the database with POIs and navigation nodes."""
    conn = psycopg2.connect(settings.DATABASE_URL)
    cur = conn.cursor()

    try:
        # Check if building exists, create if not
        cur.execute("SELECT building_id FROM buildings LIMIT 1")
        building_row = cur.fetchone()
        if building_row:
            building_id = building_row[0]
        else:
            # Check building table schema
            cur.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'buildings'")
            cols = [row[0] for row in cur.fetchall()]
            print(f"  Buildings columns: {cols}")

            if 'name' in cols:
                cur.execute("""
                    INSERT INTO buildings (name)
                    VALUES ('PwC Building')
                    RETURNING building_id
                """)
            else:
                cur.execute("""
                    INSERT INTO buildings DEFAULT VALUES
                    RETURNING building_id
                """)
            building_id = cur.fetchone()[0]

        print(f"📍 Using building_id: {building_id}")

        # Check if floor exists, create if not
        cur.execute("SELECT floor_id FROM floors WHERE floor_number = 1 LIMIT 1")
        floor_row = cur.fetchone()
        if floor_row:
            floor_id = floor_row[0]
        else:
            cur.execute("""
                INSERT INTO floors (building_id, floor_number, name)
                VALUES (%s, 1, 'Ground Floor')
                RETURNING floor_id
            """, (building_id,))
            floor_id = cur.fetchone()[0]

        print(f"📍 Using floor_id: {floor_id}")

        # Clear existing data
        print("🗑️  Clearing existing POIs and nav nodes...")
        cur.execute("DELETE FROM nav_edges")
        cur.execute("DELETE FROM nav_nodes")
        cur.execute("DELETE FROM pois")

        # Insert POIs
        print(f"📍 Inserting {len(units)} POIs...")
        poi_map = {}  # name -> poi_id
        poi_coords = {}  # poi_id -> (x, y, z)

        for unit in units:
            # Convert lat/lon to local coordinates (simple offset for demo)
            # In real scenario, you'd use proper projection
            base_lon, base_lat = 55.2746, 25.2007  # Approximate center
            x = (unit['lon'] - base_lon) * 111000  # ~111km per degree at equator
            y = (unit['lat'] - base_lat) * 111000
            z = 0.0

            # Create point geometry - format: POINT(x y)
            cur.execute("""
                INSERT INTO pois (name, type, floor_id, coordinates)
                VALUES (%s, %s, %s, ST_SetSRID(ST_MakePoint(%s, %s), 4326))
                RETURNING poi_id
            """, (unit['name'], unit['category'], floor_id, unit['lon'], unit['lat']))

            poi_id = cur.fetchone()[0]
            poi_map[unit['name']] = poi_id
            poi_coords[poi_id] = (x, y, z)
            print(f"  ✓ {unit['name']} (ID: {poi_id})")

        # Create navigation nodes for each POI
        print("\n🔗 Creating navigation nodes...")
        node_map = {}  # poi_id -> node_id

        for poi_id, coords in poi_coords.items():
            x, y, z = coords

            cur.execute("""
                INSERT INTO nav_nodes (floor, x, y, z)
                VALUES (%s, %s, %s, %s)
                RETURNING node_id
            """, (1, x, y, z))

            node_id = cur.fetchone()[0]
            node_map[poi_id] = node_id

            # Link POI to nearest node
            cur.execute("""
                UPDATE pois SET nearest_node = %s WHERE poi_id = %s
            """, (node_id, poi_id))

        # Create edges using K-nearest neighbors for more realistic paths
        print("\n🔀 Creating navigation edges (K-nearest neighbors)...")
        node_ids = list(node_map.values())

        # Get all node positions
        cur.execute("SELECT node_id, x, y, floor FROM nav_nodes")
        nodes = {row[0]: (row[1], row[2], row[3]) for row in cur.fetchall()}

        # For each node, connect to K nearest neighbors
        K = 6  # Number of nearest neighbors to connect
        edge_set = set()  # Track edges to avoid duplicates

        for node_a in node_ids:
            pos_a = nodes.get(node_a)
            if not pos_a:
                continue

            # Calculate distances to all other nodes on same floor
            distances = []
            for node_b in node_ids:
                if node_a == node_b:
                    continue
                pos_b = nodes.get(node_b)
                if not pos_b or pos_a[2] != pos_b[2]:  # Same floor check
                    continue

                dx = pos_b[0] - pos_a[0]
                dy = pos_b[1] - pos_a[1]
                dist = (dx*dx + dy*dy) ** 0.5
                distances.append((dist, node_b))

            # Sort by distance and take K nearest
            distances.sort(key=lambda x: x[0])
            for dist, node_b in distances[:K]:
                # Create canonical edge tuple (smaller id first)
                edge = (min(node_a, node_b), max(node_a, node_b))
                if edge not in edge_set:
                    edge_set.add(edge)
                    cur.execute("""
                        INSERT INTO nav_edges (a, b, cost)
                        VALUES (%s, %s, %s)
                    """, (edge[0], edge[1], dist))

        edge_count = len(edge_set)
        print(f"  ✓ Created {edge_count} edges (K={K} nearest neighbors)")

        # Commit the core data first
        conn.commit()
        print("✅ Core data committed (POIs, nodes, edges)")

        # Update QR anchors with POI links
        print("\n🔗 Linking QR anchors to POIs...")

        # Map anchor names to likely POI matches
        anchor_poi_map = {
            'anchor:reception': 'Reception / Cafe',
            'anchor:cafe-entrance': 'Reception / Cafe',
            'anchor:elevator-f1': 'Elevator 1',
            'anchor:elevator-f2': 'Elevator 2',
            'anchor:elevator-f3': 'Elevator 3',
            'anchor:meeting-area': 'Meeting Room 1',
            'anchor:main-entrance': 'Board Room',
        }

        for anchor_code, poi_name in anchor_poi_map.items():
            poi_id = poi_map.get(poi_name)
            if poi_id:
                cur.execute("""
                    UPDATE qr_anchors
                    SET poi_id = %s
                    WHERE qr_code = %s
                """, (poi_id, anchor_code))
                print(f"  ✓ {anchor_code} → {poi_name} (POI {poi_id})")

        # Update anchor coordinates from linked POIs (using coordinates geometry)
        # Cast geography to geometry for ST_X/ST_Y functions
        cur.execute("""
            UPDATE qr_anchors qa
            SET x = ST_X(p.coordinates::geometry),
                y = ST_Y(p.coordinates::geometry),
                z = 0
            FROM pois p
            WHERE qa.poi_id = p.poi_id
        """)

        conn.commit()
        print("\n✅ Database seeded successfully!")

        # Print summary
        cur.execute("SELECT COUNT(*) FROM pois")
        poi_count = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM nav_nodes")
        node_count = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM nav_edges")
        edge_count = cur.fetchone()[0]

        print(f"\n📊 Summary:")
        print(f"   POIs: {poi_count}")
        print(f"   Nav Nodes: {node_count}")
        print(f"   Nav Edges: {edge_count}")

        # Also populate ar_pois_api table which is used by the actual API
        print("\n📋 Populating ar_pois_api table...")
        cur.execute("DELETE FROM ar_pois_api")
        cur.execute("""
            INSERT INTO ar_pois_api (poi_id, name, category, floor, x, y, z, wgs84_geom)
            SELECT
                p.poi_id,
                p.name,
                p.type,
                COALESCE(f.floor_number::text, '1'),
                ST_X(p.coordinates::geometry) * 111000 - 55.2746 * 111000,
                ST_Y(p.coordinates::geometry) * 111000 - 25.2007 * 111000,
                0.0,
                p.coordinates::geometry
            FROM pois p
            LEFT JOIN floors f ON p.floor_id = f.floor_id
        """)
        conn.commit()

        cur.execute("SELECT COUNT(*) FROM ar_pois_api")
        ar_count = cur.fetchone()[0]
        print(f"   ar_pois_api: {ar_count}")

    except Exception as e:
        conn.rollback()
        print(f"❌ Error: {e}")
        raise
    finally:
        cur.close()
        conn.close()

def main():
    imdf_path = Path(__file__).parent.parent / "latest_imdf"

    if not imdf_path.exists():
        print(f"❌ IMDF directory not found: {imdf_path}")
        sys.exit(1)

    print(f"📂 Loading IMDF data from: {imdf_path}")
    units = load_imdf_units(imdf_path)

    if not units:
        print("❌ No units found in IMDF data")
        sys.exit(1)

    print(f"📍 Found {len(units)} named units")
    seed_database(units)

if __name__ == "__main__":
    main()
