#!/usr/bin/env python3
"""
Export nav_nodes and nav_edges from PostgreSQL to GeoJSON files.

Converts local x,y meter coordinates back to WGS84 (lon/lat) using the venue's origin.
The resulting GeoJSON files can be added to the iOS app's IMDF bundle.

Usage:
    python scripts/export_nav_graph_geojson.py --origin-lon 55.2746839 --origin-lat 25.2007704 --output-dir ../Indoor360/IMDFVenues\ /
"""

import argparse
import json
import math
import sys
import os

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import get_connection


def local_to_wgs84(x: float, y: float, origin_lon: float, origin_lat: float) -> tuple:
    """
    Convert local meter coordinates back to WGS84 lon/lat.

    This is the inverse of the transformation used in the database view:
    x = (lon - origin_lon) * meters_per_degree_lon
    y = (lat - origin_lat) * meters_per_degree_lat

    So:
    lon = x / meters_per_degree_lon + origin_lon
    lat = y / meters_per_degree_lat + origin_lat
    """
    meters_per_degree_lat = 111320.0  # approximately constant
    meters_per_degree_lon = 111320.0 * math.cos(math.radians(origin_lat))

    lon = x / meters_per_degree_lon + origin_lon
    lat = y / meters_per_degree_lat + origin_lat

    return lon, lat


def get_level_id_for_floor(floor_num: int) -> str:
    """
    Map floor number to IMDF level_id.
    Adjust this mapping based on your venue's level.geojson.
    """
    # This mapping should match your venue's level.geojson
    # PwC Dubai venue has a single level with this ID
    level_mapping = {
        0: "d6aed8cd-fae1-4648-8e88-afd2e1cf8c3e",  # Level 0
        1: "d6aed8cd-fae1-4648-8e88-afd2e1cf8c3e",  # Also map floor 1 to the same level for now
    }
    return level_mapping.get(floor_num, "d6aed8cd-fae1-4648-8e88-afd2e1cf8c3e")


def export_nav_nodes(origin_lon: float, origin_lat: float) -> dict:
    """Export nav_nodes table to GeoJSON format."""
    features = []

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT node_id, floor, x, y, z FROM nav_nodes ORDER BY node_id")
            rows = cur.fetchall()

            for row in rows:
                node_id, floor, x, y, z = row

                # Convert local coordinates to WGS84
                lon, lat = local_to_wgs84(x, y, origin_lon, origin_lat)

                feature = {
                    "type": "Feature",
                    "id": str(node_id),
                    "geometry": {
                        "type": "Point",
                        "coordinates": [lon, lat]
                    },
                    "properties": {
                        "id": str(node_id),
                        "level_id": get_level_id_for_floor(floor) if floor else None,
                        "floor": floor,
                        "kind": "hallway",  # default kind
                        "walkable": True,
                        "local_x": x,
                        "local_y": y,
                        "local_z": z
                    }
                }
                features.append(feature)

    return {
        "type": "FeatureCollection",
        "features": features
    }


def export_nav_edges() -> dict:
    """Export nav_edges table to GeoJSON format."""
    features = []

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT edge_id, a, b, cost FROM nav_edges ORDER BY edge_id")
            rows = cur.fetchall()

            for row in rows:
                edge_id, from_id, to_id, cost = row

                feature = {
                    "type": "Feature",
                    "id": str(edge_id),
                    "geometry": None,  # Edges don't need geometry, defined by from/to nodes
                    "properties": {
                        "id": str(edge_id),
                        "from": str(from_id),
                        "to": str(to_id),
                        "weight": cost,
                        "bidir": True,  # bidirectional
                        "kind": "hallway"
                    }
                }
                features.append(feature)

    return {
        "type": "FeatureCollection",
        "features": features
    }


def calculate_venue_centroid(units_geojson_path: str) -> tuple:
    """Calculate the centroid of all units to use as origin."""
    with open(units_geojson_path, 'r') as f:
        data = json.load(f)

    all_coords = []
    for feat in data.get('features', []):
        geom = feat.get('geometry', {})
        if geom.get('type') == 'Polygon':
            for ring in geom.get('coordinates', []):
                for pt in ring:
                    all_coords.append(pt)

    if not all_coords:
        raise ValueError("No coordinates found in units")

    avg_lon = sum(pt[0] for pt in all_coords) / len(all_coords)
    avg_lat = sum(pt[1] for pt in all_coords) / len(all_coords)

    return avg_lon, avg_lat


def main():
    parser = argparse.ArgumentParser(description='Export nav_nodes and nav_edges to GeoJSON')
    parser.add_argument('--origin-lon', type=float, help='Origin longitude (WGS84)')
    parser.add_argument('--origin-lat', type=float, help='Origin latitude (WGS84)')
    parser.add_argument('--output-dir', type=str, required=True, help='Output directory for GeoJSON files')
    parser.add_argument('--auto-origin', type=str, help='Path to unit.geojson to auto-calculate origin')

    args = parser.parse_args()

    # Determine origin
    if args.auto_origin:
        origin_lon, origin_lat = calculate_venue_centroid(args.auto_origin)
        print(f"Auto-calculated origin: lon={origin_lon:.7f}, lat={origin_lat:.7f}")
    elif args.origin_lon and args.origin_lat:
        origin_lon = args.origin_lon
        origin_lat = args.origin_lat
    else:
        # Default to PwC Dubai venue centroid
        origin_lon = 55.2746839
        origin_lat = 25.2007704
        print(f"Using default origin: lon={origin_lon}, lat={origin_lat}")

    # Export nav_nodes
    print("Exporting nav_nodes...")
    nodes_geojson = export_nav_nodes(origin_lon, origin_lat)
    nodes_path = os.path.join(args.output_dir, 'nav_nodes.geojson')
    with open(nodes_path, 'w') as f:
        json.dump(nodes_geojson, f, indent=2)
    print(f"  Written {len(nodes_geojson['features'])} nodes to {nodes_path}")

    # Export nav_edges
    print("Exporting nav_edges...")
    edges_geojson = export_nav_edges()
    edges_path = os.path.join(args.output_dir, 'nav_edges.geojson')
    with open(edges_path, 'w') as f:
        json.dump(edges_geojson, f, indent=2)
    print(f"  Written {len(edges_geojson['features'])} edges to {edges_path}")

    print("\nDone! Add these files to your iOS app's IMDF bundle and rebuild.")


if __name__ == '__main__':
    main()
