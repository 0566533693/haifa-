# tests/run_nlp_suite.py
import os, csv, json, time, argparse
import requests

DEFAULT_BASE = os.environ.get("INDOOR360_BASE", "http://127.0.0.1:8000")
TIMEOUT_SECS = float(os.environ.get("INDOOR360_TIMEOUT", "5"))

CASES = [
    # English exacts
    ("Meeting Room 1", "en", "ROOM_NAV"),
    ("meeting room 2", "en", "ROOM_NAV"),
    ("elevator 3", "en", "ROOM_NAV"),
    ("theatre", "en", "ROOM_NAV"),
    ("studio", "en", "ROOM_NAV"),
    ("reception", "en", "ROOM_NAV"),

    # English typos/synonyms
    ("meeitng room 1", "en", "ROOM_NAV"),
    ("lift 3", "en", "ROOM_NAV"),
    ("toilet 1", "en", "ROOM_NAV"),

    # Arabic exact/synonyms (your Phase 4/5 focus)
    ("غرفة الاجتماعات ١", "ar", "ROOM_NAV"),
    ("غرفة الاجتماعات", "ar", "DISAMBIGUATE"),   # family (should list options)
    ("مصعد 3", "ar", "ROOM_NAV"),
    ("اسانسير 3", "ar", "ROOM_NAV"),
    ("غرفة التحكم", "ar", "ROOM_NAV"),
    ("غرفة التحكم الرئيسية", "ar", "ROOM_NAV"),
]

def health_check(base: str) -> bool:
    try:
        r = requests.get(f"{base}/", timeout=TIMEOUT_SECS)
        if r.ok:
            return True
    except Exception:
        pass
    return False

def run_suite(base: str, only: str = None, contains: str = None):
    print(f"[info] Using BASE = {base}")
    print("[info] Health check GET / ...")
    if not health_check(base):
        print("[error] Health check failed. Is the server running?")
        print("        Start it in another terminal:\n"
              "        python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --log-level debug")
        return 0, 0, 0

    # Filtered set
    eval_cases = CASES
    if only:
        eval_cases = [c for c in CASES if c[0] == only]
    if contains:
        eval_cases = [c for c in eval_cases if contains in c[0]]

    results = []
    passed = failed = 0

    for i, (dest, lang, expect_intent) in enumerate(eval_cases, 1):
        body = {"destination": dest, "lang": lang}
        print(f"[{i}/{len(eval_cases)}] POST /api/nlp/resolve  dest='{dest}' lang={lang}  (timeout {TIMEOUT_SECS}s)")
        start = time.time()
        try:
            r = requests.post(
                f"{base}/api/nlp/resolve",
                headers={"Content-Type": "application/json; charset=utf-8"},
                json=body,
                timeout=TIMEOUT_SECS
            )
            elapsed = time.time() - start
            if not r.ok:
                print(f"  -> HTTP {r.status_code}: {r.text[:200]}")
                results.append({
                    "destination": dest, "lang": lang,
                    "status": "HTTP_ERROR", "http_status": r.status_code,
                    "resp": r.text, "elapsed_ms": int(elapsed*1000)
                })
                failed += 1
                continue

            data = r.json()
            intent = data.get("intent")
            ok = (intent == expect_intent) or (expect_intent == "DISAMBIGUATE" and intent == "DISAMBIGUATE")
            results.append({
                "destination": dest, "lang": lang,
                "status": "PASS" if ok else "FAIL",
                "expected_intent": expect_intent,
                "actual_intent": intent,
                "target_poi_id": data.get("target_poi_id"),
                "target_name": data.get("target_name"),
                "confidence": data.get("confidence"),
                "options_count": len(data.get("options") or []),
                "elapsed_ms": int(elapsed*1000),
            })
            if ok:
                passed += 1
                print(f"  -> PASS ({intent}) in {int(elapsed*1000)}ms  name='{data.get('target_name')}'")
            else:
                failed += 1
                print(f"  -> FAIL expected={expect_intent} got={intent} name='{data.get('target_name')}'")

        except requests.exceptions.Timeout:
            elapsed = time.time() - start
            print(f"  -> TIMEOUT after {int(elapsed*1000)}ms")
            results.append({
                "destination": dest, "lang": lang,
                "status": "TIMEOUT", "elapsed_ms": int(elapsed*1000)
            })
            failed += 1
        except Exception as e:
            elapsed = time.time() - start
            print(f"  -> ERROR {e}")
            results.append({
                "destination": dest, "lang": lang,
                "status": "ERROR", "error": str(e), "elapsed_ms": int(elapsed*1000)
            })
            failed += 1

    total = len(eval_cases)
    passpct = (passed / total * 100.0) if total else 0.0

    # Write reports
    os.makedirs("tests/out", exist_ok=True)
    with open("tests/out/nlp_results.json", "w", encoding="utf-8") as f:
        json.dump({"total": total, "passed": passed, "failed": failed, "pass_pct": passpct, "items": results},
                  f, ensure_ascii=False, indent=2)
    with open("tests/out/nlp_results.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(results[0].keys()) if results else
                           ["destination","lang","status","elapsed_ms"])
        w.writeheader()
        for row in results:
            w.writerow(row)

    print("\n=== Phase 5 NLP Suite ===")
    print(f"Total: {total}  Passed: {passed}  Failed: {failed}  Pass%: {passpct:.1f}")
    if passpct >= 95.0:
        print("PASS: Phase 5 threshold met.")
    else:
        print("FAIL: Below threshold.")

    return total, passed, failed

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=DEFAULT_BASE, help="Base URL (default from INDOOR360_BASE or 127.0.0.1:8000)")
    ap.add_argument("--only", help="Run only a destination exactly matching this string")
    ap.add_argument("--contains", help="Run only destinations containing this substring")
    args = ap.parse_args()
    run_suite(args.base, only=args.only, contains=args.contains)

if __name__ == "__main__":
    main()
