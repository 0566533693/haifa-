import os, psycopg

DATABASE_URL = os.getenv("DATABASE_URL")
BOOST = [
    # poi_id, aliases...
    (13, ["theatre", "مسرح"]),
    (15, ["studio", "استوديو", "استديو"]),
    (18, ["reception", "cafe", "ريسبشن", "كوفي"]),
    (12, ["غرفة التحكم", "غرفة التحكم الرئيسية", "كنترول روم", "control room", "control"]),
]

def main():
    with psycopg.connect(DATABASE_URL) as conn, conn.cursor() as cur:
        cur.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_poi_alias_unique
         ON poi_aliases(poi_id, LOWER(alias_text));
        """); conn.commit()
        added = 0
        for pid, al in BOOST:
            for txt in al:
                lg = "ar" if any('\u0600' <= ch <= '\u06FF' for ch in txt) else "en"
                try:
                    cur.execute("""
                      INSERT INTO poi_aliases(poi_id, alias_text, lang)
                      VALUES (%s,%s,%s)
                      ON CONFLICT ON CONSTRAINT uq_poi_alias_unique DO NOTHING
                    """, (pid, txt, lg)); added += cur.rowcount
                except Exception: conn.rollback()
                else: conn.commit()
    print("Inserted:", added)

if __name__ == "__main__":
    main()
