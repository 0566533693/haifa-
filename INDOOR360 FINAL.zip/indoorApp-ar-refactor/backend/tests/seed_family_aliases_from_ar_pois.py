import os, re, psycopg

DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise SystemExit("Set DATABASE_URL")

# Arabic-Indic digits map
AR_DIG = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")

# Families we support (add more if you need)
FAMILIES = {
    "meeting room": {
        "en": ["meeting room {n}", "meeting {n}"],
        "ar": ["غرفة الاجتماعات {n}", "اجتماع {n}", "ميتينج {n}", "ميتينق {n}", "ميتنق {n}",
               "قاعة الاجتماعات {n}", "قاعة اجتماع {n}", "غرفة اجتماع {n}"],
    },
    "elevator": {
        "en": ["elevator {n}", "lift {n}"],
        "ar": ["مصعد {n}", "اسانسير{n}", "اسنصير {n}", "اسنسر {n}"],
    },
    "restroom": {
        "en": ["restroom {n}", "bathroom {n}", "toilet {n}", "wc {n}"],
        "ar": ["حمام {n}", "دورة المياه {n}", "مرحاض {n}"],
    },
    "phone booth": {
        "en": ["phone booth {n}", "booth {n}", "phone {n}"],
        "ar": ["فون بوث {n}", "بوث {n}"],
    },
    "quiet room": {
        "en": ["quiet room {n}", "quiet {n}"],
        "ar": ["غرفة هادئة {n}", "كوايت {n}", "وايت روم {n}", "وايت {n}"],
    },
    "war room": {
        "en": ["war room {n}"],
        "ar": ["غرفة حرب {n}", "غرفة القيادة {n}"],
    },
}

# detect base + number from canonical (English OR Arabic)
EN_FAM_PAT = r'(meeting room|rest ?room|restroom|toilet|wc|elevator|lift|phone booth|booth|quiet room|war room)\s+(\d{1,3})$'
AR_NUM = "٠١٢٣٤٥٦٧٨٩"
AR_NUM_CLASS = f"[{AR_NUM}0-9]+"
AR_FAM_PAT = rf'(غرفة الاجتماعات|قاعة الاجتماعات|قاعة اجتماع|غرفة اجتماع|مصعد|اسانسير|اسنصير|اسنسر|حمام|دورة المياه|مرحاض|فون بوث|بوث|غرفة هادئة|وايت روم|كوايت|غرفة حرب|غرفة القيادة)\s+({AR_NUM_CLASS})$'

def ar_to_western_digits(s: str) -> str:
    tbl = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
    return s.translate(tbl)

def map_ar_base_to_family(s: str) -> str | None:
    s = s.strip()
    if s in {"غرفة الاجتماعات","قاعة الاجتماعات","قاعة اجتماع","غرفة اجتماع"}: return "meeting room"
    if s in {"مصعد","اسانسير","اسنصير","اسنسر"}: return "elevator"
    if s in {"حمام","دورة المياه","مرحاض"}: return "restroom"
    if s in {"فون بوث","بوث"}: return "phone booth"
    if s in {"غرفة هادئة","وايت روم","كوايت","وايت"}: return "quiet room"
    if s in {"غرفة حرب","غرفة القيادة"}: return "war room"
    return None

def detect_family_and_number(name: str):
    s = (name or "").strip().lower()
    s = s.replace("rest room", "restroom")
    m = re.search(EN_FAM_PAT, s)
    if m:
        base_en, n = m.group(1), int(m.group(2))
        base_en = "restroom" if base_en.startswith("rest") or base_en=="toilet" or base_en=="wc" else base_en
        if base_en in {"lift"}: base_en = "elevator"
        return base_en, n

    # Arabic side — keep original for base, normalize digits to western
    m2 = re.search(AR_FAM_PAT, name or "")
    if m2:
        base_ar, nd = m2.group(1), m2.group(2)
        fam = map_ar_base_to_family(base_ar)
        if fam:
            n = int(ar_to_western_digits(nd))
            return fam, n
    return None, None

def ensure_indices(conn):
    with conn.cursor() as cur:
        cur.execute("""
        CREATE TABLE IF NOT EXISTS poi_aliases(
            poi_id     INT NOT NULL,
            alias_text TEXT NOT NULL,
            lang       VARCHAR(5)
        );
        CREATE INDEX IF NOT EXISTS idx_poi_alias_poi  ON poi_aliases(poi_id);
        CREATE INDEX IF NOT EXISTS idx_poi_alias_text ON poi_aliases(alias_text);
        """); conn.commit()
        try:
            cur.execute("""CREATE UNIQUE INDEX uq_poi_alias_unique
                           ON poi_aliases (poi_id, LOWER(alias_text));""")
            conn.commit()
        except Exception:
            conn.rollback()

def main():
    ins = 0
    with psycopg.connect(DATABASE_URL) as conn, conn.cursor() as cur:
        ensure_indices(conn)
        cur.execute("SELECT poi_id, name FROM ar_pois_api ORDER BY poi_id")
        rows = cur.fetchall()

        for pid, nm in rows:
            if not nm: continue
            fam, num = detect_family_and_number(nm)
            if not fam or not num: continue
            for pattern in FAMILIES[fam]["en"]:
                alias = pattern.format(n=num).strip()
                try:
                    cur.execute("""
                      INSERT INTO poi_aliases(poi_id, alias_text, lang)
                      VALUES (%s,%s,'en')
                      ON CONFLICT ON CONSTRAINT uq_poi_alias_unique DO NOTHING
                    """, (pid, alias)); ins += cur.rowcount
                except Exception: conn.rollback()
                else: conn.commit()

            for pattern in FAMILIES[fam]["ar"]:
                alias_en_digits = pattern.format(n=num).strip()
                alias_ar_digits = pattern.format(n=str(num).translate(AR_DIG)).strip()
                for txt in (alias_en_digits, alias_ar_digits):
                    try:
                        cur.execute("""
                          INSERT INTO poi_aliases(poi_id, alias_text, lang)
                          VALUES (%s,%s,'ar')
                          ON CONFLICT ON CONSTRAINT uq_poi_alias_unique DO NOTHING
                        """, (pid, txt)); ins += cur.rowcount
                    except Exception: conn.rollback()
                    else: conn.commit()

    print("Inserted aliases:", ins)

if __name__ == "__main__":
    main()
