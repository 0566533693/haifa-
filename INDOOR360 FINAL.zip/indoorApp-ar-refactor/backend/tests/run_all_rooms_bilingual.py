# tests/run_all_rooms_bilingual.py
import os, re, csv, json, time, argparse
import requests
# --- UTF-8 stdout on Windows ---
import sys, os
if os.name == "nt":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
# --------------------------------

BASE = os.environ.get("INDOOR360_BASE", "http://127.0.0.1:8000")
TIMEOUT = float(os.environ.get("INDOOR360_TIMEOUT", "6"))

# Arabic digits map
AR_DIGITS = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")

FAMILY_SYNS = {
    # base -> {"en":[...], "ar":[...]}
    "meeting room": {
        "en": ["meeting room", "meeting"],
        "ar": ["غرفة الاجتماعات", "اجتماع", "ميتينج", "ميتينق", "ميتنق"],
    },
    "elevator": {
        "en": ["elevator", "lift"],
        "ar": ["مصعد", "اسانسير", "أسانسير", "اصنصير"],
    },
    "restroom": {
        "en": ["restroom", "toilet", "bathroom", "wc", "washroom"],
        "ar": ["حمام", "دورة المياه", "مرحاض", "باثروم", "باتروم"],
    },
    "phone booth": {
        "en": ["phone booth", "booth", "phone"],
        "ar": ["فون بوث", "بوث"],
    },
    "quiet room": {
        "en": ["quiet room", "quiet"],
        "ar": ["غرفة هادئة", "كوايت", "وايت روم"],
    },
    "war room": {
        "en": ["war room", "war"],
        "ar": ["غرفة حرب", "غرفة القيادة", "وور روم", "وير روم"],
    },
}

NUMBERED_BASES = set(FAMILY_SYNS.keys())

def health():
    try:
        r = requests.get(f"{BASE}/", timeout=TIMEOUT)
        return r.ok
    except Exception:
        return False

def dump_pois():
    r = requests.get(f"{BASE}/api/debug/dump_pois", timeout=TIMEOUT)
    r.raise_for_status()
    return r.json().get("items", [])

def list_aliases_for(poi_id: int):
    r = requests.get(f"{BASE}/api/debug/list_aliases", params={"poi_id": poi_id}, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json().get("aliases", [])

def normalize_name(s: str) -> str:
    return (s or "").strip().lower()

def classify_numbered_base(name_norm: str):
    # detect base + number from canonical english-ish names: "meeting room 3", "elevator 2", "restroom 1", ...
    # return (base, n) or (None, None)
    m = re.search(r"(meeting room|elevator|restroom|phone booth|quiet room|war room)\s+(\d{1,3})$", name_norm)
    if m:
        return m.group(1), int(m.group(2))
    return None, None

def ar_number(n: int) -> str:
    return str(n).translate(AR_DIGITS)

def make_variants_for(base: str, n: int):
    """Generate bilingual variants for numbered families."""
    out = []
    syns = FAMILY_SYNS.get(base, {"en":[], "ar":[]})
    for en in syns["en"]:
        out.append( (f"{en} {n}", "en") )
    for ar in syns["ar"]:
        out.append( (f"{ar} {ar_number(n)}", "ar") )
        out.append( (f"{ar} {n}", "ar") )  # some users type Latin digits in Arabic UI
    return out

def test_case(text: str, lang: str, expect_poi: int):
    body = {"destination": text, "lang": lang}
    r = requests.post(
        f"{BASE}/api/nlp/resolve",
        headers={"Content-Type": "application/json; charset=utf-8"},
        json=body, timeout=TIMEOUT
    )
    if not r.ok:
        return ("HTTP_ERROR", r.status_code, r.text)
    data = r.json()
    if data.get("intent") != "ROOM_NAV":
        return ("WRONG_INTENT", data.get("intent"), data)
    if int(data.get("target_poi_id") or -1) != int(expect_poi):
        return ("WRONG_ID", data.get("target_poi_id"), data)
    return ("PASS", 200, data)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=0, help="Test only first N POIs")
    parser.add_argument("--only_ar", action="store_true", help="Run only Arabic checks")
    parser.add_argument("--only_en", action="store_true", help="Run only English checks")
    args = parser.parse_args()

    print(f"[info] BASE = {BASE}")
    if not health():
        print("[error] Health check failed. Start server first:")
        print("  python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --log-level debug")
        return

    pois = dump_pois()
    if args.limit:
        pois = pois[:args.limit]
    print(f"[info] Discovered {len(pois)} POIs from ar_pois_api")

    results = []
    total = passed = failed = 0

    for item in pois:
        pid = int(item["poi_id"])
        name = item.get("name") or ""
        name_norm = normalize_name(name)

        # 1) canonical English name (if not Arabic)
        if not args.only_ar and re.search(r"[a-z]", name_norm):
            total += 1
            st, code, payload = test_case(name, "en", pid)
            results.append({"poi_id": pid, "text": name, "lang": "en", "status": st})
            print(f"[en] {name}  -> {st}")
            passed += (st == "PASS")
            failed += (st != "PASS")

        # 2) all aliases for this poi (both EN/AR)
        aliases = list_aliases_for(pid)
        for al in aliases:
            text = al.get("alias") or ""
            lang = al.get("lang") or "en"
            if args.only_ar and lang != "ar":
                continue
            if args.only_en and lang != "en":
                continue
            if not text:
                continue
            total += 1
            st, code, payload = test_case(text, lang, pid)
            results.append({"poi_id": pid, "text": text, "lang": lang, "status": st})
            print(f"[{lang}] alias:{text}  -> {st}")
            passed += (st == "PASS")
            failed += (st != "PASS")

        # 3) if the canonical is a numbered family, generate bilingual numeric variants
        base, n = classify_numbered_base(name_norm)
        if base and n:
            variants = make_variants_for(base, n)
            for text, lang in variants:
                if args.only_ar and lang != "ar":
                    continue
                if args.only_en and lang != "en":
                    continue
                total += 1
                st, code, payload = test_case(text, lang, pid)
                results.append({"poi_id": pid, "text": text, "lang": lang, "status": st})
                print(f"[{lang}] gen:{text} -> {st}")
                passed += (st == "PASS")
                failed += (st != "PASS")

    # Summary + reports
    pass_pct = (passed / total * 100.0) if total else 0.0
    print("\n=== Phase 5 Bilingual – All Rooms ===")
    print(f"Total: {total}  Passed: {passed}  Failed: {failed}  Pass%: {pass_pct:.1f}")
    if pass_pct >= 95.0:
        print("PASS: Phase 5 threshold met.")
    else:
        print("FAIL: Below threshold.")

    os.makedirs("tests/out", exist_ok=True)
    with open("tests/out/bilingual_results.json", "w", encoding="utf-8") as f:
        json.dump({
            "total": total, "passed": passed, "failed": failed, "pass_pct": pass_pct,
            "items": results
        }, f, ensure_ascii=False, indent=2)
    with open("tests/out/bilingual_results.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["poi_id","text","lang","status"])
        w.writeheader()
        for r in results:
            w.writerow(r)

if __name__ == "__main__":
    main()
