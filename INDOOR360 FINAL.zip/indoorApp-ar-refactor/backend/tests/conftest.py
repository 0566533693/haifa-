# backend/tests/conftest.py
import os, sys

# Add the project root (the folder that contains "api", "app", "NLP") to sys.path
ROOT = os.path.dirname(os.path.dirname(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
