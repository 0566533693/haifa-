import os, psycopg

DATABASE_URL = os.getenv("DATABASE_URL")
pairs = [
    # Control room extras
    (12, "غرفة التحكم الرئيسية", "ar"),
    (12, "غرفه التحكم الرئيسيه", "ar"),
    (12, "كنترول روم", "ar"),
    (12, "control", "en"),
    # Theatre/Studio/Reception extras
    (13, "مسرح", "ar"),
    (15, "استوديو", "ar"),
    (18, "ريسبشن", "ar"), (18, "كوفي", "ar"),
]

def main():
    with psycopg.connect(DATABASE_URL) as conn, conn.cursor() as cur:
        cur.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_poi_alias_unique
        ON poi_aliases (poi_id, LOWER(alias_text));
        """); conn.commit()
        inserted = 0
        for pid, txt, lang in pairs:
            try:
                cur.execute("""
                INSERT INTO poi_aliases(poi_id, alias_text, lang)
                VALUES (%s,%s,%s)
                ON CONFLICT ON CONSTRAINT uq_poi_alias_unique DO NOTHING
                """, (pid, txt, lang))
                inserted += cur.rowcount
                conn.commit()
            except Exception:
                conn.rollback()
        print("Inserted:", inserted)

if __name__ == "__main__":
    main()
