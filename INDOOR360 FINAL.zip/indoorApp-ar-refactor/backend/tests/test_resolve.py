from api.nlp import resolve_query

def t(q, expect_name):
    r = resolve_query(q)
    assert r["intent"] == "navigate_to"
    assert r["target_name"] == expect_name

def test_en_exact():  t("Meeting Room 10", "Meeting Room 10")
def test_en_typo():   t("meeeting room 10", "Meeting Room 10")
def test_war2():      t("War Room 2", "War Room 2")
def test_ar_elev():   t("اسانسير3", "Elevator 3")
def test_ar_digit():  t("مصعد ٣", "Elevator 3")
