﻿import sys
import psycopg
from pathlib import Path

# Add backend directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.config import settings

lvl = "d6aed8cd-fae1-4648-8e88-afd2e1cf8c3e"

with psycopg.connect(settings.DATABASE_URL) as conn, conn.cursor() as cur:
    cur.execute("DELETE FROM pois WHERE floor_imdf_id=%s", (lvl,))
    print("deleted rows:", cur.rowcount)
    conn.commit()
