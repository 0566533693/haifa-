import psycopg2
import csv
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.config import settings

OUTPUT_TSV = os.path.join(os.path.dirname(__file__), "aliases_pwc.tsv")


def main():
    conn = None
    cur = None
    try:
        conn = psycopg2.connect(settings.DATABASE_URL)
        cur = conn.cursor()

        # 1) Build base rows with canonical names
        cur.execute(
            """
            WITH base AS (
                SELECT
                    a.poi_id,
                    a.alias_text,
                    a.lang,
                    COALESCE(en.name, ar.name, a.alias_text) AS canonical
                FROM poi_aliases a
                LEFT JOIN LATERAL (
                    SELECT pn.name
                    FROM poi_names pn
                    WHERE pn.poi_id = a.poi_id
                      AND pn.lang_code = 'en'
                    ORDER BY pn.name
                    LIMIT 1
                ) en ON TRUE
                LEFT JOIN LATERAL (
                    SELECT pn.name
                    FROM poi_names pn
                    WHERE pn.poi_id = a.poi_id
                      AND pn.lang_code = 'ar'
                    ORDER BY pn.name
                    LIMIT 1
                ) ar ON TRUE
            )
            SELECT DISTINCT
                poi_id,
                alias_text,
                lang,
                canonical
            FROM base
            ORDER BY poi_id, lang, alias_text;
            """
        )

        rows = cur.fetchall()
        print(f"Fetched {len(rows)} unique alias rows from DB.")

        # 2) Write TSV
        with open(OUTPUT_TSV, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(["poi_id", "alias_text", "lang", "canonical"])
            for poi_id, alias_text, lang, canonical in rows:
                writer.writerow([poi_id, alias_text, lang, canonical])

        print(f"Written TSV file: {OUTPUT_TSV}")

    except Exception as e:
        print("ERROR during export:", e)
    finally:
        try:
            if cur:
                cur.close()
            if conn:
                conn.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
