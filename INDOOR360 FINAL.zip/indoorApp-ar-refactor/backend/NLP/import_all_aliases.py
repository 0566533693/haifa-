import csv
import psycopg2
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.config import settings

# Path to the TSV/CSV with your aliases (poi_id, alias_text, lang, canonical)
ALIAS_FILE = r"C:\Users\hhs39\OneDrive - University of Wollongong\Desktop\1\.vscode\Indoor360\backend\NLP\aliases_pwc.tsv"


def detect_delimiter(path: str) -> str:
    """
    Detect whether the file is tab / comma / semicolon separated.
    """
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if "\t" in line:
                print("Detected TAB-delimited file.")
                return "\t"
            if ";" in line:
                print("Detected SEMICOLON-delimited file.")
                return ";"
            if "," in line:
                print("Detected COMMA-delimited file.")
                return ","
            # fallback: single column, let csv handle it as tab
            break
    print("Could not detect delimiter clearly, defaulting to TAB.")
    return "\t"


def main():
    if not os.path.exists(ALIAS_FILE):
        print("Alias file not found:", ALIAS_FILE)
        return

    delim = detect_delimiter(ALIAS_FILE)

    conn = psycopg2.connect(settings.DATABASE_URL)
    cur = conn.cursor()

    inserted = 0
    skipped_format = 0
    skipped_db = 0
    total = 0

    print("Reading alias file:", ALIAS_FILE)
    with open(ALIAS_FILE, "r", encoding="utf-8") as f:
        reader = csv.reader(f, delimiter=delim)

        for row in reader:
            total += 1

            # Debug the first few rows so we see the shape
            if total <= 5:
                print("Row", total, "->", repr(row))

            # Skip empty lines
            if not row or all(not c.strip() for c in row):
                continue

            # We expect at least: poi_id, alias_text, lang
            if len(row) < 3:
                skipped_format += 1
                continue

            poi_id_raw = row[0].strip()
            alias_text_raw = row[1].strip()
            lang_raw = row[2].strip()

            # Clean quotes
            alias_text = alias_text_raw.strip('"')
            lang = lang_raw.strip('"').lower()

            if not poi_id_raw or not alias_text or not lang:
                skipped_format += 1
                continue

            try:
                poi_id = int(poi_id_raw)
            except ValueError:
                # probably header like "poi_id"
                skipped_format += 1
                continue

            try:
                cur.execute(
                    """
                    INSERT INTO poi_aliases (poi_id, alias_text, lang)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (poi_id, alias_text_norm) DO NOTHING;
                    """,
                    (poi_id, alias_text, lang),
                )
                if cur.rowcount > 0:
                    inserted += 1
                else:
                    skipped_db += 1
            except Exception as e:
                print(
                    f"DB error on row (poi_id={poi_id}, alias='{alias_text}', lang='{lang}'): {e}"
                )
                skipped_db += 1

    conn.commit()
    cur.close()
    conn.close()

    print("Total lines read:", total)
    print("Inserted aliases:", inserted)
    print("Skipped (format/header/bad lines):", skipped_format)
    print("Skipped (duplicates or DB errors):", skipped_db)


if __name__ == "__main__":
    main()
