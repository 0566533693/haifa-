# backend/NLP/nlp_db_resolver.py

from typing import List, Dict, Any
import os
import sys

# Add parent directory to path for imports when run directly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# Also add NLP directory for when running via uvicorn
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.database import get_connection_v2

# Try both import styles so it works when run as a package (FastAPI)
# and when run directly (python nlp_db_resolver.py from NLP folder)
try:
    from .nlp_preproc_syn import (
        Preprocessor,
        detect_lang,
        build_json_lookup,
        match_json_name_or_family,
    )
except ImportError:
    from NLP.nlp_preproc_syn import (
        Preprocessor,
        detect_lang,
        build_json_lookup,
        match_json_name_or_family,
    )


def _get_alias_match(norm: str, lang: str):
    """
    Exact alias match using v_pois_nlp + poi_aliases.

    Returns rows like:
      (poi_id, default_name, category, floor_id)
    """
    sql = """
        SELECT DISTINCT poi_id, default_name, category, floor_id
        FROM v_pois_nlp
        WHERE alias_text_norm = %s
          AND alias_lang      = %s;
    """
    conn = get_connection_v2()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(sql, (norm, lang))
                rows = cur.fetchall()
        return rows
    finally:
        conn.close()


def _get_all_units_for_lookup():
    """
    Load names from v_pois_nlp to feed into build_json_lookup().
    We use localized_name or default_name as the "name" field.
    """
    sql = """
        SELECT DISTINCT poi_id,
                        default_name,
                        category,
                        floor_id,
                        localized_name
        FROM v_pois_nlp
        WHERE name_lang = 'en';
    """

    conn = get_connection_v2()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                rows = cur.fetchall()
    finally:
        conn.close()

    units = []
    id_map: Dict[str, Dict[str, Any]] = {}

    for poi_id, default_name, category, floor_id, localized_name in rows:
        name = localized_name or default_name
        if not name:
            continue

        # structure expected by build_json_lookup()
        u = {"name": name, "alt_name": None}
        units.append(u)

        # map original name -> metadata
        id_map[name] = {
            "poi_id": poi_id,
            "default_name": default_name,
            "category": category,
            "floor_id": floor_id,
        }

    return units, id_map


def _smart_match(user_text: str):
    """
    Use RAW_CANON_SYNONYM + numbered logic from nlp_preproc_syn
    to match ANY place (meeting, quiet, elevator, phone booth, control, etc.).

    Returns list of tuples:
      (poi_id, default_name, category, floor_id)
    """
    ar_pre = Preprocessor("ar")
    en_pre = Preprocessor("en")

    units, id_map = _get_all_units_for_lookup()
    lookup = build_json_lookup(units)

    match, family = match_json_name_or_family(user_text, lookup, ar_pre, en_pre)

    if match is None:
        return []

    orig_name = match["name"]
    info = id_map.get(orig_name)
    if not info:
        return []

    return [
        (
            info["poi_id"],
            info["default_name"],
            info["category"],
            info["floor_id"],
        )
    ]


def resolve_poi_from_text(user_text: str):
    """
    High-level resolver returning list of 4-tuples:
      (poi_id, default_name, category, floor_id)
    """
    lang = "ar" if detect_lang(user_text) == "ar" else "en"
    pre = Preprocessor(lang)
    norm = pre.norm_any(user_text)
    print(f"[NLP-DB] lang={lang}, norm='{norm}'")

    # 1) Try alias-based match (poi_aliases)
    alias_rows = _get_alias_match(norm, lang)
    if alias_rows:
        print("[NLP-DB] matched via alias table")
        return alias_rows

    # 2) Fallback: smart matching (IMDF names + synonyms)
    print("[NLP-DB] alias not found, using smart matching...")
    smart_rows = _smart_match(user_text)
    return smart_rows


def resolve_text_to_pois(text: str, limit: int = 5) -> List[Dict[str, Any]]:
    """
    Resolver used by /api/nlp/resolve.

    Returns a list of dicts:
      {
        "poiId": int,
        "poiName": str,
        "buildingId": int,
        "floorId": int,
        "confidence": float
      }
    """
    base_rows = resolve_poi_from_text(text)
    print("[NLP-DB] base_rows:", base_rows)

    if not base_rows:
        return []

    conn = get_connection_v2()
    results: List[Dict[str, Any]] = []

    try:
        with conn:
            with conn.cursor() as cur:
                for row in base_rows[:limit]:
                    # row must have at least (poi_id, default_name, category, floor_id)
                    if len(row) < 4:
                        continue

                    poi_id, default_name, category, floor_id = row[:4]

                    # 2) fetch POI + (optional) building/floor info
                    #    NOTE: we are not joining floors anymore — just return buildingId=0
                    cur.execute(
                        """
                        SELECT
                            p.poi_id,
                            COALESCE(pn.name, p.name) AS poi_name,
                            p.floor_id
                        FROM pois p
                        LEFT JOIN poi_names pn
                               ON pn.poi_id = p.poi_id
                              AND pn.lang_code = 'en'
                        WHERE p.poi_id = %s;
                        """,
                        (poi_id,),
                    )
                    rec = cur.fetchone()
                    if not rec:
                        continue

                    poi_id_db, poi_name, floor_id_db = rec

                    results.append(
                        {
                            "poiId": poi_id_db,
                            "poiName": poi_name or default_name or "",
                            "buildingId": 0,  # safe for now; routing uses poiId
                            "floorId": floor_id_db if floor_id_db is not None else 0,
                            "confidence": 1.0,
                        }
                    )
    finally:
        conn.close()

    return results


if __name__ == "__main__":
    # Manual testing from the command line
    tests = [
        "حمام",
        "bathroom",
        "غرفة الاجتماعات ٣",
        "meeting 3",
        "elevator 2",
        "فون بوث 2",
    ]
    for t in tests:
        print("====", t)
        print(resolve_poi_from_text(t))
