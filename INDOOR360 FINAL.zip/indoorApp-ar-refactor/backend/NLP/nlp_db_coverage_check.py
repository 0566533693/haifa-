import psycopg2
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.config import settings

def main():
    conn = psycopg2.connect(settings.DATABASE_URL)
    cur = conn.cursor()

    # total POIs
    cur.execute("SELECT COUNT(*) FROM pois;")
    total_pois = cur.fetchone()[0]

    # POIs with at least one alias
    cur.execute("SELECT COUNT(DISTINCT poi_id) FROM poi_aliases;")
    with_alias = cur.fetchone()[0]

    # POIs that have no name and no alias
    cur.execute(
        """
        SELECT COUNT(*)
        FROM pois p
        LEFT JOIN poi_names n ON n.poi_id = p.poi_id
        LEFT JOIN poi_aliases a ON a.poi_id = p.poi_id
        WHERE n.poi_id IS NULL
          AND a.poi_id IS NULL;
        """
    )
    no_name_no_alias = cur.fetchone()[0]

    print("=== NLP/DB Coverage Report ===")
    print(f"Total POIs:                {total_pois}")
    print(f"POIs with aliases:         {with_alias}")
    print(f"POIs with NO name/alias:   {no_name_no_alias}")

    if no_name_no_alias == 0:
        print("✅ All POIs have at least one name or alias.")
    else:
        print("⚠ Some POIs are missing names/aliases. Inspect them in SQL.")

    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
