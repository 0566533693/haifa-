--
-- PostgreSQL database dump
--
-- ============================================================================
-- Indoor360 Full Database Backup
-- Compatible with pgAdmin Query Tool (uses INSERT instead of COPY)
--
-- PREREQUISITE: PostGIS extension must be installed on the server
-- ============================================================================

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

-- Create PostGIS extension first (required for geography type)
CREATE EXTENSION IF NOT EXISTS postgis;

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sensor_data DROP CONSTRAINT IF EXISTS sensor_data_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.saved_places DROP CONSTRAINT IF EXISTS saved_places_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.saved_places DROP CONSTRAINT IF EXISTS saved_places_poi_id_fkey;
ALTER TABLE IF EXISTS ONLY public.saved_places DROP CONSTRAINT IF EXISTS saved_places_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.routes DROP CONSTRAINT IF EXISTS routes_start_poi_fkey;
ALTER TABLE IF EXISTS ONLY public.routes DROP CONSTRAINT IF EXISTS routes_end_poi_fkey;
ALTER TABLE IF EXISTS ONLY public.qr_anchors DROP CONSTRAINT IF EXISTS qr_anchors_poi_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pois DROP CONSTRAINT IF EXISTS pois_floor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.poi_metadata DROP CONSTRAINT IF EXISTS poi_metadata_poi_id_fkey;
ALTER TABLE IF EXISTS ONLY public.otp_tokens DROP CONSTRAINT IF EXISTS otp_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.navigation_history DROP CONSTRAINT IF EXISTS navigation_history_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.navigation_history DROP CONSTRAINT IF EXISTS navigation_history_route_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nav_edges DROP CONSTRAINT IF EXISTS nav_edges_b_fkey;
ALTER TABLE IF EXISTS ONLY public.nav_edges DROP CONSTRAINT IF EXISTS nav_edges_a_fkey;
ALTER TABLE IF EXISTS ONLY public.imdf_packages DROP CONSTRAINT IF EXISTS imdf_packages_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.imdf_files DROP CONSTRAINT IF EXISTS imdf_files_package_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heatmap_readings DROP CONSTRAINT IF EXISTS heatmap_readings_floor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heatmap_readings DROP CONSTRAINT IF EXISTS heatmap_readings_ap_id_fkey;
ALTER TABLE IF EXISTS ONLY public.floors DROP CONSTRAINT IF EXISTS floors_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.floors DROP CONSTRAINT IF EXISTS floors_building_id_fkey;
ALTER TABLE IF EXISTS ONLY public.error_reports DROP CONSTRAINT IF EXISTS error_reports_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_files DROP CONSTRAINT IF EXISTS blueprint_files_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_files DROP CONSTRAINT IF EXISTS blueprint_files_floor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.anchors DROP CONSTRAINT IF EXISTS anchors_floor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.access_points DROP CONSTRAINT IF EXISTS access_points_building_id_fkey;
DROP TRIGGER IF EXISTS qr_anchors_updated_at_trigger ON public.qr_anchors;
DROP INDEX IF EXISTS public.idx_users_email;
DROP INDEX IF EXISTS public.idx_users_created_at;
DROP INDEX IF EXISTS public.idx_users_auth_provider;
DROP INDEX IF EXISTS public.idx_saved_places_user_id;
DROP INDEX IF EXISTS public.idx_saved_places_poi_id;
DROP INDEX IF EXISTS public.idx_saved_places_category_id;
DROP INDEX IF EXISTS public.idx_qr_anchors_qr_code;
DROP INDEX IF EXISTS public.idx_qr_anchors_floor;
DROP INDEX IF EXISTS public.idx_qr_anchors_active;
DROP INDEX IF EXISTS public.idx_poi_synonyms_synonym_lower;
DROP INDEX IF EXISTS public.idx_poi_synonyms_poi_id;
DROP INDEX IF EXISTS public.idx_poi_names_poi_id;
DROP INDEX IF EXISTS public.idx_poi_names_lang;
DROP INDEX IF EXISTS public.idx_ar_pois_floor;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_unique;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.sensor_data DROP CONSTRAINT IF EXISTS sensor_data_pkey;
ALTER TABLE IF EXISTS ONLY public.saved_places DROP CONSTRAINT IF EXISTS saved_places_user_id_poi_id_key;
ALTER TABLE IF EXISTS ONLY public.saved_places DROP CONSTRAINT IF EXISTS saved_places_pkey;
ALTER TABLE IF EXISTS ONLY public.routes DROP CONSTRAINT IF EXISTS routes_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_role_name_key;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.qr_anchors DROP CONSTRAINT IF EXISTS qr_anchors_qr_code_key;
ALTER TABLE IF EXISTS ONLY public.qr_anchors DROP CONSTRAINT IF EXISTS qr_anchors_pkey;
ALTER TABLE IF EXISTS ONLY public.pois DROP CONSTRAINT IF EXISTS pois_pkey;
ALTER TABLE IF EXISTS ONLY public.pois DROP CONSTRAINT IF EXISTS pois_external_id_key;
ALTER TABLE IF EXISTS ONLY public.poi_synonyms DROP CONSTRAINT IF EXISTS poi_synonyms_pkey;
ALTER TABLE IF EXISTS ONLY public.poi_names DROP CONSTRAINT IF EXISTS poi_names_poi_id_lang_code_key;
ALTER TABLE IF EXISTS ONLY public.poi_names DROP CONSTRAINT IF EXISTS poi_names_pkey;
ALTER TABLE IF EXISTS ONLY public.poi_metadata DROP CONSTRAINT IF EXISTS poi_metadata_pkey;
ALTER TABLE IF EXISTS ONLY public.place_categories DROP CONSTRAINT IF EXISTS place_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.place_categories DROP CONSTRAINT IF EXISTS place_categories_name_key;
ALTER TABLE IF EXISTS ONLY public.otp_tokens DROP CONSTRAINT IF EXISTS otp_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.navigation_history DROP CONSTRAINT IF EXISTS navigation_history_pkey;
ALTER TABLE IF EXISTS ONLY public.nav_nodes DROP CONSTRAINT IF EXISTS nav_nodes_pkey;
ALTER TABLE IF EXISTS ONLY public.nav_edges DROP CONSTRAINT IF EXISTS nav_edges_pkey;
ALTER TABLE IF EXISTS ONLY public.imdf_packages DROP CONSTRAINT IF EXISTS imdf_packages_pkey;
ALTER TABLE IF EXISTS ONLY public.imdf_files DROP CONSTRAINT IF EXISTS imdf_files_pkey;
ALTER TABLE IF EXISTS ONLY public.heatmap_readings DROP CONSTRAINT IF EXISTS heatmap_readings_pkey;
ALTER TABLE IF EXISTS ONLY public.floors DROP CONSTRAINT IF EXISTS floors_pkey;
ALTER TABLE IF EXISTS ONLY public.error_reports DROP CONSTRAINT IF EXISTS error_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.buildings DROP CONSTRAINT IF EXISTS buildings_pkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_files DROP CONSTRAINT IF EXISTS blueprint_files_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.ar_pois_api DROP CONSTRAINT IF EXISTS ar_pois_api_pkey;
ALTER TABLE IF EXISTS ONLY public.anchors DROP CONSTRAINT IF EXISTS anchors_pkey;
ALTER TABLE IF EXISTS ONLY public.access_points DROP CONSTRAINT IF EXISTS access_points_pkey;
ALTER TABLE IF EXISTS ONLY public.access_points DROP CONSTRAINT IF EXISTS access_points_mac_address_key;
ALTER TABLE IF EXISTS public.users ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_roles ALTER COLUMN user_role_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sessions ALTER COLUMN session_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sensor_data ALTER COLUMN sensor_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.saved_places ALTER COLUMN saved_place_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.routes ALTER COLUMN route_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN role_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.qr_anchors ALTER COLUMN qr_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pois ALTER COLUMN poi_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.poi_synonyms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.poi_names ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.poi_metadata ALTER COLUMN metadata_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.place_categories ALTER COLUMN category_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.otp_tokens ALTER COLUMN otp_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.navigation_history ALTER COLUMN history_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.nav_nodes ALTER COLUMN node_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.nav_edges ALTER COLUMN edge_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.imdf_packages ALTER COLUMN package_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.imdf_files ALTER COLUMN file_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.heatmap_readings ALTER COLUMN reading_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.floors ALTER COLUMN floor_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.error_reports ALTER COLUMN error_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.buildings ALTER COLUMN building_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blueprint_files ALTER COLUMN file_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_logs ALTER COLUMN log_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.anchors ALTER COLUMN anchor_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.access_points ALTER COLUMN ap_id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_user_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_roles_user_role_id_seq;
DROP TABLE IF EXISTS public.user_roles;
DROP SEQUENCE IF EXISTS public.sessions_session_id_seq;
DROP TABLE IF EXISTS public.sessions;
DROP SEQUENCE IF EXISTS public.sensor_data_sensor_id_seq;
DROP TABLE IF EXISTS public.sensor_data;
DROP SEQUENCE IF EXISTS public.saved_places_saved_place_id_seq;
DROP TABLE IF EXISTS public.saved_places;
DROP SEQUENCE IF EXISTS public.routes_route_id_seq;
DROP TABLE IF EXISTS public.routes;
DROP SEQUENCE IF EXISTS public.roles_role_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP SEQUENCE IF EXISTS public.qr_anchors_qr_id_seq;
DROP TABLE IF EXISTS public.qr_anchors;
DROP SEQUENCE IF EXISTS public.pois_poi_id_seq;
DROP TABLE IF EXISTS public.pois;
DROP SEQUENCE IF EXISTS public.poi_synonyms_id_seq;
DROP TABLE IF EXISTS public.poi_synonyms;
DROP SEQUENCE IF EXISTS public.poi_names_id_seq;
DROP TABLE IF EXISTS public.poi_names;
DROP SEQUENCE IF EXISTS public.poi_metadata_metadata_id_seq;
DROP TABLE IF EXISTS public.poi_metadata;
DROP SEQUENCE IF EXISTS public.place_categories_category_id_seq;
DROP TABLE IF EXISTS public.place_categories;
DROP SEQUENCE IF EXISTS public.otp_tokens_otp_id_seq;
DROP TABLE IF EXISTS public.otp_tokens;
DROP SEQUENCE IF EXISTS public.navigation_history_history_id_seq;
DROP TABLE IF EXISTS public.navigation_history;
DROP SEQUENCE IF EXISTS public.nav_nodes_node_id_seq;
DROP TABLE IF EXISTS public.nav_nodes;
DROP SEQUENCE IF EXISTS public.nav_edges_edge_id_seq;
DROP TABLE IF EXISTS public.nav_edges;
DROP SEQUENCE IF EXISTS public.imdf_packages_package_id_seq;
DROP TABLE IF EXISTS public.imdf_packages;
DROP SEQUENCE IF EXISTS public.imdf_files_file_id_seq;
DROP TABLE IF EXISTS public.imdf_files;
DROP SEQUENCE IF EXISTS public.heatmap_readings_reading_id_seq;
DROP TABLE IF EXISTS public.heatmap_readings;
DROP SEQUENCE IF EXISTS public.floors_floor_id_seq;
DROP TABLE IF EXISTS public.floors;
DROP SEQUENCE IF EXISTS public.error_reports_error_id_seq;
DROP TABLE IF EXISTS public.error_reports;
DROP SEQUENCE IF EXISTS public.buildings_building_id_seq;
DROP TABLE IF EXISTS public.buildings;
DROP SEQUENCE IF EXISTS public.blueprint_files_file_id_seq;
DROP TABLE IF EXISTS public.blueprint_files;
DROP SEQUENCE IF EXISTS public.audit_logs_log_id_seq;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.ar_pois_api;
DROP SEQUENCE IF EXISTS public.anchors_anchor_id_seq;
DROP TABLE IF EXISTS public.anchors;
DROP SEQUENCE IF EXISTS public.access_points_ap_id_seq;
DROP TABLE IF EXISTS public.access_points;
DROP FUNCTION IF EXISTS public.update_qr_anchors_updated_at();
DROP EXTENSION IF EXISTS postgis;
--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: update_qr_anchors_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_qr_anchors_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_points (
    ap_id integer NOT NULL,
    building_id integer,
    ssid character varying(100),
    mac_address character varying(50),
    location public.geography(Point,4326)
);


--
-- Name: access_points_ap_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.access_points_ap_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: access_points_ap_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.access_points_ap_id_seq OWNED BY public.access_points.ap_id;


--
-- Name: anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.anchors (
    anchor_id integer NOT NULL,
    floor_id integer,
    coordinates public.geography(Point,4326),
    anchor_type character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: anchors_anchor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.anchors_anchor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: anchors_anchor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.anchors_anchor_id_seq OWNED BY public.anchors.anchor_id;


--
-- Name: ar_pois_api; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_pois_api (
    poi_id integer NOT NULL,
    name text,
    category text,
    floor text,
    x double precision,
    y double precision,
    z double precision,
    wgs84_geom public.geometry(Point,4326)
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    log_id integer NOT NULL,
    user_id integer,
    action character varying(150),
    details text,
    "timestamp" timestamp without time zone DEFAULT now()
);


--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_log_id_seq OWNED BY public.audit_logs.log_id;


--
-- Name: blueprint_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blueprint_files (
    file_id integer NOT NULL,
    floor_id integer,
    file_path text,
    version_number character varying(50),
    uploaded_by integer,
    "timestamp" timestamp without time zone DEFAULT now()
);


--
-- Name: blueprint_files_file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blueprint_files_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blueprint_files_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blueprint_files_file_id_seq OWNED BY public.blueprint_files.file_id;


--
-- Name: buildings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.buildings (
    building_id integer NOT NULL,
    name character varying(150),
    address text,
    description text
);


--
-- Name: buildings_building_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.buildings_building_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: buildings_building_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.buildings_building_id_seq OWNED BY public.buildings.building_id;


--
-- Name: error_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_reports (
    error_id integer NOT NULL,
    user_id integer,
    error_type character varying(100),
    description text,
    "timestamp" timestamp without time zone DEFAULT now()
);


--
-- Name: error_reports_error_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_reports_error_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_reports_error_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_reports_error_id_seq OWNED BY public.error_reports.error_id;


--
-- Name: floors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.floors (
    floor_id integer NOT NULL,
    building_id integer,
    floor_number integer,
    name character varying(100),
    blueprint_file text,
    version character varying(50),
    uploaded_by integer,
    uploaded_at timestamp without time zone DEFAULT now()
);


--
-- Name: floors_floor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.floors_floor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: floors_floor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.floors_floor_id_seq OWNED BY public.floors.floor_id;


--
-- Name: heatmap_readings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heatmap_readings (
    reading_id integer NOT NULL,
    floor_id integer,
    ap_id integer,
    coordinates public.geography(Point,4326),
    rssi_value integer,
    "timestamp" timestamp without time zone DEFAULT now()
);


--
-- Name: heatmap_readings_reading_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.heatmap_readings_reading_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: heatmap_readings_reading_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.heatmap_readings_reading_id_seq OWNED BY public.heatmap_readings.reading_id;


--
-- Name: imdf_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imdf_files (
    file_id integer NOT NULL,
    package_id integer,
    file_name text,
    data jsonb,
    uploaded_at timestamp without time zone DEFAULT now()
);


--
-- Name: imdf_files_file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.imdf_files_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: imdf_files_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.imdf_files_file_id_seq OWNED BY public.imdf_files.file_id;


--
-- Name: imdf_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imdf_packages (
    package_id integer NOT NULL,
    name text,
    version text,
    uploaded_by integer,
    uploaded_at timestamp without time zone DEFAULT now()
);


--
-- Name: imdf_packages_package_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.imdf_packages_package_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: imdf_packages_package_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.imdf_packages_package_id_seq OWNED BY public.imdf_packages.package_id;


--
-- Name: nav_edges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nav_edges (
    edge_id integer NOT NULL,
    a integer,
    b integer,
    cost double precision NOT NULL
);


--
-- Name: nav_edges_edge_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nav_edges_edge_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nav_edges_edge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nav_edges_edge_id_seq OWNED BY public.nav_edges.edge_id;


--
-- Name: nav_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nav_nodes (
    node_id integer NOT NULL,
    floor integer NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    z double precision NOT NULL
);


--
-- Name: nav_nodes_node_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nav_nodes_node_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nav_nodes_node_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nav_nodes_node_id_seq OWNED BY public.nav_nodes.node_id;


--
-- Name: navigation_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.navigation_history (
    history_id integer NOT NULL,
    user_id integer,
    route_id integer,
    start_time timestamp without time zone DEFAULT now(),
    end_time timestamp without time zone
);


--
-- Name: navigation_history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.navigation_history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: navigation_history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.navigation_history_history_id_seq OWNED BY public.navigation_history.history_id;


--
-- Name: otp_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_tokens (
    otp_id integer NOT NULL,
    user_id integer,
    otp_code character varying(10),
    expires_at timestamp without time zone,
    is_used boolean DEFAULT false
);


--
-- Name: otp_tokens_otp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.otp_tokens_otp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: otp_tokens_otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.otp_tokens_otp_id_seq OWNED BY public.otp_tokens.otp_id;


--
-- Name: place_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.place_categories (
    category_id integer NOT NULL,
    name character varying(50) NOT NULL,
    icon character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: place_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.place_categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: place_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.place_categories_category_id_seq OWNED BY public.place_categories.category_id;


--
-- Name: poi_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poi_metadata (
    metadata_id integer NOT NULL,
    poi_id integer,
    language character varying(10),
    label character varying(150),
    description text,
    offers text
);


--
-- Name: poi_metadata_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.poi_metadata_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: poi_metadata_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.poi_metadata_metadata_id_seq OWNED BY public.poi_metadata.metadata_id;


--
-- Name: poi_names; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poi_names (
    id integer NOT NULL,
    poi_id integer NOT NULL,
    lang_code character varying(10) DEFAULT 'en'::character varying NOT NULL,
    name text NOT NULL
);


--
-- Name: poi_names_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.poi_names_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: poi_names_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.poi_names_id_seq OWNED BY public.poi_names.id;


--
-- Name: poi_synonyms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poi_synonyms (
    id integer NOT NULL,
    poi_id integer NOT NULL,
    lang character varying(10) DEFAULT 'en'::character varying NOT NULL,
    synonym text NOT NULL
);


--
-- Name: poi_synonyms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.poi_synonyms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: poi_synonyms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.poi_synonyms_id_seq OWNED BY public.poi_synonyms.id;


--
-- Name: pois; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pois (
    poi_id integer NOT NULL,
    floor_id integer,
    name character varying(150),
    type character varying(50),
    coordinates public.geography(Point,4326),
    description text,
    accessible_features text,
    external_id text,
    nearest_node integer
);


--
-- Name: pois_poi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pois_poi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pois_poi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pois_poi_id_seq OWNED BY public.pois.poi_id;


--
-- Name: qr_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qr_anchors (
    qr_id integer NOT NULL,
    qr_code character varying(100) NOT NULL,
    poi_id integer,
    location_name character varying(255) NOT NULL,
    floor_level integer NOT NULL,
    x double precision DEFAULT 0,
    y double precision DEFAULT 0,
    z double precision DEFAULT 0,
    description text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: qr_anchors_qr_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qr_anchors_qr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qr_anchors_qr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qr_anchors_qr_id_seq OWNED BY public.qr_anchors.qr_id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    role_id integer NOT NULL,
    role_name character varying(50),
    description text
);


--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.role_id;


--
-- Name: routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.routes (
    route_id integer NOT NULL,
    start_poi integer,
    end_poi integer,
    path_geometry public.geography(LineString,4326),
    distance_meters double precision,
    estimated_time integer
);


--
-- Name: routes_route_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.routes_route_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: routes_route_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.routes_route_id_seq OWNED BY public.routes.route_id;


--
-- Name: saved_places; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_places (
    saved_place_id integer NOT NULL,
    user_id integer NOT NULL,
    poi_id integer,
    title character varying(200) NOT NULL,
    category_id integer,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: saved_places_saved_place_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.saved_places_saved_place_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: saved_places_saved_place_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.saved_places_saved_place_id_seq OWNED BY public.saved_places.saved_place_id;


--
-- Name: sensor_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sensor_data (
    sensor_id integer NOT NULL,
    user_id integer,
    type character varying(50),
    reading jsonb,
    "timestamp" timestamp without time zone DEFAULT now()
);


--
-- Name: sensor_data_sensor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sensor_data_sensor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sensor_data_sensor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sensor_data_sensor_id_seq OWNED BY public.sensor_data.sensor_id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    session_id integer NOT NULL,
    user_id integer,
    jwt_token text,
    device_info text,
    started_at timestamp without time zone DEFAULT now(),
    ended_at timestamp without time zone
);


--
-- Name: sessions_session_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_session_id_seq OWNED BY public.sessions.session_id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_role_id integer NOT NULL,
    user_id integer,
    role_id integer,
    assigned_at timestamp without time zone DEFAULT now()
);


--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_roles_user_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_roles_user_role_id_seq OWNED BY public.user_roles.user_role_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    name character varying(100),
    email character varying(150) NOT NULL,
    phone character varying(20),
    password_hash text,
    auth_provider character varying(50),
    role character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    date_of_birth date,
    CONSTRAINT users_email_format_check CHECK (((email)::text ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::text))
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: access_points ap_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_points ALTER COLUMN ap_id SET DEFAULT nextval('public.access_points_ap_id_seq'::regclass);


--
-- Name: anchors anchor_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anchors ALTER COLUMN anchor_id SET DEFAULT nextval('public.anchors_anchor_id_seq'::regclass);


--
-- Name: audit_logs log_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN log_id SET DEFAULT nextval('public.audit_logs_log_id_seq'::regclass);


--
-- Name: blueprint_files file_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blueprint_files ALTER COLUMN file_id SET DEFAULT nextval('public.blueprint_files_file_id_seq'::regclass);


--
-- Name: buildings building_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buildings ALTER COLUMN building_id SET DEFAULT nextval('public.buildings_building_id_seq'::regclass);


--
-- Name: error_reports error_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_reports ALTER COLUMN error_id SET DEFAULT nextval('public.error_reports_error_id_seq'::regclass);


--
-- Name: floors floor_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floors ALTER COLUMN floor_id SET DEFAULT nextval('public.floors_floor_id_seq'::regclass);


--
-- Name: heatmap_readings reading_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heatmap_readings ALTER COLUMN reading_id SET DEFAULT nextval('public.heatmap_readings_reading_id_seq'::regclass);


--
-- Name: imdf_files file_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imdf_files ALTER COLUMN file_id SET DEFAULT nextval('public.imdf_files_file_id_seq'::regclass);


--
-- Name: imdf_packages package_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imdf_packages ALTER COLUMN package_id SET DEFAULT nextval('public.imdf_packages_package_id_seq'::regclass);


--
-- Name: nav_edges edge_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nav_edges ALTER COLUMN edge_id SET DEFAULT nextval('public.nav_edges_edge_id_seq'::regclass);


--
-- Name: nav_nodes node_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nav_nodes ALTER COLUMN node_id SET DEFAULT nextval('public.nav_nodes_node_id_seq'::regclass);


--
-- Name: navigation_history history_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_history ALTER COLUMN history_id SET DEFAULT nextval('public.navigation_history_history_id_seq'::regclass);


--
-- Name: otp_tokens otp_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_tokens ALTER COLUMN otp_id SET DEFAULT nextval('public.otp_tokens_otp_id_seq'::regclass);


--
-- Name: place_categories category_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_categories ALTER COLUMN category_id SET DEFAULT nextval('public.place_categories_category_id_seq'::regclass);


--
-- Name: poi_metadata metadata_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_metadata ALTER COLUMN metadata_id SET DEFAULT nextval('public.poi_metadata_metadata_id_seq'::regclass);


--
-- Name: poi_names id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_names ALTER COLUMN id SET DEFAULT nextval('public.poi_names_id_seq'::regclass);


--
-- Name: poi_synonyms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_synonyms ALTER COLUMN id SET DEFAULT nextval('public.poi_synonyms_id_seq'::regclass);


--
-- Name: pois poi_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pois ALTER COLUMN poi_id SET DEFAULT nextval('public.pois_poi_id_seq'::regclass);


--
-- Name: qr_anchors qr_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_anchors ALTER COLUMN qr_id SET DEFAULT nextval('public.qr_anchors_qr_id_seq'::regclass);


--
-- Name: roles role_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN role_id SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- Name: routes route_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routes ALTER COLUMN route_id SET DEFAULT nextval('public.routes_route_id_seq'::regclass);


--
-- Name: saved_places saved_place_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_places ALTER COLUMN saved_place_id SET DEFAULT nextval('public.saved_places_saved_place_id_seq'::regclass);


--
-- Name: sensor_data sensor_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sensor_data ALTER COLUMN sensor_id SET DEFAULT nextval('public.sensor_data_sensor_id_seq'::regclass);


--
-- Name: sessions session_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN session_id SET DEFAULT nextval('public.sessions_session_id_seq'::regclass);


--
-- Name: user_roles user_role_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN user_role_id SET DEFAULT nextval('public.user_roles_user_role_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: access_points; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: anchors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ar_pois_api; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ar_pois_api VALUES (319, 'Phone Booth 5', 'room', '1', -7.384671427309513, -2.1105857146903872, 0, '0101000020E6100000B7B8ACE923A34B4068923ED45F333940');
INSERT INTO public.ar_pois_api VALUES (320, 'Meeting Room 1', 'room', '1', -9.772439999505877, -0.07881000032648444, 0, '0101000020E6100000CA47393523A34B4063E1560761333940');
INSERT INTO public.ar_pois_api VALUES (321, 'Meeting Room 2', 'room', '1', -14.615924999117851, 2.430900000035763, 0, '0101000020E6100000DAD42FC721A34B404B17AC8262333940');
INSERT INTO public.ar_pois_api VALUES (322, 'Quiet Room 3', 'room', '1', -10.085737500339746, -4.388662500306964, 0, '0101000020E610000001028C1D23A34B40A909EC7B5E333940');
INSERT INTO public.ar_pois_api VALUES (323, 'Meeting Room 3', 'room', '1', -12.489085713401437, -3.548828572034836, 0, '0101000020E6100000EE26EB6722A34B402B11DCFA5E333940');
INSERT INTO public.ar_pois_api VALUES (324, 'Meeting Room 4', 'room', '1', -14.671424999833107, -2.225550000090152, 0, '0101000020E6100000F216FEC221A34B408236DEC25F333940');
INSERT INTO public.ar_pois_api VALUES (325, 'Quiet Room 4', 'room', '1', -17.219271427951753, -1.33199999993667, 0, '0101000020E61000009AAB710221A34B401DB3EC4960333940');
INSERT INTO public.ar_pois_api VALUES (326, 'Board Room', 'room', '1', -18.808949999511242, -13.879162500146776, 0, '0101000020E6100000FBA24E8A20A34B407C5578E158333940');
INSERT INTO public.ar_pois_api VALUES (327, 'Meeting Room 5', 'room', '1', -12.556874999776483, -18.507862499915063, 0, '0101000020E610000033A7CB6222A34B409C32DC2556333940');
INSERT INTO public.ar_pois_api VALUES (328, 'Meeting Room 6', 'room', '1', -2.9288142854347825, -23.389285714365542, 0, '0101000020E6100000D0D96A3A25A34B405D570D4453333940');
INSERT INTO public.ar_pois_api VALUES (329, 'Meeting Room 11', 'room', '1', 5.115712501108646, -26.15576250012964, 0, '0101000020E6100000B8E45D9A27A34B4074F3E8A151333940');
INSERT INTO public.ar_pois_api VALUES (283, 'Theatre', 'theater', '1', 22.489525000564754, 21.356399999931455, 0, '0101000020E6100000D7D25BBB2CA34B40D40330AF6D333940');
INSERT INTO public.ar_pois_api VALUES (284, 'Restroom1', 'room', '1', 5.397771428339183, 1.2447857139632106, 0, '0101000020E610000082CDAEAF27A34B402F4C65CF61333940');
INSERT INTO public.ar_pois_api VALUES (285, 'Meeting Room 10', 'room', '1', -5.0369333336129785, -9.596566666848958, 0, '0101000020E61000007DB4199B24A34B400686C4685B333940');
INSERT INTO public.ar_pois_api VALUES (286, 'Meeitng Room 9', 'room', '1', 1.5775875002145767, -13.04666250012815, 0, '0101000020E610000026DAFA8E26A34B40B2964C5F59333940');
INSERT INTO public.ar_pois_api VALUES (287, 'Reception / Cafe', 'walkway', '1', -4.9522086950019, 2.531926086638123, 0, '0101000020E6100000DFD880A124A34B403922F19162333940');
INSERT INTO public.ar_pois_api VALUES (288, 'Meeitng Room 12', 'room', '1', 8.727771429345012, -14.707500000018626, 0, '0101000020E6100000ED4F57AB28A34B40F723456458333940');
INSERT INTO public.ar_pois_api VALUES (289, 'Meeting Room 13', 'room', '1', 11.402475000359118, -10.919625000096858, 0, '0101000020E6100000A0FF797529A34B4043E6CAA05A333940');
INSERT INTO public.ar_pois_api VALUES (290, 'Meeting Room 14', 'room', '1', 12.925950000062585, -8.198737499769777, 0, '0101000020E61000002C369CE829A34B400A490B3C5C333940');
INSERT INTO public.ar_pois_api VALUES (291, 'Difference Area', 'room', '1', 9.240133333951235, 33.95489999977872, 0, '0101000020E6100000F4D20FD228A34B4094CD661F75333940');
INSERT INTO public.ar_pois_api VALUES (292, 'Studio', 'room', '1', 24.941700000315905, 34.188000000081956, 0, '0101000020E61000000651AD742DA34B40003CA24275333940');
INSERT INTO public.ar_pois_api VALUES (293, 'Studio', 'walkway', '1', 28.67382272798568, 21.462859090883285, 0, '0101000020E6100000D392B98E2EA34B406F4747BF6D333940');
INSERT INTO public.ar_pois_api VALUES (294, 'Phone Booth 4', 'room', '1', 29.41083750128746, 29.435812499839813, 0, '0101000020E61000007C606CC62EA34B406FF25B7472333940');
INSERT INTO public.ar_pois_api VALUES (295, 'Phone booth 3', 'room', '1', 28.601528571918607, 27.748414285480976, 0, '0101000020E610000093EB42892EA34B4047C6507571333940');
INSERT INTO public.ar_pois_api VALUES (296, 'Raised Area', 'room', '1', 25.978933334350586, 7.893333333078772, 0, '0101000020E6100000B05B10C32DA34B402C344CBC65333940');
INSERT INTO public.ar_pois_api VALUES (297, 'Quiet Room 1', 'room', '1', 17.07972857169807, 24.73555714264512, 0, '0101000020E6100000181E86222BA34B403D17EFAD6F333940');
INSERT INTO public.ar_pois_api VALUES (298, 'Quiet Room 2', 'room', '1', 14.867657143622637, 25.79005714226514, 0, '0101000020E610000017D6597B2AA34B40B347514D70333940');
INSERT INTO public.ar_pois_api VALUES (299, 'Production Room', 'room', '1', 22.19167499989271, 29.10234999936074, 0, '0101000020E6100000BC68D9A42CA34B404026F54172333940');
INSERT INTO public.ar_pois_api VALUES (300, 'Elevator 5', 'room', '1', 8.860971429385245, 4.500257142819464, 0, '0101000020E6100000E74A68B528A34B407F8D72BB63333940');
INSERT INTO public.ar_pois_api VALUES (301, 'Elevator 4', 'room', '1', 6.39042857196182, 5.651485714595765, 0, '0101000020E61000003771B3FA27A34B40CF7F736964333940');
INSERT INTO public.ar_pois_api VALUES (302, 'Elevator 3', 'room', '1', 12.874414286576211, 8.857799999881536, 0, '0101000020E6100000672AB7E429A34B408AB2124E66333940');
INSERT INTO public.ar_pois_api VALUES (303, 'Elevator 2', 'room', '1', 10.429837500676513, 10.313287499826401, 0, '0101000020E61000004FACF82B29A34B40C274102A67333940');
INSERT INTO public.ar_pois_api VALUES (304, 'Elevator 1', 'room', '1', 7.911128572188318, 11.163428571540862, 0, '0101000020E6100000DEF79F6D28A34B40C84D8FAA67333940');
INSERT INTO public.ar_pois_api VALUES (305, 'Restroom2', 'room', '1', 11.782976470887661, 12.991570588201284, 0, '0101000020E610000038723B9229A34B401A55E0BE68333940');
INSERT INTO public.ar_pois_api VALUES (306, 'Store Room', 'room', '1', -3.201557142660022, -4.944257142953575, 0, '0101000020E61000003E2DCE2525A34B404831F2275E333940');
INSERT INTO public.ar_pois_api VALUES (307, 'IDF Room', 'room', '1', 3.5797499995678663, -8.498437500093132, 0, '0101000020E6100000A4164A2627A34B40A4DFBE0E5C333940');
INSERT INTO public.ar_pois_api VALUES (308, 'Meeting Room 7', 'room', '1', -8.290114285424352, -13.79095714353025, 0, '0101000020E610000000643FA523A34B408B4CCDEE58333940');
INSERT INTO public.ar_pois_api VALUES (309, 'Meeting Room 8', 'room', '1', -0.33934285677969456, -17.47932857181877, 0, '0101000020E610000096931CFE25A34B40E2AB51C156333940');
INSERT INTO public.ar_pois_api VALUES (310, 'Phone Booth 2', 'room', '1', 22.27928571496159, 10.917642856482416, 0, '0101000020E6100000266378AB2CA34B40E304698567333940');
INSERT INTO public.ar_pois_api VALUES (311, 'Phone booth 1', 'room', '1', 21.069385714828968, 8.854628570843488, 0, '0101000020E6100000C7D008502CA34B40EBFB974D66333940');
INSERT INTO public.ar_pois_api VALUES (312, 'Testing Room', 'room', '1', 20.72092500049621, 6.261787499766797, 0, '0101000020E61000003440B3352CA34B405826B2C564333940');
INSERT INTO public.ar_pois_api VALUES (313, 'Control Room', 'room', '1', 18.8906142860651, 2.754385713953525, 0, '0101000020E610000083C760AB2BA34B4052DA90B362333940');
INSERT INTO public.ar_pois_api VALUES (314, 'Emerging Tech Lab', 'room', '1', 23.21503333374858, 0.4957999996840954, 0, '0101000020E6100000EC0330F22CA34B40947E305E61333940');
INSERT INTO public.ar_pois_api VALUES (315, 'War Room 3', 'room', '1', 20.925085715018213, -4.227514286059886, 0, '0101000020E6100000381621452CA34B40EF6847945E333940');
INSERT INTO public.ar_pois_api VALUES (316, 'War Room 2', 'room', '1', 17.383709999732673, -9.408360000234097, 0, '0101000020E6100000A8277F392BA34B4012E136855B333940');
INSERT INTO public.ar_pois_api VALUES (317, 'War Room 1', 'room', '1', 14.88232500012964, -16.817887499928474, 0, '0101000020E6100000649C757C2AA34B4024134B2557333940');
INSERT INTO public.ar_pois_api VALUES (318, 'Luggage Storage', 'room', '1', -5.916299999691546, 0.7298249998129904, 0, '0101000020E6100000C4DCA45824A34B4098B78F8161333940');


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: blueprint_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: buildings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.buildings VALUES (3, 'PwC Building', NULL, NULL);


--
-- Data for Name: error_reports; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: floors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.floors VALUES (4, 3, 1, 'Ground Floor', NULL, NULL, NULL, '2025-11-25 20:41:35.557548');


--
-- Data for Name: heatmap_readings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: imdf_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: imdf_packages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: nav_edges; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.nav_edges VALUES (3598, 283, 293, 6.185213974870436);
INSERT INTO public.nav_edges VALUES (3599, 283, 297, 6.3784481183922415);
INSERT INTO public.nav_edges VALUES (3600, 283, 299, 7.751674401105059);
INSERT INTO public.nav_edges VALUES (3601, 283, 298, 8.817606551172041);
INSERT INTO public.nav_edges VALUES (3602, 283, 295, 8.843892484378227);
INSERT INTO public.nav_edges VALUES (3603, 283, 310, 10.440874065536674);
INSERT INTO public.nav_edges VALUES (3604, 284, 301, 4.517120000099132);
INSERT INTO public.nav_edges VALUES (3605, 284, 300, 4.753088308083141);
INSERT INTO public.nav_edges VALUES (3606, 284, 307, 9.911387416581055);
INSERT INTO public.nav_edges VALUES (3607, 284, 304, 10.232127846150249);
INSERT INTO public.nav_edges VALUES (3608, 284, 303, 10.371085458457854);
INSERT INTO public.nav_edges VALUES (3609, 284, 287, 10.429708476352738);
INSERT INTO public.nav_edges VALUES (3610, 285, 306, 5.0012588084770595);
INSERT INTO public.nav_edges VALUES (3611, 285, 308, 5.308116217470103);
INSERT INTO public.nav_edges VALUES (3612, 285, 322, 7.253460506720842);
INSERT INTO public.nav_edges VALUES (3613, 285, 286, 7.460231036218244);
INSERT INTO public.nav_edges VALUES (3614, 285, 319, 7.845494565646031);
INSERT INTO public.nav_edges VALUES (3615, 285, 307, 8.686375500337572);
INSERT INTO public.nav_edges VALUES (3616, 286, 309, 4.829404776808559);
INSERT INTO public.nav_edges VALUES (3617, 286, 307, 4.969406938839966);
INSERT INTO public.nav_edges VALUES (3618, 286, 288, 7.340538905186899);
INSERT INTO public.nav_edges VALUES (3619, 286, 306, 9.406869621901093);
INSERT INTO public.nav_edges VALUES (3620, 286, 308, 9.895732062378887);
INSERT INTO public.nav_edges VALUES (3621, 287, 318, 2.043780901100091);
INSERT INTO public.nav_edges VALUES (3622, 287, 319, 5.241163112421662);
INSERT INTO public.nav_edges VALUES (3623, 287, 320, 5.481840270221952);
INSERT INTO public.nav_edges VALUES (3624, 287, 306, 7.678417580713481);
INSERT INTO public.nav_edges VALUES (3625, 287, 322, 8.616708442381682);
INSERT INTO public.nav_edges VALUES (3626, 287, 321, 9.664244361782893);
INSERT INTO public.nav_edges VALUES (3627, 288, 289, 4.637028812491618);
INSERT INTO public.nav_edges VALUES (3628, 288, 317, 6.506325004192667);
INSERT INTO public.nav_edges VALUES (3629, 288, 290, 7.745236768405138);
INSERT INTO public.nav_edges VALUES (3630, 288, 307, 8.065642055001362);
INSERT INTO public.nav_edges VALUES (3631, 288, 309, 9.481328762443047);
INSERT INTO public.nav_edges VALUES (3632, 289, 290, 3.118365736226802);
INSERT INTO public.nav_edges VALUES (3633, 289, 316, 6.169205299234688);
INSERT INTO public.nav_edges VALUES (3634, 289, 317, 6.8482739826844465);
INSERT INTO public.nav_edges VALUES (3635, 289, 307, 8.188844566651454);
INSERT INTO public.nav_edges VALUES (3636, 286, 289, 10.052497347072864);
INSERT INTO public.nav_edges VALUES (3637, 290, 316, 4.618962092167614);
INSERT INTO public.nav_edges VALUES (3638, 290, 317, 8.838390682989353);
INSERT INTO public.nav_edges VALUES (3639, 290, 315, 8.930665484537178);
INSERT INTO public.nav_edges VALUES (3640, 290, 307, 9.351003932054846);
INSERT INTO public.nav_edges VALUES (3641, 291, 298, 9.916334156987993);
INSERT INTO public.nav_edges VALUES (3642, 291, 297, 12.101881515296226);
INSERT INTO public.nav_edges VALUES (3643, 291, 299, 13.830750992994012);
INSERT INTO public.nav_edges VALUES (3644, 291, 292, 15.70329683150065);
INSERT INTO public.nav_edges VALUES (3645, 283, 291, 18.283013476712696);
INSERT INTO public.nav_edges VALUES (3646, 291, 295, 20.331849165121756);
INSERT INTO public.nav_edges VALUES (3647, 292, 299, 5.7815632338739364);
INSERT INTO public.nav_edges VALUES (3648, 292, 294, 6.523532481633499);
INSERT INTO public.nav_edges VALUES (3649, 292, 295, 7.40692981939875);
INSERT INTO public.nav_edges VALUES (3650, 292, 297, 12.294684652611014);
INSERT INTO public.nav_edges VALUES (3651, 283, 292, 13.063809581753029);
INSERT INTO public.nav_edges VALUES (3652, 292, 298, 13.115326290707749);
INSERT INTO public.nav_edges VALUES (3653, 293, 295, 6.285970931470848);
INSERT INTO public.nav_edges VALUES (3654, 293, 294, 8.006945537389022);
INSERT INTO public.nav_edges VALUES (3655, 293, 299, 10.018985004245348);
INSERT INTO public.nav_edges VALUES (3656, 293, 297, 12.0471395708611);
INSERT INTO public.nav_edges VALUES (3657, 293, 310, 12.332545926629734);
INSERT INTO public.nav_edges VALUES (3658, 294, 295, 1.871441603820847);
INSERT INTO public.nav_edges VALUES (3659, 294, 299, 7.226859930346739);
INSERT INTO public.nav_edges VALUES (3660, 283, 294, 10.638678163382162);
INSERT INTO public.nav_edges VALUES (3661, 294, 297, 13.196539237204645);
INSERT INTO public.nav_edges VALUES (3662, 295, 299, 6.55128725739488);
INSERT INTO public.nav_edges VALUES (3663, 295, 297, 11.909205825653247);
INSERT INTO public.nav_edges VALUES (3664, 296, 310, 4.778476807471703);
INSERT INTO public.nav_edges VALUES (3665, 296, 311, 5.002773866194725);
INSERT INTO public.nav_edges VALUES (3666, 296, 312, 5.505324099477055);
INSERT INTO public.nav_edges VALUES (3667, 296, 314, 7.897002129174391);
INSERT INTO public.nav_edges VALUES (3668, 296, 313, 8.755172731637007);
INSERT INTO public.nav_edges VALUES (3669, 296, 315, 13.132262667020507);
INSERT INTO public.nav_edges VALUES (3670, 297, 298, 2.4505571311840573);
INSERT INTO public.nav_edges VALUES (3671, 297, 299, 6.723159684167452);
INSERT INTO public.nav_edges VALUES (3672, 298, 299, 8.038191434155825);
INSERT INTO public.nav_edges VALUES (3673, 298, 305, 13.164972955944188);
INSERT INTO public.nav_edges VALUES (3674, 300, 301, 2.7256025451749335);
INSERT INTO public.nav_edges VALUES (3675, 300, 302, 5.924179548175166);
INSERT INTO public.nav_edges VALUES (3676, 300, 303, 6.021018408976211);
INSERT INTO public.nav_edges VALUES (3677, 300, 304, 6.730531549615223);
INSERT INTO public.nav_edges VALUES (3678, 300, 305, 8.980006541907718);
INSERT INTO public.nav_edges VALUES (3679, 301, 304, 5.717870455919383);
INSERT INTO public.nav_edges VALUES (3680, 301, 303, 6.168405011159509);
INSERT INTO public.nav_edges VALUES (3681, 301, 302, 7.2334308626564265);
INSERT INTO public.nav_edges VALUES (3682, 301, 305, 9.10804143612175);
INSERT INTO public.nav_edges VALUES (3683, 302, 303, 2.8450658205839265);
INSERT INTO public.nav_edges VALUES (3684, 302, 305, 4.275429309598078);
INSERT INTO public.nav_edges VALUES (3685, 302, 304, 5.472671029021056);
INSERT INTO public.nav_edges VALUES (3686, 302, 311, 8.194972042459616);
INSERT INTO public.nav_edges VALUES (3687, 303, 304, 2.6583142231286963);
INSERT INTO public.nav_edges VALUES (3688, 303, 305, 3.000697481420507);
INSERT INTO public.nav_edges VALUES (3689, 304, 305, 4.281741396549372);
INSERT INTO public.nav_edges VALUES (3690, 305, 311, 10.166203121126845);
INSERT INTO public.nav_edges VALUES (3691, 306, 319, 5.052537866141406);
INSERT INTO public.nav_edges VALUES (3692, 306, 318, 6.2900744781380755);
INSERT INTO public.nav_edges VALUES (3693, 306, 322, 6.906563878164725);
INSERT INTO public.nav_edges VALUES (3694, 306, 307, 7.656260482141013);
INSERT INTO public.nav_edges VALUES (3695, 308, 327, 6.360380737929989);
INSERT INTO public.nav_edges VALUES (3696, 308, 309, 8.764636336599631);
INSERT INTO public.nav_edges VALUES (3697, 308, 322, 9.572220603681423);
INSERT INTO public.nav_edges VALUES (3698, 306, 308, 10.20575889876382);
INSERT INTO public.nav_edges VALUES (3699, 309, 328, 6.452360475413708);
INSERT INTO public.nav_edges VALUES (3700, 285, 309, 9.176344127096181);
INSERT INTO public.nav_edges VALUES (3701, 307, 309, 9.79875978173299);
INSERT INTO public.nav_edges VALUES (3702, 310, 311, 2.391628305856399);
INSERT INTO public.nav_edges VALUES (3703, 310, 312, 4.909732907382642);
INSERT INTO public.nav_edges VALUES (3704, 310, 313, 8.83865720760641);
INSERT INTO public.nav_edges VALUES (3705, 302, 310, 9.627801368240995);
INSERT INTO public.nav_edges VALUES (3706, 311, 312, 2.616151694758816);
INSERT INTO public.nav_edges VALUES (3707, 311, 313, 6.477654502530747);
INSERT INTO public.nav_edges VALUES (3708, 311, 314, 8.629821480699013);
INSERT INTO public.nav_edges VALUES (3709, 312, 313, 3.9562488039929087);
INSERT INTO public.nav_edges VALUES (3710, 312, 314, 6.282291638442115);
INSERT INTO public.nav_edges VALUES (3711, 302, 312, 8.264805580845357);
INSERT INTO public.nav_edges VALUES (3712, 313, 314, 4.878709822838115);
INSERT INTO public.nav_edges VALUES (3713, 313, 315, 7.272276232812927);
INSERT INTO public.nav_edges VALUES (3714, 302, 313, 8.570083335356696);
INSERT INTO public.nav_edges VALUES (3715, 314, 315, 5.249148305901937);
INSERT INTO public.nav_edges VALUES (3716, 310, 314, 10.463767588436234);
INSERT INTO public.nav_edges VALUES (3717, 315, 316, 6.275548125210101);
INSERT INTO public.nav_edges VALUES (3718, 312, 315, 10.491288459806944);
INSERT INTO public.nav_edges VALUES (3719, 289, 315, 11.638920080401139);
INSERT INTO public.nav_edges VALUES (3720, 316, 317, 7.820359626385822);
INSERT INTO public.nav_edges VALUES (3721, 288, 316, 10.149194907981473);
INSERT INTO public.nav_edges VALUES (3722, 314, 316, 11.493333595201252);
INSERT INTO public.nav_edges VALUES (3723, 317, 329, 13.512313985107676);
INSERT INTO public.nav_edges VALUES (3724, 286, 317, 13.828889252050956);
INSERT INTO public.nav_edges VALUES (3725, 318, 319, 3.197506477886253);
INSERT INTO public.nav_edges VALUES (3726, 318, 320, 3.9400134854933855);
INSERT INTO public.nav_edges VALUES (3727, 318, 322, 6.601751536982862);
INSERT INTO public.nav_edges VALUES (3728, 318, 323, 7.842728379222819);
INSERT INTO public.nav_edges VALUES (3729, 319, 320, 3.135211525100338);
INSERT INTO public.nav_edges VALUES (3730, 319, 322, 3.5334673860221577);
INSERT INTO public.nav_edges VALUES (3731, 319, 323, 5.303167706112055);
INSERT INTO public.nav_edges VALUES (3732, 320, 322, 4.321224814161879);
INSERT INTO public.nav_edges VALUES (3733, 320, 323, 4.406948243674862);
INSERT INTO public.nav_edges VALUES (3734, 320, 324, 5.348695789862235);
INSERT INTO public.nav_edges VALUES (3735, 320, 321, 5.455088562756605);
INSERT INTO public.nav_edges VALUES (3736, 321, 325, 4.575677986532624);
INSERT INTO public.nav_edges VALUES (3737, 321, 324, 4.656780739141613);
INSERT INTO public.nav_edges VALUES (3738, 321, 323, 6.346699862397299);
INSERT INTO public.nav_edges VALUES (3739, 321, 322, 8.187125959382831);
INSERT INTO public.nav_edges VALUES (3740, 319, 321, 8.539093670587011);
INSERT INTO public.nav_edges VALUES (3741, 322, 323, 2.545860102746971);
INSERT INTO public.nav_edges VALUES (3742, 322, 324, 5.070264838348822);
INSERT INTO public.nav_edges VALUES (3743, 323, 324, 2.552189440006133);
INSERT INTO public.nav_edges VALUES (3744, 323, 325, 5.223886083562453);
INSERT INTO public.nav_edges VALUES (3745, 324, 325, 2.6999913014418526);
INSERT INTO public.nav_edges VALUES (3746, 319, 324, 7.287660420313947);
INSERT INTO public.nav_edges VALUES (3747, 320, 325, 7.551541796097668);
INSERT INTO public.nav_edges VALUES (3748, 322, 325, 7.7608306222577);
INSERT INTO public.nav_edges VALUES (3749, 319, 325, 9.865371401330925);
INSERT INTO public.nav_edges VALUES (3750, 326, 327, 7.779029855733122);
INSERT INTO public.nav_edges VALUES (3751, 308, 326, 10.519205529199457);
INSERT INTO public.nav_edges VALUES (3752, 323, 326, 12.11018099226141);
INSERT INTO public.nav_edges VALUES (3753, 324, 326, 12.366317052171487);
INSERT INTO public.nav_edges VALUES (3754, 325, 326, 12.647464756738412);
INSERT INTO public.nav_edges VALUES (3755, 322, 326, 12.890462620489368);
INSERT INTO public.nav_edges VALUES (3756, 327, 328, 10.794806423158352);
INSERT INTO public.nav_edges VALUES (3757, 285, 327, 11.660219384151471);
INSERT INTO public.nav_edges VALUES (3758, 309, 327, 12.260749312496673);
INSERT INTO public.nav_edges VALUES (3759, 322, 327, 14.333817676225886);
INSERT INTO public.nav_edges VALUES (3760, 328, 329, 8.50692688447181);
INSERT INTO public.nav_edges VALUES (3761, 308, 328, 10.994155222167517);
INSERT INTO public.nav_edges VALUES (3762, 286, 328, 11.281733554988644);
INSERT INTO public.nav_edges VALUES (3763, 285, 328, 13.952894489719846);
INSERT INTO public.nav_edges VALUES (3764, 309, 329, 10.248811377983683);
INSERT INTO public.nav_edges VALUES (3765, 288, 329, 12.004569295710711);
INSERT INTO public.nav_edges VALUES (3766, 286, 329, 13.578174816014904);
INSERT INTO public.nav_edges VALUES (3767, 289, 329, 16.482210672302767);


--
-- Data for Name: nav_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.nav_nodes VALUES (283, 1, 22.489525000636945, 21.35639999994865, 0);
INSERT INTO public.nav_nodes VALUES (284, 1, 5.397771428441445, 1.2447857141850704, 0);
INSERT INTO public.nav_nodes VALUES (285, 1, -5.0369333336561795, -9.59656666686115, 0);
INSERT INTO public.nav_nodes VALUES (286, 1, 1.5775874998027462, -13.046662499949235, 0);
INSERT INTO public.nav_nodes VALUES (287, 1, -4.952208695343074, 2.531926086859926, 0);
INSERT INTO public.nav_nodes VALUES (288, 1, 8.72777142870973, -14.707499999936147, 0);
INSERT INTO public.nav_nodes VALUES (289, 1, 11.402474999762546, -10.919625000035182, 0);
INSERT INTO public.nav_nodes VALUES (290, 1, 12.925950000017394, -8.198737499885311, 0);
INSERT INTO public.nav_nodes VALUES (291, 1, 9.240133333612732, 33.95489999968859, 0);
INSERT INTO public.nav_nodes VALUES (292, 1, 24.941699999651235, 34.188000000046515, 0);
INSERT INTO public.nav_nodes VALUES (293, 1, 28.67382272769703, 21.462859090739528, 0);
INSERT INTO public.nav_nodes VALUES (294, 1, 29.410837500513765, 29.435812499819747, 0);
INSERT INTO public.nav_nodes VALUES (295, 1, 28.60152857137166, 27.74841428549024, 0);
INSERT INTO public.nav_nodes VALUES (296, 1, 25.978933333625776, 7.893333332990693, 0);
INSERT INTO public.nav_nodes VALUES (297, 1, 17.0797285715949, 24.735557142690823, 0);
INSERT INTO public.nav_nodes VALUES (298, 1, 14.86765714331284, 25.790057142394573, 0);
INSERT INTO public.nav_nodes VALUES (299, 1, 22.1916749996538, 29.102349999636346, 0);
INSERT INTO public.nav_nodes VALUES (300, 1, 8.860971428688913, 4.5002571428298666, 0);
INSERT INTO public.nav_nodes VALUES (301, 1, 6.390428571293683, 5.651485714416538, 0);
INSERT INTO public.nav_nodes VALUES (302, 1, 12.874414285974467, 8.857799999798743, 0);
INSERT INTO public.nav_nodes VALUES (303, 1, 10.429837500325334, 10.313287499752022, 0);
INSERT INTO public.nav_nodes VALUES (304, 1, 7.911128571713277, 11.163428571467904, 0);
INSERT INTO public.nav_nodes VALUES (305, 1, 11.782976470819051, 12.991570588138046, 0);
INSERT INTO public.nav_nodes VALUES (306, 1, -3.201557142638478, -4.944257142891928, 0);
INSERT INTO public.nav_nodes VALUES (307, 1, 3.579749999637727, -8.498437500232825, 0);
INSERT INTO public.nav_nodes VALUES (308, 1, -8.290114286033656, -13.790957143349658, 0);
INSERT INTO public.nav_nodes VALUES (309, 1, -0.3393428569395951, -17.4793285719268, 0);
INSERT INTO public.nav_nodes VALUES (310, 1, 22.27928571470983, 10.917642856732357, 0);
INSERT INTO public.nav_nodes VALUES (311, 1, 21.069385714767463, 8.854628570908574, 0);
INSERT INTO public.nav_nodes VALUES (312, 1, 20.720925000212276, 6.261787499727944, 0);
INSERT INTO public.nav_nodes VALUES (313, 1, 18.890614285297147, 2.7543857140805983, 0);
INSERT INTO public.nav_nodes VALUES (314, 1, 23.21503333366337, 0.495799999615798, 0);
INSERT INTO public.nav_nodes VALUES (315, 1, 20.925085714658564, -4.227514285879863, 0);
INSERT INTO public.nav_nodes VALUES (316, 1, 17.38370999974137, -9.408360000396243, 0);
INSERT INTO public.nav_nodes VALUES (317, 1, 14.882324999810237, -16.817887500049977, 0);
INSERT INTO public.nav_nodes VALUES (318, 1, -5.916299999732644, 0.7298249996559036, 0);
INSERT INTO public.nav_nodes VALUES (319, 1, -7.3846714279994785, -2.110585714444113, 0);
INSERT INTO public.nav_nodes VALUES (320, 1, -9.772440000155314, -0.07881000021114914, 0);
INSERT INTO public.nav_nodes VALUES (321, 1, -14.61592499985187, 2.4309000000144465, 0);
INSERT INTO public.nav_nodes VALUES (322, 1, -10.08573750024766, -4.388662500119267, 0);
INSERT INTO public.nav_nodes VALUES (323, 1, -12.489085713873749, -3.548828572000673, 0);
INSERT INTO public.nav_nodes VALUES (324, 1, -14.671424999711746, -2.2255499999808137, 0);
INSERT INTO public.nav_nodes VALUES (325, 1, -17.21927142856572, -1.331999999791833, 0);
INSERT INTO public.nav_nodes VALUES (326, 1, -18.808950000149594, -13.879162500213482, 0);
INSERT INTO public.nav_nodes VALUES (327, 1, -12.556874999845036, -18.507862499884453, 0);
INSERT INTO public.nav_nodes VALUES (328, 1, -2.9288142856884747, -23.389285714273456, 0);
INSERT INTO public.nav_nodes VALUES (329, 1, 5.1157125003342685, -26.155762500135182, 0);


--
-- Data for Name: navigation_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: otp_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: place_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.place_categories VALUES (1, 'Dining', 'fork.knife', '2025-11-22 15:20:49.181168');
INSERT INTO public.place_categories VALUES (2, 'Shopping', 'cart', '2025-11-22 15:20:49.181168');
INSERT INTO public.place_categories VALUES (3, 'Facility', 'building.2', '2025-11-22 15:20:49.181168');
INSERT INTO public.place_categories VALUES (4, 'Meeting', 'person.3', '2025-11-22 15:20:49.181168');


--
-- Data for Name: poi_metadata; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: poi_names; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.poi_names VALUES (162, 319, 'en', 'Phone Booth 5');
INSERT INTO public.poi_names VALUES (163, 320, 'en', 'Meeting Room 1');
INSERT INTO public.poi_names VALUES (164, 321, 'en', 'Meeting Room 2');
INSERT INTO public.poi_names VALUES (165, 322, 'en', 'Quiet Room 3');
INSERT INTO public.poi_names VALUES (166, 323, 'en', 'Meeting Room 3');
INSERT INTO public.poi_names VALUES (167, 324, 'en', 'Meeting Room 4');
INSERT INTO public.poi_names VALUES (168, 325, 'en', 'Quiet Room 4');
INSERT INTO public.poi_names VALUES (169, 326, 'en', 'Board Room');
INSERT INTO public.poi_names VALUES (170, 327, 'en', 'Meeting Room 5');
INSERT INTO public.poi_names VALUES (171, 328, 'en', 'Meeting Room 6');
INSERT INTO public.poi_names VALUES (172, 329, 'en', 'Meeting Room 11');
INSERT INTO public.poi_names VALUES (173, 283, 'en', 'Theatre');
INSERT INTO public.poi_names VALUES (174, 284, 'en', 'Restroom1');
INSERT INTO public.poi_names VALUES (175, 285, 'en', 'Meeting Room 10');
INSERT INTO public.poi_names VALUES (176, 286, 'en', 'Meeitng Room 9');
INSERT INTO public.poi_names VALUES (177, 287, 'en', 'Reception / Cafe');
INSERT INTO public.poi_names VALUES (178, 288, 'en', 'Meeitng Room 12');
INSERT INTO public.poi_names VALUES (179, 289, 'en', 'Meeting Room 13');
INSERT INTO public.poi_names VALUES (180, 290, 'en', 'Meeting Room 14');
INSERT INTO public.poi_names VALUES (181, 291, 'en', 'Difference Area');
INSERT INTO public.poi_names VALUES (182, 292, 'en', 'Studio');
INSERT INTO public.poi_names VALUES (183, 293, 'en', 'Studio');
INSERT INTO public.poi_names VALUES (184, 294, 'en', 'Phone Booth 4');
INSERT INTO public.poi_names VALUES (185, 295, 'en', 'Phone booth 3');
INSERT INTO public.poi_names VALUES (186, 296, 'en', 'Raised Area');
INSERT INTO public.poi_names VALUES (187, 297, 'en', 'Quiet Room 1');
INSERT INTO public.poi_names VALUES (188, 298, 'en', 'Quiet Room 2');
INSERT INTO public.poi_names VALUES (189, 299, 'en', 'Production Room');
INSERT INTO public.poi_names VALUES (190, 300, 'en', 'Elevator 5');
INSERT INTO public.poi_names VALUES (191, 301, 'en', 'Elevator 4');
INSERT INTO public.poi_names VALUES (192, 302, 'en', 'Elevator 3');
INSERT INTO public.poi_names VALUES (193, 303, 'en', 'Elevator 2');
INSERT INTO public.poi_names VALUES (194, 304, 'en', 'Elevator 1');
INSERT INTO public.poi_names VALUES (195, 305, 'en', 'Restroom2');
INSERT INTO public.poi_names VALUES (196, 306, 'en', 'Store Room');
INSERT INTO public.poi_names VALUES (197, 307, 'en', 'IDF Room');
INSERT INTO public.poi_names VALUES (198, 308, 'en', 'Meeting Room 7');
INSERT INTO public.poi_names VALUES (199, 309, 'en', 'Meeting Room 8');
INSERT INTO public.poi_names VALUES (200, 310, 'en', 'Phone Booth 2');
INSERT INTO public.poi_names VALUES (201, 311, 'en', 'Phone booth 1');
INSERT INTO public.poi_names VALUES (202, 312, 'en', 'Testing Room');
INSERT INTO public.poi_names VALUES (203, 313, 'en', 'Control Room');
INSERT INTO public.poi_names VALUES (204, 314, 'en', 'Emerging Tech Lab');
INSERT INTO public.poi_names VALUES (205, 315, 'en', 'War Room 3');
INSERT INTO public.poi_names VALUES (206, 316, 'en', 'War Room 2');
INSERT INTO public.poi_names VALUES (207, 317, 'en', 'War Room 1');
INSERT INTO public.poi_names VALUES (208, 318, 'en', 'Luggage Storage');


--
-- Data for Name: poi_synonyms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.poi_synonyms VALUES (391, 319, 'en', 'phone booth 5');
INSERT INTO public.poi_synonyms VALUES (392, 320, 'en', 'meeting 1');
INSERT INTO public.poi_synonyms VALUES (393, 320, 'en', 'meeting room 1');
INSERT INTO public.poi_synonyms VALUES (394, 320, 'en', 'room 1');
INSERT INTO public.poi_synonyms VALUES (395, 320, 'en', 'meeting room 1');
INSERT INTO public.poi_synonyms VALUES (396, 321, 'en', 'meeting 2');
INSERT INTO public.poi_synonyms VALUES (397, 321, 'en', 'meeting room 2');
INSERT INTO public.poi_synonyms VALUES (398, 321, 'en', 'room 2');
INSERT INTO public.poi_synonyms VALUES (399, 321, 'en', 'meeting room 2');
INSERT INTO public.poi_synonyms VALUES (400, 322, 'en', 'quiet room 3');
INSERT INTO public.poi_synonyms VALUES (401, 323, 'en', 'meeting room 3');
INSERT INTO public.poi_synonyms VALUES (402, 323, 'en', 'meeting room 3');
INSERT INTO public.poi_synonyms VALUES (403, 323, 'en', 'room 3');
INSERT INTO public.poi_synonyms VALUES (404, 323, 'en', 'meeting 3');
INSERT INTO public.poi_synonyms VALUES (405, 324, 'en', 'meeting room 4');
INSERT INTO public.poi_synonyms VALUES (406, 324, 'en', 'meeting 4');
INSERT INTO public.poi_synonyms VALUES (407, 324, 'en', 'meeting room 4');
INSERT INTO public.poi_synonyms VALUES (408, 324, 'en', 'room 4');
INSERT INTO public.poi_synonyms VALUES (409, 325, 'en', 'quiet room 4');
INSERT INTO public.poi_synonyms VALUES (410, 326, 'en', 'board room');
INSERT INTO public.poi_synonyms VALUES (411, 327, 'en', 'room 5');
INSERT INTO public.poi_synonyms VALUES (412, 327, 'en', 'meeting 5');
INSERT INTO public.poi_synonyms VALUES (413, 327, 'en', 'meeting room 5');
INSERT INTO public.poi_synonyms VALUES (414, 327, 'en', 'meeting room 5');
INSERT INTO public.poi_synonyms VALUES (415, 328, 'en', 'meeting 6');
INSERT INTO public.poi_synonyms VALUES (416, 328, 'en', 'meeting room 6');
INSERT INTO public.poi_synonyms VALUES (417, 328, 'en', 'room 6');
INSERT INTO public.poi_synonyms VALUES (418, 328, 'en', 'meeting room 6');
INSERT INTO public.poi_synonyms VALUES (419, 329, 'en', 'room 11');
INSERT INTO public.poi_synonyms VALUES (420, 329, 'en', 'meeting 11');
INSERT INTO public.poi_synonyms VALUES (421, 329, 'en', 'meeting room 11');
INSERT INTO public.poi_synonyms VALUES (422, 329, 'en', 'meeting room 11');
INSERT INTO public.poi_synonyms VALUES (423, 283, 'en', 'theatre');
INSERT INTO public.poi_synonyms VALUES (424, 283, 'en', 'theater');
INSERT INTO public.poi_synonyms VALUES (425, 283, 'en', 'auditorium');
INSERT INTO public.poi_synonyms VALUES (426, 283, 'en', 'theatre');
INSERT INTO public.poi_synonyms VALUES (427, 284, 'en', 'restroom');
INSERT INTO public.poi_synonyms VALUES (428, 284, 'en', 'restroom1');
INSERT INTO public.poi_synonyms VALUES (429, 284, 'en', 'restroom 1');
INSERT INTO public.poi_synonyms VALUES (430, 284, 'en', 'toilet 1');
INSERT INTO public.poi_synonyms VALUES (431, 284, 'en', 'bathroom');
INSERT INTO public.poi_synonyms VALUES (432, 284, 'en', 'wc');
INSERT INTO public.poi_synonyms VALUES (433, 284, 'en', 'toilet');
INSERT INTO public.poi_synonyms VALUES (434, 285, 'en', 'meeting 10');
INSERT INTO public.poi_synonyms VALUES (435, 285, 'en', 'meeting room 10');
INSERT INTO public.poi_synonyms VALUES (436, 285, 'en', 'meeting room 10');
INSERT INTO public.poi_synonyms VALUES (437, 285, 'en', 'room 10');
INSERT INTO public.poi_synonyms VALUES (438, 286, 'en', 'meeitng room 9');
INSERT INTO public.poi_synonyms VALUES (439, 287, 'en', 'walkway');
INSERT INTO public.poi_synonyms VALUES (440, 287, 'en', 'cafe');
INSERT INTO public.poi_synonyms VALUES (441, 287, 'en', 'lobby');
INSERT INTO public.poi_synonyms VALUES (442, 287, 'en', 'coffee');
INSERT INTO public.poi_synonyms VALUES (443, 287, 'en', 'reception / cafe');
INSERT INTO public.poi_synonyms VALUES (444, 287, 'en', 'cafeteria');
INSERT INTO public.poi_synonyms VALUES (445, 287, 'en', 'front desk');
INSERT INTO public.poi_synonyms VALUES (446, 287, 'en', 'reception');
INSERT INTO public.poi_synonyms VALUES (447, 288, 'en', 'meeitng room 12');
INSERT INTO public.poi_synonyms VALUES (448, 289, 'en', 'meeting 13');
INSERT INTO public.poi_synonyms VALUES (449, 289, 'en', 'meeting room 13');
INSERT INTO public.poi_synonyms VALUES (450, 289, 'en', 'meeting room 13');
INSERT INTO public.poi_synonyms VALUES (451, 289, 'en', 'room 13');
INSERT INTO public.poi_synonyms VALUES (452, 290, 'en', 'meeting room 14');
INSERT INTO public.poi_synonyms VALUES (453, 290, 'en', 'meeting room 14');
INSERT INTO public.poi_synonyms VALUES (454, 290, 'en', 'meeting 14');
INSERT INTO public.poi_synonyms VALUES (455, 290, 'en', 'room 14');
INSERT INTO public.poi_synonyms VALUES (456, 291, 'en', 'difference area');
INSERT INTO public.poi_synonyms VALUES (457, 292, 'en', 'studio');
INSERT INTO public.poi_synonyms VALUES (458, 293, 'en', 'walkway');
INSERT INTO public.poi_synonyms VALUES (459, 293, 'en', 'studio');
INSERT INTO public.poi_synonyms VALUES (460, 294, 'en', 'phone booth 4');
INSERT INTO public.poi_synonyms VALUES (461, 295, 'en', 'phone booth 3');
INSERT INTO public.poi_synonyms VALUES (462, 296, 'en', 'raised area');
INSERT INTO public.poi_synonyms VALUES (463, 297, 'en', 'quiet room 1');
INSERT INTO public.poi_synonyms VALUES (464, 298, 'en', 'quiet room 2');
INSERT INTO public.poi_synonyms VALUES (465, 299, 'en', 'production room');
INSERT INTO public.poi_synonyms VALUES (466, 300, 'en', 'elevator 5');
INSERT INTO public.poi_synonyms VALUES (467, 300, 'en', 'elevator');
INSERT INTO public.poi_synonyms VALUES (468, 300, 'en', 'lift');
INSERT INTO public.poi_synonyms VALUES (469, 301, 'en', 'elevator');
INSERT INTO public.poi_synonyms VALUES (470, 301, 'en', 'lift');
INSERT INTO public.poi_synonyms VALUES (471, 301, 'en', 'elevator 4');
INSERT INTO public.poi_synonyms VALUES (472, 302, 'en', 'elevator');
INSERT INTO public.poi_synonyms VALUES (473, 302, 'en', 'lift');
INSERT INTO public.poi_synonyms VALUES (474, 302, 'en', 'elevator 3');
INSERT INTO public.poi_synonyms VALUES (475, 303, 'en', 'elevator');
INSERT INTO public.poi_synonyms VALUES (476, 303, 'en', 'lift');
INSERT INTO public.poi_synonyms VALUES (477, 303, 'en', 'elevator 2');
INSERT INTO public.poi_synonyms VALUES (478, 304, 'en', 'elevator 1');
INSERT INTO public.poi_synonyms VALUES (479, 304, 'en', 'elevator');
INSERT INTO public.poi_synonyms VALUES (480, 304, 'en', 'lift');
INSERT INTO public.poi_synonyms VALUES (481, 305, 'en', 'restroom');
INSERT INTO public.poi_synonyms VALUES (482, 305, 'en', 'toilet 2');
INSERT INTO public.poi_synonyms VALUES (483, 305, 'en', 'bathroom');
INSERT INTO public.poi_synonyms VALUES (484, 305, 'en', 'wc');
INSERT INTO public.poi_synonyms VALUES (485, 305, 'en', 'restroom 2');
INSERT INTO public.poi_synonyms VALUES (486, 305, 'en', 'restroom2');
INSERT INTO public.poi_synonyms VALUES (487, 305, 'en', 'toilet');
INSERT INTO public.poi_synonyms VALUES (488, 306, 'en', 'store room');
INSERT INTO public.poi_synonyms VALUES (489, 307, 'en', 'idf room');
INSERT INTO public.poi_synonyms VALUES (490, 308, 'en', 'meeting room 7');
INSERT INTO public.poi_synonyms VALUES (491, 308, 'en', 'room 7');
INSERT INTO public.poi_synonyms VALUES (492, 308, 'en', 'meeting 7');
INSERT INTO public.poi_synonyms VALUES (493, 308, 'en', 'meeting room 7');
INSERT INTO public.poi_synonyms VALUES (494, 309, 'en', 'meeting 8');
INSERT INTO public.poi_synonyms VALUES (495, 309, 'en', 'meeting room 8');
INSERT INTO public.poi_synonyms VALUES (496, 309, 'en', 'meeting room 8');
INSERT INTO public.poi_synonyms VALUES (497, 309, 'en', 'room 8');
INSERT INTO public.poi_synonyms VALUES (498, 310, 'en', 'phone booth 2');
INSERT INTO public.poi_synonyms VALUES (499, 311, 'en', 'phone booth 1');
INSERT INTO public.poi_synonyms VALUES (500, 312, 'en', 'testing room');
INSERT INTO public.poi_synonyms VALUES (501, 313, 'en', 'control room');
INSERT INTO public.poi_synonyms VALUES (502, 314, 'en', 'emerging tech lab');
INSERT INTO public.poi_synonyms VALUES (503, 315, 'en', 'war room 3');
INSERT INTO public.poi_synonyms VALUES (504, 316, 'en', 'war room 2');
INSERT INTO public.poi_synonyms VALUES (505, 317, 'en', 'war room 1');
INSERT INTO public.poi_synonyms VALUES (506, 318, 'en', 'luggage storage');


--
-- Data for Name: pois; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.pois VALUES (319, 4, 'Phone Booth 5', 'room', '0101000020E6100000B7B8ACE923A34B4068923ED45F333940', NULL, NULL, NULL, 319);
INSERT INTO public.pois VALUES (320, 4, 'Meeting Room 1', 'room', '0101000020E6100000CA47393523A34B4063E1560761333940', NULL, NULL, NULL, 320);
INSERT INTO public.pois VALUES (321, 4, 'Meeting Room 2', 'room', '0101000020E6100000DAD42FC721A34B404B17AC8262333940', NULL, NULL, NULL, 321);
INSERT INTO public.pois VALUES (322, 4, 'Quiet Room 3', 'room', '0101000020E610000001028C1D23A34B40A909EC7B5E333940', NULL, NULL, NULL, 322);
INSERT INTO public.pois VALUES (323, 4, 'Meeting Room 3', 'room', '0101000020E6100000EE26EB6722A34B402B11DCFA5E333940', NULL, NULL, NULL, 323);
INSERT INTO public.pois VALUES (324, 4, 'Meeting Room 4', 'room', '0101000020E6100000F216FEC221A34B408236DEC25F333940', NULL, NULL, NULL, 324);
INSERT INTO public.pois VALUES (325, 4, 'Quiet Room 4', 'room', '0101000020E61000009AAB710221A34B401DB3EC4960333940', NULL, NULL, NULL, 325);
INSERT INTO public.pois VALUES (326, 4, 'Board Room', 'room', '0101000020E6100000FBA24E8A20A34B407C5578E158333940', NULL, NULL, NULL, 326);
INSERT INTO public.pois VALUES (327, 4, 'Meeting Room 5', 'room', '0101000020E610000033A7CB6222A34B409C32DC2556333940', NULL, NULL, NULL, 327);
INSERT INTO public.pois VALUES (328, 4, 'Meeting Room 6', 'room', '0101000020E6100000D0D96A3A25A34B405D570D4453333940', NULL, NULL, NULL, 328);
INSERT INTO public.pois VALUES (329, 4, 'Meeting Room 11', 'room', '0101000020E6100000B8E45D9A27A34B4074F3E8A151333940', NULL, NULL, NULL, 329);
INSERT INTO public.pois VALUES (283, 4, 'Theatre', 'theater', '0101000020E6100000D7D25BBB2CA34B40D40330AF6D333940', NULL, NULL, NULL, 283);
INSERT INTO public.pois VALUES (284, 4, 'Restroom1', 'room', '0101000020E610000082CDAEAF27A34B402F4C65CF61333940', NULL, NULL, NULL, 284);
INSERT INTO public.pois VALUES (285, 4, 'Meeting Room 10', 'room', '0101000020E61000007DB4199B24A34B400686C4685B333940', NULL, NULL, NULL, 285);
INSERT INTO public.pois VALUES (286, 4, 'Meeitng Room 9', 'room', '0101000020E610000026DAFA8E26A34B40B2964C5F59333940', NULL, NULL, NULL, 286);
INSERT INTO public.pois VALUES (287, 4, 'Reception / Cafe', 'walkway', '0101000020E6100000DFD880A124A34B403922F19162333940', NULL, NULL, NULL, 287);
INSERT INTO public.pois VALUES (288, 4, 'Meeitng Room 12', 'room', '0101000020E6100000ED4F57AB28A34B40F723456458333940', NULL, NULL, NULL, 288);
INSERT INTO public.pois VALUES (289, 4, 'Meeting Room 13', 'room', '0101000020E6100000A0FF797529A34B4043E6CAA05A333940', NULL, NULL, NULL, 289);
INSERT INTO public.pois VALUES (290, 4, 'Meeting Room 14', 'room', '0101000020E61000002C369CE829A34B400A490B3C5C333940', NULL, NULL, NULL, 290);
INSERT INTO public.pois VALUES (291, 4, 'Difference Area', 'room', '0101000020E6100000F4D20FD228A34B4094CD661F75333940', NULL, NULL, NULL, 291);
INSERT INTO public.pois VALUES (292, 4, 'Studio', 'room', '0101000020E61000000651AD742DA34B40003CA24275333940', NULL, NULL, NULL, 292);
INSERT INTO public.pois VALUES (293, 4, 'Studio', 'walkway', '0101000020E6100000D392B98E2EA34B406F4747BF6D333940', NULL, NULL, NULL, 293);
INSERT INTO public.pois VALUES (294, 4, 'Phone Booth 4', 'room', '0101000020E61000007C606CC62EA34B406FF25B7472333940', NULL, NULL, NULL, 294);
INSERT INTO public.pois VALUES (295, 4, 'Phone booth 3', 'room', '0101000020E610000093EB42892EA34B4047C6507571333940', NULL, NULL, NULL, 295);
INSERT INTO public.pois VALUES (296, 4, 'Raised Area', 'room', '0101000020E6100000B05B10C32DA34B402C344CBC65333940', NULL, NULL, NULL, 296);
INSERT INTO public.pois VALUES (297, 4, 'Quiet Room 1', 'room', '0101000020E6100000181E86222BA34B403D17EFAD6F333940', NULL, NULL, NULL, 297);
INSERT INTO public.pois VALUES (298, 4, 'Quiet Room 2', 'room', '0101000020E610000017D6597B2AA34B40B347514D70333940', NULL, NULL, NULL, 298);
INSERT INTO public.pois VALUES (299, 4, 'Production Room', 'room', '0101000020E6100000BC68D9A42CA34B404026F54172333940', NULL, NULL, NULL, 299);
INSERT INTO public.pois VALUES (300, 4, 'Elevator 5', 'room', '0101000020E6100000E74A68B528A34B407F8D72BB63333940', NULL, NULL, NULL, 300);
INSERT INTO public.pois VALUES (301, 4, 'Elevator 4', 'room', '0101000020E61000003771B3FA27A34B40CF7F736964333940', NULL, NULL, NULL, 301);
INSERT INTO public.pois VALUES (302, 4, 'Elevator 3', 'room', '0101000020E6100000672AB7E429A34B408AB2124E66333940', NULL, NULL, NULL, 302);
INSERT INTO public.pois VALUES (303, 4, 'Elevator 2', 'room', '0101000020E61000004FACF82B29A34B40C274102A67333940', NULL, NULL, NULL, 303);
INSERT INTO public.pois VALUES (304, 4, 'Elevator 1', 'room', '0101000020E6100000DEF79F6D28A34B40C84D8FAA67333940', NULL, NULL, NULL, 304);
INSERT INTO public.pois VALUES (305, 4, 'Restroom2', 'room', '0101000020E610000038723B9229A34B401A55E0BE68333940', NULL, NULL, NULL, 305);
INSERT INTO public.pois VALUES (306, 4, 'Store Room', 'room', '0101000020E61000003E2DCE2525A34B404831F2275E333940', NULL, NULL, NULL, 306);
INSERT INTO public.pois VALUES (307, 4, 'IDF Room', 'room', '0101000020E6100000A4164A2627A34B40A4DFBE0E5C333940', NULL, NULL, NULL, 307);
INSERT INTO public.pois VALUES (308, 4, 'Meeting Room 7', 'room', '0101000020E610000000643FA523A34B408B4CCDEE58333940', NULL, NULL, NULL, 308);
INSERT INTO public.pois VALUES (309, 4, 'Meeting Room 8', 'room', '0101000020E610000096931CFE25A34B40E2AB51C156333940', NULL, NULL, NULL, 309);
INSERT INTO public.pois VALUES (310, 4, 'Phone Booth 2', 'room', '0101000020E6100000266378AB2CA34B40E304698567333940', NULL, NULL, NULL, 310);
INSERT INTO public.pois VALUES (311, 4, 'Phone booth 1', 'room', '0101000020E6100000C7D008502CA34B40EBFB974D66333940', NULL, NULL, NULL, 311);
INSERT INTO public.pois VALUES (312, 4, 'Testing Room', 'room', '0101000020E61000003440B3352CA34B405826B2C564333940', NULL, NULL, NULL, 312);
INSERT INTO public.pois VALUES (313, 4, 'Control Room', 'room', '0101000020E610000083C760AB2BA34B4052DA90B362333940', NULL, NULL, NULL, 313);
INSERT INTO public.pois VALUES (314, 4, 'Emerging Tech Lab', 'room', '0101000020E6100000EC0330F22CA34B40947E305E61333940', NULL, NULL, NULL, 314);
INSERT INTO public.pois VALUES (315, 4, 'War Room 3', 'room', '0101000020E6100000381621452CA34B40EF6847945E333940', NULL, NULL, NULL, 315);
INSERT INTO public.pois VALUES (316, 4, 'War Room 2', 'room', '0101000020E6100000A8277F392BA34B4012E136855B333940', NULL, NULL, NULL, 316);
INSERT INTO public.pois VALUES (317, 4, 'War Room 1', 'room', '0101000020E6100000649C757C2AA34B4024134B2557333940', NULL, NULL, NULL, 317);
INSERT INTO public.pois VALUES (318, 4, 'Luggage Storage', 'room', '0101000020E6100000C4DCA45824A34B4098B78F8161333940', NULL, NULL, NULL, 318);


--
-- Data for Name: qr_anchors; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.qr_anchors VALUES (4, 'anchor:stairs-f1', NULL, 'Stairwell Floor 1', 1, 12, 15, 0, 'Main stairwell ground floor entrance', true, '2025-11-25 08:12:54.971282', '2025-11-25 08:41:01.801364');
INSERT INTO public.qr_anchors VALUES (7, 'anchor:stairs-f2', NULL, 'Stairwell Floor 2', 2, 12, 15, 3, 'Main stairwell second floor', true, '2025-11-25 08:12:54.971282', '2025-11-25 08:41:01.801364');
INSERT INTO public.qr_anchors VALUES (10, 'anchor:office-wing', NULL, 'Office Wing', 3, 30, 8, 6, 'Executive office area entrance', true, '2025-11-25 08:12:54.971282', '2025-11-25 08:41:01.801364');
INSERT INTO public.qr_anchors VALUES (5, 'anchor:cafe-entrance', 287, 'Cafeteria Entrance', 1, 55.27455538550725, 25.200722810144928, 0, 'Cafeteria main entrance', true, '2025-11-25 08:12:54.971282', '2025-11-25 21:40:03.263378');
INSERT INTO public.qr_anchors VALUES (2, 'anchor:reception', 287, 'Reception Desk', 1, 55.27455538550725, 25.200722810144928, 0, 'Main reception and information desk', true, '2025-11-25 08:12:54.971282', '2025-11-25 21:40:03.263378');
INSERT INTO public.qr_anchors VALUES (9, 'anchor:elevator-f3', 302, 'Elevator Floor 3', 3, 55.27471598571429, 25.2007798, 0, 'Main elevator bank third floor', true, '2025-11-25 08:12:54.971282', '2025-11-25 21:40:03.263378');
INSERT INTO public.qr_anchors VALUES (6, 'anchor:elevator-f2', 303, 'Elevator Floor 2', 2, 55.2746939625, 25.2007929125, 0, 'Main elevator bank second floor', true, '2025-11-25 08:12:54.971282', '2025-11-25 21:40:03.263378');
INSERT INTO public.qr_anchors VALUES (3, 'anchor:elevator-f1', 304, 'Elevator Floor 1', 1, 55.27467127142857, 25.200800571428573, 0, 'Main elevator bank ground floor', true, '2025-11-25 08:12:54.971282', '2025-11-25 21:40:03.263378');
INSERT INTO public.qr_anchors VALUES (8, 'anchor:meeting-area', 320, 'Meeting Room Area', 2, 55.27451196, 25.20069929, 0, 'Conference room corridor entrance', true, '2025-11-25 08:12:54.971282', '2025-11-25 21:40:03.263378');
INSERT INTO public.qr_anchors VALUES (1, 'anchor:main-entrance', 326, 'Main Entrance', 1, 55.27443055, 25.2005749625, 0, 'Primary building entrance with reception', true, '2025-11-25 08:12:54.971282', '2025-11-25 21:40:03.263378');


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: routes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: saved_places; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.saved_places VALUES (5, 2, NULL, 'Test', 4, 'Notes', '2025-11-25 20:09:56.587081', '2025-11-25 20:09:56.587081');


--
-- Data for Name: sensor_data; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sessions VALUES (1, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsImV4cCI6MTc2NDQxMjYwN30.DOpra2vK40p9QH54PyuTmefPQ_QU9JMHdOQrsm95UqQ', NULL, '2025-11-22 10:36:47.009032', '2025-11-22 10:46:39.466061');
INSERT INTO public.sessions VALUES (2, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsImV4cCI6MTc2NDQxMjY1MH0.Wyiu-q2vmg9DGplThGYctACw6yeHwmE420zj5mHYlXA', NULL, '2025-11-22 10:37:30.648232', '2025-11-22 10:46:39.466061');
INSERT INTO public.sessions VALUES (3, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsImV4cCI6MTc2NDQxMjg2OH0.1Sz2wuZVZyE0Ljvzg8kmw4Nrv30GbZLlg0AT6GL9hzU', NULL, '2025-11-22 10:41:08.628956', '2025-11-22 10:46:39.466061');
INSERT INTO public.sessions VALUES (4, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsImV4cCI6MTc2NDQxMzA2MH0.dv1CUWI8i-O6vYDfdnwtnMukUL_qSLDvZ2UjyJIS0r8', NULL, '2025-11-22 10:44:20.678254', '2025-11-22 10:46:39.466061');
INSERT INTO public.sessions VALUES (5, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDEzMTgzfQ.PCUxm8wYTRFmH-LhGRoqmgYprNncgg9wrDU3gj15jVY', NULL, '2025-11-22 10:46:23.336693', '2025-11-22 10:46:39.466061');
INSERT INTO public.sessions VALUES (6, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDEzMjMwfQ.orFhcLcRynK0GGewI56mIPeboHoYCBafjmXbKg8ywTo', NULL, '2025-11-22 10:47:10.117574', '2025-11-22 10:47:20.681039');
INSERT INTO public.sessions VALUES (7, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDEzMzY3fQ.KPqRmhLva9y6j2wGchUcSzXC__qDe2yb0oAhAJ6wYUo', NULL, '2025-11-22 10:49:27.693771', NULL);
INSERT INTO public.sessions VALUES (8, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1MjIwfQ.q7CO6PrA5UvknRWDzksoHj9heZsKR7G7S6Z8Y2dkZx4', NULL, '2025-11-22 11:20:20.124838', NULL);
INSERT INTO public.sessions VALUES (9, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1MjQwfQ.OgtKI8qM3kCXjHSPXMqguP9LgHsqeI2OHRAuzQormaM', NULL, '2025-11-22 11:20:40.614682', NULL);
INSERT INTO public.sessions VALUES (10, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1MjQ1fQ.ExhqxMc9gMZUVDJ_nJrycfIusN-CIQX3DJl7Fdxu8sM', NULL, '2025-11-22 11:20:45.398403', NULL);
INSERT INTO public.sessions VALUES (11, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1MzA5fQ.TQKKYHTmhDS_LVrl0wYi6p4PsU861cMaqlWD2FepRMQ', NULL, '2025-11-22 11:21:49.576484', NULL);
INSERT INTO public.sessions VALUES (12, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1MzQxfQ.yPYw4pnBM6-eMXkK1MQMObxsLBupW4ZZIp1MAA_RaSE', NULL, '2025-11-22 11:22:21.372827', NULL);
INSERT INTO public.sessions VALUES (13, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1NDQxfQ.KKImsqiDo7Aad280SLEuJzxTyoKDbx1qVLWyhtERylw', NULL, '2025-11-22 11:24:01.908031', NULL);
INSERT INTO public.sessions VALUES (14, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1NTQyfQ.EKDpeZzU-G7wB_tp6UCrnwrkfLXr6d4MhxTPJGbqmdo', NULL, '2025-11-22 11:25:42.807468', NULL);
INSERT INTO public.sessions VALUES (15, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1NTUwfQ.l9vK-l2_fuTm2XKUz69p0yzfVMuTNR8PJLDDzoUMano', NULL, '2025-11-22 11:25:50.659997', NULL);
INSERT INTO public.sessions VALUES (16, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1NjI0fQ.ayQcKv_DycOGXfFGOn4hHfUsQHBMsgTFHF8Vngd8sDE', NULL, '2025-11-22 11:27:04.752102', NULL);
INSERT INTO public.sessions VALUES (17, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1ODE4fQ.vh4YmZ47MpRQCHP7hdWwsmqbjtkL86ykFSeTodxMjlo', NULL, '2025-11-22 11:30:18.306558', NULL);
INSERT INTO public.sessions VALUES (18, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1ODgxfQ.g8ivwWxvpCa_znJPmxGpcQjgpfQzXKrE5x8-5vFTK-0', NULL, '2025-11-22 11:31:21.277575', NULL);
INSERT INTO public.sessions VALUES (19, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE1OTQwfQ.L0uRn158rcFG6RBFWcZikISuDp2oRXgBaeQRxcT_vck', NULL, '2025-11-22 11:32:20.402666', NULL);
INSERT INTO public.sessions VALUES (22, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE3NDA3fQ.WJ8jd8hvH1GFYfffIHUhlQLNGBiVfJlvJFIJk-39Vc4', NULL, '2025-11-22 11:56:47.375511', NULL);
INSERT INTO public.sessions VALUES (23, 1, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzY0NDE3NDcyfQ.3PuEAbaNimUnJbn4DmLuPsWKI5XNxjVIbW1ZdqTs4x4', NULL, '2025-11-22 11:57:52.113536', NULL);
INSERT INTO public.sessions VALUES (24, 3, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzIiwiZXhwIjoxNzY0NDE3NDkxfQ.sp4RRw3G5ASJu2a4pk2PpMi-nKWiRmwCLgtpuPUO1Fw', NULL, '2025-11-22 11:58:11.444976', '2025-11-22 12:34:07.157067');
INSERT INTO public.sessions VALUES (25, 3, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzIiwiZXhwIjoxNzY0NDE3NTI1fQ.-tqk5ylayskW0_M0EDAmdtLRMZOtFr5HTfGjj4Wv-C0', NULL, '2025-11-22 11:58:45.085098', '2025-11-22 12:34:07.157067');
INSERT INTO public.sessions VALUES (26, 3, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzIiwiZXhwIjoxNzY0NDE3NzQyfQ.1tk586Re5XLg32bD_pZy1q-nXQMXD1qYpeQTJHiecDc', NULL, '2025-11-22 12:02:22.417345', '2025-11-22 12:34:07.157067');
INSERT INTO public.sessions VALUES (27, 3, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzIiwiZXhwIjoxNzY0NDE5NjY4fQ.TH7Bk-q5xK-dACSt_t2HzGj9Xcb_bedxWXEP2rVBTj8', NULL, '2025-11-22 12:34:28.356197', '2025-11-22 12:35:03.868297');
INSERT INTO public.sessions VALUES (20, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDE2MDI0fQ.ethxC2N1TY1SozP4mX0w1tjk8b2qgY2dQAhW6HlhEmE', NULL, '2025-11-22 11:33:44.529722', '2025-11-22 12:47:58.080013');
INSERT INTO public.sessions VALUES (21, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDE2MDU1fQ.KIB3h3gJgvA0VvbFEptzpuxy4ZQf0v_ogB0Btdqv2RM', NULL, '2025-11-22 11:34:15.832133', '2025-11-22 12:47:58.080013');
INSERT INTO public.sessions VALUES (28, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDE5ODE3fQ.tPrzNIO3Qza-ioWSLK__IahT_XklTyn_wc_ul9_dfkE', NULL, '2025-11-22 12:36:57.777514', '2025-11-22 12:47:58.080013');
INSERT INTO public.sessions VALUES (29, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDIwMzA0fQ.AXxIR-Ivo1riR7hKcuHPH15nu6o9lS85vFQd3NRka1U', NULL, '2025-11-22 12:45:04.868161', '2025-11-22 12:47:58.080013');
INSERT INTO public.sessions VALUES (30, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDIwMzE2fQ.bq2dJCTz4k23rxHo8gFdnLcZYJqRjbJIQF6Cm2Wo2kY', NULL, '2025-11-22 12:45:16.611464', '2025-11-22 12:47:58.080013');
INSERT INTO public.sessions VALUES (31, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDIwNDg5fQ.Gcbe8hq5B44vqjlY-fvCNLj5l-sevoUJPhq_qXTj6qE', NULL, '2025-11-22 12:48:09.106257', '2025-11-22 12:52:12.932806');
INSERT INTO public.sessions VALUES (32, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDIwNzQ3fQ.A_Q5dIaRR6HLSDteRFDDJmepyup3-EdCYJR5A6uPcF0', NULL, '2025-11-22 12:52:27.903276', '2025-11-22 12:53:56.797337');
INSERT INTO public.sessions VALUES (33, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDIwODQ5fQ.Yl_BMsskWAEsQu5MnVRDhZ6LtvXPtFfDuqmJuqWgsF4', NULL, '2025-11-22 12:54:09.857054', '2025-11-22 12:57:59.921559');
INSERT INTO public.sessions VALUES (34, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDIwOTgxfQ.1bmbZnWYvIUJbHaUKm2ZKgTwRx-Dl1jEH6Jog-d8fbg', NULL, '2025-11-22 12:56:21.488217', '2025-11-22 12:57:59.921559');
INSERT INTO public.sessions VALUES (35, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDIxMDkzfQ.9V48z52wLS8PE86FLG1cs1RpnMNlQ-mfA_Hcftrh1ds', NULL, '2025-11-22 12:58:13.181444', '2025-11-22 12:58:57.050023');
INSERT INTO public.sessions VALUES (36, 3, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzIiwiZXhwIjoxNzY0NDIxMTQ4fQ.ML_P0cMBuvUlM-s4G2ax-AwFIAzS7fpccwkjb2yBUpc', NULL, '2025-11-22 12:59:08.753172', NULL);
INSERT INTO public.sessions VALUES (37, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDM2MTIwfQ.QBIgB0oZX3rq3bxbIW5Iptn0zjaD71n3RF-Hb253qJA', NULL, '2025-11-22 17:08:40.527981', NULL);
INSERT INTO public.sessions VALUES (38, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDM2MTIzfQ.y04yCFyp3_jUyV8R30upFcpPYa6FqSoYW388fB4ojvk', NULL, '2025-11-22 17:08:43.453483', NULL);
INSERT INTO public.sessions VALUES (39, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NDM2ODg5fQ.cSUI_hil1h5wAxQWqEK5z3T5XjvS3EfjBO5Yy8vQYSk', NULL, '2025-11-22 17:21:29.123429', NULL);
INSERT INTO public.sessions VALUES (40, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NjUzOTkyfQ.IN_4KICEr9yGxQlFYg4mdYcKRp4-P6SccvEF5zM77SY', NULL, '2025-11-25 05:39:52.237906', NULL);
INSERT INTO public.sessions VALUES (41, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NjcyMDk4fQ.sdKs1tSQYCgdGQALa8nD4J9trI7Uz5PGOK3nyfT138M', NULL, '2025-11-25 10:41:38.06978', NULL);
INSERT INTO public.sessions VALUES (42, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0Njk3NTYzfQ.SFDvZypA31wp7qSbrKN7_ZOakZcD0OphsOv02cFQEfo', NULL, '2025-11-25 17:46:03.148579', NULL);
INSERT INTO public.sessions VALUES (43, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0Njk3NTY1fQ.CHANGTIFB0Pvtwsd5cfpMuxa7lczN783ac2NJTSKFwQ', NULL, '2025-11-25 17:46:05.278352', NULL);
INSERT INTO public.sessions VALUES (44, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0Njk4OTcxfQ.ckap3UMHfwVVf6fhxboDoGQ-V4fXxjKBeXQlFsMe4g4', NULL, '2025-11-25 18:09:31.532976', NULL);
INSERT INTO public.sessions VALUES (45, 2, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyIiwiZXhwIjoxNzY0NzAxNjA4fQ.I4BLEE2OcNce7Bl8Y_TwqzEKIrSBPuwLaSFiCd5kmrs', NULL, '2025-11-25 18:53:28.394237', NULL);


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users VALUES (1, 'Milad', 'abc@gmail.com', NULL, '$2b$12$EpVrSCy6uA7XG3t0uHMWoOhLTCSag.WOI1bOqHEGVhT5zEuhuCvb2', 'email', 'user', '2025-11-22 10:36:47.001121', '2025-11-22 10:36:47.001125', NULL);
INSERT INTO public.users VALUES (3, 'Haifa', 'haifa@gmail.com', NULL, '$2b$12$ihV/BOqn5F3amBmuB9wIweTuITsJEgcVzmMSZ8x9Pcgx8chGTlcKa', 'email', 'user', '2025-11-22 11:58:11.442568', '2025-11-22 12:35:00.395796', NULL);
INSERT INTO public.users VALUES (2, 'Milad Ateff', 'milad@gmail.com', '+1 (555) 123-1238', '$2b$12$I1R68st0.4D1js9PBf9/suoBbM0PgDsI2MEnTNmlCvqFe97GJdV.2', 'email', 'user', '2025-11-22 11:33:44.526306', '2025-11-25 18:12:37.349373', '1995-01-16');


--
-- Name: access_points_ap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.access_points_ap_id_seq', 1, false);


--
-- Name: anchors_anchor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.anchors_anchor_id_seq', 1, false);


--
-- Name: audit_logs_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_log_id_seq', 1, false);


--
-- Name: blueprint_files_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blueprint_files_file_id_seq', 1, false);


--
-- Name: buildings_building_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.buildings_building_id_seq', 3, true);


--
-- Name: error_reports_error_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.error_reports_error_id_seq', 1, false);


--
-- Name: floors_floor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.floors_floor_id_seq', 4, true);


--
-- Name: heatmap_readings_reading_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.heatmap_readings_reading_id_seq', 1, false);


--
-- Name: imdf_files_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.imdf_files_file_id_seq', 1, false);


--
-- Name: imdf_packages_package_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.imdf_packages_package_id_seq', 1, false);


--
-- Name: nav_edges_edge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nav_edges_edge_id_seq', 3767, true);


--
-- Name: nav_nodes_node_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nav_nodes_node_id_seq', 329, true);


--
-- Name: navigation_history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.navigation_history_history_id_seq', 1, false);


--
-- Name: otp_tokens_otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.otp_tokens_otp_id_seq', 1, false);


--
-- Name: place_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.place_categories_category_id_seq', 4, true);


--
-- Name: poi_metadata_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.poi_metadata_metadata_id_seq', 1, false);


--
-- Name: poi_names_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.poi_names_id_seq', 208, true);


--
-- Name: poi_synonyms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.poi_synonyms_id_seq', 506, true);


--
-- Name: pois_poi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pois_poi_id_seq', 329, true);


--
-- Name: qr_anchors_qr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.qr_anchors_qr_id_seq', 20, true);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 1, false);


--
-- Name: routes_route_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.routes_route_id_seq', 1, false);


--
-- Name: saved_places_saved_place_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.saved_places_saved_place_id_seq', 5, true);


--
-- Name: sensor_data_sensor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sensor_data_sensor_id_seq', 1, false);


--
-- Name: sessions_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_session_id_seq', 45, true);


--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_roles_user_role_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_id_seq', 3, true);


--
-- Name: access_points access_points_mac_address_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_points
    ADD CONSTRAINT access_points_mac_address_key UNIQUE (mac_address);


--
-- Name: access_points access_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_points
    ADD CONSTRAINT access_points_pkey PRIMARY KEY (ap_id);


--
-- Name: anchors anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anchors
    ADD CONSTRAINT anchors_pkey PRIMARY KEY (anchor_id);


--
-- Name: ar_pois_api ar_pois_api_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_pois_api
    ADD CONSTRAINT ar_pois_api_pkey PRIMARY KEY (poi_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (log_id);


--
-- Name: blueprint_files blueprint_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blueprint_files
    ADD CONSTRAINT blueprint_files_pkey PRIMARY KEY (file_id);


--
-- Name: buildings buildings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buildings
    ADD CONSTRAINT buildings_pkey PRIMARY KEY (building_id);


--
-- Name: error_reports error_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_reports
    ADD CONSTRAINT error_reports_pkey PRIMARY KEY (error_id);


--
-- Name: floors floors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floors
    ADD CONSTRAINT floors_pkey PRIMARY KEY (floor_id);


--
-- Name: heatmap_readings heatmap_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heatmap_readings
    ADD CONSTRAINT heatmap_readings_pkey PRIMARY KEY (reading_id);


--
-- Name: imdf_files imdf_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imdf_files
    ADD CONSTRAINT imdf_files_pkey PRIMARY KEY (file_id);


--
-- Name: imdf_packages imdf_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imdf_packages
    ADD CONSTRAINT imdf_packages_pkey PRIMARY KEY (package_id);


--
-- Name: nav_edges nav_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nav_edges
    ADD CONSTRAINT nav_edges_pkey PRIMARY KEY (edge_id);


--
-- Name: nav_nodes nav_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nav_nodes
    ADD CONSTRAINT nav_nodes_pkey PRIMARY KEY (node_id);


--
-- Name: navigation_history navigation_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_history
    ADD CONSTRAINT navigation_history_pkey PRIMARY KEY (history_id);


--
-- Name: otp_tokens otp_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_tokens
    ADD CONSTRAINT otp_tokens_pkey PRIMARY KEY (otp_id);


--
-- Name: place_categories place_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_categories
    ADD CONSTRAINT place_categories_name_key UNIQUE (name);


--
-- Name: place_categories place_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_categories
    ADD CONSTRAINT place_categories_pkey PRIMARY KEY (category_id);


--
-- Name: poi_metadata poi_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_metadata
    ADD CONSTRAINT poi_metadata_pkey PRIMARY KEY (metadata_id);


--
-- Name: poi_names poi_names_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_names
    ADD CONSTRAINT poi_names_pkey PRIMARY KEY (id);


--
-- Name: poi_names poi_names_poi_id_lang_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_names
    ADD CONSTRAINT poi_names_poi_id_lang_code_key UNIQUE (poi_id, lang_code);


--
-- Name: poi_synonyms poi_synonyms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_synonyms
    ADD CONSTRAINT poi_synonyms_pkey PRIMARY KEY (id);


--
-- Name: pois pois_external_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pois
    ADD CONSTRAINT pois_external_id_key UNIQUE (external_id);


--
-- Name: pois pois_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pois
    ADD CONSTRAINT pois_pkey PRIMARY KEY (poi_id);


--
-- Name: qr_anchors qr_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_anchors
    ADD CONSTRAINT qr_anchors_pkey PRIMARY KEY (qr_id);


--
-- Name: qr_anchors qr_anchors_qr_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_anchors
    ADD CONSTRAINT qr_anchors_qr_code_key UNIQUE (qr_code);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (route_id);


--
-- Name: saved_places saved_places_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_places
    ADD CONSTRAINT saved_places_pkey PRIMARY KEY (saved_place_id);


--
-- Name: saved_places saved_places_user_id_poi_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_places
    ADD CONSTRAINT saved_places_user_id_poi_id_key UNIQUE (user_id, poi_id);


--
-- Name: sensor_data sensor_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sensor_data
    ADD CONSTRAINT sensor_data_pkey PRIMARY KEY (sensor_id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (session_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_role_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: idx_ar_pois_floor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ar_pois_floor ON public.ar_pois_api USING btree (floor);


--
-- Name: idx_poi_names_lang; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_poi_names_lang ON public.poi_names USING btree (lang_code);


--
-- Name: idx_poi_names_poi_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_poi_names_poi_id ON public.poi_names USING btree (poi_id);


--
-- Name: idx_poi_synonyms_poi_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_poi_synonyms_poi_id ON public.poi_synonyms USING btree (poi_id);


--
-- Name: idx_poi_synonyms_synonym_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_poi_synonyms_synonym_lower ON public.poi_synonyms USING btree (lower(synonym));


--
-- Name: idx_qr_anchors_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qr_anchors_active ON public.qr_anchors USING btree (active) WHERE (active = true);


--
-- Name: idx_qr_anchors_floor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qr_anchors_floor ON public.qr_anchors USING btree (floor_level);


--
-- Name: idx_qr_anchors_qr_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qr_anchors_qr_code ON public.qr_anchors USING btree (qr_code);


--
-- Name: idx_saved_places_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saved_places_category_id ON public.saved_places USING btree (category_id);


--
-- Name: idx_saved_places_poi_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saved_places_poi_id ON public.saved_places USING btree (poi_id);


--
-- Name: idx_saved_places_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saved_places_user_id ON public.saved_places USING btree (user_id);


--
-- Name: idx_users_auth_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_auth_provider ON public.users USING btree (auth_provider);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: qr_anchors qr_anchors_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER qr_anchors_updated_at_trigger BEFORE UPDATE ON public.qr_anchors FOR EACH ROW EXECUTE FUNCTION public.update_qr_anchors_updated_at();


--
-- Name: access_points access_points_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_points
    ADD CONSTRAINT access_points_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(building_id) ON DELETE CASCADE;


--
-- Name: anchors anchors_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anchors
    ADD CONSTRAINT anchors_floor_id_fkey FOREIGN KEY (floor_id) REFERENCES public.floors(floor_id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: blueprint_files blueprint_files_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blueprint_files
    ADD CONSTRAINT blueprint_files_floor_id_fkey FOREIGN KEY (floor_id) REFERENCES public.floors(floor_id) ON DELETE CASCADE;


--
-- Name: blueprint_files blueprint_files_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blueprint_files
    ADD CONSTRAINT blueprint_files_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(user_id);


--
-- Name: error_reports error_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_reports
    ADD CONSTRAINT error_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: floors floors_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floors
    ADD CONSTRAINT floors_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(building_id) ON DELETE CASCADE;


--
-- Name: floors floors_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floors
    ADD CONSTRAINT floors_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(user_id);


--
-- Name: heatmap_readings heatmap_readings_ap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heatmap_readings
    ADD CONSTRAINT heatmap_readings_ap_id_fkey FOREIGN KEY (ap_id) REFERENCES public.access_points(ap_id) ON DELETE CASCADE;


--
-- Name: heatmap_readings heatmap_readings_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heatmap_readings
    ADD CONSTRAINT heatmap_readings_floor_id_fkey FOREIGN KEY (floor_id) REFERENCES public.floors(floor_id) ON DELETE CASCADE;


--
-- Name: imdf_files imdf_files_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imdf_files
    ADD CONSTRAINT imdf_files_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.imdf_packages(package_id) ON DELETE CASCADE;


--
-- Name: imdf_packages imdf_packages_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imdf_packages
    ADD CONSTRAINT imdf_packages_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(user_id);


--
-- Name: nav_edges nav_edges_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nav_edges
    ADD CONSTRAINT nav_edges_a_fkey FOREIGN KEY (a) REFERENCES public.nav_nodes(node_id) ON DELETE CASCADE;


--
-- Name: nav_edges nav_edges_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nav_edges
    ADD CONSTRAINT nav_edges_b_fkey FOREIGN KEY (b) REFERENCES public.nav_nodes(node_id) ON DELETE CASCADE;


--
-- Name: navigation_history navigation_history_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_history
    ADD CONSTRAINT navigation_history_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.routes(route_id);


--
-- Name: navigation_history navigation_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_history
    ADD CONSTRAINT navigation_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: otp_tokens otp_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_tokens
    ADD CONSTRAINT otp_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: poi_metadata poi_metadata_poi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poi_metadata
    ADD CONSTRAINT poi_metadata_poi_id_fkey FOREIGN KEY (poi_id) REFERENCES public.pois(poi_id) ON DELETE CASCADE;


--
-- Name: pois pois_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pois
    ADD CONSTRAINT pois_floor_id_fkey FOREIGN KEY (floor_id) REFERENCES public.floors(floor_id) ON DELETE CASCADE;


--
-- Name: qr_anchors qr_anchors_poi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_anchors
    ADD CONSTRAINT qr_anchors_poi_id_fkey FOREIGN KEY (poi_id) REFERENCES public.pois(poi_id) ON DELETE SET NULL;


--
-- Name: routes routes_end_poi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_end_poi_fkey FOREIGN KEY (end_poi) REFERENCES public.pois(poi_id);


--
-- Name: routes routes_start_poi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_start_poi_fkey FOREIGN KEY (start_poi) REFERENCES public.pois(poi_id);


--
-- Name: saved_places saved_places_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_places
    ADD CONSTRAINT saved_places_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.place_categories(category_id) ON DELETE SET NULL;


--
-- Name: saved_places saved_places_poi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_places
    ADD CONSTRAINT saved_places_poi_id_fkey FOREIGN KEY (poi_id) REFERENCES public.pois(poi_id) ON DELETE SET NULL;


--
-- Name: saved_places saved_places_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_places
    ADD CONSTRAINT saved_places_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: sensor_data sensor_data_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sensor_data
    ADD CONSTRAINT sensor_data_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(role_id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict aGOJU4atw9SniEcbH7vf0lJcLTtko4OVWFDBlL4HSKI1iVsG4rdeLc56apgNCzs

