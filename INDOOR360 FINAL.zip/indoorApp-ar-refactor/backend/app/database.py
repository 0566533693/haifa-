# app/database.py
"""
Centralized database connection module.
All database connections should use this module to ensure consistency.
"""

import psycopg
import psycopg2
from app.config import settings


def get_connection():
    """
    Get a psycopg3 database connection.
    Use this for new code that uses psycopg (v3).

    Usage:
        from app.database import get_connection
        with get_connection() as conn, conn.cursor() as cur:
            cur.execute("SELECT ...")
    """
    return psycopg.connect(settings.DATABASE_URL)


def get_connection_v2():
    """
    Get a psycopg2 database connection.
    Use this for legacy code that uses psycopg2.

    Usage:
        from app.database import get_connection_v2
        conn = get_connection_v2()
        try:
            cur = conn.cursor()
            cur.execute("SELECT ...")
        finally:
            conn.close()
    """
    return psycopg2.connect(settings.DATABASE_URL)


# Aliases for convenience
get_db = get_connection
get_db_v2 = get_connection_v2
