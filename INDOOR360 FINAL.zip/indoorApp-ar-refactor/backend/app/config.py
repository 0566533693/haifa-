# app/config.py
import os
from pathlib import Path
from dotenv import load_dotenv

# Load ../.env no matter where uvicorn is launched from
ENV_PATH = (Path(__file__).resolve().parent.parent / ".env")
load_dotenv(ENV_PATH)

class Settings:
    # ------------ DATABASE ------------
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql://postgres:admin1234@127.0.0.1:5432/indoor360"
    )

    # ------------ CORS ------------
    CORS_ALLOW_ORIGINS = os.getenv("CORS_ALLOW_ORIGINS", "*").split(",")

    # ------------ JWT AUTH SETTINGS ------------
    JWT_SECRET_KEY: str = os.getenv(
        "JWT_SECRET_KEY",
        "your-secret-key-change-in-production-min-32-chars-long"
    )

    JWT_ALGORITHM: str = os.getenv("JWT_ALGORITHM", "HS256")

    # 🔥 YOU WERE MISSING THIS → CRITICAL
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(
        os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "10080")  # 7 days default
    )

settings = Settings()
