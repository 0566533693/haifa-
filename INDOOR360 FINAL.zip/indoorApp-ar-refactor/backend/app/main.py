# app/main.py
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings

# --------- Routers ----------
from api.auth import router as auth_router           # Email/Password auth
from api.auth_link import router as auth_link_router # Firebase link auth
from api.saved_places import router as saved_places_router
from api.poi import router as poi_router
from api.route import router as route_router
from api.position import router as position_router
from api.nlp import router as nlp_router
from api.debug import router as debug_router
from api.imdf import router as imdf_router
from api.debug_aliases import router as debug_alias_router
from api import ar                                     # AR endpoints
from api import navigation                              # navigation endpoints
from api import user_profile                            # user profile endpoints
from api import qr_position                             # QR positioning endpoints
# ----------------------------------------------

app = FastAPI(
    title="Indoor360 AR Backend",
    version="0.1.0"
)

# ------------------ CORS ------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ALLOW_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# -------------------------------------------


# ========== FIX PowerShell UTF-8 BUG ==========
@app.middleware("http")
async def force_utf8_on_json(request: Request, call_next):
    resp = await call_next(request)
    ct = resp.headers.get("content-type", "")
    if ct.startswith("application/json") and "charset=" not in ct.lower():
        resp.headers["content-type"] = "application/json; charset=utf-8"
    return resp
# ==============================================


# ----------- Include Routers (ORDER MATTERS) -----------
app.include_router(auth_router)           # /api/auth/signup, /api/auth/login, /api/auth/me ...
app.include_router(auth_link_router)      # /api/auth/link   (firebase auto-link)

app.include_router(saved_places_router)
app.include_router(debug_router)
app.include_router(poi_router)
app.include_router(route_router)
app.include_router(position_router)
app.include_router(nlp_router)
app.include_router(imdf_router)
app.include_router(debug_alias_router)

app.include_router(ar.router)
app.include_router(navigation.router)
app.include_router(user_profile.router)
app.include_router(qr_position.router)
# ---------------------------------------------------------


# ---------------- Root & Debug ----------------
@app.get("/")
def root():
    return {"ok": True, "service": "Indoor360 AR Backend"}

@app.get("/healthz")
def health():
    return {"ok": True}

@app.get("/debug/routes")
def debug_routes():
    return [r.path for r in app.router.routes]

@app.get("/api/nlp/healthz")
def nlp_health():
    return {"ok": True}
# -------------------------------------------------
