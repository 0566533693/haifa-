# connecting.py
import os
import json
import zipfile
import psycopg2
import traceback
from psycopg2.extras import Json

# Import central database configuration
from app.config import settings

# === CONFIG ===
IMDF_ZIP = r"C:\Users\hhs39\OneDrive - University of Wollongong\Desktop\1\.vscode\Indoor360\backend\IMDF_Mon_07_Jul_2025_09_12_01_GMT.zip"
EXTRACT_DIR = "./imdf_extracted"

# -----------------------------------------
#  ALIAS DICTIONARIES (can extend later)
# -----------------------------------------
BATHROOM_SYNONYMS_EN = [
    "bathroom", "bathrooms",
    "toilet", "toilets",
    "restroom", "restrooms",
]

BATHROOM_SYNONYMS_AR = [
    "حمام", "الحمام",
    "دورة المياه", "دورات المياه",
]


def insert_aliases_for_bathrooms(cur, package_id: int) -> None:
    """
    Find all restroom POIs in this IMDF package and insert aliases
    into poi_aliases automatically.

    Uses ON CONFLICT so duplicates are ignored safely.
    We assume restroom names in IMDF are like 'Restroom1', 'Restroom 1', etc.
    """
    # 1) find restrooms in this package
    cur.execute(
        """
        SELECT p.poi_id, p.name
        FROM pois p
        WHERE p.package_id = %s
          AND lower(p.name) LIKE 'restroom%%';
        """,
        (package_id,),
    )
    rows = cur.fetchall()
    print(f"Found {len(rows)} restroom POIs for alias insertion.")

    # 2) insert English & Arabic synonyms
    for poi_id, default_name in rows:
        # English
        for alias in BATHROOM_SYNONYMS_EN:
            cur.execute(
                """
                INSERT INTO poi_aliases (poi_id, alias_text, lang)
                VALUES (%s, %s, %s)
                ON CONFLICT (poi_id, alias_text_norm) DO NOTHING;
                """,
                (poi_id, alias, "en"),
            )

        # Arabic
        for alias in BATHROOM_SYNONYMS_AR:
            cur.execute(
                """
                INSERT INTO poi_aliases (poi_id, alias_text, lang)
                VALUES (%s, %s, %s)
                ON CONFLICT (poi_id, alias_text_norm) DO NOTHING;
                """,
                (poi_id, alias, "ar"),
            )

    print("Aliases for bathrooms inserted (duplicates skipped automatically).")


def main():
    conn = None
    cur = None

    try:
        # 1) Ensure extract directory exists
        os.makedirs(EXTRACT_DIR, exist_ok=True)

        # 2) Extract IMDF ZIP
        with zipfile.ZipFile(IMDF_ZIP, "r") as z:
            files = z.namelist()
            print("Files inside ZIP:", files)
            z.extractall(EXTRACT_DIR)

        # 3) Connect to DB
        conn = psycopg2.connect(settings.DATABASE_URL)
        cur = conn.cursor()

        # 4) Insert IMDF package record
        package_name = os.path.splitext(os.path.basename(IMDF_ZIP))[0]
        cur.execute(
            """
            INSERT INTO imdf_packages (name, version, uploaded_by)
            VALUES (%s, %s, %s)
            RETURNING package_id;
            """,
            (package_name, "1.0", None),
        )
        package_id = cur.fetchone()[0]
        conn.commit()
        print(f"Inserted package {package_id}: {package_name}")

        # 5) Insert each JSON/GeoJSON file into imdf_files
        inserted = 0
        for fname in os.listdir(EXTRACT_DIR):
            if not fname.lower().endswith((".json", ".geojson")):
                continue

            fpath = os.path.join(EXTRACT_DIR, fname)
            with open(fpath, "r", encoding="utf-8") as fh:
                data = json.load(fh)

            cur.execute(
                """
                INSERT INTO imdf_files (package_id, file_name, data)
                VALUES (%s, %s, %s);
                """,
                (package_id, fname, Json(data)),
            )
            inserted += 1

        conn.commit()
        print(f"Inserted {inserted} JSON/GeoJSON files into imdf_files.")

        # 6) Call import_*() functions (buildings/floors/pois only)
        for fn in ("import_imdf_buildings", "import_imdf_floors", "import_imdf_pois"):
            try:
                cur.execute(f"SELECT {fn}(%s);", (package_id,))
                print(f"Called {fn}({package_id})")
            except Exception as e:
                print(f"  Warning: function {fn} not found or failed: {e}")
        conn.commit()

        # 7) Populate poi_names (EN) for this package from unit.geojson
        #    First delete existing EN names for POIs in this package
        cur.execute(
            """
            DELETE FROM poi_names pn
            USING pois p
            WHERE pn.poi_id = p.poi_id
              AND pn.lang_code = 'en'
              AND p.package_id = %s;
            """,
            (package_id,),
        )

        #    Then insert fresh EN names from IMDF units
        cur.execute(
            """
            WITH u AS (
              SELECT
                ft->>'id' AS imdf_id,
                NULLIF(ft->'properties'->>'name','') AS name_en
              FROM imdf_files f
              CROSS JOIN LATERAL jsonb_array_elements((f.data)->'features') AS ft
              WHERE f.package_id = %s
                AND ft->>'feature_type' = 'unit'
            )
            INSERT INTO poi_names (poi_id, lang_code, name)
            SELECT p.poi_id, 'en', u.name_en
            FROM pois p
            JOIN u ON u.imdf_id = p.imdf_id
            WHERE u.name_en IS NOT NULL
              AND p.package_id = %s;
            """,
            (package_id, package_id),
        )
        conn.commit()

        # Report: EN names count
        cur.execute(
            """
            SELECT COUNT(*)
            FROM poi_names pn
            JOIN pois p ON pn.poi_id = p.poi_id
            WHERE pn.lang_code = 'en'
              AND p.package_id = %s;
            """,
            (package_id,),
        )
        count_names = cur.fetchone()[0]
        print(f"Inserted EN names into poi_names for this package: {count_names}")

        # 8) Automatically add bathroom aliases for this package
        insert_aliases_for_bathrooms(cur, package_id)
        conn.commit()

        print("IMDF import + alias generation completed successfully.")

    except Exception:
        print("ERROR during import:")
        traceback.print_exc()
    finally:
        try:
            if cur is not None:
                cur.close()
            if conn is not None:
                conn.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
