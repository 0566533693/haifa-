# backend/api/qr_position.py
"""QR code positioning API for indoor navigation."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.database import get_connection_v2

router = APIRouter(prefix="/api/qr", tags=["QR Positioning"])


# ---------- Pydantic Models ----------

class QRResolveRequest(BaseModel):
    qr_code: str


class QRPositionResponse(BaseModel):
    poi_id: int
    poi_name: str
    location_name: str
    x: float
    y: float
    z: float
    floor: int
    description: Optional[str] = None


class QRAnchorInfo(BaseModel):
    qr_code: str
    location_name: str
    floor: int
    poi_id: Optional[int] = None
    description: Optional[str] = None


# ---------- DB Helper ----------

def get_db():
    """Get database connection from centralized module."""
    return get_connection_v2()


# ---------- Endpoints ----------

@router.get("/healthz")
def qr_healthz():
    """Health check for QR positioning service."""
    return {"ok": True, "service": "qr_position"}


@router.post("/resolve", response_model=QRPositionResponse)
def resolve_qr_anchor(req: QRResolveRequest):
    """
    Resolve a QR code to POI coordinates.

    Supports two formats:
    - 'anchor:reception' - QR anchor placed at a known location
    - 'poi:CAFENOOR' - Direct POI reference by ID/name

    This is the main endpoint used when a user scans a QR code.
    It returns the exact position for AR positioning.
    """
    qr_code = req.qr_code.strip()
    if not qr_code:
        raise HTTPException(status_code=400, detail="QR code cannot be empty")

    conn = None
    try:
        conn = get_db()
        cur = conn.cursor()

        # Handle POI direct reference (poi:CAFENOOR)
        if qr_code.startswith("poi:"):
            poi_identifier = qr_code[4:]  # Remove "poi:" prefix

            # First get the column info to build the right query
            cur.execute("""
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name = 'pois'
            """)
            cols = {row[0].lower() for row in cur.fetchall()}

            # Determine floor column name
            floor_col = 'floor' if 'floor' in cols else 'level' if 'level' in cols else 'floor_level'
            name_col = 'name'
            name_ar_col = 'name_ar' if 'name_ar' in cols else None

            # Build query based on available columns
            if poi_identifier.isdigit():
                query = f"""
                    SELECT poi_id, {name_col}, {floor_col}, x, y, COALESCE(z, 0) as z
                    FROM pois
                    WHERE poi_id = %s
                """
                cur.execute(query, (int(poi_identifier),))
            else:
                # Search by name (case-insensitive)
                if name_ar_col:
                    query = f"""
                        SELECT poi_id, {name_col}, {floor_col}, x, y, COALESCE(z, 0) as z
                        FROM pois
                        WHERE UPPER({name_col}) = UPPER(%s)
                           OR UPPER({name_ar_col}) = UPPER(%s)
                        LIMIT 1
                    """
                    cur.execute(query, (poi_identifier, poi_identifier))
                else:
                    query = f"""
                        SELECT poi_id, {name_col}, {floor_col}, x, y, COALESCE(z, 0) as z
                        FROM pois
                        WHERE UPPER({name_col}) = UPPER(%s)
                        LIMIT 1
                    """
                    cur.execute(query, (poi_identifier,))

            row = cur.fetchone()
            if not row:
                raise HTTPException(
                    status_code=404,
                    detail=f"POI '{poi_identifier}' not found"
                )

            return QRPositionResponse(
                poi_id=row[0],
                poi_name=row[1],
                location_name=row[1],
                floor=row[2] or 1,
                x=float(row[3]) if row[3] else 0.0,
                y=float(row[4]) if row[4] else 0.0,
                z=float(row[5]) if row[5] else 0.0,
                description=f"POI: {row[1]}"
            )

        # Handle anchor reference (anchor:reception or just the anchor code)
        # First try to get coordinates from linked POI
        # Note: pois table uses 'coordinates' geography column, cast to geometry for ST_X/ST_Y
        cur.execute("""
            SELECT
                qa.poi_id,
                qa.location_name,
                qa.floor_level,
                qa.description,
                qa.x as qr_x,
                qa.y as qr_y,
                qa.z as qr_z,
                ST_X(p.coordinates::geometry) as poi_x,
                ST_Y(p.coordinates::geometry) as poi_y,
                0 as poi_z,
                p.name as poi_name
            FROM qr_anchors qa
            LEFT JOIN pois p ON qa.poi_id = p.poi_id
            WHERE qa.qr_code = %s AND qa.active = TRUE
        """, (qr_code,))

        row = cur.fetchone()
        if not row:
            raise HTTPException(
                status_code=404,
                detail=f"QR code '{qr_code}' not found or inactive"
            )

        # Use POI coordinates if linked, otherwise use QR anchor coordinates
        poi_id = row[0]
        location_name = row[1]
        floor = row[2]
        description = row[3]

        # QR anchor coordinates (fallback)
        qr_x, qr_y, qr_z = row[4], row[5], row[6]
        # POI coordinates (preferred if available)
        poi_x, poi_y, poi_z = row[7], row[8], row[9]
        poi_name = row[10]

        # Use POI coords if available and poi is linked
        if poi_id and poi_x is not None:
            x, y, z = poi_x, poi_y, poi_z
            name = poi_name or location_name
        else:
            x, y, z = qr_x or 0, qr_y or 0, qr_z or 0
            name = location_name
            poi_id = poi_id or 0  # Return 0 if no POI linked

        return QRPositionResponse(
            poi_id=poi_id or 0,
            location_name=location_name,
            floor=floor,
            description=description,
            x=float(x) if x is not None else 0.0,
            y=float(y) if y is not None else 0.0,
            z=float(z) if z is not None else 0.0,
            poi_name=name
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            conn.close()


@router.get("/list", response_model=List[QRAnchorInfo])
def list_qr_anchors(floor: Optional[int] = None, active_only: bool = True):
    """
    List all QR anchors, optionally filtered by floor.

    Useful for admin/debug purposes and for generating QR codes.

    Args:
        floor: Optional floor number to filter by
        active_only: If True, only return active anchors (default: True)
    """
    conn = None
    try:
        conn = get_db()
        cur = conn.cursor()

        query = """
            SELECT qr_code, location_name, floor_level, poi_id, description
            FROM qr_anchors
            WHERE 1=1
        """
        params = []

        if active_only:
            query += " AND active = TRUE"

        if floor is not None:
            query += " AND floor_level = %s"
            params.append(floor)

        query += " ORDER BY floor_level, location_name"

        cur.execute(query, params)

        return [
            QRAnchorInfo(
                qr_code=row[0],
                location_name=row[1],
                floor=row[2],
                poi_id=row[3],
                description=row[4]
            )
            for row in cur.fetchall()
        ]

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            conn.close()


@router.get("/anchor/{qr_code}", response_model=QRPositionResponse)
def get_qr_anchor(qr_code: str):
    """
    Get a specific QR anchor by its code.

    Alternative to POST /resolve for simple GET requests.
    """
    req = QRResolveRequest(qr_code=qr_code)
    return resolve_qr_anchor(req)
