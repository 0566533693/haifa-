# backend/api/auth.py
from fastapi import APIRouter, HTTPException, status, Depends
from datetime import datetime, timedelta
import psycopg
from psycopg.rows import dict_row

from api.auth_models import SignUpRequest, LoginRequest, ChangePasswordRequest, UpdateProfileRequest, AuthResponse, UserResponse, ErrorResponse
from api.auth_utils import (
    verify_password,
    get_password_hash,
    create_access_token,
    get_db_connection,
    get_current_user
)
from app.config import settings

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post(
    "/signup",
    response_model=AuthResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new user account",
    description="Register a new user with name, email, and password. Returns JWT token and user info.",
    responses={
        201: {"description": "User created successfully"},
        400: {"description": "Email already exists or validation error", "model": ErrorResponse},
        500: {"description": "Internal server error", "model": ErrorResponse}
    }
)
async def signup(request: SignUpRequest):
    """
    Create a new user account

    - **name**: User's full name (min 2 characters)
    - **email**: Valid email address (must be unique)
    - **password**: Password (min 8 characters)

    Returns JWT access token and user information.
    """
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                # Check if email already exists
                cur.execute("SELECT user_id FROM Users WHERE email = %s", (request.email,))
                existing_user = cur.fetchone()

                if existing_user:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Email already registered"
                    )

                # Hash password
                password_hash = get_password_hash(request.password)

                # Insert new user
                cur.execute(
                    """
                    INSERT INTO Users (name, email, password_hash, auth_provider, role, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    RETURNING user_id, name, email, role, created_at
                    """,
                    (
                        request.name,
                        request.email,
                        password_hash,
                        "email",
                        "user",
                        datetime.utcnow(),
                        datetime.utcnow()
                    )
                )

                user = cur.fetchone()
                conn.commit()

                # Create JWT token
                access_token = create_access_token(
                    data={"sub": str(user["user_id"])}
                )

                # Create session record (optional)
                try:
                    cur.execute(
                        """
                        INSERT INTO Sessions (user_id, jwt_token, started_at)
                        VALUES (%s, %s, %s)
                        """,
                        (user["user_id"], access_token, datetime.utcnow())
                    )
                    conn.commit()
                except Exception as e:
                    # Sessions table might not exist, continue anyway
                    print(f"Warning: Could not create session: {e}")

                # Return response
                return AuthResponse(
                    access_token=access_token,
                    token_type="bearer",
                    user=UserResponse(**user)
                )

    except HTTPException:
        raise
    except Exception as e:
        print(f"Signup error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create user: {str(e)}"
        )


@router.post(
    "/login",
    response_model=AuthResponse,
    summary="Login with email and password",
    description="Authenticate user with email and password. Returns JWT token and user info.",
    responses={
        200: {"description": "Login successful"},
        401: {"description": "Invalid credentials", "model": ErrorResponse},
        500: {"description": "Internal server error", "model": ErrorResponse}
    }
)
async def login(request: LoginRequest):
    """
    Login with email and password

    - **email**: User's email address
    - **password**: User's password

    Returns JWT access token and user information.
    """
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                # Fetch user by email
                cur.execute(
                    """
                    SELECT user_id, name, email, password_hash, role, created_at
                    FROM Users
                    WHERE email = %s AND auth_provider = %s
                    """,
                    (request.email, "email")
                )

                user = cur.fetchone()

                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Invalid email or password"
                    )

                # Verify password
                if not verify_password(request.password, user["password_hash"]):
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Invalid email or password"
                    )

                # Create JWT token
                access_token = create_access_token(
                    data={"sub": str(user["user_id"])}
                )

                # Create session record (optional)
                try:
                    cur.execute(
                        """
                        INSERT INTO Sessions (user_id, jwt_token, started_at)
                        VALUES (%s, %s, %s)
                        """,
                        (user["user_id"], access_token, datetime.utcnow())
                    )
                    conn.commit()
                except Exception as e:
                    # Sessions table might not exist, continue anyway
                    print(f"Warning: Could not create session: {e}")

                # Remove password_hash from response
                user_data = {k: v for k, v in user.items() if k != "password_hash"}

                # Return response
                return AuthResponse(
                    access_token=access_token,
                    token_type="bearer",
                    user=UserResponse(**user_data)
                )

    except HTTPException:
        raise
    except Exception as e:
        print(f"Login error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )


@router.get(
    "/me",
    response_model=UserResponse,
    summary="Get current user profile",
    description="Get authenticated user's profile information. Requires valid JWT token.",
    responses={
        200: {"description": "User profile retrieved successfully"},
        401: {"description": "Unauthorized - invalid or missing token", "model": ErrorResponse}
    }
)
async def get_me(current_user: dict = Depends(get_current_user)):
    """
    Get current authenticated user's profile

    Requires valid JWT token in Authorization header.
    Returns user information (without password).
    """
    return UserResponse(**current_user)


@router.post(
    "/logout",
    summary="Logout current user",
    description="End current user session. Mark session as ended in database.",
    responses={
        200: {"description": "Logout successful"},
        401: {"description": "Unauthorized - invalid or missing token", "model": ErrorResponse}
    }
)
async def logout(current_user: dict = Depends(get_current_user)):
    """
    Logout current user

    Marks the current session as ended in the database.
    Client should delete the token from local storage.
    """
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                # Mark sessions as ended (optional - Sessions table might not exist)
                try:
                    cur.execute(
                        """
                        UPDATE Sessions
                        SET ended_at = %s
                        WHERE user_id = %s AND ended_at IS NULL
                        """,
                        (datetime.utcnow(), current_user["user_id"])
                    )
                    conn.commit()
                except Exception as e:
                    print(f"Warning: Could not update sessions: {e}")

        return {"message": "Logout successful"}

    except Exception as e:
        print(f"Logout error: {e}")
        # Don't fail logout on database errors
        return {"message": "Logout successful"}


@router.post(
    "/change-password",
    summary="Change user password",
    description="Change the authenticated user's password. Requires current password verification.",
    responses={
        200: {"description": "Password changed successfully"},
        400: {"description": "Invalid current password or validation error", "model": ErrorResponse},
        401: {"description": "Unauthorized - invalid or missing token", "model": ErrorResponse}
    }
)
async def change_password(
    request: ChangePasswordRequest,
    current_user: dict = Depends(get_current_user)
):
    """
    Change password for authenticated user

    - **current_password**: User's current password (for verification)
    - **new_password**: New password (min 8 characters, max 72 bytes)

    Verifies current password, then updates to new password.
    """
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                # Get user's current password hash
                cur.execute(
                    "SELECT password_hash FROM Users WHERE user_id = %s",
                    (current_user["user_id"],)
                )
                user = cur.fetchone()

                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="User not found"
                    )

                # Verify current password
                if not verify_password(request.current_password, user["password_hash"]):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Current password is incorrect"
                    )

                # Hash new password
                new_password_hash = get_password_hash(request.new_password)

                # Update password
                cur.execute(
                    """
                    UPDATE Users
                    SET password_hash = %s, updated_at = %s
                    WHERE user_id = %s
                    """,
                    (new_password_hash, datetime.utcnow(), current_user["user_id"])
                )
                conn.commit()

                return {"message": "Password changed successfully"}

    except HTTPException:
        raise
    except Exception as e:
        print(f"Change password error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to change password"
        )


@router.put(
    "/profile",
    response_model=UserResponse,
    summary="Update user profile",
    description="Update authenticated user's profile information (name, phone, date of birth)",
    responses={
        200: {"description": "Profile updated successfully"},
        400: {"description": "Validation error", "model": ErrorResponse},
        401: {"description": "Unauthorized - invalid or missing token", "model": ErrorResponse}
    }
)
async def update_profile(
    request: UpdateProfileRequest,
    current_user: dict = Depends(get_current_user)
):
    """
    Update profile for authenticated user

    - **name**: User's full name (optional)
    - **phone**: Phone number (optional)
    - **date_of_birth**: Date of birth in YYYY-MM-DD format (optional)

    Returns updated user information.
    """
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                # Build dynamic update query based on provided fields
                update_fields = []
                params = []

                if request.name is not None:
                    update_fields.append("name = %s")
                    params.append(request.name)

                if request.phone is not None:
                    update_fields.append("phone = %s")
                    params.append(request.phone)

                if request.date_of_birth is not None:
                    update_fields.append("date_of_birth = %s")
                    params.append(request.date_of_birth)

                if not update_fields:
                    # No fields to update, just return current user
                    cur.execute(
                        """
                        SELECT user_id, name, email, phone,
                               CAST(date_of_birth AS TEXT) as date_of_birth,
                               role, created_at
                        FROM Users WHERE user_id = %s
                        """,
                        (current_user["user_id"],)
                    )
                    user = cur.fetchone()
                    return UserResponse(**user)

                # Add updated_at to all updates
                update_fields.append("updated_at = %s")
                params.append(datetime.utcnow())

                # Add user_id for WHERE clause
                params.append(current_user["user_id"])

                # Execute update
                query = f"""
                    UPDATE Users
                    SET {', '.join(update_fields)}
                    WHERE user_id = %s
                    RETURNING user_id, name, email, phone,
                              CAST(date_of_birth AS TEXT) as date_of_birth,
                              role, created_at
                """
                cur.execute(query, params)
                user = cur.fetchone()
                conn.commit()

                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="User not found"
                    )

                return UserResponse(**user)

    except HTTPException:
        raise
    except Exception as e:
        print(f"Update profile error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update profile"
        )
