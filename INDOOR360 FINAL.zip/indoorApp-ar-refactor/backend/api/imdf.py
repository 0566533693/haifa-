from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
import os
from pathlib import Path
from datetime import datetime

router = APIRouter(prefix="/api/imdf", tags=["imdf"])

@router.get("/latest")
def latest_imdf():
    p = Path(os.getenv("IMDF_PATH","").strip())
    if not p or not p.exists() or not p.is_file():
        raise HTTPException(status_code=404, detail=f"IMDF package not found at {p}")
    return FileResponse(path=str(p), filename=p.name, media_type="application/zip")

@router.get("/manifest")
def manifest():
    p = Path(os.getenv("IMDF_PATH","").strip())
    if not p or not p.exists() or not p.is_file():
        raise HTTPException(status_code=404, detail=f"IMDF package not found at {p}")
    return {
        "filename": p.name,
        "bytes": p.stat().st_size,
        "modified_iso": datetime.fromtimestamp(p.stat().st_mtime).isoformat()
    }
