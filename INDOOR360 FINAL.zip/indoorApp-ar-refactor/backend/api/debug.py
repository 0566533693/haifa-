# backend/api/debug.py
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import json, psycopg
from app.database import get_connection

router = APIRouter(prefix="/api/debug", tags=["debug"])

# ---------------- DB helpers ----------------

def _conn():
    """Get database connection from centralized module."""
    return get_connection()

def _ensure_alias_table():
    with _conn() as conn, conn.cursor() as cur:
        # Base table
        cur.execute("""
        CREATE TABLE IF NOT EXISTS poi_aliases (
          poi_id     INT NOT NULL,
          alias_text TEXT NOT NULL,
          lang       VARCHAR(5)
        );
        """)
        # Generated lower() column for conflict inference + indexing
        cur.execute("""
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_name='poi_aliases' AND column_name='alias_text_norm'
          ) THEN
            EXECUTE 'ALTER TABLE poi_aliases
                     ADD COLUMN alias_text_norm TEXT
                     GENERATED ALWAYS AS (lower(alias_text)) STORED';
          END IF;
        END$$;
        """)
        # Supporting indexes (not unique)
        cur.execute("""CREATE INDEX IF NOT EXISTS idx_poi_alias_norm ON poi_aliases (alias_text_norm);""")
        cur.execute("""CREATE INDEX IF NOT EXISTS idx_poi_alias_poi  ON poi_aliases (poi_id);""")
        conn.commit()

# ---------------- Introspection ----------------

@router.get("/cols")
def list_columns(table: str = Query(..., description="Table name, e.g., 'pois'")):
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("""
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name = %s
                ORDER BY ordinal_position
            """, (table,))
            cols = [r[0] for r in cur.fetchall()]
            return {"table": table, "columns": cols}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")

@router.get("/sample")
def sample_rows(table: str = Query(..., description="Table name")):
    t = table.replace('"', '""')
    sql = f'SELECT * FROM "{t}" LIMIT 3'
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute(sql)
            rows = cur.fetchall()
            cols = [d[0] for d in cur.description]
            return {"table": table, "columns": cols, "rows": rows}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")

# ---------------- AR view (x/y meters) ----------------


@router.get("/create_ar_view")
def create_ar_view(
    table: str = Query("pois"),
    geom_col: str = Query("geom"),
    name_col: str = Query("name"),          # <- default to the generic 'name'
    category_col: str = Query("category"),
    floor_col: str = Query("floor_imdf_id"),
    origin_lon: float = Query(...),
    origin_lat: float = Query(...),
    prefer_alias_first: bool = Query(True, description="If true, pick best alias (EN preferred) over base name")
):
    """
    Create/replace view ar_pois_api with local-meter x,y relative to an origin lon/lat.
    If prefer_alias_first=True and poi_aliases exists, the view will choose a 'pretty' name:
        COALESCE(best_english_alias, best_any_alias, base_name)
    Otherwise it uses the base name column only.
    """
    # sanitize identifiers
    t  = '"' + table.replace('"','""') + '"'
    gc = '"' + geom_col.replace('"','""') + '"'
    nc = '"' + name_col.replace('"','""') + '"'
    cc = "NULL" if category_col.upper() == "NULL" else '"' + category_col.replace('"','""') + '"'
    fc = "NULL" if floor_col.upper()    == "NULL"    else '"' + floor_col.replace('"','""') + '"'

    # base select (without alias join)
    base_select = f"""
      SELECT
        p.id                        AS poi_id,
        {nc}                        AS base_name,
        {cc}                        AS category,
        {fc}                        AS floor,
        (ST_X(ST_Transform({gc}, 3857)) - ST_X(o.g))::double precision AS x,
        (ST_Y(ST_Transform({gc}, 3857)) - ST_Y(o.g))::double precision AS y,
        0.0::double precision       AS z
      FROM {t} p
      CROSS JOIN (
        SELECT ST_Transform(ST_SetSRID(ST_MakePoint({origin_lon}, {origin_lat}), 4326), 3857) AS g
      ) o
      WHERE {gc} IS NOT NULL
    """

    # if alias table exists and prefer_alias_first, build a wrapper that prefers aliases
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("""
                SELECT EXISTS (
                  SELECT 1 FROM information_schema.tables
                  WHERE table_schema='public' AND table_name='poi_aliases'
                )
            """)
            has_alias = bool(cur.fetchone()[0])
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error checking alias table: {e}")

    if prefer_alias_first and has_alias:
        # Use LATERAL subqueries to pick one best EN alias, else any alias
        create_sql = f"""
        CREATE OR REPLACE VIEW ar_pois_api AS
        WITH base AS (
          {base_select}
        )
        SELECT
          b.poi_id,
          COALESCE(a_en.alias_text, a_any.alias_text, b.base_name) AS name,
          b.category,
          b.floor,
          b.x, b.y, b.z
        FROM base b
        LEFT JOIN LATERAL (
          SELECT alias_text
          FROM poi_aliases pa
          WHERE pa.poi_id = b.poi_id AND pa.lang = 'en'
          ORDER BY length(alias_text) DESC, alias_text ASC
          LIMIT 1
        ) a_en ON TRUE
        LEFT JOIN LATERAL (
          SELECT alias_text
          FROM poi_aliases pa
          WHERE pa.poi_id = b.poi_id
          ORDER BY (lang='en') DESC, length(alias_text) DESC, alias_text ASC
          LIMIT 1
        ) a_any ON TRUE;
        """
    else:
        # no alias table or not preferring alias: just expose base name
        create_sql = f"""
        CREATE OR REPLACE VIEW ar_pois_api AS
        {base_select.replace(" AS base_name", " AS name")}
        ;
        """

    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("DROP VIEW IF EXISTS ar_pois_api;")
            cur.execute(create_sql)
            conn.commit()
        return {
            "ok": True,
            "view": "ar_pois_api",
            "origin": [origin_lon, origin_lat],
            "prefer_alias_first": bool(prefer_alias_first),
            "used_alias_table": bool(prefer_alias_first and has_alias)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error creating view: {e}")


# ---------------- Alias utilities (seed/list/stats) ----------------

def _alias_variants(base: str, number: Optional[int]) -> List[tuple]:
    """
    Generate EN+AR variants for common bases. Includes numbered forms when number is provided.
    """
    base_l = (base or "").strip().lower()
    num = f" {number}" if number is not None else ""
    out: List[tuple] = []

    if base_l in ["meeting room", "meeting"]:
        en = [f"meeting room{num}", f"meeting{num}"]
        ar = [f"غرفة الاجتماعات{num}".strip(), f"اجتماع{num}".strip()]
    elif base_l in ["restroom", "bathroom", "toilet", "wc"]:
        en = [f"restroom{num}", f"toilet{num}", f"bathroom{num}", f"wc{num}"]
        ar = [f"حمام{num}".strip(), f"دورة المياه{num}".strip()]
    elif base_l in ["elevator", "lift"]:
        en = [f"elevator{num}", f"lift{num}"]
        ar = [f"مصعد{num}".strip(), "اسانسير" + (str(number) if number else "")]
    elif base_l in ["phone booth", "booth", "phone"]:
        en = [f"phone booth{num}", f"booth{num}", f"phone{num}"]
        ar = [f"فون بوث{num}".strip(), f"بوث{num}".strip()]
    elif base_l in ["quiet room", "quiet", "white room"]:
        en = [f"quiet room{num}", f"quiet{num}"]
        ar = [f"غرفة هادئة{num}".strip(), f"كوايت{num}".strip(), f"وايت روم{num}".strip()]
    elif base_l in ["board room", "board"]:
        en = [f"board room{num}", f"board{num}"]
        ar = [f"بورد روم{num}".strip()]
    elif base_l in ["control room", "control"]:
        en = [f"control room{num}", f"control{num}"]
        ar = [f"غرفة التحكم{num}".strip(), f"كنترول روم{num}".strip()]
    elif base_l in ["theatre", "theater"]:
        en = ["theatre"]; ar = ["مسرح"]
    elif base_l in ["studio"]:
        en = ["studio"]; ar = ["استوديو"]
    elif base_l in ["reception", "reception / cafe", "cafe", "coffee"]:
        en = ["reception", "cafe"]; ar = ["ريسبشن", "كوفي"]
    else:
        en = [base_l + num]; ar = []

    for a in en: out.append((a, "en"))
    for a in ar: out.append((a, "ar"))
    return out

class SeedOne(BaseModel):
    poi_id: int
    base: str
    number: Optional[int] = None

class SeedBulk(BaseModel):
    items: List[SeedOne]

@router.post("/seed_aliases_manual")
def seed_aliases_manual(req: SeedOne):
    try:
        _ensure_alias_table()
        variants = _alias_variants(req.base, req.number)
        if not variants:
            raise HTTPException(status_code=400, detail="No variants generated")
        with _conn() as conn, conn.cursor() as cur:
            for alias_text, lang in variants:
                if not alias_text:
                    continue
                cur.execute(
                    """
                    INSERT INTO poi_aliases (poi_id, alias_text, lang)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (poi_id, alias_text_norm) DO NOTHING
                    """,
                    (req.poi_id, alias_text, lang),
                )
            conn.commit()
        return {"ok": True, "poi_id": req.poi_id, "inserted": len(variants)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"seed_aliases_manual error: {e}")

@router.post("/seed_aliases_bulk")
def seed_aliases_bulk(req: SeedBulk):
    try:
        _ensure_alias_table()
        total = 0
        with _conn() as conn, conn.cursor() as cur:
            for item in req.items:
                variants = _alias_variants(item.base, item.number)
                for alias_text, lang in variants:
                    if not alias_text:
                        continue
                    cur.execute(
                        """
                        INSERT INTO poi_aliases (poi_id, alias_text, lang)
                        VALUES (%s, %s, %s)
                        ON CONFLICT (poi_id, alias_text_norm) DO NOTHING
                        """,
                        (item.poi_id, alias_text, lang),
                    )
                    total += 1
            conn.commit()
        return {"ok": True, "inserted": total}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"seed_aliases_bulk error: {e}")

class AliasAdd(BaseModel):
    poi_id: int
    alias_text: str
    lang: Optional[str] = None  # auto-detect if None

@router.post("/alias_add")
def alias_add(req: AliasAdd):
    """
    Insert an exact alias string (useful for any custom Arabic/English form).
    """
    try:
        _ensure_alias_table()
        has_ar = any("\u0600" <= ch <= "\u06FF" for ch in req.alias_text or "")
        lg = req.lang or ("ar" if has_ar else "en")
        with _conn() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO poi_aliases (poi_id, alias_text, lang)
                VALUES (%s, %s, %s)
                ON CONFLICT (poi_id, alias_text_norm) DO NOTHING
                """,
                (req.poi_id, (req.alias_text or "").strip(), lg),
            )
            conn.commit()
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"alias_add error: {e}")

@router.get("/list_aliases")
def list_aliases(poi_id: Optional[int] = None, contains: Optional[str] = None):
    """
    Inspect what's stored. Example:
      /api/debug/list_aliases?poi_id=12
      /api/debug/list_aliases?contains=تحكم
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            if poi_id is not None:
                cur.execute(
                    "SELECT poi_id, alias_text, lang FROM poi_aliases WHERE poi_id=%s ORDER BY alias_text",
                    (poi_id,),
                )
            elif contains:
                like = f"%{contains}%"
                cur.execute(
                    "SELECT poi_id, alias_text, lang FROM poi_aliases WHERE alias_text ILIKE %s ORDER BY poi_id, alias_text",
                    (like,),
                )
            else:
                cur.execute(
                    "SELECT poi_id, alias_text, lang FROM poi_aliases ORDER BY poi_id, alias_text LIMIT 200"
                )
            rows = cur.fetchall()
        return {"aliases": [{"poi_id": r[0], "alias": r[1], "lang": r[2]} for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"list_aliases error: {e}")

@router.get("/alias_stats")
def alias_stats():
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM poi_aliases")
            total = cur.fetchone()[0]
            cur.execute("SELECT poi_id, COUNT(*) FROM poi_aliases GROUP BY poi_id ORDER BY 1")
            by_poi = cur.fetchall()
        return {
            "total_aliases": int(total),
            "by_poi": [{"poi_id": r[0], "count": r[1]} for r in by_poi]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"alias_stats error: {e}")

# ---------------- Optional: auto-seed from IMDF units GeoJSON ----------------

@router.post("/seed_from_imdf_units")
def seed_from_imdf_units(
    path: str = Query(..., description="Absolute path to IMDF units GeoJSON (features[].properties.name/alt_name)"),
    default_lang: str = Query("en")
):
    """
    Reads IMDF units GeoJSON and inserts 'name'/'alt_name' as aliases
    by matching normalized strings against existing ar_pois_api names.
    Useful when DB already has canonical POIs and you want to augment with IMDF text.
    """
    try:
        if not os.path.exists(path):
            raise HTTPException(status_code=400, detail=f"IMDF units file not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            gj = json.load(f)

        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT poi_id, name FROM ar_pois_api")
            db_rows = cur.fetchall()

        from NLP.nlp_preproc_syn import norm_json_name
        norm_to_poi: Dict[str, List[int]] = {}
        for pid, nm in db_rows:
            nn = norm_json_name(nm or "")
            if nn:
                norm_to_poi.setdefault(nn, []).append(int(pid))

        _ensure_alias_table()
        inserted = 0

        with _conn() as conn, conn.cursor() as cur:
            for ft in gj.get("features", []):
                props = ft.get("properties", {}) or {}
                name = (props.get("name") or "").strip()
                alt  = (props.get("alt_name") or "").strip()

                for candidate in [name, alt]:
                    if not candidate:
                        continue
                    nn = norm_json_name(candidate)
                    if not nn:
                        continue
                    ids = norm_to_poi.get(nn)
                    if not ids:
                        continue
                    poi_id = sorted(ids)[0]
                    has_ar = any("\u0600" <= ch <= "\u06FF" for ch in candidate)
                    lang = "ar" if has_ar else default_lang

                    cur.execute(
                        """
                        INSERT INTO poi_aliases (poi_id, alias_text, lang)
                        VALUES (%s, %s, %s)
                        ON CONFLICT (poi_id, alias_text_norm) DO NOTHING
                        """,
                        (poi_id, candidate, lang),
                    )
                    inserted += 1

            conn.commit()

        return {"ok": True, "inserted": inserted, "source": path}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"seed_from_imdf_units error: {e}")

# ---------------- Migration: dedupe + unique constraint + cleanup ----------------

@router.post("/alias_migrate_fix")
def alias_migrate_fix(fix_mojibake: bool = True):
    """
    1) Ensure table + generated lower() column.
    2) Remove duplicates per (poi_id, alias_text_norm).
    3) Add UNIQUE constraint on (poi_id, alias_text_norm).
    4) Optionally delete mojibake Arabic rows.
    """
    try:
        _ensure_alias_table()
        with _conn() as conn, conn.cursor() as cur:
            # 2) delete duplicates (keep first)
            cur.execute("""
                WITH ranked AS (
                  SELECT ctid,
                         row_number() OVER (
                           PARTITION BY poi_id, alias_text_norm
                           ORDER BY ctid
                         ) AS rn
                  FROM poi_aliases
                )
                DELETE FROM poi_aliases p
                USING ranked r
                WHERE p.ctid = r.ctid
                  AND r.rn > 1;
            """)

            # 3) add unique constraint on (poi_id, alias_text_norm)
            cur.execute("""
                DO $$
                BEGIN
                  IF NOT EXISTS (
                    SELECT 1
                    FROM pg_constraint
                    WHERE conname = 'uq_poi_alias_unique'
                      AND conrelid = 'poi_aliases'::regclass
                  ) THEN
                    EXECUTE 'ALTER TABLE poi_aliases
                             ADD CONSTRAINT uq_poi_alias_unique
                             UNIQUE (poi_id, alias_text_norm)';
                  END IF;
                END$$;
            """)

            # 4) optional mojibake cleanup
            if fix_mojibake:
                cur.execute("""
                    DELETE FROM poi_aliases
                    WHERE lang = 'ar'
                      AND (alias_text ~ '^[ØÙÛÐ]' OR alias_text LIKE 'Ã%%' OR alias_text LIKE 'Â%%');
                """)

            conn.commit()

        return {"ok": True, "deduped": True, "unique": "poi_id, alias_text_norm", "mojibake_deleted": fix_mojibake}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"alias_migrate_fix error: {e}")
@router.post("/alias_cleanup_no_ar")
def alias_cleanup_no_ar():
    """
    Delete rows marked as Arabic (lang='ar') but containing no Arabic codepoints.
    Useful to remove mojibake that sneaked in as Latin-1.
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("""
                DELETE FROM poi_aliases
                WHERE lang = 'ar' AND alias_text !~ '[\\u0600-\\u06FF]';
            """)
            deleted = cur.rowcount
            conn.commit()
        return {"ok": True, "deleted": int(deleted)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"alias_cleanup_no_ar error: {e}")

@router.post("/alias_cleanup_no_ar_py")
def alias_cleanup_no_ar_py():
    """
    Delete rows marked as Arabic (lang='ar') but containing NO Arabic codepoints.
    Works in Python so we don't rely on PostgreSQL regex unicode classes.
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT poi_id, alias_text FROM poi_aliases WHERE lang='ar'")
            rows = cur.fetchall()

        def has_arabic(s: str) -> bool:
            return any('\u0600' <= ch <= '\u06FF' for ch in s or "")

        bad = [(pid, txt) for (pid, txt) in rows if not has_arabic(txt)]
        deleted = 0
        if bad:
            with _conn() as conn, conn.cursor() as cur:
                for pid, txt in bad:
                    cur.execute(
                        "DELETE FROM poi_aliases WHERE poi_id=%s AND alias_text=%s AND lang='ar'",
                        (pid, txt)
                    )
                    deleted += cur.rowcount
                conn.commit()
        return {"ok": True, "deleted": int(deleted)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"alias_cleanup_no_ar_py error: {e}")


@router.post("/alias_dedupe")
def alias_dedupe():
    """
    Remove exact duplicates ignoring case on alias_text per poi_id.
    Keeps the first row and deletes the rest.
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            # Delete duplicates using row_number over (poi_id, lower(alias_text), lang)
            cur.execute("""
                WITH ranked AS (
                  SELECT ctid, ROW_NUMBER() OVER (
                    PARTITION BY poi_id, LOWER(alias_text), lang ORDER BY ctid
                  ) AS rn
                  FROM poi_aliases
                )
                DELETE FROM poi_aliases p
                USING ranked r
                WHERE p.ctid = r.ctid AND r.rn > 1;
            """)
            deleted = cur.rowcount
            conn.commit()
        return {"ok": True, "deleted": int(deleted)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"alias_dedupe error: {e}")
@router.get("/list_pois")
def list_pois():
    """
    Returns all POIs from ar_pois_api (poi_id, name) for automated testing.
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT poi_id, name FROM ar_pois_api ORDER BY poi_id")
            rows = cur.fetchall()
        return {"pois": [{"poi_id": int(r[0]), "name": r[1]} for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"list_pois error: {e}")


@router.get("/list_alias_samples")
def list_alias_samples():
    """
    (Optional) Quick peek at a few aliases per POI to sanity-check Arabic seeding.
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("""
                SELECT poi_id, alias_text, lang
                FROM poi_aliases
                ORDER BY poi_id, alias_text
                LIMIT 200
            """)
            rows = cur.fetchall()
        return {"aliases": [{"poi_id": int(r[0]), "alias": r[1], "lang": r[2]} for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"list_alias_samples error: {e}")
@router.get("/dump_pois")
def dump_pois():
    """
    Return all canonical POIs from ar_pois_api.
    Response: {"items":[{"poi_id":..., "name":"..."}, ...]}
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT poi_id, name FROM ar_pois_api ORDER BY poi_id")
            rows = cur.fetchall()
        return {"items": [{"poi_id": int(r[0]), "name": r[1]} for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"dump_pois error: {e}")


@router.post("/seed_from_imdf_by_id")
def seed_from_imdf_by_id(
    path: str = Query(..., description="IMDF units GeoJSON path (features[].properties.id/name/alt_name)"),
    prefer_alt: bool = Query(False),
    pois_id_column: str = Query("imdf_id", description="Column in pois to match IMDF id (e.g., imdf_id or unit_id)")
):
    try:
        if not os.path.exists(path):
            raise HTTPException(status_code=400, detail=f"IMDF units file not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            gj = json.load(f)

        _ensure_alias_table()
        inserted = 0

        with _conn() as conn, conn.cursor() as cur:
            for ft in gj.get("features", []):
                props = ft.get("properties") or {}
                unit_id = (props.get("id") or props.get("unit_id") or "").strip()
                nm = (props.get("name") or "").strip()
                alt = (props.get("alt_name") or "").strip()
                if not unit_id:
                    continue
                label = (alt if (prefer_alt and alt) else nm) or alt
                if not label:
                    continue

                # Try chosen column first; if not found and column was 'imdf_id', try 'unit_id' as a fallback.
                try_cols = [pois_id_column] + (["unit_id"] if pois_id_column != "unit_id" else [])
                poi_id = None
                for col in try_cols:
                    cur.execute(f'SELECT id FROM pois WHERE "{col}" = %s LIMIT 1', (unit_id,))
                    row = cur.fetchone()
                    if row:
                        poi_id = int(row[0])
                        break
                if poi_id is None:
                    continue

                has_ar = any("\u0600" <= ch <= "\u06FF" for ch in label)
                lang = "ar" if has_ar else "en"

                try:
                    cur.execute(
                        "INSERT INTO poi_aliases (poi_id, alias_text, lang) VALUES (%s, %s, %s)",
                        (poi_id, label, lang),
                    )
                    inserted += 1
                except Exception:
                    pass  # duplicate → ignore

            conn.commit()

        return {"ok": True, "inserted": inserted, "source": path}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"seed_from_imdf_by_id error: {e}")

