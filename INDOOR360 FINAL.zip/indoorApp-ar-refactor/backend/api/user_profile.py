# backend/api/user_profile.py

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from app.database import get_connection_v2

router = APIRouter()

# ---------- DB helper ----------

def get_db():
    """Get database connection from centralized module."""
    return get_connection_v2()


# ---------- Pydantic models (match iOS) ----------

class UserSettingsIn(BaseModel):
    preferredLanguage: Optional[str] = None
    voiceEnabled: Optional[bool] = None
    darkMode: Optional[bool] = None
    lastSelectedVenueId: Optional[int] = None


class UserSettingsOut(BaseModel):
    userId: int
    preferredLanguage: Optional[str] = None
    voiceEnabled: Optional[bool] = None
    darkMode: Optional[bool] = None
    lastSelectedVenueId: Optional[int] = None


class SearchHistoryIn(BaseModel):
    query: str
    resolvedPoiId: Optional[int] = None
    resolvedLabel: Optional[str] = None


class SearchHistoryItem(BaseModel):
    searchId: int
    userId: int
    query: str
    resolvedPoiId: Optional[int] = None
    resolvedLabel: Optional[str] = None
    searchedAt: str


# ---------- SETTINGS ENDPOINTS ----------

@router.get("/api/user/{user_id}/settings", response_model=UserSettingsOut)
def get_user_settings(user_id: int):
    """
    Return settings for a user.
    If no row exists yet -> return defaults.
    """
    conn = get_db()
    cur = conn.cursor()

    cur.execute(
        """
        SELECT
            user_id,
            preferred_language,
            voice_enabled,
            dark_mode,
            last_selected_venue
        FROM user_settings
        WHERE user_id = %s
        """,
        (user_id,)
    )
    row = cur.fetchone()

    cur.close()
    conn.close()

    # No settings yet -> default values
    if not row:
        return UserSettingsOut(
            userId=user_id,
            preferredLanguage="en",
            voiceEnabled=True,
            darkMode=False,
            lastSelectedVenueId=None,
        )

    return UserSettingsOut(
        userId=row[0],
        preferredLanguage=row[1],
        voiceEnabled=row[2],
        darkMode=row[3],
        lastSelectedVenueId=row[4],
    )


@router.put("/api/user/{user_id}/settings", response_model=UserSettingsOut)
def upsert_user_settings(user_id: int, body: UserSettingsIn):
    """
    Insert or update settings for a user.
    """
    conn = get_db()
    cur = conn.cursor()

    try:
        # Try update first
        cur.execute(
            """
            UPDATE user_settings
            SET
                preferred_language   = %s,
                voice_enabled        = %s,
                dark_mode            = %s,
                last_selected_venue  = %s,
                updated_at           = NOW()
            WHERE user_id = %s
            """,
            (
                body.preferredLanguage,
                body.voiceEnabled,
                body.darkMode,
                body.lastSelectedVenueId,
                user_id,
            ),
        )

        if cur.rowcount == 0:
            # No existing row -> insert
            cur.execute(
                """
                INSERT INTO user_settings (
                    user_id,
                    preferred_language,
                    voice_enabled,
                    dark_mode,
                    last_selected_venue
                )
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    user_id,
                    body.preferredLanguage,
                    body.voiceEnabled,
                    body.darkMode,
                    body.lastSelectedVenueId,
                ),
            )

        conn.commit()
    except psycopg2.Error as e:
        conn.rollback()
        print("❌ user_settings DB error:", e)
        raise HTTPException(status_code=500, detail="Database error in user_settings")
    finally:
        cur.close()
        conn.close()

    return UserSettingsOut(
        userId=user_id,
        preferredLanguage=body.preferredLanguage,
        voiceEnabled=body.voiceEnabled,
        darkMode=body.darkMode,
        lastSelectedVenueId=body.lastSelectedVenueId,
    )


# ---------- SEARCH HISTORY ENDPOINTS ----------

@router.get(
    "/api/user/{user_id}/searches",
    response_model=List[SearchHistoryItem]
)
def get_search_history(user_id: int, limit: int = 10):
    """
    Return latest N searches for this user.
    """
    conn = get_db()
    cur = conn.cursor()

    cur.execute(
        """
        SELECT
            search_id,
            user_id,
            query,
            resolved_poi_id,
            resolved_label,
            searched_at
        FROM search_history
        WHERE user_id = %s
        ORDER BY searched_at DESC
        LIMIT %s
        """,
        (user_id, limit)
    )

    rows = cur.fetchall()
    cur.close()
    conn.close()

    return [
        SearchHistoryItem(
            searchId=row[0],
            userId=row[1],
            query=row[2],
            resolvedPoiId=row[3],
            resolvedLabel=row[4],
            searchedAt=row[5].isoformat(),
        )
        for row in rows
    ]


@router.post(
    "/api/user/{user_id}/searches",
    response_model=SearchHistoryItem
)
def add_search_history(user_id: int, body: SearchHistoryIn):
    """
    Store one search (text + resolved POI).
    """
    conn = get_db()
    cur = conn.cursor()

    try:
        cur.execute(
            """
            INSERT INTO search_history (
                user_id,
                query,
                resolved_poi_id,
                resolved_label
            )
            VALUES (%s, %s, %s, %s)
            RETURNING
                search_id,
                searched_at
            """,
            (
                user_id,
                body.query.strip(),
                body.resolvedPoiId,
                body.resolvedLabel,
            ),
        )
        row = cur.fetchone()
        conn.commit()
    except psycopg2.Error as e:
        conn.rollback()
        print("❌ search_history DB error:", e)
        raise HTTPException(status_code=500, detail="Database error in search_history")
    finally:
        cur.close()
        conn.close()

    return SearchHistoryItem(
        searchId=row[0],
        userId=user_id,
        query=body.query.strip(),
        resolvedPoiId=body.resolvedPoiId,
        resolvedLabel=body.resolvedLabel,
        searchedAt=row[1].isoformat(),
    )
