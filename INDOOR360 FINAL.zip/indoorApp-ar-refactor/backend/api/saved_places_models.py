"""
Pydantic models for saved places API
"""

from pydantic import BaseModel, Field, field_validator
from typing import Optional
from datetime import datetime


class CategoryResponse(BaseModel):
    """Response model for place category"""
    category_id: int
    name: str
    icon: Optional[str] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class SavedPlaceResponse(BaseModel):
    """Response model for saved place"""
    saved_place_id: int
    user_id: int
    poi_id: Optional[int] = None
    title: str
    category_id: Optional[int] = None
    category_name: Optional[str] = None
    category_icon: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class CreateSavedPlaceRequest(BaseModel):
    """
    Request model for creating a saved place.

    NOTE: category_name is OPTIONAL here so the backend will not return 422
    even if the app sends nothing or a placeholder like "Category".
    """
    poi_id: Optional[int] = None
    title: str = Field(..., min_length=1, max_length=200)
    category_name: Optional[str] = None
    notes: Optional[str] = None

    @field_validator("title")
    @classmethod
    def validate_title(cls, v: str) -> str:
        """Ensure title is not just whitespace"""
        if not v.strip():
            raise ValueError("Title cannot be empty or whitespace only")
        return v.strip()


class UpdateSavedPlaceRequest(BaseModel):
    """Request model for updating a saved place"""
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    category_name: Optional[str] = None
    notes: Optional[str] = None

    @field_validator("title")
    @classmethod
    def validate_title(cls, v: Optional[str]) -> Optional[str]:
        """Ensure title is not just whitespace if provided"""
        if v is not None and not v.strip():
            raise ValueError("Title cannot be empty or whitespace only")
        return v.strip() if v else None
