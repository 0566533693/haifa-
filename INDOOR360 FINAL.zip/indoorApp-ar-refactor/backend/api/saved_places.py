"""
Saved places API endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg.rows import dict_row
import psycopg

from app.config import settings
from api.saved_places_models import (
    CategoryResponse,
    SavedPlaceResponse,
    CreateSavedPlaceRequest,
    UpdateSavedPlaceRequest,
)
from api.auth_utils import get_current_user

router = APIRouter(prefix="/api/saved-places", tags=["saved-places"])

# Use the same DB URL as the rest of the backend
DATABASE_URL = settings.DATABASE_URL


@router.get("/categories", response_model=list[CategoryResponse])
async def get_categories():
    """
    Get all place categories
    """
    try:
        with psycopg.connect(DATABASE_URL, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT category_id, name, icon, created_at
                    FROM place_categories
                    ORDER BY name
                    """
                )
                categories = cur.fetchall()
                return [CategoryResponse(**cat) for cat in categories]

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch categories: {str(e)}",
        )


@router.get("", response_model=list[SavedPlaceResponse])
async def get_saved_places(current_user: dict = Depends(get_current_user)):
    """
    Get all saved places for the current user
    """
    try:
        with psycopg.connect(DATABASE_URL, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        sp.saved_place_id,
                        sp.user_id,
                        sp.poi_id,
                        sp.title,
                        sp.category_id,
                        pc.name as category_name,
                        pc.icon as category_icon,
                        sp.notes,
                        sp.created_at,
                        sp.updated_at
                    FROM saved_places sp
                    LEFT JOIN place_categories pc ON sp.category_id = pc.category_id
                    WHERE sp.user_id = %s
                    ORDER BY sp.created_at DESC
                    """,
                    (current_user["user_id"],),
                )

                places = cur.fetchall()
                return [SavedPlaceResponse(**place) for place in places]

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch saved places: {str(e)}",
        )


@router.post("", response_model=SavedPlaceResponse, status_code=status.HTTP_201_CREATED)
async def create_saved_place(
    request: CreateSavedPlaceRequest,
    current_user: dict = Depends(get_current_user),
):
    """
    Create a new saved place for the current user.

    If category_name is missing, empty, or equals the placeholder "Category",
    we automatically map it to a default category like "Favorites".
    """
    try:
        with psycopg.connect(DATABASE_URL, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                # ---------- Resolve category name ----------
                raw = (request.category_name or "").strip()
                if not raw or raw.lower() == "category":
                    category_name = "Favorites"  # 👈 default category
                else:
                    category_name = raw

                # Get or create category_id from category_name
                cur.execute(
                    """
                    SELECT category_id, name, icon, created_at
                    FROM place_categories
                    WHERE name = %s
                    """,
                    (category_name,),
                )
                category = cur.fetchone()

                if not category:
                    # Auto-create the category if it doesn't exist yet
                    cur.execute(
                        """
                        INSERT INTO place_categories (name, icon)
                        VALUES (%s, %s)
                        RETURNING category_id, name, icon, created_at
                        """,
                        (category_name, "bookmark.fill"),
                    )
                    category = cur.fetchone()

                category_id = category["category_id"]

                # ---------- Validate POI if provided ----------
                if request.poi_id:
                    cur.execute(
                        "SELECT poi_id FROM pois WHERE poi_id = %s",
                        (request.poi_id,),
                    )
                    if not cur.fetchone():
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail=f"POI with id {request.poi_id} not found",
                        )

                # ---------- Check duplicate (same user + poi_id) ----------
                if request.poi_id:
                    cur.execute(
                        """
                        SELECT saved_place_id FROM saved_places
                        WHERE user_id = %s AND poi_id = %s
                        """,
                        (current_user["user_id"], request.poi_id),
                    )

                    if cur.fetchone():
                        raise HTTPException(
                            status_code=status.HTTP_409_CONFLICT,
                            detail="This place is already saved",
                        )

                # ---------- Insert saved place ----------
                cur.execute(
                    """
                    INSERT INTO saved_places (user_id, poi_id, title, category_id, notes)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING saved_place_id, user_id, poi_id, title,
                              category_id, notes, created_at, updated_at
                    """,
                    (
                        current_user["user_id"],
                        request.poi_id,
                        request.title,
                        category_id,
                        request.notes,
                    ),
                )

                place = cur.fetchone()
                conn.commit()

                return SavedPlaceResponse(
                    **place,
                    category_name=category["name"],
                    category_icon=category["icon"],
                )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create saved place: {str(e)}",
        )


@router.put("/{saved_place_id}", response_model=SavedPlaceResponse)
async def update_saved_place(
    saved_place_id: int,
    request: UpdateSavedPlaceRequest,
    current_user: dict = Depends(get_current_user),
):
    """
    Update a saved place (must be owned by current user)
    """
    try:
        with psycopg.connect(DATABASE_URL, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                # Check ownership
                cur.execute(
                    """
                    SELECT user_id, category_id
                    FROM saved_places
                    WHERE saved_place_id = %s
                    """,
                    (saved_place_id,),
                )

                place = cur.fetchone()
                if not place:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Saved place not found",
                    )

                if place["user_id"] != current_user["user_id"]:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You don't have permission to update this saved place",
                    )

                # Build update query dynamically
                updates = []
                params: list = []

                if request.title is not None:
                    updates.append("title = %s")
                    params.append(request.title)

                if request.category_name is not None:
                    raw = request.category_name.strip()
                    if not raw or raw.lower() == "category":
                        category_name = "Favorites"
                    else:
                        category_name = raw

                    # Get or create category_id
                    cur.execute(
                        """
                        SELECT category_id, name, icon, created_at
                        FROM place_categories
                        WHERE name = %s
                        """,
                        (category_name,),
                    )
                    category = cur.fetchone()
                    if not category:
                        cur.execute(
                            """
                            INSERT INTO place_categories (name, icon)
                            VALUES (%s, %s)
                            RETURNING category_id, name, icon, created_at
                            """,
                            (category_name, "bookmark.fill"),
                        )
                        category = cur.fetchone()

                    updates.append("category_id = %s")
                    params.append(category["category_id"])
                else:
                    category = None

                if request.notes is not None:
                    updates.append("notes = %s")
                    params.append(request.notes)

                if not updates:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="No fields to update",
                    )

                updates.append("updated_at = NOW()")
                params.append(saved_place_id)

                # Execute update
                cur.execute(
                    f"""
                    UPDATE saved_places
                    SET {', '.join(updates)}
                    WHERE saved_place_id = %s
                    RETURNING saved_place_id, user_id, poi_id, title,
                              category_id, notes, created_at, updated_at
                    """,
                    params,
                )

                updated_place = cur.fetchone()
                conn.commit()

                # If we changed the category, use that; otherwise, look it up
                if category is None:
                    cur.execute(
                        """
                        SELECT name, icon
                        FROM place_categories
                        WHERE category_id = %s
                        """,
                        (updated_place["category_id"],),
                    )
                    category = cur.fetchone()

                return SavedPlaceResponse(
                    **updated_place,
                    category_name=category["name"],
                    category_icon=category["icon"],
                )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update saved place: {str(e)}",
        )


@router.delete("/{saved_place_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_saved_place(
    saved_place_id: int,
    current_user: dict = Depends(get_current_user),
):
    """
    Delete a saved place (must be owned by current user)
    """
    try:
        with psycopg.connect(DATABASE_URL, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                # Check ownership
                cur.execute(
                    """
                    SELECT user_id FROM saved_places
                    WHERE saved_place_id = %s
                    """,
                    (saved_place_id,),
                )

                place = cur.fetchone()
                if not place:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Saved place not found",
                    )

                if place["user_id"] != current_user["user_id"]:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="You don't have permission to delete this saved place",
                    )

                # Delete
                cur.execute(
                    """
                    DELETE FROM saved_places
                    WHERE saved_place_id = %s
                    """,
                    (saved_place_id,),
                )
                conn.commit()

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete saved place: {str(e)}",
        )
