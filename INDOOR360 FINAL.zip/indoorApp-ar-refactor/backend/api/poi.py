# backend/api/poi.py
from fastapi import APIRouter, HTTPException
import difflib
from typing import List, Tuple, Dict, Any
import psycopg2 as psycopg
from app.database import get_connection_v2

router = APIRouter(prefix="/api/poi", tags=["poi"])


# ---------- DB helpers ----------

def _conn():
    """Get database connection from centralized module."""
    return get_connection_v2()

def _rel_exists(schema: str, name: str) -> bool:
    """Check if a table or view exists in current schema."""
    q = """
    SELECT EXISTS (
      SELECT 1
      FROM information_schema.tables
      WHERE table_schema = %s AND table_name = %s
    )
    UNION
    SELECT EXISTS (
      SELECT 1
      FROM information_schema.views
      WHERE table_schema = %s AND table_name = %s
    )
    """
    with _conn() as conn, conn.cursor() as cur:
        cur.execute(q, (schema, name, schema, name))
        rows = cur.fetchall()
        return any(r[0] for r in rows)

def _columns(table: str):
    with _conn() as conn, conn.cursor() as cur:
        cur.execute("""
            SELECT column_name
            FROM information_schema.columns
            WHERE table_name = %s
        """, (table,))
        return {r[0].lower() for r in cur.fetchall()}

def _pick(cols, *candidates):
    for c in candidates:
        if c and c.lower() in cols:
            return c
    return None

# ---------- Core loaders ----------

def _load_pois_from_view() -> List[Tuple[int, str, Any, Any, float, float, float]]:
    """poi_id, name, category, floor, x, y, z from ar_pois_api."""
    with _conn() as conn, conn.cursor() as cur:
        cur.execute("""
            SELECT poi_id, name, category, floor, x, y, z
            FROM ar_pois_api
            ORDER BY poi_id ASC
        """)
        return cur.fetchall()

def _load_pois_fallback() -> List[Tuple[int, str, Any, Any, float, float, float]]:
    """Map a generic pois table if view not present."""
    table = "pois"
    cols = _columns(table)

    pk     = _pick(cols, "poi_id", "id")
    name   = _pick(cols, "name", "poi_name", "label", "display_name")
    cat    = _pick(cols, "category", "type", "kind")
    floorc = _pick(cols, "floor", "level", "floor_number", "storey", "floor_imdf_id")
    xcol   = _pick(cols, "x", "local_x", "pos_x")
    ycol   = _pick(cols, "y", "local_y", "pos_y")
    zcol   = _pick(cols, "z", "local_z", "pos_z")
    geom   = _pick(cols, "geom", "geometry")

    if not pk or not name:
        raise HTTPException(
            status_code=500,
            detail=f"DB error: Could not find primary key/name columns in {table}. "
                   f"Columns: {sorted(list(cols))}"
        )

    if not (xcol and ycol):
        if geom:
            raise HTTPException(
                status_code=500,
                detail=("DB has geometry but no x/y. Recreate the view via "
                        "/api/debug/create_ar_view?table=pois&geom_col=geom&name_col=name&category_col=NULL"
                        "&floor_col=floor_imdf_id&origin_lon=<lon>&origin_lat=<lat>")
            )
        else:
            raise HTTPException(
                status_code=500,
                detail=f"DB error: No x/y columns and no geometry in {table}. Columns: {sorted(list(cols))}"
            )

    q = f"""
        SELECT
          {pk}      AS poi_id,
          {name}    AS name,
          {cat or 'NULL'} AS category,
          {floorc or 'NULL'} AS floor,
          {xcol}    AS x,
          {ycol}    AS y,
          {zcol or '0'} AS z
        FROM {table}
        ORDER BY {pk} ASC
    """
    with _conn() as conn, conn.cursor() as cur:
        cur.execute(q)
        return cur.fetchall()

def _load_pois_all() -> List[Tuple[int, str, Any, Any, float, float, float]]:
    if _rel_exists("public", "ar_pois_api"):
        return _load_pois_from_view()
    return _load_pois_fallback()

def _try_load_aliases() -> List[Tuple[int, str]]:
    """Optional alias list (poi_id, alias_text)."""
    out: List[Tuple[int, str]] = []
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT poi_id, alias_text FROM poi_aliases")
            for pid, alias in cur.fetchall():
                if alias:
                    out.append((int(pid), str(alias)))
    except Exception:
        pass
    return out

# ---------- API ----------

@router.get("/list")
def list_pois():
    try:
        rows = _load_pois_all()
        pois = [
            {
                "id": r[0],
                "name": r[1],
                "category": r[2],
                "floor": r[3],
                "x": float(r[4]) if r[4] is not None else None,
                "y": float(r[5]) if r[5] is not None else None,
                "z": float(r[6]) if r[6] is not None else None,
            }
            for r in rows
        ]
        return {"pois": pois}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")

@router.get("/search")
def search_pois(q: str, limit: int = 20):
    """
    Fuzzy search over names (and optional aliases) with a relevance score.
    Returns plain list of POIs for iOS RemotePOIService.
    """
    try:
        rows = _load_pois_all()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")

    name_by_id: Dict[int, str] = {}
    base: List[Dict[str, Any]] = []

    for r in rows:
        pid, name, category, floor, x, y, z = r
        name = name or ""
        base.append({
            "id": int(pid),
            "name": name,
            "category": category,
            "floor": floor,
            "x": float(x),
            "y": float(y),
            "z": float(z)
        })

    alias = _try_load_aliases()

    ql = (q or "").lower().strip()
    if not ql:
        return []

    scored = []
    for item in base:
        label = item["name"].lower()

        score = difflib.SequenceMatcher(None, ql, label).ratio()
        if ql in label:
            score = max(score, 0.98)

        for (pid, alias_text) in alias:
            if pid == item["id"]:
                al = alias_text.lower()
                s2 = difflib.SequenceMatcher(None, ql, al).ratio()
                if ql in al:
                    s2 = max(s2, 0.98)
                score = max(score, s2)

        if score >= 0.50:
            out = dict(item)
            out["score"] = round(float(score), 2)
            scored.append(out)

    scored.sort(key=lambda d: d["score"], reverse=True)

    # ------- THIS IS THE FIX -------
    output = []
    for item in scored[:max(1, min(limit, 50))]:
        output.append({
            "id": item["id"],
            "name": item["name"],
            "category": item["category"],
            "floor": item["floor"],
            "distance_m": None
        })

    return output


@router.get("/suggest")
def suggest_pois(q: str, limit: int = 8):
    """
    Lightweight typeahead: returns [{id, name, score}] only.
    Use this for dropdown suggestions while typing.
    """
    try:
        rows = _load_pois_all()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")

    # names
    items = [(int(r[0]), str(r[1] or "")) for r in rows]
    # aliases (optional)
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT poi_id, alias_text FROM poi_aliases")
            items += [(int(pid), str(alias or "")) for pid, alias in cur.fetchall() if alias]
    except Exception:
        pass

    ql = (q or "").lower().strip()
    if not ql:
        return {"suggestions": []}

    scored = []
    for pid, label in items:
        lab_l = label.lower()
        score = difflib.SequenceMatcher(None, ql, lab_l).ratio()
        if ql in lab_l:
            score = max(score, 0.98)
        if score >= 0.50:
            scored.append({"id": pid, "name": label, "score": round(float(score), 2)})

    # de-dupe by id: keep highest score/name containing query if possible
    best_by_id: Dict[int, Dict[str, Any]] = {}
    for s in scored:
        cur = best_by_id.get(s["id"])
        if (cur is None) or (s["score"] > cur["score"]) or (ql in s["name"].lower() and ql not in cur["name"].lower()):
            best_by_id[s["id"]] = s

    out = sorted(best_by_id.values(), key=lambda d: d["score"], reverse=True)
    return {"suggestions": out[:max(1, min(limit, 20))]}
