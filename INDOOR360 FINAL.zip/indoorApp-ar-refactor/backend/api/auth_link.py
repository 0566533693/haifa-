# backend/api/auth_link.py

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from typing import Optional

from api.nlp import get_db

# Full path: /api/auth/link
router = APIRouter(
    prefix="/api/auth",
    tags=["auth"],
)

# ---------- Pydantic models ----------

class AuthLinkIn(BaseModel):
    # 👇 these names must be SNAKE_CASE to match what Swift sends
    firebase_uid: str
    email: EmailStr
    display_name: Optional[str] = None
    auth_provider: str = "firebase"


class UserOut(BaseModel):
    # Response fields use snake_case too (Swift JSONDecoder has .convertFromSnakeCase)
    id: int
    firebase_uid: Optional[str]
    email: EmailStr
    name: Optional[str] = None
    auth_provider: Optional[str] = None


# ---------- Endpoint ----------

@router.post("/link", response_model=UserOut)
def link_user(body: AuthLinkIn):
    """
    Link a Firebase user to a row in `users` table.

    - If email is new  -> INSERT
    - If email exists -> UPDATE that row and return it
    """
    conn = get_db()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO users (firebase_uid, email, name, auth_provider)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (email) DO UPDATE
                    SET
                        firebase_uid   = EXCLUDED.firebase_uid,
                        name           = EXCLUDED.name,
                        auth_provider  = EXCLUDED.auth_provider,
                        updated_at     = NOW()
                    RETURNING user_id, firebase_uid, email, name, auth_provider;
                    """,
                    (
                        body.firebase_uid,
                        body.email,
                        body.display_name,
                        body.auth_provider,
                    ),
                )
                row = cur.fetchone()
                return UserOut(
                    id=row[0],
                    firebase_uid=row[1],
                    email=row[2],
                    name=row[3],
                    auth_provider=row[4],
                )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error in auth link: {e}")
    finally:
        conn.close()
