# backend/api/navigation.py

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from api.nlp import get_db

router = APIRouter(prefix="/api/user/{user_id}/navigation", tags=["navigation"])


# ---------- Pydantic models ----------

# 👇 match what the iOS app actually sends (snake_case keys)
class NavigationLogIn(BaseModel):
    from_poi_id: int
    to_poi_id: int
    distance_m: float
    duration_sec: float


class NavigationLogOut(BaseModel):
    session_id: int


# ---------- Endpoint ----------

@router.post("", response_model=NavigationLogOut)
def log_navigation(user_id: int, body: NavigationLogIn):
    """
    Insert one row in navigation_sessions.
    iOS payload keys are snake_case (because of JSONEncoder.convertToSnakeCase),
    so the model above uses the same names.
    """
    conn = get_db()
    cur = conn.cursor()

    try:
        cur.execute(
            """
            INSERT INTO navigation_sessions (
                user_id,
                start_poi_id,
                end_poi_id,
                distance_m,
                duration_sec,
                started_at
            )
            VALUES (%s, %s, %s, %s, %s, NOW())
            RETURNING session_id
            """,
            (
                user_id,
                body.from_poi_id,
                body.to_poi_id,
                body.distance_m,
                body.duration_sec,
            ),
        )
        session_id = cur.fetchone()[0]
        conn.commit()
        return {"session_id": session_id}

    except Exception as e:
        conn.rollback()
        print("❌ navigation DB error:", e)
        raise HTTPException(
            status_code=500,
            detail=f"Database error in navigation logging: {e}",
        )
    finally:
        cur.close()
        conn.close()
