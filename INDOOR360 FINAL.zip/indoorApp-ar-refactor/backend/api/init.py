from api.nlp import router as nlp_router
