# backend/api/ar.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import psycopg
from app.database import get_connection

router = APIRouter(prefix="/api/ar", tags=["ar"])

class AnchorOut(BaseModel):
    anchor_id: int
    poi_id: int
    floor: int
    x: float
    y: float
    z: float
    label: str

def _conn():
    """Get database connection from centralized module."""
    return get_connection()

@router.get("/anchor/{anchor_id}", response_model=AnchorOut)
def get_anchor(anchor_id: int):
    with _conn() as conn, conn.cursor() as cur:
        cur.execute("""
            SELECT anchor_id, poi_id, floor, x, y, z, label
            FROM ar_anchors
            WHERE anchor_id = %s
        """, (anchor_id,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Anchor not found")
        return AnchorOut(
            anchor_id=row[0], poi_id=row[1], floor=row[2],
            x=float(row[3]), y=float(row[4]), z=float(row[5]), label=row[6]
        )
