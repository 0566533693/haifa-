# backend/api/debug_aliases.py
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional
import psycopg
from app.database import get_connection

router = APIRouter(prefix="/api/debug", tags=["debug-aliases"])

def _conn():
    """Get database connection from centralized module."""
    return get_connection()

def _ensure_table():
    with _conn() as conn, conn.cursor() as cur:
        cur.execute("""
        CREATE TABLE IF NOT EXISTS poi_aliases (
          poi_id     INT NOT NULL,
          alias_text TEXT NOT NULL,
          lang       VARCHAR(5)
        );
        CREATE INDEX IF NOT EXISTS idx_poi_alias_text ON poi_aliases (alias_text);
        CREATE INDEX IF NOT EXISTS idx_poi_alias_poi  ON poi_aliases (poi_id);
        """)
        conn.commit()

# ---------- SEED HELPERS ----------
def _alias_variants(base: str, number: Optional[int]) -> List[tuple]:
    base_l = (base or "").strip().lower()
    num = f" {number}" if number is not None else ""
    out: List[tuple] = []

    if base_l in ["meeting room", "meeting"]:
        en = [f"meeting room{num}", f"meeting{num}"]
        ar = [f"غرفة الاجتماعات{num}".strip(), f"اجتماع{num}".strip()]
    elif base_l in ["restroom", "bathroom", "toilet", "wc"]:
        en = [f"restroom{num}", f"toilet{num}", f"bathroom{num}", f"wc{num}"]
        ar = [f"حمام{num}".strip(), f"دورة المياه{num}".strip()]
    elif base_l in ["elevator", "lift"]:
        en = [f"elevator{num}", f"lift{num}"]
        ar = [f"مصعد{num}".strip(), "اسانسير" + (str(number) if number else "")]
    elif base_l in ["phone booth", "booth", "phone"]:
        en = [f"phone booth{num}", f"booth{num}", f"phone{num}"]
        ar = [f"فون بوث{num}".strip(), f"بوث{num}".strip()]
    elif base_l in ["quiet room", "quiet", "white room"]:
        en = [f"quiet room{num}", f"quiet{num}"]
        ar = [f"غرفة هادئة{num}".strip(), f"كوايت{num}".strip(), f"وايت روم{num}".strip()]
    elif base_l in ["board room", "board"]:
        en = [f"board room{num}", f"board{num}"]
        ar = [f"بورد روم{num}".strip()]
    elif base_l in ["control room", "control"]:
        en = [f"control room{num}", f"control{num}"]
        ar = [f"غرفة التحكم{num}".strip(), f"كنترول روم{num}".strip()]
    elif base_l in ["theatre", "theater"]:
        en = ["theatre"]; ar = ["مسرح"]
    elif base_l in ["studio"]:
        en = ["studio"]; ar = ["استوديو"]
    elif base_l in ["reception", "reception / cafe", "cafe", "coffee"]:
        en = ["reception", "cafe"]; ar = ["ريسبشن", "كوفي"]
    else:
        en = [base_l + num]; ar = []

    for a in en: out.append((a, "en"))
    for a in ar: out.append((a, "ar"))
    return out

class SeedOne(BaseModel):
    poi_id: int
    base: str
    number: Optional[int] = None

class SeedBulk(BaseModel):
    items: List[SeedOne]

@router.post("/seed_aliases_manual")
def seed_aliases_manual(req: SeedOne):
    try:
        _ensure_table()
        variants = _alias_variants(req.base, req.number)
        if not variants:
            raise HTTPException(status_code=400, detail="No variants generated")
        with _conn() as conn, conn.cursor() as cur:
            for alias_text, lang in variants:
                if not alias_text:
                    continue
                cur.execute(
                    "INSERT INTO poi_aliases (poi_id, alias_text, lang) VALUES (%s, %s, %s)",
                    (req.poi_id, alias_text, lang),
                )
            conn.commit()
        return {"ok": True, "poi_id": req.poi_id, "inserted": len(variants)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"seed_aliases_manual error: {e}")

@router.post("/seed_aliases_bulk")
def seed_aliases_bulk(req: SeedBulk):
    try:
        _ensure_table()
        total = 0
        with _conn() as conn, conn.cursor() as cur:
            for item in req.items:
                variants = _alias_variants(item.base, item.number)
                for alias_text, lang in variants:
                    if not alias_text:
                        continue
                    cur.execute(
                        "INSERT INTO poi_aliases (poi_id, alias_text, lang) VALUES (%s, %s, %s)",
                        (item.poi_id, alias_text, lang),
                    )
                    total += 1
            conn.commit()
        return {"ok": True, "inserted": total}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"seed_aliases_bulk error: {e}")

# ---------- READ/DEBUG ----------
@router.get("/list_aliases")
def list_aliases(poi_id: Optional[int] = None, contains: Optional[str] = None):
    """
    Inspect what's stored. Example:
      /api/debug/list_aliases?poi_id=12
      /api/debug/list_aliases?contains=تحكم
    """
    try:
        with _conn() as conn, conn.cursor() as cur:
            if poi_id is not None:
                cur.execute(
                    "SELECT poi_id, alias_text, lang FROM poi_aliases WHERE poi_id=%s ORDER BY alias_text",
                    (poi_id,),
                )
            elif contains:
                like = f"%{contains}%"
                cur.execute(
                    "SELECT poi_id, alias_text, lang FROM poi_aliases WHERE alias_text ILIKE %s ORDER BY poi_id, alias_text",
                    (like,),
                )
            else:
                cur.execute(
                    "SELECT poi_id, alias_text, lang FROM poi_aliases ORDER BY poi_id, alias_text LIMIT 200"
                )
            rows = cur.fetchall()
        return {"aliases": [{"poi_id": r[0], "alias": r[1], "lang": r[2]} for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"list_aliases error: {e}")

@router.get("/alias_stats")
def alias_stats():
    try:
        with _conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM poi_aliases")
            total = cur.fetchone()[0]
            cur.execute("SELECT poi_id, COUNT(*) FROM poi_aliases GROUP BY poi_id ORDER BY 1")
            by_poi = cur.fetchall()
        return {
            "total_aliases": int(total),
            "by_poi": [{"poi_id": r[0], "count": r[1]} for r in by_poi]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"alias_stats error: {e}")
