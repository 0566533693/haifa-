# backend/api/route.py
"""
A* Pathfinding for Indoor Navigation

Uses the nav_nodes and nav_edges tables to compute optimal paths
between POIs through the navigation graph.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import math
import heapq
from typing import Dict, List, Tuple, Optional
import psycopg
from app.database import get_connection

router = APIRouter(prefix="/api/path", tags=["route"])


class RouteRequest(BaseModel):
    fromPoiId: int
    toPoiId: int


def _conn():
    """Get database connection from centralized module."""
    return get_connection()


# ============================================================================
# Database Queries
# ============================================================================

def _get_poi_info(poi_id: int) -> Tuple[float, float, float, Optional[int]]:
    """Get POI coordinates and nearest navigation node."""
    with _conn() as conn, conn.cursor() as cur:
        # First try ar_pois_api for coordinates
        cur.execute(
            "SELECT x, y, z FROM ar_pois_api WHERE poi_id = %s",
            (poi_id,)
        )
        coords = cur.fetchone()

        if not coords:
            raise HTTPException(
                status_code=404,
                detail=f"POI {poi_id} not found in ar_pois_api"
            )

        # Get nearest_node from pois table
        cur.execute(
            "SELECT nearest_node FROM pois WHERE poi_id = %s",
            (poi_id,)
        )
        node_row = cur.fetchone()
        nearest_node = node_row[0] if node_row else None

        return float(coords[0]), float(coords[1]), float(coords[2]), nearest_node


def _load_nav_graph() -> Tuple[Dict[int, Tuple[float, float, float]], Dict[int, List[Tuple[int, float]]]]:
    """
    Load the navigation graph from database.

    Returns:
        nodes: {node_id: (x, y, z)}
        edges: {node_id: [(neighbor_id, cost), ...]}
    """
    nodes: Dict[int, Tuple[float, float, float]] = {}
    edges: Dict[int, List[Tuple[int, float]]] = {}

    with _conn() as conn, conn.cursor() as cur:
        # Load all nodes
        cur.execute("SELECT node_id, x, y, z FROM nav_nodes")
        for row in cur.fetchall():
            node_id, x, y, z = row
            nodes[node_id] = (float(x), float(y), float(z))
            edges[node_id] = []

        # Load all edges (bidirectional)
        cur.execute("SELECT a, b, cost FROM nav_edges")
        for row in cur.fetchall():
            a, b, cost = row
            cost = float(cost)
            if a in edges:
                edges[a].append((b, cost))
            if b in edges:
                edges[b].append((a, cost))

    return nodes, edges


def _find_nearest_node(
    x: float, y: float, z: float,
    nodes: Dict[int, Tuple[float, float, float]]
) -> int:
    """Find the nearest navigation node to a given point."""
    min_dist = float('inf')
    nearest = None

    for node_id, (nx, ny, nz) in nodes.items():
        dist = math.sqrt((x - nx)**2 + (y - ny)**2 + (z - nz)**2)
        if dist < min_dist:
            min_dist = dist
            nearest = node_id

    if nearest is None:
        raise HTTPException(status_code=500, detail="No navigation nodes found")

    return nearest


# ============================================================================
# A* Algorithm
# ============================================================================

def _heuristic(node_id: int, goal_id: int, nodes: Dict[int, Tuple[float, float, float]]) -> float:
    """Euclidean distance heuristic for A*."""
    if node_id not in nodes or goal_id not in nodes:
        return float('inf')

    x1, y1, z1 = nodes[node_id]
    x2, y2, z2 = nodes[goal_id]
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)


def _astar(
    start_node: int,
    goal_node: int,
    nodes: Dict[int, Tuple[float, float, float]],
    edges: Dict[int, List[Tuple[int, float]]]
) -> Tuple[List[int], float]:
    """
    A* pathfinding algorithm.

    Args:
        start_node: Starting node ID
        goal_node: Goal node ID
        nodes: Node positions {id: (x, y, z)}
        edges: Adjacency list {id: [(neighbor, cost), ...]}

    Returns:
        path: List of node IDs from start to goal
        total_cost: Total path cost in meters
    """
    if start_node == goal_node:
        return [start_node], 0.0

    # Priority queue: (f_score, counter, node_id)
    # Counter is used to break ties and ensure FIFO ordering
    counter = 0
    open_set = [(0.0, counter, start_node)]

    # Track where we came from for path reconstruction
    came_from: Dict[int, int] = {}

    # g_score: cost from start to node
    g_score: Dict[int, float] = {start_node: 0.0}

    # f_score: g_score + heuristic
    f_score: Dict[int, float] = {start_node: _heuristic(start_node, goal_node, nodes)}

    # Set of visited nodes
    closed_set = set()

    while open_set:
        _, _, current = heapq.heappop(open_set)

        if current == goal_node:
            # Reconstruct path
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path, g_score[goal_node]

        if current in closed_set:
            continue
        closed_set.add(current)

        # Explore neighbors
        for neighbor, cost in edges.get(current, []):
            if neighbor in closed_set:
                continue

            tentative_g = g_score[current] + cost

            if neighbor not in g_score or tentative_g < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f = tentative_g + _heuristic(neighbor, goal_node, nodes)
                f_score[neighbor] = f
                counter += 1
                heapq.heappush(open_set, (f, counter, neighbor))

    # No path found
    raise HTTPException(
        status_code=404,
        detail=f"No path found from node {start_node} to node {goal_node}"
    )


# ============================================================================
# Path Simplification (Douglas-Peucker)
# ============================================================================

def _perpendicular_distance(
    point: Tuple[float, float, float],
    line_start: Tuple[float, float, float],
    line_end: Tuple[float, float, float]
) -> float:
    """Calculate perpendicular distance from point to line segment."""
    x, y, z = point
    x1, y1, z1 = line_start
    x2, y2, z2 = line_end

    # Line vector
    dx = x2 - x1
    dy = y2 - y1
    dz = z2 - z1

    line_len_sq = dx*dx + dy*dy + dz*dz

    if line_len_sq == 0:
        # Start and end are the same point
        return math.sqrt((x - x1)**2 + (y - y1)**2 + (z - z1)**2)

    # Project point onto line
    t = max(0, min(1, ((x - x1)*dx + (y - y1)*dy + (z - z1)*dz) / line_len_sq))

    proj_x = x1 + t * dx
    proj_y = y1 + t * dy
    proj_z = z1 + t * dz

    return math.sqrt((x - proj_x)**2 + (y - proj_y)**2 + (z - proj_z)**2)


def _simplify_path(
    points: List[Tuple[float, float, float]],
    epsilon: float = 0.5
) -> List[Tuple[float, float, float]]:
    """
    Douglas-Peucker path simplification algorithm.
    Removes points that don't contribute significantly to the path shape.

    Args:
        points: List of (x, y, z) coordinates
        epsilon: Maximum distance threshold (in meters)

    Returns:
        Simplified list of points
    """
    if len(points) <= 2:
        return points

    # Find the point with maximum distance from the line
    max_dist = 0
    max_idx = 0

    for i in range(1, len(points) - 1):
        dist = _perpendicular_distance(points[i], points[0], points[-1])
        if dist > max_dist:
            max_dist = dist
            max_idx = i

    # If max distance exceeds epsilon, recursively simplify
    if max_dist > epsilon:
        left = _simplify_path(points[:max_idx + 1], epsilon)
        right = _simplify_path(points[max_idx:], epsilon)
        return left[:-1] + right
    else:
        # All points between start and end are close to the line
        return [points[0], points[-1]]


# ============================================================================
# API Endpoint
# ============================================================================

@router.post("/route")
def compute_route(req: RouteRequest):
    """
    Compute optimal route between two POIs using A* pathfinding.

    Input:
        { "fromPoiId": 193, "toPoiId": 189 }

    Returns:
        {
            "path": [{"x": ..., "y": ..., "z": ...}, ...],
            "length_m": 45.67,
            "waypoints": 12
        }
    """
    # 1) Get POI coordinates and nearest nodes
    from_x, from_y, from_z, from_node = _get_poi_info(req.fromPoiId)
    to_x, to_y, to_z, to_node = _get_poi_info(req.toPoiId)

    # 2) Load navigation graph
    nodes, edges = _load_nav_graph()

    if not nodes:
        raise HTTPException(status_code=500, detail="Navigation graph is empty")

    # 3) Find nearest nodes if not set in POI
    if from_node is None or from_node not in nodes:
        from_node = _find_nearest_node(from_x, from_y, from_z, nodes)

    if to_node is None or to_node not in nodes:
        to_node = _find_nearest_node(to_x, to_y, to_z, nodes)

    # 4) Run A* pathfinding
    node_path, total_cost = _astar(from_node, to_node, nodes, edges)

    # 5) Convert node IDs to coordinates
    path_points = []

    # Add start POI position
    path_points.append((from_x, from_y, from_z))

    # Add all waypoints from A*
    for node_id in node_path:
        if node_id in nodes:
            path_points.append(nodes[node_id])

    # Add end POI position
    path_points.append((to_x, to_y, to_z))

    # 6) Simplify path to remove redundant points
    simplified = _simplify_path(path_points, epsilon=1.0)

    # 7) Calculate actual path length
    path_length = 0.0
    for i in range(1, len(simplified)):
        x1, y1, z1 = simplified[i - 1]
        x2, y2, z2 = simplified[i]
        path_length += math.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)

    # 8) Format response
    path = [{"x": p[0], "y": p[1], "z": p[2]} for p in simplified]

    return {
        "path": path,
        "length_m": round(path_length, 2),
        "waypoints": len(path)
    }


# ============================================================================
# Debug Endpoint
# ============================================================================

@router.get("/debug/graph-stats")
def get_graph_stats():
    """Get statistics about the navigation graph."""
    nodes, edges = _load_nav_graph()

    total_edges = sum(len(e) for e in edges.values()) // 2  # Bidirectional

    return {
        "nodes": len(nodes),
        "edges": total_edges,
        "avg_connections": round(sum(len(e) for e in edges.values()) / len(nodes), 2) if nodes else 0
    }
