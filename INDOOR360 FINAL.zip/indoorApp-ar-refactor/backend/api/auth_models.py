# backend/api/auth_models.py
from pydantic import BaseModel, EmailStr, Field, validator
from datetime import datetime
from typing import Optional


class SignUpRequest(BaseModel):
    """Request model for user signup"""
    name: str = Field(..., min_length=2, description="User's full name")
    email: EmailStr = Field(..., description="User's email address")
    password: str = Field(..., min_length=8, max_length=72, description="User's password (8-72 characters)")

    @validator('name')
    def name_must_not_be_empty(cls, v):
        if not v or not v.strip():
            raise ValueError('Name cannot be empty')
        return v.strip()

    @validator('email')
    def email_must_be_lowercase(cls, v):
        return v.lower()

    @validator('password')
    def password_length_check(cls, v):
        if len(v.encode('utf-8')) > 72:
            raise ValueError('Password cannot be longer than 72 bytes')
        return v


class LoginRequest(BaseModel):
    """Request model for user login"""
    email: EmailStr = Field(..., description="User's email address")
    password: str = Field(..., description="User's password")


class ChangePasswordRequest(BaseModel):
    """Request model for changing password"""
    current_password: str = Field(..., description="Current password")
    new_password: str = Field(..., min_length=8, max_length=72, description="New password (8-72 characters)")

    @validator('new_password')
    def validate_password_bytes(cls, v):
        """Ensure password doesn't exceed bcrypt's 72-byte limit when UTF-8 encoded"""
        if len(v.encode('utf-8')) > 72:
            raise ValueError('Password must not exceed 72 bytes when UTF-8 encoded')
        return v


class UpdateProfileRequest(BaseModel):
    """Request model for updating user profile"""
    name: Optional[str] = Field(None, min_length=2, description="User's full name")
    phone: Optional[str] = Field(None, max_length=20, description="Phone number")
    date_of_birth: Optional[str] = Field(None, description="Date of birth (YYYY-MM-DD)")

    @validator('name')
    def name_must_not_be_empty(cls, v):
        if v is not None and (not v or not v.strip()):
            raise ValueError('Name cannot be empty')
        return v.strip() if v else v

    @validator('phone')
    def phone_validation(cls, v):
        if v is not None and v.strip() == '':
            return None
        return v

    @validator('date_of_birth')
    def validate_date_format(cls, v):
        if v is not None:
            try:
                from datetime import datetime
                datetime.strptime(v, '%Y-%m-%d')
            except ValueError:
                raise ValueError('Date of birth must be in YYYY-MM-DD format')
        return v


class UserResponse(BaseModel):
    """Response model for user data"""
    user_id: int
    name: str
    email: str
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    role: Optional[str] = "user"
    created_at: datetime

    class Config:
        from_attributes = True  # Pydantic v2 (was orm_mode in v1)


class AuthResponse(BaseModel):
    """Response model for authentication (signup/login)"""
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class ErrorResponse(BaseModel):
    """Error response model"""
    detail: str
    error_code: Optional[str] = None
