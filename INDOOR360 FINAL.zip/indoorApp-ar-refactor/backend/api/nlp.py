# backend/api/nlp.py

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
from app.database import get_connection_v2

router = APIRouter()

# ---------- Pydantic models ----------

class NLPMatchOut(BaseModel):
    poiId: int
    poiName: str
    floor: int
    confidence: float
    buildingId: int
    floorId: int


class NLPResolveRequest(BaseModel):
    query: str


# ---------- DB helper ----------

def get_db():
    """Get database connection from centralized module."""
    return get_connection_v2()


# ---------- Healthcheck ----------

@router.get("/api/nlp/healthz")
def nlp_healthz():
    return {"ok": True}


# ---------- Resolve endpoint ----------

@router.post("/api/nlp/resolve", response_model=List[NLPMatchOut])
def resolve_nlp(req: NLPResolveRequest):
    text = req.query.strip()
    if not text:
        return []

    try:
        conn = get_db()
        cur = conn.cursor()

        # 1) Try synonym match
               # 1) Try synonym match
        cur.execute(
            """
            SELECT
                n.poi_id,
                n.name AS poi_name,
                COALESCE(
                    CASE
                        WHEN p.floor ~ '^[0-9]+$' THEN p.floor::int
                        ELSE 0
                    END,
                    0
                ) AS floor,
                1.0 AS score
            FROM poi_synonyms s
            JOIN poi_names n ON n.poi_id = s.poi_id
            JOIN ar_pois_api p ON p.poi_id = n.poi_id
            WHERE LOWER(s.synonym) = LOWER(%s)
            ORDER BY score DESC
            """,
            (text,)
        )
        rows = cur.fetchall()

        # 2) Fallback: match on poi_names
        if not rows:
            cur.execute(
                """
                SELECT
                    n.poi_id,
                    n.name AS poi_name,
                    COALESCE(
                        CASE
                            WHEN p.floor ~ '^[0-9]+$' THEN p.floor::int
                            ELSE 0
                        END,
                        0
                    ) AS floor,
                    1.0 AS score
                FROM poi_names n
                JOIN ar_pois_api p ON p.poi_id = n.poi_id
                WHERE LOWER(n.name) = LOWER(%s)
                ORDER BY score DESC
                """,
                (text,)
            )
            rows = cur.fetchall()



        # 2) Fallback: match on poi_names
        if not rows:
            cur.execute(
                """
                SELECT
                    n.poi_id,
                    n.name AS poi_name,
                    COALESCE(NULLIF(p.floor, '')::int, 0) AS floor,
                    1.0 AS score
                FROM poi_names n
                JOIN ar_pois_api p ON p.poi_id = n.poi_id
                WHERE LOWER(n.name) = LOWER(%s)
                ORDER BY score DESC
                """,
                (text,)
            )
            rows = cur.fetchall()

        cur.close()
        conn.close()

    except psycopg2.Error as e:
        # This prints the REAL DB error in your terminal
        print(" NLP DB error:", e)
        try:
            conn.rollback()
            conn.close()
        except Exception:
            pass
        raise HTTPException(status_code=500, detail="Database error in NLP resolve")



    # Remove duplicate poiIds (fixes the Swift warning about duplicates)
    results: list[NLPMatchOut] = []
    seen_ids: set[int] = set()

    for poi_id, poi_name, floor, score in rows:
        if poi_id in seen_ids:
            continue
        seen_ids.add(poi_id)

        floor_int = int(floor or 0)

        # For now we only have one building; front-end requires these keys
        building_id = 1
        floor_id = floor_int

        results.append(
            NLPMatchOut(
                poiId=int(poi_id),
                poiName=poi_name,
                floor=floor_int,
                confidence=float(score),
                buildingId=building_id,
                floorId=floor_id,
            )
        )

    return results
