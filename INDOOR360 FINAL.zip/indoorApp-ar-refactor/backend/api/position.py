# backend/api/position.py
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
import psycopg, time, math, asyncio, json
from typing import Optional
from app.database import get_connection

router = APIRouter(prefix="/api/position", tags=["position"])

# ---------- DB helpers ----------
def _conn():
    """Get database connection from centralized module."""
    return get_connection()

def _any_floor():
    with _conn() as conn, conn.cursor() as cur:
        cur.execute("SELECT floor FROM ar_pois_api WHERE floor IS NOT NULL LIMIT 1;")
        r = cur.fetchone()
        return r[0] if r else None

def _poi_xyz_floor(poi_id: int):
    with _conn() as conn, conn.cursor() as cur:
        cur.execute("""
            SELECT x, y, z, floor
            FROM ar_pois_api
            WHERE poi_id = %s
        """, (poi_id,))
        r = cur.fetchone()
        if not r:
            raise HTTPException(status_code=404, detail=f"POI {poi_id} not found")
        return float(r[0]), float(r[1]), float(r[2]), r[3]

# ---------- Current-position (REST) ----------
@router.get("/current_position")
def current_position():
    """
    Simple deterministic stub so front-end has a shape to consume.
    """
    ts = int(time.time())
    yaw = (ts % 360) * math.pi / 180.0
    return {
        "x": 0.5, "y": 1.2, "z": 0.0,
        "yaw": round(yaw, 3),
        "floor": _any_floor(),
        "ts": ts
    }

# ---------- Optional: set target so WS yaw points to it ----------
class TargetReq(BaseModel):
    poi_id: int

TARGET: Optional[int] = None

@router.post("/set_target")
def set_target(req: TargetReq):
    global TARGET
    # Validate it exists (throws 404 if not)
    _poi_xyz_floor(req.poi_id)
    TARGET = req.poi_id
    return {"ok": True, "target_poi_id": TARGET}

# ---------- WebSocket live stream ----------
@router.websocket("/ws")
async def ws_position(ws: WebSocket):
    """
    Sends {"x","y","z","yaw","floor","ts"} ~1 Hz.
    If /set_target was called, yaw points toward that POI (same floor only).
    We simulate a tiny walk forward to prove live updates.
    """
    await ws.accept()

    # per-connection state
    floor_key = _any_floor()
    x, y, z = 0.5, 1.2, 0.0
    yaw = 0.0

    try:
        while True:
            ts = int(time.time())

            # tiny forward motion (0.15 m/s) to show change
            step = 0.15
            x += step * math.cos(yaw)
            y += step * math.sin(yaw)

            # if a target is set and on same floor, face it
            try:
                if TARGET is not None:
                    tx, ty, tz, tfloor = _poi_xyz_floor(TARGET)
                    if tfloor == floor_key:
                        yaw = math.atan2(ty - y, tx - x)
            except Exception:
                # ignore target errors; keep streaming
                pass

            payload = {
                "x": round(x, 3), "y": round(y, 3), "z": round(z, 3),
                "yaw": round(yaw, 3),
                "floor": floor_key,
                "ts": ts
            }
            await ws.send_text(json.dumps(payload))
            await asyncio.sleep(1.0)

    except WebSocketDisconnect:
        # client closed — just exit
        return
