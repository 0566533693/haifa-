-- QR Anchors table for QR code-based indoor positioning
-- Each QR code maps to a known POI location

CREATE TABLE IF NOT EXISTS qr_anchors (
    qr_id SERIAL PRIMARY KEY,
    qr_code VARCHAR(100) UNIQUE NOT NULL,
    poi_id INT REFERENCES pois(poi_id) ON DELETE SET NULL,
    location_name VARCHAR(255) NOT NULL,
    floor_level INT NOT NULL,
    -- Store explicit coordinates so QR works even without POI linkage
    x DOUBLE PRECISION DEFAULT 0,
    y DOUBLE PRECISION DEFAULT 0,
    z DOUBLE PRECISION DEFAULT 0,
    description TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Index for fast QR code lookups
CREATE INDEX IF NOT EXISTS idx_qr_anchors_qr_code ON qr_anchors(qr_code);
CREATE INDEX IF NOT EXISTS idx_qr_anchors_floor ON qr_anchors(floor_level);
CREATE INDEX IF NOT EXISTS idx_qr_anchors_active ON qr_anchors(active) WHERE active = TRUE;

-- Sample demo data - coordinates match common indoor locations
-- poi_id can be NULL if not linked to a specific POI
INSERT INTO qr_anchors (qr_code, poi_id, location_name, floor_level, x, y, z, description) VALUES
    -- Floor 1 anchors (using explicit coordinates)
    ('anchor:main-entrance', NULL, 'Main Entrance', 1, 0.0, 0.0, 0.0, 'Primary building entrance with reception'),
    ('anchor:reception', NULL, 'Reception Desk', 1, 5.0, 3.0, 0.0, 'Main reception and information desk'),
    ('anchor:elevator-f1', NULL, 'Elevator Floor 1', 1, 10.0, 15.0, 0.0, 'Main elevator bank ground floor'),
    ('anchor:stairs-f1', NULL, 'Stairwell Floor 1', 1, 12.0, 15.0, 0.0, 'Main stairwell ground floor entrance'),
    ('anchor:cafe-entrance', NULL, 'Cafeteria Entrance', 1, 20.0, 5.0, 0.0, 'Cafeteria main entrance'),

    -- Floor 2 anchors
    ('anchor:elevator-f2', NULL, 'Elevator Floor 2', 2, 10.0, 15.0, 3.0, 'Main elevator bank second floor'),
    ('anchor:stairs-f2', NULL, 'Stairwell Floor 2', 2, 12.0, 15.0, 3.0, 'Main stairwell second floor'),
    ('anchor:meeting-area', NULL, 'Meeting Room Area', 2, 25.0, 10.0, 3.0, 'Conference room corridor entrance'),

    -- Floor 3 anchors
    ('anchor:elevator-f3', NULL, 'Elevator Floor 3', 3, 10.0, 15.0, 6.0, 'Main elevator bank third floor'),
    ('anchor:office-wing', NULL, 'Office Wing', 3, 30.0, 8.0, 6.0, 'Executive office area entrance')
ON CONFLICT (qr_code) DO UPDATE SET
    location_name = EXCLUDED.location_name,
    floor_level = EXCLUDED.floor_level,
    x = EXCLUDED.x,
    y = EXCLUDED.y,
    z = EXCLUDED.z,
    description = EXCLUDED.description,
    updated_at = NOW();

-- Function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_qr_anchors_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-update timestamp
DROP TRIGGER IF EXISTS qr_anchors_updated_at_trigger ON qr_anchors;
CREATE TRIGGER qr_anchors_updated_at_trigger
    BEFORE UPDATE ON qr_anchors
    FOR EACH ROW
    EXECUTE FUNCTION update_qr_anchors_updated_at();
