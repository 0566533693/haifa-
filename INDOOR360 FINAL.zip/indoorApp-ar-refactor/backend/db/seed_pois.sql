INSERT INTO pois (name, category, floor, x, y, z)
VALUES
('Meeting Room A3','room',3,12.4,8.2,0.0),
('Reception','service',3,2.0,1.5,0.0)
ON CONFLICT DO NOTHING;
