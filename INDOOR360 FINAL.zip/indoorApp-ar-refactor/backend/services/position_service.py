def get_current_position():
    # Phase 1: fixed. Phase 3: replace with live estimate or DB/IMU/Wi-Fi fusion.
    return {"x": 0.5, "y": 1.2, "z": 0.0, "floor": 3, "orientation_rad": 1.57, "ts": 1730611200}
