import math

def straight_line(origin, target):
    # Accept origin/target as {"x":..,"y":..,"z":..} for Phase 1
    ox, oy, oz = (origin or {}).get("x", 0.5), (origin or {}).get("y", 1.2), (origin or {}).get("z", 0.0)
    if target and "x" in target:
        tx, ty, tz = target["x"], target["y"], target.get("z", 0.0)
    else:
        # If only poi_id provided in Phase 1, hardcode to match /poi/list id 101
        tx, ty, tz = 12.4, 8.2, 0.0

    path = [
        {"x": ox, "y": oy, "z": oz},
        {"x": (ox + tx) / 2.0, "y": (oy + ty) / 2.0, "z": (oz + tz) / 2.0},
        {"x": tx, "y": ty, "z": tz}
    ]
    length = math.dist((ox, oy, oz), (tx, ty, tz))
    return path, round(length, 2)
