# fastapi_app.py

import psycopg2
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List

from NLP import nlp_db_resolver   # import the module, not individual functions
from app.config import settings


app = FastAPI(
    title="Indoor360 Backend",
    version="1.0.0",
)


# =======================
#  MODELS FOR NLP ROUTES
# =======================

class Query(BaseModel):
    """Legacy request model: { "text": "meeting room 3" }"""
    text: str


class NLPRequest(BaseModel):
    """New request model used by the iOS app: { "query": "meeting room 3" }"""
    query: str


class NLPMatch(BaseModel):
    """
    Response item that iOS decodes.
    """
    poiId: int
    poiName: str
    buildingId: int
    floorId: int
    confidence: float


# =======================
#   LEGACY NLP ENDPOINT
# =======================

@app.post("/v1/nlp/resolve")
def resolve_legacy(q: Query):
    """
    Debug endpoint.
    Returns raw rows from resolve_poi_from_text().
    """
    try:
        rows = nlp_db_resolver.resolve_poi_from_text(q.text)
    except Exception as e:
        print("❌ /v1/nlp/resolve error:", e)
        raise HTTPException(status_code=500, detail="NLP legacy resolve failed")

    return {
        "query": q.text,
        "matches": rows,
    }


# =======================
#   MAIN iOS NLP ENDPOINT
# =======================

# =======================
#   MAIN iOS NLP ENDPOINT
# =======================

@app.post("/api/nlp/resolve", response_model=List[NLPMatch])
def nlp_resolve(req: NLPRequest):
    """
    Input:
        { "query": "meeting room 3" }

    Output:
        [
          {
            "poiId": 731,
            "poiName": "Meeting Room 3",
            "buildingId": 0,
            "floorId": 3,
            "confidence": 1.0
          }
        ]
    """
    try:
        matches = nlp_db_resolver.resolve_text_to_pois(req.query)
        return matches
    except Exception as e:
        print("❌ /api/nlp/resolve error:", repr(e))
        raise HTTPException(
            status_code=500,
            detail=f"NLP resolve failed: {e!r}",
        )

class RouteRequest(BaseModel):
    """
    Accept BOTH:
      { "from_poi_id": 1, "to_poi_id": 688 }   (snake_case)
    AND
      { "fromPoiId": 1, "toPoiId": 688 }       (camelCase from iOS)
    """
    from_poi_id: int = Field(..., alias="fromPoiId")
    to_poi_id: int = Field(..., alias="toPoiId")

    class Config:
        allow_population_by_field_name = True   # allow from_poi_id or fromPoiId


class RouteSegment(BaseModel):
    # extremely simplified: list of [x, y] points; adjust later if you have 3D
    points: List[List[float]]


class RouteResponse(BaseModel):
    path: List[RouteSegment]
    lengthM: float
    durationS: float


# =======================
#   ROUTE ENDPOINT
# =======================

@app.post("/api/path/route", response_model=RouteResponse)
def api_route(req: RouteRequest):
    """
    Very simple DB-based route:
    - right now it just returns a dummy straight line between two POIs
    - later you can replace with your real A* / routes table
    """

    from_id = req.from_poi_id
    to_id = req.to_poi_id

    try:
        conn = get_db_conn()
        cur = conn.cursor()

        # 1) Get coordinates for both POIs (mock: we just get any centroid columns you have)
        #    If you don't have geom_x / geom_y, adjust to your schema.
        cur.execute(
            """
            SELECT poi_id, ST_X(geom), ST_Y(geom)
            FROM pois
            WHERE poi_id IN (%s, %s)
            ORDER BY poi_id;
            """,
            (from_id, to_id),
        )
        rows = cur.fetchall()

        if len(rows) != 2:
            raise HTTPException(
                status_code=404,
                detail=f"Could not find both POIs {from_id} and {to_id}",
            )

        # naive: rows[0] is from, rows[1] is to (because of ORDER BY poi_id)
        (_, x1, y1), (_, x2, y2) = rows

        # 2) Build a single straight-line segment
        seg = RouteSegment(points=[[x1, y1], [x2, y2]])

        # fake distance in meters (Euclidean in local coords)
        dist = ((x2 - x1)**2 + (y2 - y1)**2) ** 0.5
        duration = dist / 1.2 if dist > 0 else 0.0  # pretend: 1.2 m/s walking

        return RouteResponse(
            path=[seg],
            lengthM=dist,
            durationS=duration,
        )

    except HTTPException:
        raise
    except Exception as e:
        print("❌ /api/path/route error:", e)
        raise HTTPException(status_code=500, detail=f"Route failed: {e}")
    finally:
        try:
            cur.close()
            conn.close()
        except Exception:
            pass



# =======================
#  HEALTH CHECK
# =======================
# =======================
#  NLP HEALTH ENDPOINTS
# =======================

# Simple global health
@app.get("/healthz")
def health_check_root():
    return {"ok": True}

# NLP health for iOS (THIS is what the app calls)
@app.get("/api/nlp/healthz")
def health_check_nlp():
    return {"ok": True}