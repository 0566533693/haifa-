-- =====================================================
-- INDOOR360 – FINAL DB SCHEMA (SUBMISSION VERSION)
-- Core schema + IMDF + NLP synonyms
-- Haifa – Backend / NLP & Data layer
-- =====================================================


-- =====================================================
-- 0) EXTENSIONS
-- =====================================================

-- Enable PostGIS extension for spatial data
CREATE EXTENSION IF NOT EXISTS postgis;


-- =====================================================
-- 1) USERS, AUTH, SESSIONS
-- =====================================================

CREATE TABLE IF NOT EXISTS Users (
    user_id       SERIAL PRIMARY KEY,
    name          VARCHAR(100),
    email         VARCHAR(150) UNIQUE,
    phone         VARCHAR(20),
    password_hash TEXT,
    auth_provider VARCHAR(50), -- email, google, facebook, guest
    role          VARCHAR(50),
    created_at    TIMESTAMP DEFAULT NOW(),
    updated_at    TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS OTP_Tokens (
    otp_id     SERIAL PRIMARY KEY,
    user_id    INT REFERENCES Users(user_id) ON DELETE CASCADE,
    otp_code   VARCHAR(10),
    expires_at TIMESTAMP,
    is_used    BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS Sessions (
    session_id  SERIAL PRIMARY KEY,
    user_id     INT REFERENCES Users(user_id) ON DELETE CASCADE,
    jwt_token   TEXT,
    device_info TEXT,
    started_at  TIMESTAMP DEFAULT NOW(),
    ended_at    TIMESTAMP
);


-- =====================================================
-- 2) BUILDINGS & FLOORS & BLUEPRINTS
-- =====================================================

CREATE TABLE IF NOT EXISTS Buildings (
    building_id SERIAL PRIMARY KEY,
    name        VARCHAR(150),
    address     TEXT,
    description TEXT
);

CREATE TABLE IF NOT EXISTS Floors (
    floor_id      SERIAL PRIMARY KEY,
    building_id   INT REFERENCES Buildings(building_id) ON DELETE CASCADE,
    floor_number  INT,
    name          VARCHAR(100),
    blueprint_file TEXT,
    version       VARCHAR(50),
    uploaded_by   INT REFERENCES Users(user_id),
    uploaded_at   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Blueprint_Files (
    file_id        SERIAL PRIMARY KEY,
    floor_id       INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    file_path      TEXT,
    version_number VARCHAR(50),
    uploaded_by    INT REFERENCES Users(user_id),
    timestamp      TIMESTAMP DEFAULT NOW()
);


-- =====================================================
-- 3) POINTS OF INTEREST (POIs) & METADATA (GENERIC MODEL)
--    Note: For the live PwC demo we also use IMDF-based
--    tables (pois, poi_names, ar_pois_api) in a separate
--    script. This section is the generic Indoor360 model.
-- =====================================================

CREATE TABLE IF NOT EXISTS POIs (
    poi_id              SERIAL PRIMARY KEY,
    floor_id            INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    name                VARCHAR(150),
    type                VARCHAR(50), -- restroom, shop, exit, etc.
    coordinates         GEOGRAPHY(POINT, 4326), -- PostGIS point
    description         TEXT,
    accessible_features TEXT
);

CREATE TABLE IF NOT EXISTS POI_Metadata (
    metadata_id SERIAL PRIMARY KEY,
    poi_id      INT REFERENCES POIs(poi_id) ON DELETE CASCADE,
    language    VARCHAR(10),
    label       VARCHAR(150),
    description TEXT,
    offers      TEXT
);

-- Stable external_id for NLP / IMDF mapping (optional)
ALTER TABLE POIs
  ADD COLUMN IF NOT EXISTS external_id TEXT UNIQUE;


-- =====================================================
-- 4) NAVIGATION & ROUTES & ANCHORS & HISTORY & ERRORS
-- =====================================================

CREATE TABLE IF NOT EXISTS Routes (
    route_id        SERIAL PRIMARY KEY,
    start_poi       INT REFERENCES POIs(poi_id),
    end_poi         INT REFERENCES POIs(poi_id),
    path_geometry   GEOGRAPHY(LINESTRING, 4326),
    distance_meters FLOAT,
    estimated_time  INT
);

CREATE TABLE IF NOT EXISTS Anchors (
    anchor_id   SERIAL PRIMARY KEY,
    floor_id    INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    coordinates GEOGRAPHY(POINT, 4326),
    anchor_type VARCHAR(50),
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Navigation_History (
    history_id SERIAL PRIMARY KEY,
    user_id    INT REFERENCES Users(user_id),
    route_id   INT REFERENCES Routes(route_id),
    start_time TIMESTAMP DEFAULT NOW(),
    end_time   TIMESTAMP
);

CREATE TABLE IF NOT EXISTS Error_Reports (
    error_id   SERIAL PRIMARY KEY,
    user_id    INT REFERENCES Users(user_id),
    error_type VARCHAR(100),
    description TEXT,
    timestamp  TIMESTAMP DEFAULT NOW()
);


-- =====================================================
-- 5) WIFI HEATMAP & SENSOR DATA
-- =====================================================

CREATE TABLE IF NOT EXISTS Access_Points (
    ap_id      SERIAL PRIMARY KEY,
    building_id INT REFERENCES Buildings(building_id) ON DELETE CASCADE,
    ssid       VARCHAR(100),
    mac_address VARCHAR(50) UNIQUE,
    location   GEOGRAPHY(POINT, 4326)
);

CREATE TABLE IF NOT EXISTS Heatmap_Readings (
    reading_id  SERIAL PRIMARY KEY,
    floor_id    INT REFERENCES Floors(floor_id) ON DELETE CASCADE,
    ap_id       INT REFERENCES Access_Points(ap_id) ON DELETE CASCADE,
    coordinates GEOGRAPHY(POINT, 4326),
    rssi_value  INT,
    timestamp   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Sensor_Data (
    sensor_id SERIAL PRIMARY KEY,
    user_id   INT REFERENCES Users(user_id) ON DELETE CASCADE,
    type      VARCHAR(50), -- IMU, BLE, Wi-Fi
    reading   JSONB,
    timestamp TIMESTAMP DEFAULT NOW()
);


-- =====================================================
-- 6) ADMIN & ACCESS CONTROL
-- =====================================================

CREATE TABLE IF NOT EXISTS Roles (
    role_id     SERIAL PRIMARY KEY,
    role_name   VARCHAR(50) UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS User_Roles (
    user_role_id SERIAL PRIMARY KEY,
    user_id      INT REFERENCES Users(user_id) ON DELETE CASCADE,
    role_id      INT REFERENCES Roles(role_id) ON DELETE CASCADE,
    assigned_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Audit_Logs (
    log_id   SERIAL PRIMARY KEY,
    user_id  INT REFERENCES Users(user_id),
    action   VARCHAR(150),
    details  TEXT,
    timestamp TIMESTAMP DEFAULT NOW()
);


-- =====================================================
-- 7) IMDF PACKAGES & RAW JSON FILES
-- =====================================================

CREATE TABLE IF NOT EXISTS imdf_packages (
    package_id  SERIAL PRIMARY KEY,
    name        TEXT,   -- e.g., "PwC Campus July 2025"
    version     TEXT,
    uploaded_by INT REFERENCES Users(user_id),
    uploaded_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS imdf_files (
    file_id    SERIAL PRIMARY KEY,
    package_id INT REFERENCES imdf_packages(package_id) ON DELETE CASCADE,
    file_name  TEXT,    -- e.g., "unit.geojson"
    data       JSONB,   -- raw GeoJSON
    uploaded_at TIMESTAMP DEFAULT NOW()
);


-- =====================================================
-- 8) (OPTIONAL) IMDF → POIs ENRICHMENT
-- NOTE:
--  - This section assumes you ALSO have an IMDF-based
--    schema with:
--      * pois (lowercase)
--      * poi_names
--    defined in another script.
--  - Use this block when you want to auto-fill names
--    from IMDF unit.geojson.
-- =====================================================

-- (Keep as design reference; comment out if not needed.)

/*
ALTER TABLE pois
  ADD COLUMN IF NOT EXISTS imdf_id TEXT UNIQUE;

CREATE OR REPLACE VIEW v_pois_localized AS
SELECT
  p.id           AS poi_pk,
  p.imdf_id      AS imdf_id,
  p.floor_id     AS floor_id,
  p.category     AS category,
  p.geom         AS coordinates,
  p.description  AS description,
  p.accessible_features,
  MAX(CASE WHEN n.lang_code = 'en' THEN n.name END) AS name_en,
  MAX(CASE WHEN n.lang_code = 'ar' THEN n.name END) AS name_ar
FROM pois p
LEFT JOIN poi_names n ON n.poi_id = p.id
GROUP BY
  p.id, p.imdf_id, p.floor_id, p.category,
  p.geom, p.description, p.accessible_features;

-- Example enrichment from IMDF unit*.geojson into IMDF schema.
WITH u AS (
  SELECT
    (ft->'properties'->>'id')              AS imdf_id,
    NULLIF(ft->'properties'->>'name','')   AS name_en,
    NULLIF(ft->'properties'->>'alt_name','') AS name_ar,
    NULLIF(ft->'properties'->>'category','') AS category
  FROM imdf_files f
  CROSS JOIN LATERAL jsonb_array_elements(f.data->'features') AS ft
  WHERE LOWER(f.file_name) LIKE 'unit%.geojson'
)
UPDATE pois p
SET name     = COALESCE(u.name_en, p.name),
    category = COALESCE(u.category, p.category)
FROM u
WHERE p.imdf_id = u.imdf_id
  AND (u.name_en IS NOT NULL OR u.category IS NOT NULL);
*/


-- =====================================================
-- 9) NLP: POI SYNONYMS TABLE (FINAL VERSION USED IN APP)
-- =====================================================

-- This table is what the FastAPI NLP endpoint uses:
--   poi_synonyms  +  poi_names  +  ar_pois_api
-- to resolve queries like "bathroom", "Meeting Room 3",
-- "اجتماع", "غرفة اتصال", etc.

CREATE TABLE IF NOT EXISTS poi_synonyms (
    id      SERIAL PRIMARY KEY,
    poi_id  INTEGER NOT NULL,
    lang    VARCHAR(10) NOT NULL DEFAULT 'en',
    synonym TEXT NOT NULL
);

-- Core English + Arabic synonym set used in the demo.
-- (These INSERTs seed the NLP experience.)

-- Reception / Cafe
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(693, 'en', 'Reception'),
(693, 'en', 'reception'),
(693, 'en', 'front desk'),
(693, 'en', 'lobby'),
(693, 'en', 'cafe'),
(693, 'en', 'coffee area'),
(693, 'en', 'coffee shop');

-- Theatre
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(687, 'en', 'theatre'),
(687, 'en', 'theater'),
(687, 'en', 'presentation room'),
(687, 'en', 'auditorium'),
(687, 'en', 'main hall');

-- Bathrooms / toilets
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(688, 'en', 'bathroom'),
(688, 'en', 'bathrooms'),
(688, 'en', 'toilet'),
(688, 'en', 'toilets'),
(688, 'en', 'washroom'),
(688, 'en', 'restroom'),
(712, 'en', 'bathroom 2'),
(712, 'en', 'restroom 2'),
(712, 'en', 'toilet 2');

-- Bathrooms in Arabic
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(688, 'ar', 'حمام'),
(688, 'ar', 'حمامات'),
(688, 'ar', 'دورة مياه'),
(712, 'ar', 'حمام'),
(712, 'ar', 'دورة مياه'),
(712, 'ar', 'حمام ٢'),
(712, 'ar', 'دورة المياه ٢');

-- War Rooms
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(723, 'en', 'war room 3'),
(723, 'en', 'war room'),
(724, 'en', 'war room 2'),
(724, 'en', 'war room'),
(725, 'en', 'war room 1'),
(725, 'en', 'war room');

INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(723, 'ar', 'غرفة حرب'),
(724, 'ar', 'غرفة حرب'),
(725, 'ar', 'غرفة حرب');

-- Quiet Rooms
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(703, 'en', 'quiet room 1'),
(703, 'en', 'quiet room'),
(704, 'en', 'quiet room 2'),
(704, 'en', 'quiet room'),
(730, 'en', 'quiet room 3'),
(730, 'en', 'quiet room'),
(733, 'en', 'quiet room 4'),
(733, 'en', 'quiet room');

INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(703, 'ar', 'غرفة هادئة'),
(704, 'ar', 'غرفة هادئة');

-- Phone booths (English)
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(700, 'en', 'phone booth 4'),
(701, 'en', 'phone booth 3'),
(718, 'en', 'phone booth 2'),
(719, 'en', 'phone booth 1'),
(727, 'en', 'phone booth 5'),
(700, 'en', 'phone'),
(701, 'en', 'phone'),
(718, 'en', 'phone'),
(719, 'en', 'phone'),
(727, 'en', 'phone');

-- Phone booths (Arabic "غرفة اتصال")
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(700, 'ar', 'غرفة اتصال'),
(701, 'ar', 'غرفة اتصال'),
(718, 'ar', 'غرفة اتصال'),
(719, 'ar', 'غرفة اتصال'),
(727, 'ar', 'غرفة اتصال');

-- Tech / Emerging Tech Lab, Control Room, Testing Room
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(722, 'en', 'emerging tech lab'),
(722, 'en', 'tech lab'),
(722, 'en', 'tech'),
(722, 'en', 'lab'),
(722, 'en', 'emerging tech'),
(722, 'en', 'technology lab');

INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(721, 'en', 'control room'),
(721, 'en', 'av control'),
(721, 'en', 'control');

INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(720, 'en', 'testing room'),
(720, 'en', 'test room');

-- Elevators (English)
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(104, 'en', 'elevator 3'),
(104, 'en', 'elevator'),
(104, 'en', 'lift'),

(706, 'en', 'elevator 5'),
(706, 'en', 'lift 5'),
(707, 'en', 'elevator 4'),
(707, 'en', 'lift 4'),
(709, 'en', 'elevator 3'),
(709, 'en', 'lift 3'),
(710, 'en', 'elevator 2'),
(710, 'en', 'lift 2'),
(711, 'en', 'elevator 1'),
(711, 'en', 'lift 1');

-- Store / luggage / other rooms
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(713, 'en', 'store room'),
(713, 'en', 'storage room'),
(726, 'en', 'luggage storage'),
(726, 'en', 'bag storage'),
(714, 'en', 'idf room'),
(714, 'en', 'network room'),
(705, 'en', 'production room'),
(705, 'en', 'production'),
(702, 'en', 'raised area'),
(697, 'en', 'difference area');

-- Meeting rooms (generic English + Arabic)
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(728, 'en', 'meeting room'),
(729, 'en', 'meeting room'),
(731, 'en', 'meeting room'),
(732, 'en', 'meeting room'),
(735, 'en', 'meeting room'),
(736, 'en', 'meeting room'),
(737, 'en', 'meeting room'),
(728, 'en', 'meeting'),
(729, 'en', 'meeting'),
(731, 'en', 'meeting'),
(732, 'en', 'meeting'),
(735, 'en', 'meeting'),
(736, 'en', 'meeting'),
(737, 'en', 'meeting'),
(728, 'en', 'meetingroom'),
(729, 'en', 'meetingroom'),
(731, 'en', 'meetingroom'),
(732, 'en', 'meetingroom'),
(735, 'en', 'meetingroom'),
(736, 'en', 'meetingroom'),
(737, 'en', 'meetingroom');

INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(728, 'ar', 'غرفة اجتماعات'),
(729, 'ar', 'غرفة اجتماعات'),
(731, 'ar', 'غرفة اجتماعات'),
(732, 'ar', 'غرفة اجتماعات'),
(735, 'ar', 'غرفة اجتماعات'),
(736, 'ar', 'غرفة اجتماعات'),
(728, 'ar', 'اجتماع'),
(729, 'ar', 'اجتماع'),
(731, 'ar', 'اجتماع'),
(732, 'ar', 'اجتماع'),
(735, 'ar', 'اجتماع'),
(736, 'ar', 'اجتماع');

-- Board room (English)
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(734, 'en', 'boardroom'),
(734, 'en', 'board room'),
(734, 'en', 'meeting room board');

-- Tech lab extra
INSERT INTO poi_synonyms (poi_id, lang, synonym) VALUES
(722, 'en', 'tech lab'),
(722, 'en', 'tech'),
(722, 'en', 'lab'),
(722, 'en', 'emerging tech'),
(722, 'en', 'technology lab');
